******************************************************************************************
* Program: TZA_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Tanzania
******************************************************************************************

use "Data/Tanzania/NPS LSMS 2009/Data/Merged/TZA_Merged",clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=hhid
replace pid=sbmemno
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if  sbq5 == 1 //Reference Person
replace hh_link = 2 if  sbq5 == 2 //Spouse/Husband
replace hh_link = 3 if  sbq5 == 3  |  sbq5 == 4 |  sbq5 == 6 //child, grand child
replace hh_link = 4 if   sbq5 == 7 //Ascendant (parent, grand parent, parent in law)
replace hh_link = 98 if  sbq5 == 9 | sbq5 == 10 //Not related
replace hh_link = 99 if   sbq5 == 5 | sbq5 ==8   //Others 

*-----------------------------------------

* Age
gen age=sbq4

* Gender
replace male=1 if sbq2==1
replace male=0 if sbq2==2

*-----------------------------------------

* Weight
replace wgt=hh_weight												
gen hh_wgt = hh_weight

* Interview dates	
replace refdatex=1
replace refmonth=sa2q18m	
replace refyear=sa2q18y

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if scq4==1
replace educ=0 if scq4==2
gen educlvl=.
replace educlvl=1 if scq7>=41 & scq7<=45 | scq7==34
replace educlvl=0 if scq7<=33 & scq7>=21
replace educlvl=0 if scq7>1 & scq7<=19

gen edu = .
replace edu = 1 if inrange(scq6,11,19) | scq6==1
replace edu = 2 if inrange(scq6,21,34) | scq6==2
replace edu = 3 if inrange(scq6,41,45)
replace edu = 1 if edu == . & seq2==2

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for market section: Age 5 and above */
replace emp=0 if seq3==2 & seq4==2
replace emp=1 if seq3==1
replace emp=2 if seq3==2 & seq4==1

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*Work status
replace emp_wj = 1 if seq9 == 1
	replace emp_wj = 1 if seq9 == . & seq10 == 1
replace emp_se = 1 if  seq22==1 | (seq22 == . & seq23 == 1)
*And see further below!
	
*-----------------------------------------

* Hours by job nature																/* There isn't an unknown or refused to answer category */

* Actual hours worked in wage job last week
replace ahrswk_wj=seq19
replace ahrswk_wj=0 if seq19==. & (emp==0 | emp==2)									/* Replace missing hours with 0 if person is not working */

* Actual hours worked in self-employed non-agri job last week 						/* Unpaid family worker on non-farm HH business */
replace ahrswk_sn=seq45
replace ahrswk_sn=0 if seq45==. & (emp==0 | emp==2)

* Actual hours worked in self-employed agri job last week 							/* Agri activities: livestock, fishing, whether for sale or HH use, collecting firewood and water */
*** DL Edited to make it just seq46 "hours in ag last 7 days"
*** the wood and water are not in other countries
*gen wood= seq47_hr + (seq47_mins/60)												/* No cases where mins is missing and hr is positve, and vice versa*/
*gen water= seq48_hr + (seq48_mins/60)
*egen byte sa=rowtotal(seq46_hr wood water), missing
*replace ahrswk_sa=sa
*replace ahrswk_sa=0 if sa==. & (emp==0 | emp==2)

replace ahrswk_sa=seq46
replace ahrswk_sa=0 if seq46==. & (emp==0 | emp==2)

gen indic_se = 0
replace indic_se = 1 if (ahrswk_sn > 0 & ahrswk_sn != .) | (ahrswk_sa > 0 & ahrswk_sa != .)

replace emp_wj = 1 if emp_wj == . & (ahrswk_wj > 0 & ahrswk_wj != .) &  indic_se == 0
replace emp_se = 1 if emp_se == . & indic_se == 1 & (ahrswk_wj == 0 | ahrswk_wj == .)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .	

*-----------------------------------------

* All jobs

* Actual hours worked in last week
egen all = rowtotal(ahrswk_wj ahrswk_sn ahrswk_sa), missing
replace ahrswk_aj= all


*Wage Job Hours: As far as I can tell, wage job hours are for all jobs. 
*We do not have a main job identifier, cannot select individuals into set 1.
*Since we do not have additional wage job incomes, we cannot select ind. into sets 2 & 3.

*-----------------------------------------

* Commuting and meal hours 															/* Commuting hours are asked for wage jobs only*/
replace mealhrsx=2
replace chrsx=2

local comcon & emp == 1 | emp == 2
replace chrsday=seq15_1*2 if seq15_1>=0 & seq15_1<99 `comcon'								/* Convert from hours and minutes for one way trip to hours only for round trip. Keep as missing if time=99 */
replace chrsday=(seq15_1+(seq15_2/60))*2 if (seq15_1>0 & seq15_1<99) & (seq15_2>0 & seq15_2<99) `comcon'
replace chrsday=(seq15_2/60)*2 if (seq15_1==0 | seq15_1==99) & (seq15_2>=0 & seq15_2<99) `comcon'

replace chrsday=0 if emp == 0										/* Set hour to zero if hour is missing and self reported as not working on any wage job in last 7 days */
replace commuting = 0 if emp == 0
replace commuting = chrsday*7 if emp == 1 | emp == 2
 			
*-----------------------------------------
 

gen ind = .

replace ind = 1 if inrange(sbq10,1,2)
replace ind = 2 if ind==. & seq22==1 & inrange(seq24,5,39)
replace ind = 2 if ind==. & seq22==1 & inrange(seq24,101,107)
replace ind = 3 if ind==. & seq22==1 & inrange(seq24,41,99)
replace ind = 3 if ind==. & seq22==1 & inrange(seq24,447,4923)
replace ind =1 if ind==. & inrange(seq13,1,3)
replace ind =2 if ind==. & inrange(seq13,5,39)
replace ind =2 if ind==. & inrange(seq13,101,107)
replace ind =3 if ind==. & inrange(seq13,41,99)
replace ind =3 if ind==. & inrange(seq13,447,4923)

*-----------------------------------------
*Income: Wage jobs
*-----------------------------------------
*1) Income Wage job (personal level): wage salary questions goes from hourly up to yearly periodicity
gen inc_wj_cash =  seq18_1 
	replace inc_wj_cash = inc_wj_cash* seq19 * 52/12 if seq18_2 == 1			//Hourly-->Weekly --> monthly
	replace inc_wj_cash = . if seq18_2 == 2 // inc_wj_cash*25 if seq18_2 == 2	//Daily, set to missing for now. Need more info.
	replace inc_wj_cash = inc_wj_cash*52/12 if seq18_2 == 3						//Weekly
	replace inc_wj_cash = inc_wj_cash*26/12 if seq18_2 == 4						//byweekly
	replace inc_wj_cash = inc_wj_cash/3 if seq18_2 == 6							//quarter
	replace inc_wj_cash = inc_wj_cash/6 if seq18_2 == 7							//halfyear
	replace inc_wj_cash = inc_wj_cash/12 if seq18_2 == 8						//yearly
		
gen inc_wj_inkind =   seq21_1  
	replace inc_wj_inkind = . if inc_wj_inkind == 99
	replace inc_wj_inkind = inc_wj_inkind* seq19 * 52/12 if seq21_2 == 1		//Hourly-->Weekly -- > monthly
	replace inc_wj_inkind = . if seq21_2 == 2 //inc_wj_inkind*25 if seq21_2 == 2	//Daily
	replace inc_wj_inkind = inc_wj_inkind*52/12 if seq21_2 == 3					//Weekly
	replace inc_wj_inkind = inc_wj_inkind*26/12 if seq21_2 == 4					//byweekly
	replace inc_wj_inkind = inc_wj_inkind/3 if seq21_2 == 6						//quarter
	replace inc_wj_inkind = inc_wj_inkind/6 if seq21_2 == 7						//halfyear
	replace inc_wj_inkind = inc_wj_inkind/12 if seq21_2 == 8					//yearly

*Standard variables
replace inc_wj_mj_c_o = inc_wj_cash
replace inc_wj_mj_ik_o = inc_wj_inkind

egen wj_mjtot = rowtotal(inc_wj_mj_c_o inc_wj_mj_ik_o),m
	replace inc_wj_mj_tot_o = wj_mjtot if    seq9 == 1 //
	replace inc_wj_mj_tot_o = wj_mjtot if inc_wj_mj_tot_o == . &  (seq10 == 1 & seq9 == .)

*Reported hourly wage rate
replace rep_hr_wage = seq18_1 if seq18_2 == 1
replace rep_hr_wage = seq21_1 if seq21_2 == 1 & rep_hr_wage == .
egen tot_hr = rowtotal(seq18_1 seq21_1) if (seq18_2 == 1 & seq21_2 == 1) ,m 
replace rep_hr_wage = tot_hr if (seq18_2 == 1 & seq21_2 == 1)

/*
*test
gen inc_wj_hr = .
replace inc_wj_hr = seq18_1*seq19 * 52/12 if seq18_2 == 1					//monthly
replace inc_wj_hr = inc_wj_hr/(ahrswk_aj*52/12)
*/
	
*-----------------------------------------
*2)	Income business/self employment, Personal level (Merging issues: 3 more observations appear suddenly?! Clarified: Had to disentangle
	//individuals that have multiple jobs)
*-----------------------------------------
*Note: I do not use standard variable codes, because we only have self employed non-agric!
gen inc_se_1 =  seq36_2 														//Net income (profit) from business or businesses last week/month=
	replace inc_se_1 = inc_se_1*52/12 if seq36_1 == 1							//Weekly --> Monthly
gen inc_se_2 = seq36_2o															//Additional activity in seq36
	replace inc_se_2 = inc_se_2*52/12 if seq36_1o == 1
gen inc_se_3 = seq36_2o_act2													//Third additional acitivity in seq36
	replace inc_se_3 = inc_se_3 *52/12 if seq36_1o_act2 == 1
	
egen inc_se_na = rowtotal(inc_se_1 inc_se_2 inc_se_3), m						//Total from individual self employment activities
	
*3) Farm production	(Household level): Needs to be standardized.
egen farmcosts = rowtotal(  cropcosts livestockcosts machinecosts fishingcosts othfishexpd)
egen farmrevenue = rowtotal( croprevenue livestockrevenue fishingrevenue)
gen hh_se_a =  (farmrevenue - farmcosts)/12	//Farm income measure
*Leo made sure that farmincome is adjusted for periodicity!
	*1: plot revenue is from short plus long rain season (harvests in Aug.-Sept. vs. Jan-Feb.!) plotrentexpd plotrentrevenue taken out.
	*2: crop revenue (short plus long rain season)
	*3: agric. products and by-products: last 12 months
	*4: livestock and livestock by products: 12 months

*-----------------------------------------
*HH Income
*-----------------------------------------
*Household wage job income
	bysort hid: egen  inc_wj_c_hh = total(inc_wj_mj_c_o),m
	bysort hid: egen  inc_wj_ik_hh = total(inc_wj_mj_ik_o),m
	egen hh_wj = rowtotal(inc_wj_c_hh inc_wj_ik_hh),m
	
*Household self employment (non-agriculture)
	bysort hid: egen hh_se_na = total(inc_se_na),m
	
*Total household income
	egen hh_tot = rowtotal(hh_wj hh_se_na hh_se_a),m		//HH wage + hh non-agric (se) + hh agric
	replace inc_hh = hh_tot
		
*order hid pid hh_link inc_wj_mj_tot_o hh_wj hh_se_na hh_se_a inc_hh

	
***************************************************************************
*Expenditures. Check whether deciles are consistent with our income measure
gen expd = expm

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
