clear

use "Data\Egypt\LMPS 2006\Data\elmps06_Inddtav3_merged.dta" 
 
*Females above age 6, male children 6 to 17 only
***************************************************
* Standard Variables:
	*1) Age	
		rename  de0104 age
	*2) Country
		gen country = "EGY"
	*3) Gender
		gen male=.
		replace male=1 if de0101==1
		replace male=0 if de0101==2	
	*4) Year
		gen year = 2006
	*5) Weights
		gen wgt = expan
*________________________________________________________________________________________

*Data we need: Four categories, Questionnaire page 27/72


	*1) Cooking  (av6)
		gen p_cook = q4307
		recode p_cook (2=0)
		gen cook = q4308
		replace cook = 0 if p_cook == 0 & cook == .
		
		gen p_dish = q4309
		recode p_dish (2=0)
		gen dish = q4310
		replace dish = 0 if p_dish == 0 & dish == .
	
	*____________________________________________________________________________________*
	
		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
		
		egen cooking = rowtotal(cook dish)						/* cooking*/
		replace cooking = . if (cook ==. & dish ==.)
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_iron = q4311
		recode p_iron (2=0)
		gen iron = q4312
		replace iron = 0 if p_iron == 0 & iron == .
		
		gen p_clean = q4313
		recode p_clean (2=0)
		gen clean = q4314
		replace clean = 0 if p_clean == 0 & clean == .
		
		*____________________________________________________________________________________*
		
		gen p_cleaning = 1 if (p_clean + p_iron >=1) & (p_clean + p_iron != .)
		replace p_cleaning = 0 if (p_clean + p_iron == 0)
		
		egen cleaning =  rowtotal(iron clean)
		replace cleaning = . if (iron ==.  & clean ==.)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .		
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = q4325
		recode p_kid1 (2=0)
 		gen kid1 = q4326
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = q4327
		recode p_kid2 (2=0)
		gen kid2 = q4328
		replace kid2 = 0 if p_kid2 == 0 & kid2 == .

		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)
		
		egen childcare =  rowtotal(kid1 kid2)
		replace childcare = . if (kid1==. & kid2==.)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = q4319
		recode p_goods_services (2=0)
		
		gen goods_services = q4320										/*shopping for clothes and food*/
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .

	
	*5) Collecting water & Firewood
		gen p_water = q4315
		recode p_water (2=0)
		gen water = q4316
		replace water = 0 if p_water == 0 & water == .
		
		gen p_wood = q4317
		recode p_wood (2=0)
		gen wood = q4318
		replace wood = 0 if p_wood == 0 & wood == .

		*____________________________________________________________________________________*
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(water wood)
		replace coll_wf = . if (water ==. & wood ==.)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
	
keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/EGY_timeuse.dta", replace

