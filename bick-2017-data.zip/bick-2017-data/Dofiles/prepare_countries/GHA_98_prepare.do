***********************************************************************************************
* Program: GHA_98_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Ghana LSS 1998
***********************************************************************************************

use "Data\Ghana\LSS 1998-99\Data\Household\GHA_98_Merged", clear 
rename pid pid98

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs clust nh
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid=clusts+"-"+nhs
replace pid=pid98
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if rel == 1 //Reference Person
replace hh_link = 2 if rel == 2 //Spouse
replace hh_link = 3 if rel == 3 | rel == 4 //child, grand child
replace hh_link = 4 if  rel == 5 //Ascendant (parent, grand parent)
replace hh_link = 98 if  rel == 8 | rel == 9 //Not related
replace hh_link = 99 if  rel ==6 | rel == 7  //Others 


foreach v in `vs'{
	drop `v's
}

*-----------------------------------------

* Age 
gen age=agey

* Gender
replace male=1 if sex==1
replace male=0 if sex==2

*-----------------------------------------

* Weight
replace wgt=weight		//This is cluster weight
gen hh_wgt = . 	//weight		

* Interview date													  				/* Date of 3rd visit, when employment section was asked */
replace refdatex=1
replace refdate=mdy(s0vmonth, s0vday, (s0vyear+1900))	
format refdate %td

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if s2aq4==1
replace educ=0 if s2aq4==2
gen educlvl=.

gen edu = .
replace edu = 1 if inrange(s2aq2,1,5) | s2aq2==17
replace edu = 2 if inrange(s2aq2,6,10)
replace edu = 3 if inrange(s2aq2,11,16)
replace edu = 1 if edu ==. & s2aq1 ==2

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for market section: Age 7 and above */
replace emp=0 if s4gq1==2		 													/* Did you do any work for pay, profit, family gain or did you produce anything for barter or home use during the last 7 days? (including temporary absence from work)? */
replace emp=1 if s4gq1==1	

*Added by Paul: Section G is jumped if people are considered to be out of the labour force
*Employment section: s4fq10: Are you still unemployed?! Section 4 g Question 18: For how long have you been unemployed?
replace emp = 0 if (emp == . & s4fq10 == 2)

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0


*Work status
replace emp_wj = 1 if s4bq8 == 1
replace emp_se = 1 if inrange(s4bq8,2,6)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* All job

* Actual hours worked last week	
replace ahrswk_aj=s4gq3e
replace ahrswk_aj=0 if s4gq3e==. & emp==0

*Paul: Replace Hours to zero if person is out of the labour force
replace ahrswk_aj = 0 if s4fq10 == 2 & ahrswk_aj == .

*-----------------------------------------

* Main job

* Actual hours worked last week	
replace ahrswk_mj=s4gq3a
replace ahrswk_mj=0 if s4gq3a==. & emp==0

*Paul: Replace Hours to zero if person is out of the labour force
replace ahrswk_mj = 0 if s4fq10 == 2 & ahrswk_mj == .

*-----------------------------------------

* Second, third and fourth jobs

* Actual hours worked last week	
egen sj=rowtotal(s4gq3b s4gq3c s4gq3d), missing
replace ahrswk_sj=sj
replace ahrswk_sj=0 if sj==. & emp==0

*Paul: Replace Hours to zero if person is out of the labour force
replace ahrswk_sj = 0 if s4fq10 == 2 & ahrswk_sj == .
		
*-----------------------------------------

* Hours worked by job nature

* Generate indicator for each job nature							
local jobs mj
local nature wj sa sn uc
local time ahrswk

foreach n in `nature'{ 
	gen mj_`n'=0
}

replace mj_wj=1 if (s4gq2==1 & s4bq8==1) | (s4gq2==2 & s4cq12>=2 & s4cq12<=7) | (s4gq2==3 & s4dq11==1) | (s4gq2==4 & s4eq11==1) 
replace mj_sn=1 if (s4gq2==1 & s4bq8>=2 & s4bq8<=4) | (s4gq2==2 & s4cq12>=8 & s4cq12<=10) | (s4gq2==3 & s4dq11>=2 & s4dq11<=4) | (s4gq2==4 & s4eq11>=2 & s4eq11<=4)
replace mj_sa=1 if (s4gq2==1 & (s4bq8==5 | s4bq8==6)) | (s4gq2==2 & s4cq12==1 ) | (s4gq2==3 & (s4dq11==5 | s4dq11==6)) | (s4gq2==4 & (s4eq11==5 | s4eq11==6)) 
replace mj_uc=1 if (s4gq2==1 & s4bq8>6) | (s4gq2==2 & s4cq12==11 ) | (s4gq2>2) | (s4gq2==3 & s4dq11>6) | (s4gq2==4 & s4eq11>6)| (s4gq2>4)

* Generate hours worked by job nature: Does this generate hours worked in all jobs of a spec. job nature?
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}
*No! The above yields only hours worked in main wage job!
gen indic_se = 0
replace indic_se = 1 if s4bq8!=1 & s4bq8!=.
replace indic_se = indic_se + 1 if s4cq12 == 1 | (s4cq12 >= 8 & s4cq12 <= 10)
replace indic_se = indic_se +1 if s4dq11 >= 2 & s4dq11 <= 5
replace indic_se = indic_se +1 if s4eq11 >= 2 & s4eq11 <= 5


replace ahrswk_wj_mj = s4gq3a if s4bq8==1
gen wj_sj =  s4gq3b if (s4gq2==2 & s4cq12>=2 & s4cq12<=7)
gen wj_tj = s4gq3c if (s4gq2==3 & s4dq11==1)
gen wj_fj = s4gq3d if (s4gq2==4 & s4eq11==1) 
egen wj_all = rowtotal(ahrswk_wj_mj wj_sj wj_tj wj_fj),m

replace ahrswk_wj_aj = ahrswk_wj_mj if s4bq8==1 & s4aq7 == 2 						//These guys did only one (wage) main job
replace ahrswk_wj_aj = wj_all if s4bq8==1											//These guys have multiple (wage) jobs

replace flag_set1 = 1 if  s4bq8==1 & s4aq7 == 2										//These guys only have one (wage) job!

egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
*3 individuals have mistakenly written false job numbers into answer sheets, s.t. wage jobs are not correctly built up. Kick these out.
replace flag_set1 = 0 if diff2 < 0 & flag_set1 == 1

replace flag_set2 = 1 if flag_set1 == 1 | (s4bq8==1 & s4aq7 == 1 & indic_se == 0) 	//These guys have multiple wage jobs, no se hours
replace flag_set2 = 0 if diff2 < 0 & flag_set2 == 1

replace flag_set3 = 1 if flag_set2 == 1 | (s4bq8==1 & s4aq7 == 1 & indic_se > 0)	//These guys have se jobs on top of wj

sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------
gen ind = .
replace ind = 1 if inrange(s4bq4,0,199)
replace ind = 2 if inrange(s4bq4,200,399)
replace ind = 3 if inrange(s4bq4,400,999)

 
*-----------------------------------------
*Income: Wage jobs available on personal level
*-----------------------------------------
*Based on Files INC: DISAGGREGATED (i.e. individual) HOUSEHOLD INCOME VARIABLES (expressed on an ANNUAL basis)
*The INC files contain income information on the individual level (see document User's Guide, p18/195 ff.)
egen wj_mjc = rowtotal(j1cash j1bonk j1h j1tr j1oth),m			//Main wage job, cash & bonus (if not included) & others. Don't know if net or gross.
	replace inc_wj_mj_c_o = wj_mjc/12
egen wj_mjik = rowtotal( j1k ),m								//inkind
	replace inc_wj_mj_ik_o = wj_mjik/12
egen wj_mjtot = rowtotal(inc_wj_mj_c_o inc_wj_mj_ik_o),m	
	replace inc_wj_mj_tot_o = wj_mjtot if s4bq8 == 1			//total, is already monthly. S4bq8: In this connection (job!!), are you a paid employee (1)? Self employed (2)?...
	
egen wj_ajc = rowtotal(j1cash  j2cash  j3cash j4cash),m	
	replace inc_wj_aj_c_o = wj_ajc/12							//cash

egen vik1 = rowtotal(j1k j1bonk j1h j1tr j1oth),m  
	gen ik1 = vik1 if s4bq8 == 1
egen vik2 = rowtotal(j2k j2h),m
	gen ik2 = vik2 if s4cq12 == 1 | (s4cq12 >= 8 & s4cq12 <= 10)
gen ik3 = j3k if s4dq11 >= 2 & s4dq11 <= 5
gen ik4 = j4k if s4eq11 >= 2 & s4eq11 <= 5
egen wj_ajk	= rowtotal(ik1 ik2 ik3 ik4),m
	replace inc_wj_aj_ik_o = wj_ajk/12							//inkind
	
egen wj_ajtot = rowtotal(inc_wj_aj_c_o inc_wj_aj_ik_o),m	
	replace inc_wj_aj_tot_o = wj_ajtot if s4bq8 == 1
	*if (s4bq8 == 1  & s4cq12 == .) | (s4bq8 == 1 & inlist(s4cq12,2,7))			//total, wage jobs

*Added by Paul: 19.10.2016
*replace inc_wj_mj_tot_o = . if s4aq1 == 2						//Make sure we have only main wage job in here
*replace inc_wj_aj_tot_o = . if s4aq1 == 2						//Make sure second wage job/first se does not pull down mean
	
	
*Self employed income (cash)
egen inc_se_c = rowtotal(j1secash j2secash j3secash j4secash), m
	
*Generate total individual income variable: 
egen tot_wjse = rowtotal(wj_ajc inc_se_c j1bonk j1h j1tr j1oth j2k j2h j3k j4k ),m
replace ind_tot_wjse = tot_wjse/12

*-----------------------------------------
*Income has been aggregated to household level
*-----------------------------------------
*1) HH level
	egen HH_inc = rowtotal(totemp agri1c nfsey2 /* imprt remitinc otherinc */), m
		replace inc_hh = HH_inc/12
	
	*Problem: All incomes were mentioned in the old Cedi currency, which was changed in July 2007, at the rate 10000:1 
	// for the new cedi currency. So, go in here and standardize to the new cedi!
	foreach v in inc_wj_mj_c_o inc_wj_mj_ik_o inc_wj_aj_c_o inc_wj_aj_ik_o inc_wj_mj_tot_o inc_wj_aj_tot_o inc_hh ind_tot_wjse {
		replace `v' = `v'/10000
	}

	
*******************
*Consumption and farm production
*******************

*egen expd = rowtotal(expfoodc housexp othexpc expremit), missing 	//Calculation of expenditure measure
gen farmincome = agri1c								//Farm income measure


* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'  
order hid pid male age wgt hh_wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 



/* Old code for income	
gen inc_mj = s4bq6a
	replace inc_mj = . if s4bq6b == 1 //inc_mj*24 if s4bq6b == 1		//Daily, what do we do here?
	replace inc_mj = inc_mj*52/12 if s4bq6b == 2		//Weekly
	replace inc_mj = inc_mj*2 if s4bq6b == 3		//fortnightly
	replace inc_mj = inc_mj/3 if s4bq6b == 5		//quarterly
	replace inc_mj = inc_mj/12 if s4bq6b == 6		//yearly

	replace inc_mj = .	if s4bq9 == 1 |  s4bq9 == 8 |  s4bq9 == 9 |  s4bq9 == 96 	//We only want employee incomes
	replace inc_mj = . if inc_mj > 7680000 											//How can wage income be 58 Million?!
	
*Additional Wage jobs
*2nd job
gen inc_wj_sj_c = s4cq10a
	replace inc_wj_sj_c = . if s4cq10b == 1 //s4cq10a*24 if s4cq10b == 1 : We do not know days worked in 2nd job per month
	replace inc_wj_sj_c = s4cq10a*52/12 if s4cq10b == 2
	replace inc_wj_sj_c = s4cq10a*2 if s4cq10b == 3
	replace inc_wj_sj_c = s4cq10a/3 if s4cq10b == 5
	replace inc_wj_sj_c = s4cq10a/12 if s4cq10b == 6

	replace inc_wj_sj_c = . if s4cq12 == 1 | s4cq12 == 8 | s4cq12 == 9 | s4cq12 == 11
	gen inc_wj_sj_c_net = inc_wj_sj_c if s4cq13 == 1				//Taxes are deducted
	gen inc_wj_sj_c_gross = inc_wj_sj_c if s4cq13 == 2				//Taxes not deducted
	
	
*3rd job
gen inc_wj_tj_c = s4dq9a
	replace inc_wj_tj_c = . if  s4dq9b == 1 // s4dq9a*24 if  s4dq9b == 1
	replace inc_wj_tj_c = s4dq9a*52/12 if s4dq9b == 2
	replace inc_wj_tj_c = s4dq9a*2 if s4dq9b == 3
	replace inc_wj_tj_c = s4dq9a/3 if s4dq9b == 5
	replace inc_wj_tj_c = s4dq9a/12 if s4dq9b == 6

	replace inc_wj_tj_c = . if s4dq11 == 2 | s4dq11 == 3 | s4dq11 == 5		//Only wage incomes observations matter
	
*4th job
gen inc_wj_fj_c = s4eq9a
	replace inc_wj_fj_c = . if  s4eq9b == 1 // s4eq9a*24 if  s4eq9b == 1
	replace inc_wj_fj_c = s4eq9a*52/12 if s4eq9b == 2
	replace inc_wj_fj_c = s4eq9a*2 if s4eq9b == 3
	replace inc_wj_fj_c = s4eq9a/3 if s4eq9b == 5
	replace inc_wj_fj_c = s4eq9a/12 if s4eq9b == 6

	replace inc_wj_fj_c = . if s4eq11 == 2 | s4eq11 == 3 | s4eq11 == 5		//Only wage incomes observations matter	

*-----------------------------------------
*Inkind values
local add_vars  s4bq12 s4bq15 s4bq17 s4bq19 s4bq21 s4cq15 s4cq17 s4dq14 s4eq14	//bonus inkind accom trans other (main and all other jobs)
local inkind_vars
foreach var in `add_vars' {
	gen `var'_value = `var'a
	replace `var'_value = . if `var'b == 1 //`var'a*24 if `var'b == 1
	replace `var'_value = `var'a*52/12 if `var'b == 2
	replace `var'_value = `var'a*2 if `var'b == 3
	replace `var'_value = `var'a/3 if `var'b == 5
	replace `var'_value = `var'a/12 if `var'b == 6
	
	if "`var'" != "s4bq12" {
		local inkind_vars `inkind_vars' `var'_value
	}
}	
	
	replace s4bq12_value = . if s4bq13 == 1 		//Did person already include bonus in main salary question?

local fj_ik s4bq12 s4bq15 s4bq17 s4bq19 s4bq21		//First job inkind values
local fj_ikvalue	
	foreach v in `fj_ik' {
		replace `v'_value = . if s4bq9 == 1 |  s4bq9 == 8 |  s4bq9 == 9 | s4bq9 == 96	//This is first job: Only employess matter, set self employed inkind to missing
	
		if "`v'" != "s4bq12" {
			local fj_ikvalue `fj_ikvalue' `v'_value		
		}
	}

local sj_ik s4cq15 s4cq17																//Second job
	foreach v in `sj_ik' {
		replace `v'_value = . if s4cq12 == 1 | s4cq12 == 8 | s4cq12 == 9 | s4cq12 == 11 	
	}
	
replace s4dq14_value = . if s4dq11 == 2 | s4dq11 == 3 | s4dq11 == 5	 					//Third job
	
replace s4eq14_value = . if s4eq11 == 2 | s4eq11 == 3 | s4eq11 == 5						//Fourth job
	
*-----------------------------------------	
*Our standard wage variables	


*main job cash income, wage and gross/net: Need to add bonus if not yet included	
egen mj_c = rowtotal(s4bq12_value inc_mj), m											//Main job cash: bonus + cash income
	replace inc_wj_mj_c_n = mj_c if s4bq10 == 1    										//Tax deducted already or not?
	replace inc_wj_mj_c_g = mj_c if s4bq10 == 2    										//Tax deducted already or not?
	replace inc_wj_mj_c_o = mj_c														//One variable for gross & net incomes
	
egen mj_ik = rowtotal(`fj_ikvalue'),m
	replace inc_wj_mj_ik_o = mj_ik if s4bq10 == 1

egen wj_mjtotn = rowtotal(inc_wj_mj_c_n inc_wj_mj_ik_o),m
	replace inc_wj_mj_tot_n = wj_mjtotn if s4bq10 == 1
egen wj_mjtotg = rowtotal(inc_wj_mj_c_g inc_wj_mj_ik_o),m
	replace inc_wj_mj_tot_g = wj_mjtotg if s4bq10 == 2   

*All wage jobs income: Put in other, since we do not know if third/fourth is net or gross!
egen wj_ajc = rowtotal(inc_wj_mj_c_o inc_wj_sj_c inc_wj_tj_c inc_wj_fj_c),m						//Generate one variable with either net or gross (cannot have both at same time)
	replace inc_wj_aj_c_o = wj_ajc
egen wj_ajik = rowtotal(`inkind_vars' ), m
	replace inc_wj_aj_ik_o = wj_ajik
egen wj_ajtot = rowtotal(inc_wj_aj_c_o inc_wj_aj_ik_o),m	
	replace inc_wj_aj_tot_o = wj_ajtot 
	
*Overall wage incomes, net, gross, other: Stay with other only, net & gross do not have many observations
/*
egen netwjinc = rowtotal(inc_wj_mj_c_net inc_wj_sj_c_net inc_wj_tj_c inc_wj_fj_c inc_wj_ik),m				//Overall net wage income
	replace inc_wj_net = netwjinc if s4bq10 == 1 & s4cq13 == 1							//Tax deducted in main and second job
	
egen grosswjinc = rowtotal(inc_wj_mj_c_gross inc_wj_sj_c_gross inc_wj_tj_c inc_wj_fj_c inc_wj_ik),m
	replace inc_wj_gross = grosswjinc if s4bq10 == 2 & s4cq13 == 2						//Tax not deducted in main and second job
*/

*generate hh income from wage jobs, to compare with the provided measure.
bysort hid: egen hh_wj = total(inc_wj_aj_tot_o),m

*/
