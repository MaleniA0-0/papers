clear

use "Data/Tajikistan\LSMS 2007\Data\TJK07_merged.dta" 


*Hours are determined using "how many times*(how many hours + how many minutes each time)

***************************************************
* Standard Variables:
	*1) Age	
		rename  m1q3 age
	*2) Country
		gen country = "TJK"
	*3) Gender
		gen male=.
		replace male=1 if m1q2==1
		replace male=0 if m1q2==2		
	*4) Year
		gen year = 2007
	*5) Weight
		gen wgt = popw
*________________________________________________________________________________________

*Data we need: Four categories
local variables  fa68_3 fa69_3 fa70_3 fa72_3 fa63_3 fa64_3
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

local var fa68 fa69 fa70 fa72 fa63 fa64

foreach v in `var' {
egen `v'_time = rowtotal(`v'_2 `v'_3_hrs)
}

	*1) Cooking  (av6)
		gen p_cooking = 1 if fa69_1 >= 1 & fa69_1 != .
		replace p_cooking = 0 if fa69_1 == 0
		gen cooking = fa69_1*(fa69_time)  					/* cooking*/
		replace p_cooking = 1 if cooking > 0 & cooking != .
		*egen cooking = rowtotal(fa69_2 fa69_3_hrs)
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen cleaning =  fa70_1*(fa70_time) 					/*laundry and cleaning the house*/
		gen p_cleaning = 1 if fa70_1 >= 1 & fa70_1 != .
		replace p_cleaning = 0 if fa70_1 == 0
		replace p_cleaning = 1 if cleaning > 0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_childcare = 1 if fa72_1 >= 1 & fa72_1 != .
		replace p_childcare = 0 if fa72_1 == 0
		gen childcare =  fa72_1*(fa72_time)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = 1 if fa68_1 >= 1 & fa68_1 != .
		replace p_goods_services = 0 if fa68_1 == 0
		gen goods_services = fa68_1*(fa68_time)			/*going to market*/
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Fetching water and firewood
		gen p_water = 1 if fa63_1>=1 & fa63_1 != .
		replace p_water = 0 if fa63_1 == 0
		gen water = fa63_1*(fa63_time)
		
		gen p_wood = 1 if fa64_1>=1 & fa64_1 != .
		replace p_wood = 0 if fa64_1 == 0
		gen wood = fa64_1*(fa64_time)
		
		*____________________________________________________________________________________*
		
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(water wood), missing
		replace coll_wf = . if (water == . & wood == .)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .

	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age wgt country male year cooking-hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf
drop water wood

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/TJK_timeuse.dta", replace
