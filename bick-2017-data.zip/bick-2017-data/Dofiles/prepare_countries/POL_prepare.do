******************************************************************************************
* Program: POL_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Poland
******************************************************************************************

use "Data\EULFS\Update 2016\2005\pl2005y", clear
rename refweek refweekEU											/* To differentiate from our standard variables */
rename refyear refyearEU											
rename age ageEU											

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hid=qhhnum
replace pid=hhseqnum
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if hhlink == 1 //Reference Person
replace hh_link = 2 if hhlink == 2 //Spouse
replace hh_link = 3 if hhlink == 3 //Child
replace hh_link = 4 if hhlink == 4 //Ascendant
replace hh_link = 99 if hhlink == 99 //Others
*-----------------------------------------

* Age 	
gen age=ageEU

* Gender
replace male=1 if sex==1
replace male=0 if sex==2

*-----------------------------------------

* Weight 
replace wgt=coeff
gen hh_wgt = .

* Interview date 													/* Full interview date is not available. Refweek is one week prior to interview week*/
replace refdatex=1
replace refweek=refweekEU
replace refyear=refyearEU

*-----------------------------------------

*Enrolled in education

gen educ=.
replace educ=1 if educstat==1
replace educ=0 if educstat==2		
*do not set educ=o if educstat==9 because that might not be true!
gen educlvl=.
replace educlvl=0 if educlevl<5						
*educlvl = 0 stands for secondary or lower, educlvl=1 for tertiary
replace educlvl=1 if educlevl>=5 & educlevl!=. & educlevl!=9 

		gen edu = .
	replace edu = 1 if hatlev1d == "L"
	replace edu = 2 if hatlev1d == "M"
	replace edu = 3 if hatlev1d == "H"
	/*
	replace edu = 1 if inrange(hatlevel,0,22)
	replace edu = 2 if inrange(hatlevel,31,36)
	replace edu = 3 if inrange(hatlevel,41,60)
	*/
	
******************************************
* Market work
******************************************

* Employment status

replace emp=1 if wstator==1											/*employed and working in reference week*/
replace emp=2 if wstator==2											/*employed but not working in refweek*/
replace emp=0 if wstator>2 & wstator!=.								/*not employed*/
replace emp=. if wstator==.											/*missing*/

*-----------------------------------------

* Reason for being economically inactive

replace reason=0 if emp<=1											/* emp=0 or 1 (employed and working or unemployed)*/
replace reason=2 if nowkreas==7										/* vacation or public holiday*/
replace reason=3 if	nowkreas==4										/* sickness */		
replace reason=4 if nowkreas==2										/* labour dispute */
replace reason=5 if nowkreas==5|nowkreas==6							/* maternity and paternity leave */
replace reason=7 if nowkreas<=1|nowkreas==3|nowkreas==8|nowkreas==9	/* other reasons */

*Work status
replace emp_wj = 1 if stapro == 3
replace emp_se = 1 if stapro == 0 | stapro == 2 | stapro == 4
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
*-----------------------------------------

* Main job

* Usual hours worked per week 										/* Universe for market section: Everyone >= age 15 */
replace uhrswk_mj=hwusual											/*no missings in usual hours*/
replace uhrswk_mj=0 if hwusual==99									/*Set hours to 0 if hours are N.A. (99) regardless of empstat, or if hours are missing and person is self-reported as not employed*/

* Actual hours worked during refweek
replace ahrswk_mj=hwactual											/* No missing values */
replace ahrswk_mj=0 if hwactual==99 
 
* Paid and unpaid overtime hours in the refweek
local ot hwoverp hwoverpu
foreach o in `ot'{
	gen `o's=`o'													/* No missing values */
	replace `o's=0 if `o'==99 										/*Set hours to 0 if hours are N.A. (99) regardless of empstat, or if hours are missing but person is self-reported as not employed*/
}

replace ohrswk_mj=hwoverps+hwoverpus 

foreach o in `ot'{
	drop `o's
}
 
*-----------------------------------------

* Second job

* Actual hours worked during refweek 
replace ahrswk_sj=hwactua2											/* No missing values */
replace ahrswk_sj=0 if hwactua2==99

replace uhrswk_sj = hwactua2
replace uhrswk_sj = 0 if hwactua2 == 99
*-----------------------------------------

* Hours worked by job nature

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx uc
local time uhrswk ahrswk ohrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if stapro==3
replace mj_sa=1 if (stapro==0 | stapro==4) & na111d=="A"
replace mj_sn=1 if (stapro==0 | stapro==4) & na111d~="A" & na111d~="9"
replace mj_sx=1 if (stapro==0 | stapro==4) & na111d=="9"
replace mj_uc=1 if stapro==.

replace sj_wj=1 if stapro2j==3
replace sj_sa=1 if (stapro2j==0 | stapro2j==4) & na112j1d=="A"
replace sj_sn=1 if (stapro2j==0 | stapro2j==4) & na112j1d~="A" & na112j1d~="9"
replace sj_sx=1 if (stapro2j==0 | stapro2j==4) & na112j1d=="9"
replace sj_uc=1 if stapro2j==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}


*-----------------------------------------

*Commuting and meal hours
replace mealhrsx=0													/*Both are explicitly excluded fr hours worked*/						
replace chrsx=0

*-----------------------------------------
	gen ind = .
	replace ind = 1 if na11s == 0
	replace ind = 2 if na11s == 1
	replace ind = 3 if na11s == 2

*-----------------------------------------
gen decile =incdecil
	replace decile = . if incdecil == 99 
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt decile `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
