clear

use "Data\Tanzania\NPS LSMS 2009\Data\Merged\TZA_Merged", clear 

***************************************************
* Standard Variables:
	*1) Age	
	gen age=sbq4
	
	*2) Country
	gen country = "TZA"
		
	*3) Gender
	gen male=.
	replace male=1 if sbq2==1
	replace male=0 if sbq2==2

	*4) Year
	gen year = 2009
	
	*5) Weight
	gen wgt = hh_weight

*________________________________________________________________________________________

 local variables seq47_mins seq48_mins
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Data we need: Four categories


	*1) Cooking  (av6)
		gen others = .  					/* cooking*/
		gen cooking=.
		
	*2) Cleaning/Housework (av7)
		gen cleaning = . 					/*laundry and cleaning the house*/
		
	*3) Childcare (Av11)
		gen childcare =  .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .						/*going to market*/
		
	*5) Fetching water and fuel
		egen water = rowtotal(seq48_hr seq48_mins_hrs), missing
		gen water_week=water*7
		egen firewood = rowtotal(seq47_hr seq47_mins_hrs), missing
		gen firewood_week = firewood*7
		egen coll_wf = rowtotal(water_week firewood_week), missing
	
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(others cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep wgt age country male year others cooking-hrs_hw
drop water water_week firewood firewood_week

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/TZA_timeuse.dta", replace
