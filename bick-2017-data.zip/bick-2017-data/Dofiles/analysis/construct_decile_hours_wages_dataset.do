* Data for Paid Employmed

use data/simplified_wj_world_data, clear

rename hr_wage_dec cd
sort country cd

foreach x in wl_n hm_n{
	by country cd: egen m`x'=mean(`x')
}
by country cd: keep if _n==1

*------------
sort cd q country
by cd: gen cidentifier=_n
sort q country cd
list countr cidentifier q if cd==1
*------------

sort country cd year
keep country cd q mwl mhm year 
rename cd decile
rename mwl wage_paid_empl
rename mhm hours_paid_empl

save data/aux, replace

* Data for Paid Employed plus Self-Employed

use data/simplified_wjse_world_data, clear

rename w_dec cd
sort country cd

foreach x in wl_n hm_n{
	by country cd: egen m`x'=mean(`x')
}
by country cd: keep if _n==1

*------------
sort cd q country
by cd: gen cidentifier=_n
sort q country cd
list countr cidentifier q if cd==1
*------------

sort country cd

sort country cd year
keep country cd q mwl mhm year
rename cd decile
rename mwl wage_all
rename mhm hours_all
joinby country decile using data/aux

rename q q_e9ry
order country year q decile hours_p wage_p hours_a wage_a

save Data/Cleaned_data/decile_hours_wages, replace
