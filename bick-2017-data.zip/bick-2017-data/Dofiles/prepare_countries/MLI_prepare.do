******************************************************************************************
* Program: MLI_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Mali
******************************************************************************************

use "Data\Mali\EPAM 2010\Data\EPAM_2010_Individu", clear
rename age agex

*Labour Module: Questionnaire 2010, page 5/11

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=string(hh)
replace pid=numindiv 
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=agex

* Gender
replace male=1 if sexe==1
replace male=0 if sexe==2

*-----------------------------------------

* Weight 	
replace wgt=iWeight

* Interview date
replace refdatex=0
replace startdate=mdy(9,10,2010)	
replace enddate=mdy(10,30,2010)
format startdate enddate %td

*-----------------------------------------

gen educ=.
replace educ=1 if M15==1
replace educ=0 if M15==2
gen educlvl=.
*no information on level of attended schooling

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for market section: Age 15 and above */
replace emp=0 if EA2B==2 | (EA2B==2 & EA3==10 & EA4==2)								/* To account for individuals who only answered No to EA2B and left the remaining questions as missing */
replace emp=1 if EA2B==1 | EA3<10
replace emp=2 if EA2B==2 & EA3==10 & EA4==1 /*Xing*/

/*Added by Paul: EA5 asks for temporary absence last week*/
replace emp=2 if EA2B==2 & EA5<6  													/*Prefer to use this question, as it stands in line with most other prepare dofiles*/
replace emp = 0 if Situat == 3	& emp == .													/*Situat = 3 are all inactive. Questionnaires were not answered for them?!*/


* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=2 if emp==2 & EA5==1
replace reason=3 if emp==2 & EA5==2
replace reason=5 if emp==2 & EA5==3
replace reason=4 if emp==2 & EA5==4
replace reason=7 if emp==2 & EA5==5 | EA5==9

*-----------------------------------------

* Main Job

* Actual days worked last week
replace adayswk_mj=AP10
replace adayswk_mj=0 if AP10==. & (emp==0 | emp==2)

* Usual hours worked per week 
replace uhrswk_mj=AP11 							
replace uhrswk_mj=0 if AP11==. & (emp==0 | emp==2)

*-----------------------------------------

* All Job

* Usual hours worked per week 
replace uhrswk_aj=AS9 							
replace uhrswk_aj=0 if AS9==. & (emp==0 | emp==2)
replace uhrswk_aj=uhrswk_mj if (uhrswk_aj==. | uhrswk_aj==0) & (uhrswk_mj>0 & uhrswk_mj<.)

*PAUL: There might be a way to work through missing hours. Check question AP13c - what is the amount of hours worked per week (main job)
replace uhrswk_aj = AP13C if uhrswk_aj == . & AS1A == 2 		/*Replace usual hours per week = that question, if hours are still missing & individual declares not to have another job!*/


******************************************
* Non-market work
******************************************

* Employment status (non-market work)												/* Universe for nm section:  */
replace emp_nm=0																	/* nm work: collect firewood, searching for water in last 7 days*/
replace emp_nm=1 if EA1D==1 | EA1E==1
replace emp_nm=. if EA1D==. & EA1E==.
	
*-----------------------------------------

* Actual hours worked in past 7 days
egen byte nm=rowtotal(EA1D_OUI EA1E_OUI), missing
replace ahrswk_nm=nm
replace ahrswk_nm=0 if emp_nm==0


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj
local nature wj sa sn uc
local time adayswk uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if (AP3>=1 & AP3<=5) | AP3==9
replace mj_sa=1 if ((AP3>=6 & AP3<=8) | AP3==10) & (AP2>=101 & AP2<=201)
replace mj_sn=1 if ((AP3>=6 & AP3<=8) | AP3==10) & (AP2>=301 & AP2<.)
replace mj_uc=1 if AP3==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */													
replace chrsx=2

*-----------------------------------------
*Timeuse
*1) Cooking  (av6)
		gen p_cooking = EA1C
		recode p_cooking (2=0)
		gen cooking =  EA1C_OUI				  					/* cooking*/
		replace cooking = 0 if p_cooking == 0 & cooking == .
		replace p_cooking = 1 if cooking > 0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_cleaning = EA1B
		recode p_cleaning (2=0)
		gen cleaning =   EA1B_OUI				 					/*laundry and cleaning the house*/
		replace cleaning = 0 if p_cleaning == 0 & cleaning == .
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_childcare = EA1F
		recode p_childcare (2=0)
		gen childcare = EA1F_OUI
		replace childcare = 0 if p_childcare == 0 & childcare == .
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .									/*going to market*/
		gen p_goods_services = .
		
	*5) Fetching water and firewoof
		gen p_wood = EA1D
		recode p_wood (2=0)
		gen wood = EA1D_OUI
		replace wood = 0 if p_wood == 0 & wood == .
		
		gen p_water = EA1E
		recode p_water (2=0)
		gen water = EA1E_OUI
		replace water = 0 if p_water == 0 & water == .

		*____________________________________________________________________________________*
	
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(wood water)
		replace coll_wf = . if (water == . & wood == .)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
