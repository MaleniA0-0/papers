******************************************************************************************
* Program: NAM_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Namibia
******************************************************************************************
clear 

use "Data\Namibia\NHIES 2009\Data\indiv_merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Age: In 5 year categories like EULFS countries! 
gen age = 2
forvalues n = 1/20 {
	local age = `n'-1
	replace age = 2 + `age'*5 if Agegroup == `n'
}

* Generate household and personal id		
drop hid
gen hid = cRegion+"0000"+string(FNumber)+string(Hnumber)
*destring hid, replace
drop pid 
gen pid = PNumber

order hid pid
sort hid pid 

*-----------------------------------------

* Gender
replace male=1 if cSex==2
replace male=0 if cSex==1

*-----------------------------------------

* Weight 
replace wgt = RaisFactP		//Looks like cluster weight
gen hh_wgt = . //RaisFactP


* Interview date
replace refdatex=0
replace startdate=mdy(6,1,2009)
replace enddate=mdy(7,1,2010)
format startdate enddate %td

gen hh_link = .
replace hh_link = 1 if  cRtoHead == 1 //Reference Person
replace hh_link = 2 if cRtoHead == 2 //Spouse
replace hh_link = 3 if cRtoHead == 3 | cRtoHead == 4 | cRtoHead == 5 //Child, grandchildren 
replace hh_link = 4 if cRtoHead == 6 //Ascendant (parents, grandparents)
replace hh_link = 99 if cRtoHead == 7 //Others

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if cInSch == 1
replace educ=0 if cInSch == 0
gen educlvl=.

gen edu = .
replace edu = 1 if cGradeGr == 1
replace edu = 2 if cGradeGr == 2 | cGradeGr == 3
replace edu = 3 if cGradeGr == 4 | cGradeGr == 5 | cGradeGr == 6

******************************************
* Market work
******************************************

* Employment status (market work)							/* Universe for employment status question: Age 8 and above */
replace emp = 1 if cWork == 1  
replace emp = 0 if cWork == 2
replace emp = 2 if cWork == 2 & cHasJob == 1
*--> Very close to official employment ratios given in official report

* Reason for being economically inactive
replace reason=0 if emp<=1
*replace reason=2 if cReason==3															/* vacation or public holiday*/
replace reason=3 if cReason==5															/* sickness */	
*replace reason=4 if D10==5															/* labour dispute */
*replace reason=5 if D10==2															/* maternity and paternity leave */
replace reason=7 if cReason==1 | cReason==2 | cReason==3 | cReason==4 | cReason==7 | cReason==8 | cReason==9			/* other reasons */

*Work status
replace emp_wj = 1 if cEmpl == 1 | cEmpl == 2
replace emp_se = 1 if inrange(cEmpl,4,8)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
*-----------------------------------------

* All Jobs																			
replace ahrswk_aj = Hours


******************************************
* Non-market work
******************************************

*No information on time spent on non market work 

******************************************
* Hours worked by job characteristics
******************************************

*No information on time spent on by job characteristics (only all job hours given, but job nature is main 

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2						

gen ind = .
replace ind = 1 if inrange(cEcon,1,13)
replace ind = 2 if inrange(cEcon,14,45)
replace ind = 3 if inrange(cEcon,50,97)

*-----------------------------------------
*Income: Not reliable, not enough info on variables. Should we really keep this?!
*-----------------------------------------
*1: No information on wage income on personal level

*2: Household income
*We know household size, and household per capita income
replace inc_hh = hh_wjse //Apparently, this should be income from self employment activities & employment, only these two!
	*It seems that the next two contain other income sources, like transfers, royalties etc. That's why I decide to go for hh_wjse!
	gen inc_hh_test1 = hh_size*hh_incpc 	
	gen inc_hh_test2 = hh_size* hAPCI2
	
*sum inc_hh inc_hh_test1 inc_hh_test2 hh_wjse //hh_wj hh_wj_n
*All this does not make any sense, how can net wage income on hh level be so much less than gross!?!


* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 


