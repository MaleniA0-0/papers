******************************************************************************************
* Program: AUS_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Australia
******************************************************************************************

use "Data\Australia\HILDA-CNEF\Data\hequiv_2005", clear 
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
destring X11101LL, replace
replace pid=X11101LL
replace hid=X11102_2005
order hid pid
sort hid pid

*-----------------------------------------

* Age
gen age=D11101_2005

* Gender
replace male=1 if D11102LL==1
replace male=0 if D11102LL==2

*-----------------------------------------

* Weight
replace wgt=W11101_2005												/* Use cross-section individual wgt*/

* Interview dates													/* Data collection began on 20 Aug 2009 and ended on 11 Mar 2010 */
replace refdatex=0
replace startdate=mdy(8,15,2005)	
replace enddate=mdy(3,11,2006)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.

******************************************
* Market work														/* Universe: age 15 and above */
******************************************

* Employment status (market work)									/* In HILDA-CNEF, emp is a derived variable (employed if annual hours worked >51)*/	
/*replace emp=0 if E11102_2005==0
replace emp=1 if E11102_2005==1
replace emp=. if E11102_2005==0 & age<15							/* NIU is treated as not employed and 0 hours in CNEF. Replace both with missing here */
replace emp=. if E11101_2005<=-2  									/* Replace emp=. if hours is missing; item-non-response(-2) or survey-non-response(-3) */
*/

replace emp=0 if E11104_2005==2
replace emp=1 if E11104_2005==1
replace emp=. if E11104_2005==-3 | E11104_2005==-1					/*Child under 15 and survey non-response*/
replace emp=. if E11102_2005==0 & age<15							/* NIU is treated as not employed and 0 hours in CNEF. Replace both with missing here */


* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* Annualized usual hours worked in previous year (all jobs)			/* Calculated from usual hours worked, or hours worked in last job if not currently working, factored by the percent of the financial year in work. Usual hours worked taken from previous wave he has become unemployed */					
replace uhrsyr_aj=E11101_2005
replace uhrsyr_aj=.	if (E11101_2005<=-2)|(age<15 & E11101_2005==0)	/* Replace hours of item-non-response(-2), survey-non-response(-3) or NIU with missing */

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													/* Both not explicitly included or excluded from work hours, chrs and mhrs are not available */
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
