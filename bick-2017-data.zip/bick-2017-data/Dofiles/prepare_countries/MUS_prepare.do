*******************************************************************************************
* Program: MUS_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Mauritius
*******************************************************************************************

use "Data\Mauritius\CMPHS 2010\Data\CMPHS2010", clear
sort serialno month district hhno v5
quietly by serialno month district hhno v5 : gen dup = cond(_N==1,0,_n)
drop if dup>1																		/* Drop duplicates */

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs serialno month district hhno
foreach v in `vs'{
	gen `v's=string(`v')	
}

replace hid=serialnos+"-"+months+"-"+districts+"-"+hhnos

foreach v in `vs'{
	drop `v's
}

replace pid=v5
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if v6 == 1 //Reference Person
replace hh_link = 2 if v6 == 2 //Spouse/Husband
replace hh_link = 3 if v6 == 3 | v6 == 4 | v6 == 5 //child, grand child
replace hh_link = 4 if   v6 == 6 | v6 == 7 //Ascendant (parent, grand parent)
replace hh_link = 98 if v6 == 9 //Not related
replace hh_link = 99 if  v6 == 8 //Others 

*-----------------------------------------

* Age 
gen age=v7

* Gender
replace male=1 if v8==1
replace male=0 if v8==2

*-----------------------------------------

* No survey weight

gen hh_wgt = .

* Interview date
replace refdatex=1
replace refmonth=month
replace refyear=2010

*-----------------------------------------
gen educ=.
replace educ=1 if v10==1
replace educ=0 if v10!=1 & v10!=.
gen educlvl=.
replace educlvl=1 if v12<=3 & v10==1 
replace educlvl=0 if v11<=99 & v10==1 & v11!=1

gen edu = .
replace edu = 1 if inrange( v11,1,17) | v11 == 99
replace edu = 2 if inrange( v11,21,31)
******************************************
* Market work																		/* Universe: Age 12 and above */
******************************************

* Employment status (market work) in reference week
replace emp=1 if v16==1 | v17==1
replace emp=0 if v16==2 & v17==2 & v18==2
replace emp=2 if v16==2 & v17==2 & v18==1

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=3 if emp==2 & v19==1
replace reason=2 if emp==2 & v19==2
replace reason=5 if emp==2 & v19==3
replace reason=7 if emp==2 & (v19>=4 & v19<=8)

*Work status
replace emp_wj = 1 if v24 == 3 | v24 == 4 | v24 == 5	
replace emp_se = 1 if v24 == 1 | v24 == 2 | v24 == 6	
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* All jobs

* Actual hours worked in reference week
replace ahrswk_aj=v33
replace ahrswk_aj=0 if (emp==0 | emp==2) & v33==.

*-----------------------------------------

* Main job

* Actual hours worked in reference week
replace ahrswk_mj=v31
replace ahrswk_mj=0 if (emp==0 | emp==2) & v31==.

* Usual hours worked per week
replace uhrswk_mj=v34
replace uhrswk_mj=0 if (emp==0 | emp==2) & v34==.

*-----------------------------------------

* Sec job

* Actual hours worked in reference week
replace ahrswk_sj=v32
replace ahrswk_sj=0 if (emp==0 | emp==2) & v32==.


******************************************
* Hours worked by job characteristics
******************************************

*Generate indicators for main and sec job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if (v24>=3 & v24<=5)
replace mj_sa=1 if (v24==1 | v24==2 | v24==6) & (v22>=1 & v22<=5)
replace mj_sn=1 if (v24==1 | v24==2 | v24==6) & (v22>=10 & v22<=99)
replace mj_sx=1 if (v24==1 | v24==2 | v24==6) & v22==.
replace mj_uc=1 if v24==7

replace sj_wj=1 if (v30==3 | v30==4)
replace sj_sa=1 if (v30==1 | v30==2 | v30==5) & (v29>=1 & v29<=5)
replace sj_sn=1 if (v30==1 | v30==2 | v30==5) & (v29>=10 & v29<=99)
replace sj_sx=1 if (v30==1 | v30==2 | v30==5) & (v29==. | v29==0)
replace sj_uc=1 if v30==6

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*We only have main wage job income, cannot add anyone to sets 2 or three
replace ahrswk_wj_mj = ahrswk_mj if (v24>=3 & v24<=5)									//That's main job employee status
replace ahrswk_wj_aj = ahrswk_mj if (v24>=3 & v24<=5) & v28 == 2						//Has only one (wage) job
replace ahrswk_wj_aj = ahrswk_wj if (v24>=3 & v24<=5) & v28 == 1 & (v30==3 | v30==4)	//Multiple wage jobs

replace flag_set1 = 1 if (v24>=3 & v24<=5) & v28 == 2
*Since we do not have total wage job income, cannot add individuals to set 2 or 3
replace flag_set2 = 1 if flag_set1 == 1 
replace flag_set3 = 1 if flag_set2 == 1 | ((v24>=3 & v24<=5) & v28 == 1 & (sj_sa == 1 | sj_sn == 1))

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=0
replace chrsx=2

*-----------------------------------------
gen ind = .
replace ind = 1 if inrange( v22,1,3)
replace ind = 2 if inrange( v22,5,39)
replace ind = 3 if inrange( v22,40,99)

*-----------------------------------------
*Income: Wage job
*-----------------------------------------
*1) From work last month
replace inc_wj_mj_tot_g = v26 if v24 == 3 | v24 == 4 | v24 == 5			//Employment section (Questionnaire part B), only employees

*-----------------------------------------
*Income: Self employment
*-----------------------------------------
*egen var1 = rowtotal(v369 v370),m										//Section 3.5
	*replace inc_se_o = var1

replace inc_se_mj_tot_g = v26 if v24 == 1 | v24 == 2 | v24 == 6			//Employment section, only self employed

*Total individual income
egen tot_wjse = rowtotal(inc_wj_mj_tot_g inc_se_mj_tot_g),m
replace ind_tot_wjse = tot_wjse

/* 
*-----------------------------------------
*Categories that are not used for income var
*-----------------------------------------
*2) from property last month
egen inc_property = rowtotal( v372 v373 v374), m
*3) from transfer income 
egen inc_transfer = rowtotal( v376 v377 v378 v379 v380 v381 v382 v383),m
*/

*Our standard variables (on household income)
bysort hid: egen hh_wj = total(v368),m
bysort hid: egen hh_se_bus = total(v369), m
bysort hid: egen hh_se_own = total(v370), m

egen tothh = rowtotal(hh_wj hh_se_bus hh_se_own),m
	replace inc_hh = tothh

***********************************************************
*Expenditures*
***********************************************************
gen expd = v341 //total monthly expenditures


* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars' expd
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
