local is a m w
foreach i in `is'{
	use data/world_analysis_individual_beta_`i'5, clear
	keep country beta_25
	rename beta_25 beta_w
	merge 1:1 country using data/world_analysis_individual_beta_`i'_wjse, keepusing(beta_2)
	rename beta_2 beta_e
	
	local lmin=-.3
	local lmax=.2
	
	sort beta_w
	gen d45=`lmin' if _n==1
	replace d45=`lmax' if _n==_N
		
	local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white))) aspectratio(1) xsize(3.5)"'
	
	twoway  (scatter beta_e beta_w if beta_e>=beta_w, msize(vsmall) mlab(country) mcolor(black) mlabpos(9)) ///
			(scatter beta_e beta_w if beta_e<beta_w, msize(vsmall) mlab(country) mcolor(black) mlabpos(3) msym(circle)) ///	
			(lfit d45 d45, lpattern(solid) lcolor(black)) ///
			, `options' legend(off) ylabel(-0.3(0.1)0.2, gmin gmax) ///
			xtitle({&beta}{sub:w} for Wage Workers) ///
			ytitle({&beta}{sub:w} for All Workers) 			
	
	graph export Alex/texinput/compare_betas_`i'.pdf, replace		
	
}
