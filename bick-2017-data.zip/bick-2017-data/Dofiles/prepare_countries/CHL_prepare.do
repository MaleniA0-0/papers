*******************************************************************************************
* Program: CHL_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Chile
*******************************************************************************************

use "Data\Chile\CASEN\Data\casen2009", clear
drop if o23==9																		/* Armed forces */

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=folio
replace pid=o
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=edad

* Gender
replace male=1 if sexo==1
replace male=0 if sexo==2

*-----------------------------------------

* Weight
replace wgt=expr

* Interview date (Missing)

*-----------------------------------------
rename educ EDUC
gen educ=.
replace educ=1 if e2!=6 | e3==1
replace educ=0 if e2==6 & e3==2
gen educlvl=.
replace educlvl=1 if e3==1 & e7t>=13 & e7t<16
replace  educlvl=0 if e3==1 & e7t<13



******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe: Age 12 and above */					
replace emp=1 if o1==1 | o2==1
replace emp=2 if o1==2 & o2==2 & o3==1
replace emp=0 if o1==2 & o2==2 & o3==2

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*-----------------------------------------

* Main Job

* Actual hours worked last week
replace ahrswk_mj=o16
replace ahrswk_mj=. if o16==999
replace ahrswk_mj=0 if ahrswk_mj==. & (emp==0 | emp==2)

*-----------------------------------------

* Hours worked by job nature
replace ahrswk_wj=ahrswk_mj if (o23>=3 & o23<=7)
replace ahrswk_sa=ahrswk_mj if (o23==1 | o23==2 | o23==8) & (c_o13>=1000 & c_o13<2000)
replace ahrswk_sn=ahrswk_mj if (o23==1 | o23==2 | o23==8) & (c_o13>=2000 & c_o13<=9600)
replace ahrswk_sx=ahrswk_mj if (o23==1 | o23==2 | o23==8) &  c_o13==0

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
