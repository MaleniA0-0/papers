*******************************************************************************************
* Program: BOL_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Bolivia
*******************************************************************************************

use "Data\Bolivia\EH 2005\Data\BASE EH 2005 (Pob y Viv)", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=folio
replace pid=nro1
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=s1_03

* Gender
replace male=1 if s1_02==1
replace male=0 if s1_02==2

*-----------------------------------------

* Weight
replace wgt=factor

* Interview date
replace refdatex=0
replace startdate=mdy(11,1,2005)
replace enddate=mdy(12,31,2005)
format startdate enddate %td

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if s3_04==1
replace educ=0 if s3_04==2
gen educlvl=.
replace educlvl=1 if s3_05a>=21 & s3_05a!=.			
*25 and higher for vocational training
replace educlvl=0 if s3_05a<21

******************************************
* Market work																		/* Universe: Age 7 and above */
******************************************

* Employment status (market work) in reference week
replace emp=1 if s4_01==1 | (s4_02>=1 & s4_02<=6)
replace emp=0 if s4_01==2 & s4_02==7 & s4_03a==8
replace emp=2 if s4_01==2 & s4_02==7 & (s4_03a>=1 & s4_03a<=7)

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=2 if emp==2 & s4_03a==1
replace reason=3 if emp==2 & s4_03a==2
replace reason=4 if emp==2 & s4_03a==4
replace reason=7 if emp==2 & (s4_03a==3 | (s4_03a>=5 & s4_03a<=7))

*-----------------------------------------

* Main job

* Actual days worked last week
replace adayswk_mj=s4_27a
replace adayswk_mj=0 if (emp==0 | emp==2) & s4_27a==.

* Usual hours worked per day last week
replace uhrsday_mj=s4_27b
replace uhrsday_mj=0 if (emp==0 | emp==2) & s4_27b==.

*-----------------------------------------

* Sec job

* Actual days worked last week
replace adayswk_sj=s4_43a
replace adayswk_sj=0 if (emp==0 | emp==2) & s4_43a==.

* Usual hours worked per day last week
replace uhrsday_sj=s4_43b1
replace uhrsday_sj=0 if (emp==0 | emp==2) & s4_43b1==.

*Paul: In Masterhours.do, bolivia hours are generated as:
		/*
		replace adayswk_sj=0 if adayswk_sj==.
		replace uhrsday_sj=0 if uhrsday_sj==.
		replace adayswk_mj=0 if adayswk_mj==.
		gen hrs = (adayswk_mj*uhrsday_mj+adayswk_sj*uhrsday_sj)
		*/
******************************************
* Hours worked by job characteristics
******************************************

* Generate indicators for agricultural vs non-agricultural industries for main and sec jobs

gen a=0
replace a=1 if s4_17cod=="01"|	s4_17cod=="011"|	s4_17cod=="0111"|	s4_17cod=="01111"|	s4_17cod=="01111002"|	s4_17cod=="01111011"|	s4_17cod=="01112007"|	s4_17cod=="01112013"|	s4_17cod=="01113001"|	s4_17cod=="01114001"|	s4_17cod=="01115"
replace a=1 if s4_17cod=="01116"|	s4_17cod=="01116001"|	s4_17cod=="01116008"|	s4_17cod=="01117002"|	s4_17cod=="0112"|	s4_17cod=="01121006"|	s4_17cod=="01122"|	s4_17cod=="01122012"|	s4_17cod=="01123"|	s4_17cod=="01124002"|	s4_17cod=="01127"
replace a=1 if s4_17cod=="0113"|	s4_17cod=="01131003"|	s4_17cod=="01132"|	s4_17cod=="01132005"|	s4_17cod=="01133029"|	s4_17cod=="01133033"|	s4_17cod=="01136015"|	s4_17cod=="01137001"|	s4_17cod=="01139"|	s4_17cod=="01139001"|	s4_17cod=="01139008"
replace a=1 if s4_17cod=="012"|	s4_17cod=="0121"|	s4_17cod=="01211"|	s4_17cod=="01211006"|	s4_17cod=="01212"|	s4_17cod=="01212001"|	s4_17cod=="01212002"|	s4_17cod=="01212003"|	s4_17cod=="01213"|	s4_17cod=="01213001"|	s4_17cod=="01213003"
replace a=1 if s4_17cod=="01214"|	s4_17cod=="01214001"|	s4_17cod=="0122"|	s4_17cod=="01221"|	s4_17cod=="01221001"|	s4_17cod=="01221002"|	s4_17cod=="01221005"|	s4_17cod=="01222"|	s4_17cod=="01300001"|	s4_17cod=="01401"|	s4_17cod=="01401001"|	s4_17cod=="01401005"|	s4_17cod=="01404002"|	s4_17cod=="01404003"
replace a=1 if s4_17cod=="0200"|	s4_17cod=="02001004"|	s4_17cod=="02001007"|	s4_17cod=="02002003"|	s4_17cod=="02002099"|	s4_17cod=="02009"|	s4_17cod=="02009005"|	s4_17cod=="0501"|	s4_17cod=="05012"|	s4_17cod=="05021002"
replace a=. if s4_17cod==""

gen b=0
replace b=1 if s4_39cod=="011"|	s4_39cod=="01111"|	s4_39cod=="01111002"|	s4_39cod=="01111010"|	s4_39cod=="01112007"|	s4_39cod=="01112013"|	s4_39cod=="01116001"|	s4_39cod=="01118099"|	s4_39cod=="01119"|	s4_39cod=="01119099"|	s4_39cod=="01121"
replace b=1 if s4_39cod=="01125003"|	s4_39cod=="01131003"|	s4_39cod=="01132"|	s4_39cod=="01137"|	s4_39cod=="01139001"|	s4_39cod=="01139008"|	s4_39cod=="012"|	s4_39cod=="0121"|	s4_39cod=="01211"|	s4_39cod=="01212001"|	s4_39cod=="01212002"
replace b=1 if s4_39cod=="01213003"|	s4_39cod=="01214"|	s4_39cod=="01221"|	s4_39cod=="01221001"|	s4_39cod=="01222"|	s4_39cod=="01300001"|	s4_39cod=="0140"|	s4_39cod=="01401001"|	s4_39cod=="01401005"|	s4_39cod=="01401099"|	s4_39cod=="01403"|	s4_39cod=="01403006"|	s4_39cod=="01404002"|	s4_39cod=="0200"
replace b=. if s4_39cod==""

*Generate indicators for main and sec job nature
local jobs mj sj
local nature wj sa sn sx
local time adayswk uhrsday

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if s4_21==1 | s4_21==2 | s4_21==8
replace mj_sa=1 if (s4_21>=3 & s4_21<=7) & a==1
replace mj_sn=1 if (s4_21>=3 & s4_21<=7) & a==0
replace mj_sx=1 if (s4_21>=3 & s4_21<=7) & a==.

replace sj_wj=1 if s4_40==1 | s4_40==2 | s4_40==8
replace sj_sa=1 if (s4_40>=3 & s4_40<=6) & b==1
replace sj_sn=1 if (s4_40>=3 & s4_40<=6) & b==0
replace sj_sx=1 if (s4_40>=3 & s4_40<=6) & b==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
