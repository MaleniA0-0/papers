quiet{

local category 12 23 13
local gs a // m f
*local as non_young // all young prime old
local xs 10 1 2 3 5

********** Permutation tests between adjacent quartiles **********

foreach t in edu ind{
if "`t'"=="edu"{
	local vs hwp // er hwe
	local as non_young
}
else{
	local vs hwe
	local as all
}

foreach c in `category' {
foreach v in `vs' {
foreach g in `gs' {
foreach a in `as' {
foreach x in `xs' {

use Data/Cleaned_data/repl_master_stats, clear
drop p
keep if coreDummy==1

if `c'==12 {
keep if q_${z}==1 | q_${z}==2
local ql=1
local qh=2
}

if `c'==23 {
keep if q_${z}==2 | q_${z}==3
local ql=2
local qh=3
}

if `c'==13 {
keep if q_${z}==1 | q_${z}==3
local ql=1
local qh=3
}

gen v="`v'"
gen g="`g'"
gen a="`a'"
gen t="`t'"
gen x=`x'
gen ql=`ql'
gen qh=`qh'

if `x'==10{
	local z `v'_`g'_all
}
else{
	local z `v'_`g'_`a'_`t'`x' 
}

permute `z' avg_hrs=r(mean), nodrop nodots reps(${reps}): summarize `z' if q_${z}==`ql'

matrix rp=r(p)
gen p=rp[1,1] 

sum `z' if q_${z}==`ql'
gen d=round(r(mean),.1) 

sum `z' if q_${z}==`qh'
replace d=d-round(r(mean),.1) 
if "`v'"=="er" replace d=d*100 

keep if _n==1
keep v g a t x ql qh p d
save Data/ptest_`v'`g'`a'`t'`x'`c', replace

}
}
}
}
}
}

clear

foreach t in edu ind{
if "`t'"=="edu"{
	local vs hwp // er hwe
	local as non_young
}
else{
	local vs hwe
	local as all
}

foreach c in `category' {
foreach v in `vs' {
foreach g in `gs' {
foreach a in `as' {
foreach x in `xs' {
	append using Data/ptest_`v'`g'`a'`t'`x'`c'
}
}
}
}
}
}
save Data/ptest_edu_ind, replace
}
