**********************************************************************************************************
* Program: prepare_hh_wjse_world.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos
*---------------------------------------------------------------------------------------------------------*
* Purpose: 	Loops over the harmonized country Datafiles to compute a micro world-dataset containing hours and
*			wage rates based on earnings from paid and self-employment activities. 
* Structure:
*			1) 	Read in country dataset. For section (6) of the published paper, the analysis builds on 
*				EU-SILC data instead of the EU-LFS surveys. Cleaning & Identifying relevant observations. 
*				Depending on the country, the correct wage rate is saved as local.
*			2)	Checks: Compute share of missing observations
*			3) 	Construct deciles for wage rates and classify the individuals accordingly. Repeat for wage 
*				percentiles.
*			4)	Keep relevant variables and append all country datasets
**********************************************************************************************************

clear all
/*
*Generate an empty dataset to be filled while running. Unmarking this section rewrites the original dataset.
set obs 1
gen country = "."
gen hid = "."
gen pid = .
saveold "Data\Cleaned_data/wjse_world_dataset.dta", version(12) replace
clear
*/

local non_eulfs ALB ECU PER COL GHA TUR VNM KEN TLS RWA IRQ UGA MUS MWI BWA PAK KHM MNG TZA USA  //BEL_silc BGR_silc  ROM_silc CHE_silc CYP_silc CZE_silc DEU_silc DNK_silc ESP_silc EST_silc FIN_silc FRA_silc GBR_silc GRC_silc HUN_silc IRL_silc ITA_silc LTU_silc LVA_silc NLD_silc POL_silc PRT_silc  SVK_silc SVN_silc SWE_silc NOR_silc
local eulfs AUT BEL BGR  ROM CHE CYP CZE DEU DNK ESP EST FIN FRA GBR GRC HUN IRL ITA LTU LVA NLD POL PRT SVK SVN SWE

local countries non_eulfs eulfs
local a all

*quiet {
foreach set in `countries' {
foreach country in ``set'' {

local incvar hr_wage_hh									//For those countries where no individual level self-employment earnings avail.
local sample 
local ws & (emp_wj == 1 | emp_se == 1)

*For the following countries, we have different individual-level wage rates from paid & self-employment activities
if  ("`country'" == "GHA" | "`country'" == "BWA" | "`country'" == "MNG" | "`country'" == "ECU" | "`country'" == "COL" | "`country'" == "PER" | "`country'" == "IDN" | "`country'" == "MUS") {
	local incvar hr_wage_wjse
}
if "`country'" == "PAK" | "`country'" == "TUR" | "`country'" == "USA" {
	local incvar hr_wage
	local sample & flag_set5 == 1
	local ws & emp_wj == 1

}

local t hr
local sample 

global income_stats country	
local income_vars inc_`incvar'_`t'
	
	if "`set'" == "non_eulfs"	{
		use "Data\Cleaned_data/`country'_all_std.dta", clear
	}
	if "`set'" == "eulfs" {	
		use "Data\Cleaned_data/`country'_silc_all_std.dta", clear	
		local incvar hr_wage_wjse
	}

	replace flag_set4=1 if flag_set3==1
	replace flag_set4=0 if flag_set4==.

	gen flag_set5=flag_set4
	*Identify non-missing wages & hours
	replace flag_set5=1 if (hrs_wj==. & hrs!=.) & (hr_wage==. & inc_wj_hr!=.) & flag_set4==0

	*Replace new wage and hrs_wj = old wage and hrs if set5:
	replace hrs_wj = hrs if flag_set5==1 & flag_set4==0 
	replace hr_wage = inc_wj_hr if flag_set5==1 & flag_set4==0 
	
	*Housekeeping
	display "We are in `country' `incvar' `a' Loop!"
	capture noisily: gen country = "`country'"

	egen totwgt = total(wgt)
	gen unit_wgt = wgt/totwgt																	//Standardized to unity weights

	gen i = 0
	replace i = 1 if (`incvar' > 0 & `incvar' != .) & age_`a' == 1	 `sample'					//Indicator for available wage job/hh_pe income	

	*Generate share of observations with missing wj income over work status employee
	sum flag_set_hhse
	local m = r(mean)
	if `m' == 1 {	//These guys have no individual level self employment income
		gen wgt_test = wgt if `incvar' == . & employed == 1  & age_`a' == 1 `ws'
		egen wgt_incemp = total(wgt_test),m
		count if `incvar' == . & employed == 1  & age_`a' == 1 `ws'
		if r(N) == 0 {
			replace wgt_incemp = 0
		}
	}
	
	if `m' == 0 {	//These guys have individual-level self employment earnings avail.
		gen wgt_test = wgt if `incvar' == . & employed == 1  & age_`a' == 1 `ws'
		egen wgt_incemp = total(wgt_test),m
		count if `incvar' == . & employed == 1  & age_`a' == 1 `ws'
		if r(N) == 0 {
			replace wgt_incemp = 0
		}
	}	
	drop wgt_test
	
	gen wgt_test = wgt if employed == 1  & age_`a' == 1 `ws'
	egen wgt_wsemp = total(wgt_test),m
		drop wgt_test	
	gen sh_mwjse_ws_hr_`a' = wgt_incemp/wgt_wsemp
		label variable sh_mwjse_ws_hr_`a' "Share missing job income/work status available"

	if "`incvar'" == "hr_wage_hh" {
		keep if employed == 1
	}	

	*Keep all w/ available wage rate and in age category and in samples 1-5:
	keep if i == 1
	gen num_obs = _N
	
	*Classify observations into deciles (based on hourly income rate)
	sort `incvar'												//Sorting based on hourly wage rate values
	gen n = sum(wgt)											//Sum of weights up to observation _n
	egen N = total(wgt)											//Total sum of weights
	gen `incvar'_pctl = n/N
		label variable `incvar'_pctl "Percentile, based on `incvar'"
	gen `incvar'_dec = 0
		label variable `incvar'_dec "Decile, based on `incvar'"
	
	*Classify observations into deciles (based on hourly work income)
	forvalues num = 0/9 {
		replace `incvar'_dec = `incvar'_dec + 1 if n/N >= `num'/10
	}
	forvalues num = 1/10 {
		sum `incvar' [aweight = wgt] if `incvar'_dec == `num' 
			local dec`num'_min = r(min)
			local dec`num'_max = r(max)
		
		local num_m1 = `num'-1
		local t`num' = (`dec_`num_m1'_max' + `dec`num'_min')/2
		
		replace `incvar'_dec = `incvar'_dec - 1 if `incvar' <= `t`num'' & `incvar'_dec == `num'
	}
	
	*Classify observations into percentiles (based on hourly work income)	
	forvalues num = 1/100 {
		replace `incvar'_pctl = `num' if (`incvar'_pctl < `num'/100 & `incvar'_pctl >= (`num'-1)/100)
	}
	forvalues num = 1/100 {
		sum `incvar' [aweight = wgt] if `incvar'_pctl == `num' 
			local dec`num'_min = r(min)
			local dec`num'_max = r(max)
		
		local num_m1 = `num'-1
		local t`num' = (`dec_`num_m1'_max' + `dec`num'_min')/2
		
		replace `incvar'_pctl = `incvar'_pctl - 1 if `incvar' <= `t`num'' & `incvar'_pctl == `num'
	}	

capture noisily gen a_hrs_m = . 	
rename a_hrs_m hrs_a_mj
local income_vars hr_wage hr_wage_wjse hr_wage_hh `incvar'_dec `incvar'_pctl sh_mwjse_ws_hr_`a'
local hrs_vars hrs hh_hrs_pe hrs_wj hrs_a_mj									//hrs_u hrs_u_mj hrs_u_aj
local flags flag_set1 flag_set2 flag_set3 flag_set4 flag_set5 flag_set_hhse flag_set_nose flag_set_nosj 
local covars country hid pid age age_`a' male edu ind unit_wgt num_obs employed

keep `income_vars' `hrs_vars' `flags' `covars' 
order `income_vars' `hrs_vars' `flags' `covars' 
		
	*resolve some trouble with string hh identifiers	
	if "`country'" == "RWA" { // | "`country'" == "TLS" {
		gen hidt = "." 
		replace hidt = string(hid)
		drop hid
		rename hidt hid
	}	
	if "`country'" == "TLS" | "`set'" == "eulfs"{
		gen hidt = "." 
		replace hidt = string(hid, "%02.0f")
		drop hid
			rename hidt hid	
		}
	
if "`country'" == "ALB" {
	merge m:m country pid using "Data\Cleaned_data/wjse_world_dataset.dta", 
	
}
if "`country'" != "ALB" {
	merge 1:m country hid pid using "Data\Cleaned_data/wjse_world_dataset.dta", 
}
	drop _merge
	
	
drop if country == "."	
saveold "Data\Cleaned_data/wjse_world_dataset.dta", version(12) replace

}
}
order country hid pid employed hrs hh_hrs hrs_wj hrs_a_mj hr_wage hr_wage_wjse hr_wage_hh  hr_wage_wjse_dec hr_wage_wjse_pctl hr_wage_hh_dec hr_wage_hh_pctl sh_mwjse_ws_hr_`a'
saveold "Data\Cleaned_data/wjse_world_dataset.dta", version(12) replace

use "Data\Cleaned_data/wjse_world_dataset.dta", clear
bysort country: keep if _n == 1
keep country sh_mwjse_ws_hr_all 

merge 1:1 country using "Data/Cleaned_data/master_stats.dta", 
drop _merge
saveold "Data/Cleaned_data/master_stats.dta", replace version(12)


*Checking data
use "Data\Cleaned_data/wjse_world_dataset.dta", clear

gen id0 = 0
replace id0 = 1 if hr_wage_wjse > 0 & hr_wage_wjse != .

gen id1 = 0
replace id1 = 1 if hr_wage_hh > 0 & hr_wage_hh != .

gen id2 = 0
	replace id2 = 1 if hr_wage > 0 & hr_wage != .

gen id3 = 0
replace id3 = 1 if id0 == 1 | id2 == 1
	
tab id0 id1
*1) Why so many individual income observations without HH income observations?
	tab country if id0 == 1 & id1 == 0												
*	Driven by Indonesia (and some few obs. by EUSilc)

*2) Why do we have observations with no hr_wahe_wjse and no hh_income?
	tab country if id0 == 0 & id1 == 0												
*	That's only USA, where we use hr_wage, no total individual income from se and wj!
*	These guys have missing total hours, but avail. usual main job hours

*3) What are countries with missing individual wage but avail. HH wage?
*	Should be KHM, TLS, RWA, VNM, TZA, IRQ UGA MWI KEN
	tab country if id0 == 0 & id1 == 1 	
*	PAK, TLS, TUR USA are also in - what's going on???	
*	PAK, TUR & USA have no hr_wage_wjse - we use hr_wage as in wage income regressions. Check!

*-------------------------------------------------------------------------*
*4) Check: HH wage rate against (either hr_wage or hr_wage_wjse available)	
	tab id3 id1
*	Good: Zero overlap where both incomes would be N/A
	
	tab country if id3 == 0 & id1 == 1
*	Good, that exactly the same as in pt. (3)

	tab country if id3 == 1 & id1 == 0
*	Good that's again mainly Indonesia, but also 2922 from USA: These guys have 
*	missing total hours, but avail. usual hours! (see above, pt.2)

*5)	Negative HH hourly wage rates? 
*	Yes, that happens when we use se_wj hourly wage rate to generate percentiles/deciles.
*	Note that we only have negative HH WAGE RATES, and this only if wj_se wage rate is used for pctls.

*6) Check if flag_set1 and 2 yield same hourly wage rates?! 
	sum hr_wage hr_wage_wjse if flag_set1 == 1 & hr_wage_wjse != . & hr_wage > 0
	tab country if hr_wage != hr_wage_wjse & flag_set1 == 1 & hr_wage_wjse != . & hr_wage > 0	//This was EUSilc, is corrected!
	count if flag_set1 == 1 & (hr_wage != hr_wage_wjse) //
	count if flag_set1 == 1 & (hr_wage != hr_wage_wjse) & (hr_wage_wjse != . & hr_wage != .) & hr_wage > 0
*	keep if hr_wage != hr_wage_wjse & flag_set1 == 1 & hr_wage_wjse != . & hr_wage > 0

*	Something with se income is going on: Already corrected EuSilc, where we had tons of people responding to have
*	no second job hours and being employee - but had second job income. Kicked them out of set 1, into set 3.
*	I think for BWA, COL GHA MNG & PER there also have to be some ind stating no sj but then they have self employment hours anyways.
*	Check it on MONDAY!
	
*	Checking flag_set2
	sum hr_wage hr_wage_wjse if flag_set2 == 1 & hr_wage_wjse != . & hr_wage > 0
	tab country if hr_wage != hr_wage_wjse & flag_set2 == 1 & hr_wage_wjse != . & hr_wage > 0	//This was EUSilc, is corrected!
	count if flag_set2 == 1 & (hr_wage != hr_wage_wjse) //
	count if flag_set2 == 1 & (hr_wage != hr_wage_wjse) & (hr_wage_wjse != . & hr_wage != .) & hr_wage > 0
*	Same countries, same issues & observations!
	
	
	sum hr_wage hr_wage_wjse if flag_set2 == 1 & hr_wage_wjse != . & hr_wage > 0

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
*****SOMETHING IS MIXED!*****


gen hm_n=hrs																	//Hrs = total hours: Baseline		
gen wl_n=hr_wage_wjse															
replace hm_n=hh_hrs_pe  if flag_set_hhse==1										//Hrs = HH hrs for countries with HH lvl se income
replace wl_n=hr_wage_hh if flag_set_hhse==1										
gen w_dec= hr_wage_wjse_dec														//Baseline: We use wjse income to gen deciles									
replace w_dec= hr_wage_hh_dec if flag_set_hhse==1

*Paul (23.02.2017): 
*Need to use main job hours for IDN and MUS. Wage used is correct
 replace hm_n=hrs_a_mj  if flag_set_nosj==1									
*Paul: What about USA, TUR & PAK? These guys do not have self employment, recode using wage and hrs in wage job
 replace hm_n = hrs_wj if flag_set_nose == 1
 replace wl_n = hr_wage if flag_set_nose == 1
 replace w_dec = hr_wage_dec if flag_set_nose == 1

foreach v in hm_n wl_n{
	replace `v'=. if hr_wage_wjse_pctl==1 | hr_wage_wjse_pct==100
	replace `v'=. if (hr_wage_hh_pctl==1 | hr_wage_hh_pct==100) & flag_set_hhse==1
	
	replace `v'=. if (hr_wage_pctl==1 | hr_wage_pct==100) & flag_set_nose == 1	
	//Do we need more conditions here? Should be kicking out PAK & TUR flag_set3? USA?

}


sum wl_n hr_wage if flag_set1 == 1

