clear all

foreach t in ind {
	
	local cs 13 12 23
	local xs 10 5 1 2 3
		
	clear all
	use data/ptest_edu_ind, clear 
	gen cs=ql*10+qh

	
	local r10 All

	keep if t=="`t'"

	if "`t'"=="edu"{
		*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		* Education
		*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
		local v hwp // er hwe
		local g a
		local a non_young // young prime old
		
		local r1 Less than Secondary
		local r2 Secondary Completed
		local r3 More than Secondary
		local r5 Ages 25+ (\textit{Non-missing Educ.}) // $ ^\dag $
	}
	else{
		*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		* Sector
		*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
		local v hwe // er hwe
		local g a
		local a all // young prime old
		
		local r1 Agriculture
		local r2 Manufacturing
		local r3 Services
		local r5 All (\textit{Non-missing Sec.}) // $ ^\dag $		
	}	
			

	foreach c in `cs'{	
	foreach x in `xs'{
		di `c' "   `v' "
		sum d if cs==`c' & v=="`v'" & g=="`g'" & a=="`a'" & x==`x' 
		local d`c'`x'=r(mean)
		qui sum p if cs==`c' & v=="`v'" & g=="`g'" & a=="`a'" & x==`x'
		local p`c'`x'=r(mean) 
	}
	}
	*if "`t'"=="ind" stop
		
	
	*#################################################################
	* Tex Table Generation
	*#################################################################
	
	local cs 13 12 23
	
	********************************
	* Settings
	********************************
	
	global name="tab_permut_`t'_`a'_${z}"
	global write="file write ${name}"
	global nextl=`"${write} ("\\") _n"'
	global lastl=`"${write} ("\end{tabular}")"'
	global close="file close ${name}"
	
local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"		
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace
	
	***************************************************************
	* Start table
	***************************************************************
	
	$write ("\begin{tabular}{l D{.}{.}{1,2} D{.}{.}{1,2} D{.}{.}{1,2}}") _n
	$write ("\tabularnewline\hline\hline") _n
	$write ("Education   & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
	$write ("&  \multicolumn{1}{c}{ Low-High } & \multicolumn{1}{c}{ Low-Middle } & \multicolumn{1}{c}{  Middle-High } \\\hline") _n
	
	foreach x in `xs'{
		$write ("`r`x''")
		global digit 1
		foreach c in `cs'{
			$write ("& ")
			global var `d`c'`x''		
			`do1'
		}
		$write ("\\[-.2cm]") _n
		global digit 2
		foreach c in `cs'{
			$write ("& ")
			global var `p`c'`x''
			`do2'
		}	
		$write ("\\") _n
		
		if `x'==5{
			if "`t'"=="edu"{
				$write ("\hline {Ages 25+} \\ ") _n			
			}
			else{
				$write ("\hline") _n			
			}
		}
	}
	$write ("\hline") _n
	*#################################################################
	${lastl}
	${close}
	*#################################################################
		
} // edu ind

