******************************************************************************************
* Program: PER_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constrcts harmonized individual employment and hours worked data for Peru
******************************************************************************************

use "Data\Peru\ENAHO 2004 & 2010\2010\PER_merged", clear 

* Initialize variables 
qui do Dofiles/initialize_variables

*-----------------------------------------

* Generate household and personal id
replace hid=conglome+"-"+vivienda+"-"+hogar
destring codperso, replace
replace pid=codperso

order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if p203 == 1 //Reference Person
replace hh_link = 2 if p203 == 2 //Spouse/Husband
replace hh_link = 3 if p203 == 3  | p203 == 4 | p203 == 5 //child, grand child
replace hh_link = 4 if  p203 == 6 //Ascendant (parent, grand parent)
replace hh_link = 98 if  p203 == 8 | p203 == 10 //Not related
replace hh_link = 99 if  p203 ==7  //Others 

*-----------------------------------------

* Age 	
gen age=p208a

* Gender
replace male=1 if p207==1
replace male=0 if p207==2

*-----------------------------------------

* Weight
replace wgt=fac500a7
gen hh_wgt = .		//There is factor07, but that is not a household weight, rather an adjusted weight based on some population projections

* Interview dates 
replace refdatex=1
destring p500a p500b p500c p500d, replace
replace startdate=mdy( p500b, p500a, p500b1)
replace enddate=mdy( p500d, p500c, p500d1)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if p307==1
replace educ=0 if p307==2
gen educlvl=.
replace educlvl=1 if p308a>=5 & p308a!=.
replace educlvl=0 if p308a<=4 & p308a!=1

gen edu = .
replace edu =1 if inrange(p301a,1,4)
replace edu =2 if inrange(p301a,5,6)
replace edu = 3 if inrange(p301a,7,11)
******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe: Age 14 and above */
egen work=anymatch(p501 p5041-p50411), values(1)	
egen all=rowtotal(p501 p5041-p50411), missing
replace work=. if all==.
replace emp=1 if work==1
replace emp=2 if work==0 & (p502==1 | p503==1)
replace emp=0 if work==0 & p502==2 & p503==2

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*Work status
replace emp_wj = 1 if p507 == 3 | p507 == 4
replace emp_se = 1 if p507 == 1 | p507 == 2 | p507 == 5 | p507 == 6
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* All jobs

* Usual hours per week
replace uhrswk_aj=p520
replace uhrswk_aj=0 if p520==. & (emp==0 | emp==2)

*-----------------------------------------

* Main job

* Actual hours worked last week
replace ahrswk_mj=p513t
replace ahrswk_mj=0 if p513t==. & (emp==0 | emp==2)

*-----------------------------------------

* Sec job

* Actual hours worked last week
replace ahrswk_sj=p518 
replace ahrswk_sj=0 if p518==. & (emp==0 | emp==2)

*-----------------------------------------
		
* Hours worked by job nature 

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn uc
local time ahrswk 

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

*14.02.2017: Paul changed ws in p507 & p517: Code 3 AND 4 are ws employee (empleado = employee, obrero = worker)
replace mj_wj=1 if p507==4 | p507 == 3
replace mj_sa=1 if (p507==1 | p507==2  | p507==5 | p507==6) & (p506>=111 & p506<=500)
replace mj_sn=1 if (p507==1 | p507==2  | p507==5 | p507==6) & (p506>500 & p506<=9900)
replace mj_uc=1 if p507==7

replace sj_wj=1 if p517==4 | p517==3
replace sj_sa=1 if (p517==1 | p517==2 | p517==5 | p517==6) & (p516>=111 & p516<=500)
replace sj_sn=1 if (p517==1 | p517==2 | p517==5 | p517==6) & (p516>500 & p516<=9900)
replace sj_uc=1 if p517==7

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*We have main and second wage job income
egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m

*check
gen id = 0
replace id = 1 if ahrswk_sj > 0 & ahrswk_sj != .

*Need second wj indicator
gen indic_sj = .
replace indic_sj = 0 if p514 == 2 
replace indic_sj = 0 if p514 == . & (ahrswk_sj==0 | ahrswk_sj == .)
replace indic_sj = 1 if p514 == 1
replace indic_sj = 1 if p514 == 2 & (ahrswk_sj > 0 & ahrswk_sj != .)								//Some people say no to p514, but still have sj
replace indic_sj = 1 if p514 == . & (ahrswk_mj != . & (ahrswk_sj > 0 & ahrswk_sj != .))				//Missing sj question, but has mj and sj hours: Redundant

replace ahrswk_wj_mj = ahrswk_mj if p507==4 | p507 == 3
replace ahrswk_wj_aj = ahrswk_wj_mj if indic_sj == 0 												//Had no other jobs except main wage job
replace ahrswk_wj_aj = ahrswk_wj_mj if indic_sj == 1 & (p517!=4 & p517 != 3)						// Has additional, non wage job							
replace ahrswk_wj_aj = ahrswk_wj if (p507==4 | p507 == 3) & indic_sj == 1 & (p517==4 | p517 == 3) 							//Had additional, but wage job

replace flag_set1 = 1 if (p507 == 3 | p507==4) & indic_sj == 0							//That's individuals with one (main) wage job only
replace flag_set2 = 1 if flag_set1 == 1 | ((p507 == 3 | p507==4) & indic_sj == 1 & (p517 == 3 | p517==4))		//Indidivuals with one or two wj, no se
replace flag_set3 = 1 if flag_set2 == 1 | ((p507 == 3 | p507==4) & indic_sj == 1 & (p517==1 | p517==2 | p517==5 | p517==6))		//individuals with multiple jobs, also se hrs

gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1
*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

gen ind = .
replace ind = 1 if inrange(p506r4,0,322)
replace ind = 2 if inrange(p506r4,510,3900)
replace ind = 3 if inrange(p506r4,4100,9900)

*-----------------------------------------
*Income Wage jobs
*-----------------------------------------
*1) Main Job (employed, cash): Standardize to monthly income
gen days_worked = 0
local alph a b c d e f g
foreach alph in `alph' {
	replace days_worked = days_worked+1 if p513`alph' != 0 & p513`alph' != .
}

local netgross e a 
foreach ea in `netgross' {
*Generate net (e) /gross (a)  income from main wage job
replace p524`ea'1 = . if p524`ea'1 >= 999999											//Missings
	gen inc_daily`ea' = p524`ea'1*days_worked*52/12 if p523 == 1						//Diario --> Monthly
	gen inc_weekly`ea' = p524`ea'1*52/12 if p523 == 2									//Semanal --> Monthly
	gen inc_twowkly`ea' = p524`ea'1*26/12 if p523 == 3									//Quincenal --> Monthly
	gen inc_monthly`ea' = p524`ea'1 if p523 == 4										//Mensual --> Monthly	
	
	if "`ea'" == "e" {
		local net inc_daily`ea' inc_weekly`ea' inc_twowkly`ea' inc_monthly`ea'
	}
	if "`ea'" == "a" {
		local gross inc_daily`ea' inc_weekly`ea' inc_twowkly`ea' inc_monthly`ea'		//Redundant
	}
}
 	*Standard variable: Net main job income in wage, cash only
	egen wj_mj_c_net = rowtotal(`net'),m
		replace inc_wj_mj_c_n = wj_mj_c_net
 	*Gross main job income in wage, cash only
	egen wj_mj_c_mj_gross = rowtotal(`gross'),m
		replace inc_wj_mj_c_g = wj_mj_c_mj_gross	
	drop `net' `gross'

*Main Job (employed, in kind)
*--> Complicated to aggregate, due to 8 periodicities
local variables p5291 p5292 p5293 p5294 p5295 p5296					//amount of values: Alimentos, vestidos, transporte, vivienda, salud, otro
foreach v in `variables' {
	
	gen `v'_amount = `v'b
	replace `v'_amount = . if `v'_amount >= 999999
	
	replace `v'_amount = `v'_amount*days_worked*52/12 if `v'a == 1		//daily --> Monthly
	replace `v'_amount = `v'_amount*52/12 if `v'a == 2					//weekly --> Monthly
	replace `v'_amount = `v'_amount*26/12 if `v'a == 3					//bi-weekly --> Monthly
	replace `v'_amount = `v'_amount if `v'a == 4						//monthly 
	replace `v'_amount = `v'_amount/2 if `v'a == 5						//bi-monthly --> Monthly
	replace `v'_amount = `v'_amount/3 if `v'a == 6						//trimonthly --> Monthly
	replace `v'_amount = `v'_amount/6 if `v'a == 7						//half-year --> Monthly
	replace `v'_amount = `v'_amount/12 if `v'a == 8						//yearly --> Monthly
	
}
 egen wj_mj_inkind = rowtotal(p5291_amount p5292_amount p5293_amount p5294_amount p5295_amount p5296_amount), m
	replace inc_wj_mj_ik_o = wj_mj_inkind
 
*Standard variables: Sum main job payment in cash & kind
egen wjmj_tot_g = rowtotal(inc_wj_mj_c_g inc_wj_mj_ik_o),m
	replace inc_wj_mj_tot_g = wjmj_tot_g	if p507 == 3 | p507 == 4	//Only employees income coded here
egen wjmj_tot_n = rowtotal(inc_wj_mj_c_n inc_wj_mj_ik_o),m	
	replace inc_wj_mj_tot_n = wjmj_tot_n 	if p507 == 3 | p507 == 4	//Only employees income coded here
 
*2) Second job (employed, cash) 
 gen inc_wj_sj_c_n =  p538e1 										//monthly net
 	replace inc_wj_sj_c_n = . if inc_wj_sj_c_n >= 999999
	
 gen inc_wj_sj_c_g =  p538a1 										//monthly gross
 	replace inc_wj_sj_c_g = . if inc_wj_sj_c_g >= 999999
	
 *Second Job (employed, in kind)
local variables  p5401 p5402 p5403 p5404 p5405 p5406				//amount of value
foreach v in `variables' {
	
	gen `v'_amount = `v'b
		replace `v'_amount = . if `v'_amount >= 999999
	
	replace `v'_amount = . if `v'a == 1 				//daily: what do we do here?! We do not have days worked in second job!
	replace `v'_amount = `v'_amount*52/12 if `v'a == 2		//weekly
	replace `v'_amount = `v'_amount*26/12 if `v'a == 3		//bi-weekly
	replace `v'_amount = `v'_amount if `v'a == 4		//monthly
	replace `v'_amount = `v'_amount/2 if `v'a == 5		//bi-monthly
	replace `v'_amount = `v'_amount/3 if `v'a == 6		//trimonthly
	replace `v'_amount = `v'_amount/6 if `v'a == 7		//half-year
	replace `v'_amount = `v'_amount/12 if `v'a == 8		//yearly
	
}
 egen inc_wj_sj_ik_o = rowtotal(p5401_amount p5402_amount p5403_amount p5404_amount p5405_amount p5406_amount), m

 *Sum employment income in cash and kind, secnd job
 *egen inc_sj_wj_gross = rowtotal(inc_cash_sj_gross total_inkind_sj), m
 *egen inc_sj_wj_net = rowtotal(inc_cash_sj_net total_inkind_sj), m


*Other bonuses (main and second work together): Christmas, national holiday, holidays, schooling, business utilities, other labour utilities, overtime bonus, profits bonus
egen bonus = rowtotal(p5441b p5442b p5443b p5444b p5445b p5446b p5447b p5448b), m	
	replace bonus = bonus/12

****Our standard variables of wage incomes****:
 egen totc_net = rowtotal(inc_wj_mj_c_n inc_wj_sj_c_n bonus), m						//total main plus second and bonuses, cash net
	replace inc_wj_aj_c_n = totc_net
	
 egen totc_gross  = rowtotal(inc_wj_mj_c_g inc_wj_sj_c_g bonus), m					//total main plus second and bonuses, cash gross
	replace inc_wj_aj_c_g = totc_gross
 
 egen tot_ik = rowtotal(inc_wj_mj_ik_o inc_wj_sj_ik_o), m							//total inkind, don't know net/gross?!
	replace inc_wj_aj_ik_o = tot_ik
 
*Total of wage job income									
egen totwj_gross = rowtotal(inc_wj_aj_c_g inc_wj_aj_ik_o),m							//total gross wage jobs income, cash + inkind 
	replace inc_wj_aj_tot_g = totwj_gross if (p507 == 3 | p507 == 4) | ((p507 == 3 | p507 == 4) & (p517 == . | p517 == 3 | p517 == 4))
egen totwj_net = rowtotal(inc_wj_aj_c_n inc_wj_aj_ik_o),m							//total net wage jobs income, cash + inkind 		
	replace inc_wj_aj_tot_n = totwj_net  if (p507 == 3 | p507 == 4) | ((p507 == 3 | p507 == 4) & (p517 == . | p517 == 3 | p517 == 4))
	
*-----------------------------------------
*Income Self employment jobs
*-----------------------------------------
*2.1) Main Job (self employed/independent)
 gen inc_mj_se = p530a																//cash & inkind value, self employed, Monthly & net profits
	replace inc_mj_se = . if inc_mj_se >= 999999									//net = rev - costs?!
	replace inc_mj_se = . if inc_mj_se == 1 & p530b == 1							//I think mistake was made here, these people do not know their profits
 
 gen inc_mj_se_owncons = p536														//Cash value of own consonsumption, Monthly
 	replace inc_mj_se_owncons = . if inc_mj_se_owncons >= 999999

*Standard variable
 egen se_mjnet = rowtotal(inc_mj_se inc_mj_se_owncons), m
	replace inc_se_mj_tot_n = se_mjnet
 
 *2.2) Second job (self employed)
  gen inc_sj_se = p541a																//cash & inkind value, self employed Monthly & net
	replace inc_sj_se = . if inc_sj_se >= 999999
	replace inc_sj_se = . if inc_sj_se==1 & p541b == 1								//I think a mistake was made here: These people do not know their profits according to p541b
	
gen inc_sj_se_owncons = p543														//Cash value of own consonsumption, Monthly 
 	replace inc_sj_se_owncons = . if inc_sj_se_owncons >= 999999
	
 egen inc_se_sj_se_n = rowtotal(inc_sj_se inc_sj_se_owncons), m

*Our standard variables
egen tot_pers_se = rowtotal(inc_se_mj_tot_n inc_se_sj_se_n),m 
	replace inc_se_aj_tot_n = tot_pers_se

*Total individual income
egen tot_wjse = rowtotal(totwj_gross inc_se_aj_tot_n),m	
	replace ind_tot_wjse = tot_wjse
	
*-----------------------------------------
*Household Income - use net income measures
*-----------------------------------------	
bysort hid: egen hh_wj = total(totwj_gross),m 										
bysort hid: egen hh_se = total(inc_se_aj_tot_n),m 	

egen hh_sewj = rowtotal(hh_wj hh_se),m
	replace inc_hh = hh_sewj 

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars' 
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 



	
/*	*Checking values 
sum inc_wj_aj_tot_n inc_se_aj_tot_n inc_hh, d									//The ones in self employed come from own consumption. But here no way to find out if that is a "I do not know".
sum inc_mj_se inc_mj_se_owncons
*Check whether multiple individuals give same self employed income in hh
keep if inc_se_aj_tot_n != .
bysort hid: gen num = _n
tab num
count if inc_se_aj_tot_n[_n] == inc_se_aj_tot_n[_n-6]
order hid pid num hh_wj inc_wj_mj_tot_n inc_wj_mj_ik_o bonus hh_se inc_se_mj_tot_n inc_hh
*/
	 
/* Income forms that are excluded in our analysis 
*------------------------------------------------------------- 
*other income sources: renting, business, interest income....
*-------------------------------------------------------------

local variables p5571 p5572 p5573 p5574 p5575 p5576 p5577 p5578
foreach v in `variables' {
	
	gen `v'_amount = `v'c
		replace `v'_amount = . if `v'_amount >= 999999
	
	replace `v'_amount = `v'_amount*7 if `v'b == 1		//daily: ~90 cases
	replace `v'_amount = `v'_amount if `v'b == 2		//weekly
	replace `v'_amount = `v'_amount/2 if `v'b == 3		//bi-weekly
	replace `v'_amount = `v'_amount/4 if `v'b == 4		//monthly
	replace `v'_amount = `v'_amount/8 if `v'b == 5		//bi-monthly
	replace `v'_amount = `v'_amount/13 if `v'b == 6		//trimonthly
	replace `v'_amount = `v'_amount/26 if `v'b == 7		//half-year
	replace `v'_amount = `v'_amount/52 if `v'b == 8		//yearly
	
}
  egen total_other_inc = rowtotal(p5571_amount p5572_amount p5573_amount p5574_amount p5575_amount p5576_amount p5577_amount p5578_amount), m

*-------------------------------------------------------------
*other income sources: Transfers (focus on public transfers!)
*-------------------------------------------------------------
local variables  p5564 p5565 p5566 p5567
local aggr 
foreach v in `variables' {
	gen `v'_amount1 = `v'c 		//Domestic social sec. payments
		replace `v'_amount1 = . if `v'_amount1 >= 999999
	*replace `v'_amount1 = `v'_amount1*7 if `v'b == 1		//daily: 0 cases
	replace `v'_amount1 = `v'_amount1 if `v'b == 2		//weekly
	replace `v'_amount1 = `v'_amount1/2 if `v'b == 3		//bi-weekly
	replace `v'_amount1 = `v'_amount1/4 if `v'b == 4		//monthly
	replace `v'_amount1 = `v'_amount1/8 if `v'b == 5		//bi-monthly
	replace `v'_amount1 = `v'_amount1/13 if `v'b == 6		//trimonthly
	replace `v'_amount1 = `v'_amount1/26 if `v'b == 7		//half-year
	replace `v'_amount1 = `v'_amount1/52 if `v'b == 8		//yearly
	
gen `v'_amount2 = `v'e		//Foreign social sec. payments
		replace `v'_amount2 = . if `v'_amount2 >= 999999	
	*replace `v'_amount2 = `v'_amount2*7 if `v'd == 1		//daily: 0 cases
	replace `v'_amount2 = `v'_amount2 if `v'd == 2		//weekly
	replace `v'_amount2 = `v'_amount2/2 if `v'd == 3		//bi-weekly
	replace `v'_amount2 = `v'_amount2/2 if `v'd == 4		//monthly
	replace `v'_amount2 = `v'_amount2/8 if `v'd == 5		//bi-monthly
	replace `v'_amount2 = `v'_amount2/13 if `v'd == 6		//trimonthly
	replace `v'_amount2 = `v'_amount2/26 if `v'd == 7		//half-year
	replace `v'_amount2 = `v'_amount2/52 if `v'd == 8		//yearly
	
local aggr `aggr' `v'_amount1 `v'_amount2	
}

egen total_transfer_inc = rowtotal(`aggr'),m
*/
