use Data/Cleaned_data/repl_master_stats,replace

keep if coreDummy==1

local z ${z}

local gs a // f m
local vs hwp // er hwe

foreach g in `gs'{
foreach v in `vs'{
	rename `v'_`g'_85plus `v'_`g'_85_89
	gen `v'_`g'=0
}
}

expand 15

local al 10
local ah 14

drop n

sort country
by country: gen n=_n-1

gen ages=""
gen age=0

forvalues a=0/14{
	local al=`al'+5
	local ah=`ah'+5
	di "`al'_`ah'"
	foreach g in `gs'{
	foreach v in `vs'{	
		replace `v'_`g'=`v'_`g'_`al'_`ah' if n==`a'
	}
	}
	replace age=(`al'+`ah')/2 if n==`a'
}


sort q_`z' n country
by q_`z' n: gen cid=_n

* Graph specifiers
local rhwe 0(5)50
local thwe Hours per Week

local rhwp 0(5)50
local thwp Hours per Week

local rer 0(10)100
local ter Employment Rate (in %)

foreach g in `gs'{
foreach v in `vs'{

	gen `v'_`g'_n=`v'_`g' if n==5
	sort country n
	by country: egen m=min(`v'_`g'_n)
	replace `v'_`g'_n=`v'_`g'/m 
	drop m

		
	local options1=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
	local options2  xlabel(15(5)90) ylabel(`r`v'_`g'', gmin gmax) ytitle(`t`v'') xtitle(Age) ysize(3.3) xsize(6)
	
	sort q_`z' n
	by q_`z' n: egen m`v'_`g'=mean(`v'_`g')
	gen m`v'_`g'_n=m`v'_`g' if n==5
	by q_`z': egen m=min(m`v'_`g'_n)
	replace m`v'_`g'_n=m`v'_`g'/m
	drop m


local c1 black
local c2 gs9
local c3 gs12

	*************************************
	

	twoway 	(connect m`v'_`g' age if q_`z'==1, lcolor(`c1') mcolor(`c1') lpattern(shortdash_dot)) ///
			(connect m`v'_`g' age if q_`z'==2, lcolor(`c2') mcolor(`c2') lpattern(dash)) ///
			(connect m`v'_`g' age if q_`z'==3, lcolor(`c3') mcolor(`c3') lpattern(solid)) ///
			, `options1' `options2' legend(label (1 Low-Income) label(2 Middle-Income) label(3 High-Income) rows(1))
	
	graph export texinput/lc_all_`v'_`g'_`z'.pdf, replace
	
	

} // v
} // g
