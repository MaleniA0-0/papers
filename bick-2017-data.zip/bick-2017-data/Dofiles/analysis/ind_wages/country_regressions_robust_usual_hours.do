clear all

quiet{


use data/simplified_wj_world_data, clear

foreach c in AUT BEL BGR  ROM CHE CYP CZE DEU DNK ESP EST FIN FRA GBR GRC HUN IRL ITA LTU LVA NLD POL PRT SVK SVN SWE{ 
	drop if country=="`c'"
}

by country, sort: gen n=_n
by country: egen mu=max(hrs_u)
keep if mu!=.
by country, sort: replace n=_n

save data/simplified_wj_world_robustness_data_usual, replace
use data/simplified_wj_world_robustness_data_usual, clear

local da
local dm & male==1 // Note here it's the other way around because I am not dropping any observations
local dw & male==0

local ba Both Sexes
local bm Men
local bw Women

*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


sort y
list country if n==1 

gen lhu=ln(hrs_u)
gen lhu_mj=ln(hrs_u_mj)
gen lhu_aj=ln(hrs_u_aj)

***********************
* For the US it's the other way around
***********************
replace lhu=lhm_o if country=="USA"


by country, sort: sum lhu*

* Only UGA has mj and aj usual hours
sum lhu* if lhu_mj!=. & lhu_aj!=.

gen cid=5 if country=="UGA"
replace cid=4 if country=="MNG"
replace cid=3 if country=="PER"
replace cid=2 if country=="TUR"
replace cid=1 if country=="USA"


local c5 Uganda 
local c4 Mongolia
local c3 Peru
local c2 Turkey
local c1 USA

local is a m w

local if5 lhu!=. & lhu_mj!=.
local if4 lhu!=. 
local if3 lhu!=. 
local if2 lhu!=. 
local if1 lhu!=. 

forvalues c=1/5{
foreach i in `is'{
	local r 1
	reg lhm_n w_n age age2 if cid==`c' `d`i''
	mat x =e(b)
	local by`r'`i'`c'=_b[w_n] 
	local sy`r'`i'`c'=_se[w_n]
	local ty`r'`i'`c'=abs(`by`r'`i'`c''/`sy`r'`i'`c'')
	local N`r'`i'`c'=e(N)
	
	local n=`N`r'`i'`c''
	if `n'>=1000{
		local n1=floor(`n'/1000)
		local n2=`n'-`n1'*1000
		local N`r'`i'`c'="`n1',`n2'"
	}
	else{			
		local N`r'`i'`c'=`n'	
	}
						

	local r 2
	reg lhm_n w_n age age2 if `if`c'' & lhm_n!=. & cid==`c' `d`i''
	mat x =e(b)
	local by`r'`i'`c'=_b[w_n] 
	local sy`r'`i'`c'=_se[w_n]
	local ty`r'`i'`c'=abs(`by`r'`i'`c''/`sy`r'`i'`c'')
	local N`r'`i'`c'=e(N)
	
	local n=`N`r'`i'`c''
	if `n'>=1000{
		local n1=floor(`n'/1000)
		local n2=`n'-`n1'*1000
		local N`r'`i'`c'="`n1',`n2'"
	}
	else{			
		local N`r'`i'`c'=`n'	
	}
	
	local N`r'`i'`c'="\multirow{3}{*}{`N`r'`i'`c''}"		
	if `c'==5 local N`r'`i'`c'

	local r 3	
	reg lhu   w_n age age2 if `if`c'' & lhm_n!=. & cid==`c' `d`i''
	mat x =e(b)
	local by`r'`i'`c'=_b[w_n] 
	local sy`r'`i'`c'=_se[w_n]
	local ty`r'`i'`c'=abs(`by`r'`i'`c''/`sy`r'`i'`c'')
	local N`r'`i'`c' 
	if `c'==5{
		local N`r'`i'`c'=e(N)
		local n=`N`r'`i'`c''
		if `n'>=1000{
			local n1=floor(`n'/1000)
			local n2=`n'-`n1'*1000
			local N`r'`i'`c'="`n1',`n2'"
		}
		else{			
			local N`r'`i'`c'=`n'	
		}
	}		
	
	if `c'==5{	
		local r 4
		reg lhu_mj   w_n age age2 if `if`c'' & lhm_n!=. & cid==`c' `d`i''
		mat x =e(b)	
		local by`r'`i'`c'=_b[w_n] 
		local sy`r'`i'`c'=_se[w_n]
		local ty`r'`i'`c'=abs(`by`r'`i'`c''/`sy`r'`i'`c'')
		local N`r'`i'`c' 
	}

}
}

forvalues c=2/5{
	local y1`c' Actual All J.\
	local y2`c' `y1`c''
}
local y11 Usual Main J.\
local y21 `y11'

local y35 Usual All J.\
local y45 Usual Main J.\

local y34 Usual Main J.\
local y33 Usual All J.\
local y32 Usual Main J.\
local y31 Actual All J.\


local rs1 3
local rs2 3
local rs3 3
local rs4 3
local rs5 4

		

local is a

*#################################################################
* Tex Table Generation
*#################################################################

********************************
* Settings
********************************

global name="tab_reg_robust_usual_brief"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"
global fonttype /* ="\textit" */
global digit 3

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{l c") _n
forvalues r=1/1{
	$write ("D{.}{.}{2,3} c")	
}
$write ("}")
$write ("\tabularnewline\hline\hline") _n
$write (" & \multicolumn{1}{c}{Dep.\ Var.: Hours}")
$write (" & \multicolumn{1}{c}{$ \beta_w $}  & \multicolumn{1}{c}{Obs.}")
$write ("\\\hline\hline") _n

local t1 Baseline
local t2 {Robustness}
local t3 // \textit{\ All hours available}

forvalues c=1/5{
	*$write (" \bf `c`c'': ") _n
	forvalues r=1/`rs`c''{
		$write (" `t`r'' ") 
		if `r'==1 $write ("- `c`c'' ")
		$write ("&")		
		$write ("`y`r'`c'' ")
		foreach i in `is'{
			$write ("&") 
			global var `by`r'`i'`c''
			`do1'
			$write (" &  `N`r'`i'`c'' ")		
		}
		$write ("\\[-.2cm]") _n
		foreach i in `is'{
			$write ("& &") 
			global var `sy`r'`i'`c''
			`do2'	
		}		
		$write ("\\") _n
		if `r'==1 | `r'==`rs`c'' $write ("\hline") _n
	}
	$write ("\hline") _n
}

		
*#################################################################
${lastl}
${close}		
*#################################################################	

} // quiet
