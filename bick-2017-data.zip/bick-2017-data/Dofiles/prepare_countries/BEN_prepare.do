******************************************************************************************
* Program: BEN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Benin
******************************************************************************************

use "Data\Benin\Data\benin_emploi", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs  M_ID1 qmstruct qmnumber
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid=M_ID1s+"-"+qmstructs+"-"+qmnumbers
replace pid=mi1
order hid pid
sort hid pid

foreach v in `vs'{
	drop `v's
}

*-----------------------------------------

* Age 
gen age=MI7

* Gender
replace male=1 if MI4==1
replace male=0 if MI4==2

*-----------------------------------------

* Weight 
replace wgt= WEIGHT750

* Interview date
replace refdatex=0
replace startdate=mdy(2,1,2010)	
replace enddate=mdy(5,31,2010)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.

******************************************
* Market work																	/* Universe: Age 6 and above */
******************************************

* Employment status (market work)												/*Paul: Adjusted by adding EA4!*/	
replace emp=1 if EA2==1															/* During the last week, have you worked at least one hour? */
replace emp=0 if EA2==2
replace emp=2 if EA4==1			

*-----------------------------------------

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* Main Job

* Actual hours worked last week
replace ahrswk_mj=AP11
replace ahrswk_mj=0 if AP11==. & emp==0

* Actual days worked last week
replace adayswk_mj=AP10
replace adayswk_mj=0 if AP10==. & emp==0

*-----------------------------------------

* Sec Job

* Actual hours worked last week
replace ahrswk_sj=AP9
replace ahrswk_sj=0 if AP9==. & emp==0


******************************************
* Non-market work
******************************************

* Actual hours worked last week in non-market activities  						/* Fetch water or wood to the market, provision of services. No explicit question about working status in non-market activities */
egen nm=rowtotal(EA1_3 EA1_5), missing
replace ahrswk_nm=nm

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2					
replace chrsx=2						

*-----------------------------------------

*-----------------------------------------
*Timeuse
*1) Cooking  (av6)
		gen cooking = . 					/* cooking*/
		
	*2) Cleaning/Housework (av7)
		gen cleaning =  EA1_2					/*laundry and cleaning the house*/
		
	*3) Childcare (Av11)
		gen childcare = .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = EA1_3			/*going to market*/
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .
		

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking-hrs_hw
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
