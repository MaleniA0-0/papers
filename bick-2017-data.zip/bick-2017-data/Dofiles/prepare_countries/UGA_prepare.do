******************************************************************************************
* Program: UGA_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Uganda
******************************************************************************************

use "Data\Uganda\NPS LSMS 2009\Data\GSEC8_11_merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=HHID
replace pid=h2q1
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if  h2q4 == 1 //Reference Person
replace hh_link = 2 if  h2q4 == 2 //Spouse/Husband
replace hh_link = 3 if  h2q4 == 3  |  h2q4 == 4 //child, grand child
replace hh_link = 4 if   h2q4 == 5 //Ascendant (parent, grand parent, parent in law)
replace hh_link = 98 if  h2q4 == 9 | h2q4 == 10 | h2q4 == 96  //Not related
replace hh_link = 99 if   h2q4 == 6 | h2q4 ==8 | h2q4 == 7  //Others 

*-----------------------------------------

* Age 
gen age=h2q8 

* Gender
replace male=1 if h2q3==1
replace male=0 if h2q3==2

*-----------------------------------------

* Weight
replace wgt=wgt09		//Looks to me like Household weight
gen hh_wgt = wgt09		

* Interview date
replace refdatex=1
replace refdate=mdy(h1bq2b, h1bq2a, h1bq2c)										
format refdate %td

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------
*schooling
gen educ=.
replace educ=1 if h4q5==3
replace educ=0 if h4q5==1 | h4q5==2
gen educlvl=.
replace educlvl=1 if h4q10==60
replace educlvl=0 if h4q10<=50

gen edu = .
replace edu = 1 if inrange(h4q7,10,23)
replace edu = 2 if inrange(h4q7,31,36)
replace edu = 3 if inrange(h4q7,41,61)
replace edu = 1 if edu == . & h4q5==1

******************************************
* Market work																		/* Universe: All HH members age>=5 */
******************************************

* Employment status (market work)
	* Paul: Added a variable to determine employment status 19.01.2014
	egen emp_iv = rowtotal(h8q04 h8q06 h8q08 h8q10 h8q12), missing
	replace emp = 1 if (emp_iv >=1 & emp_iv != .) & h8q14 == .
	*Still, apparently there is an issue when the dataset is constructed. Labour section has less observations than GSEC 2, which gives general info on person.
	*An approximate 700 ppl do not have any info on labour hours/employment, which is due to datasets not fitting together.

replace emp=1 if h8q14==1
replace emp=0 if (h8q14==2 & h8q15==2) | (h8q14==2 & h8q15==.)
replace emp=2 if (h8q14==2 & h8q15==1) | (h8q14==. & h8q15==1)

* Reason for being economically inactive
replace reason=0 if emp<2 
replace reason=1 if emp==2

*Work status
replace emp_wj = 1 if (h8q22 == 1 |  h8q22==5)	
replace emp_se = 1 if (h8q22 == 2 |  h8q22==3 |  h8q22==4 |  h8q22==6)	
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Main job																			/* Universe: All HH members age>=5 and has a job */

* Actual hours worked last week
egen byte mj=rowtotal(h8q36a h8q36b h8q36c h8q36d h8q36e h8q36f h8q36g), missing
replace ahrswk_mj=mj
replace ahrswk_mj=0 if (emp==0 | emp==2) & ahrswk_mj==.

*Paul: Replace emp if hours are positive and emp == .
replace emp = 1 if (ahrswk_mj >= 1 & ahrswk_mj != .) & emp == .
replace emp = 0 if (ahrswk_mj == 0) & emp == .


* Usual hours worked per week 
replace uhrswk_mj=h8q70 
replace uhrswk_mj=0 if (emp==0 | emp==2) & uhrswk_mj==. 	

* Usual weeks worked per month
replace wksmth_mj=h8q69 
replace wksmth_mj=0 if (emp==0 | emp==2) & wksmth_mj==. 

/*
count if (h8q18 == 1 | h8q18 == 2 | h8q18 == 3 | h8q18 == 4 | h8q18 == 5 | h8q18 == 6 | h8q18 ==  7 | h8q18 == 8)
count if ahrswk_mj == .
count if ahrswk_mj == . & uhrswk_mj !=.
*/
*-----------------------------------------

* Sec job

* Actual hours worked last week
replace ahrswk_sj=h8q43
replace ahrswk_sj=0 if (emp==0 | emp==2) & ahrswk_sj==. 

* Usual hours worked per week 
replace uhrswk_sj=h8q73 	 
replace uhrswk_sj=0 if (emp==0 | emp==2) & uhrswk_sj==. 

* Usual weeks worked per month
replace wksmth_sj=h8q72
replace wksmth_sj=0 if (emp==0 | emp==2) & wksmth_sj==. 

* Months worked in the last 12 months
replace mthsyr_sj=h8q44 			
replace mthsyr_sj=0 if (emp==0 | emp==2) & mthsyr_sj==. 


******************************************
* Non-market work																	/* Universe for nm section: All HH members age 5 and above */
******************************************

* Employment status (non-market work) not asked										/* No question about employment in non-market activities */					

*-----------------------------------------

* Actual hours per week spent on non-market work
egen nm_sa= rowtotal(h8q59 h8q60 h8q63 h8q65 h8q66), missing						/* Non-market self-employed agri: Collect firewood, water, milling & food processing, agriculture, hunting & fishing for HH use in last 7 days */
gen nm_sn= h8q64																	/* Non-market self-employed non-agri: Making handicrafts */
egen totalnm= rowtotal(nm_sa nm_sn), missing
replace ahrswk_nm=totalnm

*-----------------------------------------

* Hours worked by job nature

* Generate indicator for invalid industry codes for main and sec jobs				/* 22 obs with invalid mj industry codes. 13 obs with invalid sj industry codes */
#delimit ;

gen invalid_mj=1 if h8q20b==1 | h8q20b==2 | h8q20b==10 | h8q20b==22 |
 h8q20b==25 | h8q20b==45 | h8q20b==301 | h8q20b==326 | h8q20b==375 |
 h8q20b==541 | h8q20b==549 | h8q20b==631 | h8q20b==705 | h8q20b==806 |
 h8q20b==913 | h8q20b==999;

 gen invalid_sj=1 if h8q39b==1 | h8q39b==93 | h8q39b==111 | h8q39b==112 |
 h8q39b==414 | h8q39b==539 | h8q39b==542 | h8q39b== 549;

 #delimit cr

*Generate indicators for main and sec job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk uhrswk wksmth

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if h8q22==1
replace mj_sa=1 if h8q22==6 |((h8q22>=2 & h8q22<=5) & invalid_mj==. & h8q20b<=50)
replace mj_sn=1 if (h8q22>=2 & h8q22<=5) & invalid_mj==. & (h8q20b>50 & h8q20b<.)
replace mj_sx=1 if (h8q22>=2 & h8q22<=5) & invalid_mj==1
replace mj_uc=1 if h8q22==.

replace sj_wj=1 if h8q41==1
replace sj_sa=1 if h8q41==6 |((h8q41>=2 & h8q41<=5) & invalid_mj==. & h8q39b<=50)
replace sj_sn=1 if (h8q41>=2 & h8q41<=5) & invalid_mj==. & (h8q39b>50 & h8q39b<.)
replace sj_sx=1 if (h8q41>=2 & h8q41<=5) & invalid_mj==1
replace sj_uc=1 if h8q41==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen totalsa=rowtotal(ahrswk_sa nm_sa), missing
egen totalsn=rowtotal(ahrswk_sn nm_sn), missing
replace ahrswk_sa= totalsa
replace ahrswk_sn= totalsn

replace ahrswk_wj_mj = ahrswk_mj if h8q22==1
replace ahrswk_wj_aj = ahrswk_wj_mj if h8q22 == 1 & h8q37 == 2					//Had only one main (wage) job
replace ahrswk_wj_aj = ahrswk_wj if h8q22 == 1 & h8q37 == 1 					//Includes main plus add. wage jobs

replace flag_set1 = 1 if h8q22==1 & h8q37 == 2									//ONly main wage job, nothing else
*Note: We have some individuals who say no second job, don't give any info on potential 2nd job, but hrs_sj > 0!
replace flag_set1 = 0 if h8q37 == 2 & (h8q43 > 0 & h8q43 != .)

replace flag_set2 = 1 if flag_set1 == 1 | (h8q22==1 & h8q37 == 1 & h8q41==1)	//Second job additionally, but also wage
replace flag_set3 = 1 if flag_set2 == 1 | (h8q22==1 & h8q37 == 1 & h8q41==2 | h8q41==3 | h8q41==4 | h8q41==6)

egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1



*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

gen ind = .
replace ind = 1 if inrange( h8q20b,11,50)
replace ind = 2 if inrange( h8q20b,130,372)
replace ind = 3 if inrange( h8q20b,401,990)

*-----------------------------------------
*Income from wage jobs
*-----------------------------------------
*1) Main Job
gen days_worked = 0
foreach alph in a b c d e f g {

	replace days_worked = days_worked + 1 if h8q36`alph' != 0 & h8q36`alph' != .				//Add one for each day worked
}

gen inc_mj_cash = . 																			// h8q31a 
gen inc_mj_inkind = . 																			//h8q31b 

local vars inc_mj_cash inc_mj_inkind
local inc_mj_cash h8q31a
local inc_mj_inkind h8q31b

foreach v in `vars' {
	replace `v' = ``v''*h8q70*h8q69 if h8q31c == 1 												//Hourly to week (h8q70) to month (h8q69)
		replace `v' = ``v''*h8q76*h8q75 if h8q31c == 1 &  `v' == .								//Hourly to week to month, if usual last 7 days missing (then inc is still missing)

	replace `v' = ``v''*days_worked*h8q69 if h8q31c == 2										//Daily to week to month (weeks per month: h8q69). There are no usual days available! 
		replace `v' = ``v''*days_worked*h8q75 if h8q31c == 2 & `v' == .							//Daily to week to month
		
	replace `v' = ``v''*h8q69 if h8q31c == 3													//Weekly to month
		replace `v' = ``v''*h8q75 if h8q31c == 3 & `v' == .										//Weekly to month
	
	replace `v' = ``v'' if h8q31c==4
		
	replace `v' = . if h8q22 == 2 | h8q22 == 3 | h8q22 == 6  | h8q22 == .						//Replace to missing if not employee
		
}

	
*Our standard variables	
replace inc_wj_mj_c_g = inc_mj_cash																//Main wage job, cash (gross)
replace inc_wj_mj_ik_g = inc_mj_inkind															//Main wage job, inkind (gross)
	
egen wj_mjtot = rowtotal(inc_wj_mj_c_g inc_wj_mj_ik_g),m										//Main wage job, gross total (inkind + cash)	
	replace inc_wj_mj_tot_g = wj_mjtot if  h8q22 == 1 |  h8q22==5								//Only if main job is wage!
	
*2) Second Job - need to take into account only employees!

gen inc_sj_cash = . 																			// h8q31a 
gen inc_sj_inkind = . 																			//h8q31b 

local vars inc_sj_cash inc_sj_inkind
local inc_sj_cash h8q45a
local inc_sj_inkind h8q45b

foreach v in `vars' {
	replace `v' = ``v''*h8q73*h8q72 if h8q45c == 1 												//Hourly to week (h8q70) to month (h8q69)
		replace `v' = ``v''*h8q80*h8q79 if h8q45c == 1 &  `v' == .								//Hourly to week to month, if usual last 7 days missing (then inc is still missing)

	replace `v' = . //``v''*days_worked*h8q69 if h8q45c == 2										//Daily to week to month (weeks per month: h8q69). There are no usual days available! 
		replace `v' = . //``v''*days_worked*h8q75 if h8q45c == 2 & `v' == .							//Daily to week to month
		
	replace `v' = ``v''*h8q72 if h8q45c == 3													//Weekly to month
		replace `v' = ``v''*h8q79 if h8q45c == 3 & `v' == .										//Weekly to month
	
	replace `v' = ``v'' if h8q45c ==4
		
	replace `v' = . if h8q41 == 2 | h8q41 == 3 | h8q41 == 6 							//Replace to missing if not employee
		
}

	
*Standard variables		
egen wj_ajcash = rowtotal(inc_wj_mj_c_g inc_sj_cash),m
	replace inc_wj_aj_c_g = wj_ajcash
egen wj_ajik = rowtotal(inc_wj_mj_ik_g inc_sj_inkind),m
	replace inc_wj_aj_ik_g = wj_ajik
egen wj_ajtot = rowtotal(inc_wj_aj_c_g inc_wj_aj_ik_g),m
	replace inc_wj_aj_tot_g = wj_ajtot if (h8q22 == 1 |  h8q22==5)						//Only if main job is wage! Thus this includes all main wage job incomes and potentially on top second job wage income
	
*Wage rate:
replace rep_hr_wage = h8q31a if h8q31c == 1
replace rep_hr_wage = h8q45a if rep_hr_wage == . & 	h8q45c == 1 	
	
*-----------------------------------------
 *Self employed/Other income (on household level)
 *-----------------------------------------
 *--> Household income, but merging issue. Merging issue resolved: We have to set up Household income already in merge file
	/* This is what happens in merge file
		bysort HHID: egen hh_cash = total(h11aq05)		//But including only the relevant categories, i.e. not investments, royalties, land/plotrent etc.
		bysort HHID: egen hh_inkind = total(h11aq06)
	
		egen HH_income = rowtotal(hh_cash hh_inkind), m
		bysort HHID: keep if _n == 1
		*/

	*Standardize hh other inc to monthly
		gen hh_inc_cash =  hh_cash/12
		gen hh_inc_inkind = hh_inkind/12
 
	egen hh_se_tot = rowtotal(hh_inc_cash hh_inc_inkind),m
	
*-----------------------------------------
*3) Our standard variables
	bysort hid: egen hh_wj_c = total(inc_wj_aj_c_g)				//Bring wage income  in cash, inkind from all jobs to hh_level (cash and inkind)
	bysort hid: egen hh_wj_ik = total(inc_wj_aj_ik_g)
	egen hh_wj = rowtotal(hh_wj_c hh_wj_ik),m
	
	egen hh_tot = rowtotal(hh_wj hh_se_tot),m					//Generate household income from wage and self employment income
		replace inc_hh = hh_tot		

*order hid pid hh_link inc_wj_mj_tot_g inc_wj_aj_tot_g hh_se_tot hh_wj inc_hh
	

* Keep standardized variables
keep hid pid  ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt hh_wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
