
clear

*cd "C:\Users\Paul\Dropbox (ERC Transitions)\Hours\"
use "MTUS\Data\MTUS_W53.DTA" 

decode countrya, generate(countrycode)
drop country
gen country=countrycode

	*1) Cooking  (av6)
		gen cooking = av6/60*7				/* (cooking + washing dishes)*/

	*2) Cleaning/Housework (av7)
		gen cleaning = av7/60*7			/*Ironing + Sweeping + disposing garbage*/
	
	*3) Childcare (Av11)
		gen childcare = av11/60*7
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		replace av14 = . if av14 == -9
		egen goods_services_hrs = rowtotal(av10 av14) , missing			/*Shopping + errands*/
		gen goods_services = (goods_services_hrs/60)*7
		
	*5) Collecting Water and Firewood
		gen coll_wf = 0
		
	*6) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .
		
	*7) Commuting time
	gen commuting = .
	replace av5 = . if av5 == -9
	replace commuting = av5/60*7 if inrange(empstat,1,3)
	replace commuting = 0 if empstat == 4
	
	gen chrsday = commuting/7
	*replace commuting = av5/60*7 if empstat == 4 & 

drop emp
gen emp = .
replace emp = 1 if inrange(empstat,1,3)
replace emp = 0 if empstat == 4
	
gen male=.
replace male = 1 if sex==1
replace male = 0 if sex==2		

gen wgt = ocombwt
d
		
/*
drop if year==1964 & country=="Denmark"
drop if year==1998 & country=="France"
drop if year<=2001 & country=="Germany"
drop if year==1991 & country=="Israel"
drop if year<=2000 & country=="Netherlands"
drop if year<=2003 & country=="Spain"
drop if year<=2001 & country=="United Kingdom"
drop if year<=2010 & country=="usa"
drop if year<=2002 & country=="Italy"
*/

replace country = "AUS" if country == "Australia"
replace country = "FRA" if country == "France"
replace country = "DEU" if country == "Germany"
replace country = "ISR" if country == "Israel"
replace country = "NLD" if country == "Netherlands"
replace country = "ESP" if country == "Spain"
replace country = "GBR" if country == "United Kingdom"
replace country = "USA" if country == "usa"
replace country = "ITA" if country == "Italy"
replace country = "ZAF" if country == "South Africa"
replace country = "AUT" if country == "Austria"
replace country = "DNK" if country == "Denmark"

recode cooking cleaning childcare goods_services commuting (-0.15=.) (-1.05 = .)
rename goods_services shopping
gen MTUS=1

save "MTUS\Data\MTUS_W53_copy.DTA" , replace


local countries AUS FRA DEU ISR NLD ESP GBR USA ITA ZAF AUT DNK
foreach c in `countries' {
	use "MTUS\Data\MTUS_W53_copy.DTA"
	keep if country == "`c'"

	if "`c'" == "AUS" |  "`c'" == "AUT" |  "`c'" == "DEU" |  "`c'" == "DNK" |  "`c'" == "FRA" |  "`c'" == "GBR" |  "`c'" == "ITA"|  "`c'" == "NLD"|  "`c'" == "TAF" {
	sum year
		keep if year == r(max) 
	}
	if "`c'" == "USA" {
		keep if year == 2005
	}
	if "`c'" == "ESP" {
		keep if year == 2003
	}		
	
	
	
	*Generate Age-group dummies
local all_min = 15
local all_max = 99

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


	save "Data\Cleaned_data/`c'_timeuse.dta", replace

}
