*To merge Namibia subfiles
*Set path
* cd ""

use "Data\Namibia\NHIES 2009\Data/7a0_NHIES 2009_2010 Household dataset.dta", clear

rename hF1IncU1PM hh_wj
rename hF1IncNet hh_wj_n
rename hF1IncGSU hh_wjse
rename hPCI hh_incpc
rename HhSize hh_size

save "Data\Namibia\NHIES 2009\Data/hh_vars.dta", replace

use "Data\Namibia\NHIES 2009\Data/54a_NHIES 2009_2010 Individual dataset.dta", clear
merge m:m cRegion serial FNumber using "Data\Namibia\NHIES 2009\Data/hh_vars.dta", 

keep if _merge == 3
drop _merge

save "Data\Namibia\NHIES 2009\Data/indiv_merged.dta", replace
