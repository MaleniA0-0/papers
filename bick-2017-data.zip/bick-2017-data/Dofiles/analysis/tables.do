clear all

local xcorec "keep if coreDummy==1"
local xallc

local ls a b c

local tf \normalsize
local lm 5 

local thwp Hours Per Adult
local ter  Employment Rate
local thwe Hours Per Worker

local w0 
local w1 weighted_

foreach x in corec{
forvalues w=0/1{

	use Data/Cleaned_data/repl_master_stats,clear
	drop countryname
	*****************************
	
	replace country="TMP" if country=="TLS"
	*Population share age 15+ from World Development Indicator
	merge 1:1 country year using Data/External_data/wdi_pop_share_15plus
	drop country_name 
	replace country="TLS" if country=="TMP"
	drop if _merge==2
	* For Taiwan we do not have population share data
	tab country if _merge==1
	drop _merge	
	replace pop_share_15plus=1-.158 if country=="TAI" 
	* Table 5, http://eng.stat.gov.tw/public/Data/7113143851PNHSNJPU.pdf	
	*****************************

	rename country countrycode
	replace country="ROU" if country=="ROM"
	merge 1:1 country year using Data/External_data/pwt90, keepusing(pop)
	tab _merge
	drop if _merge==2
	drop _merge
	replace country="ROM" if country=="ROU"
	rename countrycode  country	
	
	replace pop=1.086174 if country=="TLS" 

	*****************************

	* Core vs all countries
	`x`x''
	
	* Variables
	local vs hwp er hwe 
	local g a   // f m 
	local a all // prime young old 
	
	* Weighting only on the aggregate level
	if `w'==1{
		local g a
		local a all
		gen whwp=pop_share_15plus*pop
		gen wer=whwp
		gen whwe=er_a_all*whwp
	}
	else{
		gen whwp=1
		gen wer=1
		gen whwe=1
	}
			
	foreach v in `vs'{
		if "`v'"=="er" replace `v'_`g'_`a'=`v'_`g'_`a'*100
		forvalues q=1/3{
			sum `v'_`g'_`a' [aweight=w`v'] if q_${z}==`q'
			local `v'_`g'_`a'_`q'_`w'=r(mean)
		}

		local ra_`v'_`g'_`a'_`w'=``v'_`g'_`a'_1_`w''/``v'_`g'_`a'_3_`w''
		local rb_`v'_`g'_`a'_`w'=``v'_`g'_`a'_1_`w''/``v'_`g'_`a'_2_`w''
		local rc_`v'_`g'_`a'_`w'=``v'_`g'_`a'_2_`w''/``v'_`g'_`a'_3_`w''				
		
	}
	*#################################################################
	* Tex Table Generation - LEVELS
	*#################################################################

	local ta=" Low "
	local tb=" Middle "
	local tc=" High "

	********************************
	* Settings
	********************************

	global name="tab_levels_`w`w''`x'_${z}"
	global write="file write ${name}"
	global nextl=`"${write} ("\\") _n"'
	global lastl=`"${write} ("\end{tabular}")"'
	global close="file close ${name}"

	local do1="do Dofiles/analysis/dcol"
	local do2="do Dofiles/analysis/dcol_sd"

	global fonttype /* ="\textit" */
	global digit 1

	file open ${name} using texinput/${name}.tex, write replace

	***************************************************************
	* Start table
	***************************************************************

	$write ("\begin{tabular}{lccc}") _n
	$write ("\tabularnewline\hline\hline\\[-.`lm'cm] ") _n
	$write ("& \multicolumn{3}{c}{Country Income Group} \\")
	foreach l in `ls'{
		$write (" & \;\;\; `t`l'' \;\;\; ")
	}
	$write ("\\[-.`lm'cm]\\\hline") _n
	
	foreach v in `vs'{
		$write ("`t`v''")
		forvalues q=1/3{
			$write ("&")
			global var ``v'_`g'_`a'_`q'_`w''
			`do1'				
		}
		$write ("\\") _n
		if "`v'"=="hwp" $write ("\hline") _n			
	}

	$write ("\hline") _n
	*#################################################################
	${lastl}
	${close}
	*#################################################################		
	
} // weighting
} // core vs all countries

