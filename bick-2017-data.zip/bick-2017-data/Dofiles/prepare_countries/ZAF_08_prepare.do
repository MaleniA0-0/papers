*********************************************************************************************
* Program: ZAF_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for South Africa
*********************************************************************************************

use "Data\South Africa\QLFS 2008/ZAF_08_merged", clear 
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hid=hhid
replace pid=PERSONNO
order hid pid
sort hid pid

*-----------------------------------------

* Age 
rename age_grp1 AGEGROUP
gen age=Q14AGE

* Gender
replace male=1 if Q13GENDER==1
replace male=0 if Q13GENDER==2

*-----------------------------------------

* Weight
replace wgt=Weight

* Interview date
replace refyear=2008

*hh_link is not available

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.

gen edu = .
replace edu = 1 if inrange(Q17EDUCATION,0,8)					//First 4 years
replace edu = 2 if inrange(Q17EDUCATION,9,20)					//5th to 9th year
replace edu = 3 if inrange(Q17EDUCATION,11,24)


******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe in IPUMS sample: Age 15 to 65 */
replace emp=1 if Q24APDWRK == 1 | Q24BOWNBUSNS==1 | Q24CUNPDWRK== 1		//Have job
replace emp = 0 if Q24APDWRK == 2 & Q24BOWNBUSNS==2 & Q24CUNPDWRK== 2	//Do not have job
replace emp = 2 if emp == 0 & (Q25APDWRK==1 | Q25BOWNBUSNS==1 | Q25CUNPDWRK==1 )

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=2 if Q27RSNABSENT==2										/* vacation or public holiday*/
replace reason=3 if	Q27RSNABSENT==1										/* sickness */		
replace reason=4 if Q27RSNABSENT==6											/* labour dispute */
replace reason=5 if Q27RSNABSENT==4	|  Q27RSNABSENT==3  |  Q27RSNABSENT==5 						/* maternity and paternity leave */
replace reason=7 if inrange( Q27RSNABSENT,7,14) 


replace emp_wj = 1 if Q45WRK4WHOM == 1
replace emp_se = 1 if inrange(Q45WRK4WHOM,2,4)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .


* Actual hours per week 
*1) Main job only
local dayhrs Q419MONHRSWRK Q419TUEHRSWRK Q419WEDHRSWRK Q419THUHRSWRK Q419FRIHRSWRK Q419SATHRSWRK Q419SUNHRSWRK
gen days_worked = 0
foreach d in `dayhrs' {
	replace `d' = . if `d' == 88
	replace days_worked = days_worked + 1 if `d' > 0 & `d' != .
}

egen a_mjhrs = rowtotal(`dayhrs'),m
	replace ahrswk_mj = a_mjhrs if Q41MULTIPLEJOBS == 2			
	drop a_mjhrs
	
replace uhrswk_mj = Q418HRSWRK if Q41MULTIPLEJOBS == 2	

*2) Multiple jobs
local dayhrs_mj Q4211MONHRSWRK Q4211TUEHRSWRK Q4211WEDHRSWRK Q4211THUHRSWRK Q4211FRIHRSWRK Q4211SATHRSWRK Q4211SUNHRSWRK
foreach d in `dayhrs_mj' {
	replace `d' = . if `d' == 88
	replace days_worked = days_worked + 1 if `d' > 0 & `d' != .
}
egen a_mjhrs = rowtotal(`dayhrs_mj'),m 
	replace ahrswk_mj = a_mjhrs	if Q41MULTIPLEJOBS == 1

local dayhrs_sj Q4212MONHRSWRK Q4212TUEHRSWRK Q4212WEDHRSWRK Q4212THUHRSWRK Q4212FRIHRSWRK Q4212SATHRSWRK Q4212SUNHRSWRK
egen a_sjhrs = rowtotal(`dayhrs_sj'),m 
	replace ahrswk_sj = a_sjhrs if Q41MULTIPLEJOBS == 1
	
replace uhrswk_mj = Q420FIRSTHRSWRK if Q41MULTIPLEJOBS == 1	
replace uhrswk_sj = Q420SECONDHRSWRK if Q41MULTIPLEJOBS == 1	

replace adayswk_mj = days_worked if days_worked > 0


*-----------------------------------------

* Hours worked by job nature: MJ only										/* Obs with classwk=NIU are not classified */			
egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m

replace ahrswk_wj_mj = ahrswk_mj if emp_wj == 1
replace ahrswk_wj_aj = ahrswk_mj if emp_wj == 1 & Q41MULTIPLEJOBS == 2
*We do not know the second job occupation status. Continue with main job later!

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

gen ind = .
replace ind = 1 if inrange(Q43INDUSTRY,10,301)
replace ind = 2 if inrange(Q43INDUSTRY,302,505)
replace ind = 3 if inrange(Q43INDUSTRY,611,964)	//We do not know what 990 is
*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age edu educ ind educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
