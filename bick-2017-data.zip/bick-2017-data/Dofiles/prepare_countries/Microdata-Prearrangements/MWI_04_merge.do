* Merge files for Malawi and set up HH level earnings from HH activities

* Merge employment module to individuals
use "Data\Malawi\IHS LSMS 2004\Data\ihs2_individ", clear
 
merge 1:1 case_id memid using "Data\Malawi\IHS LSMS 2004\Data\sec_e"
rename _merge _merge1

merge 1:1 case_id memid using "Data\Malawi\IHS LSMS 2004\Data\sec_b"
rename _merge _merge3

* Merge with household module to obtain interview date

merge m:1 case_id using "Data\Malawi\IHS LSMS 2004\Data\ihs2_household", keepusing (idate)

rename _merge _merge2

save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*HH enterprise activities
use "Data\Malawi\IHS LSMS 2004\Data\sec_v.dta", clear

gen mths_worked = v07
gen sales = v16										//Monthly
egen costs = rowtotal(v17a v17b v17c v17d v17e),m	//Monthly

gen profits = (sales - costs)*mths_worked/12
collapse(sum) profits  , by(case_id)

merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*HH agriculture activities 
*1) Rainfed cultivation: By plots!
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_o.dta", clear
*cost of land, fertilizer, seeds, labor 
collapse (sum) o12 o15 o19 o22, by(case_id)
egen r_crop_c = rowtotal(o12 o15 o19 o22),m
merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*2) Rainfed crop sales: We do not have value of own consumption of crops!
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_p.dta", clear
*value of crops sold, cost of other labor payments
collapse (sum) p05 , by(case_id)

merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*3) Tobacco: Net earnings form sales of tobacco (sales less costs)
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_q1.dta", clear
*profits from sales of tobacco (sales minus costs)
collapse (sum) q21 , by(case_id)

merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*4) Agriculture: Dry season cultivation
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_r.dta", clear
*costs for land, fertilizer, seeds, labor
collapse (sum) r11 r16 r20 r23 , by(case_id)
egen d_crop_c = rowtotal(r11 r16 r20 r23),m

merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*4) Agriculture: Dry season crop sales
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_s.dta", clear
collapse (sum) s05 , by(case_id)

merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

*5) Tree crop production and sales
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_t.dta", clear
collapse (sum) t09  , by(case_id)	//total value earned
*No costs, so we leave it out?!
merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace


*5) Livestock
use "Data\Malawi\IHS LSMS 2004\Data\MWI_2004_IHS2_Household1_STATA/sec_u.dta", clear
*sale of livestock, cost of buying livestock, cost spent on upkeep, revenues from sale of byproducts
collapse (sum) u07 u13 u16 u19, by(case_id) 	//u16 & u19: One HH with 9999999

merge 1:m case_id using "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", nogen
save "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", replace

