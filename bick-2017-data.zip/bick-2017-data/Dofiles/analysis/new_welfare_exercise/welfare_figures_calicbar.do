use Data/new_welfare_calicbar, clear


/* Needed for outcommented figures */
local a 64
local lab 1 "1/64" 2 "1/32" 4 "1/16" 8 "1/8" 16 "1/4" 32 "1/2" 64 "1" 128 "2"
*--------*


local v y 
sum `v' if q==3 
gen n`v'=`v'/r(mean) // *`a'
sum n`v'

forvalues t=1/2{
	sum t`t'_${z}
	local t`t'=r(mean)
}

sort ny

local options1=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local options2=`"ylabel(, angle(0) grid gmin gmax) xlabel(7(0.5)11) xtitle(ln(GDP per Capita)) ytitle(Ratio of Welfare to Consumption) "'

forvalues h=2/2{
	local v `h'
	sum w2_`v' if q==3 	
	gen n`v'=w2_`v'/r(mean) // `a' --> needed for out commented figures
	sum n`v'
	
	gen r`v'=n`v'/ny

	
	local lc gs8
	twoway (scatter r`v' ly, msize(vsmall) mlab(country) mcolor(black) mlabpos(3) yline(1)), ///
		`options1' `options2' xline(`t1', lpattern(dot) lcolor(`lc')) xline(`t2', lpattern(dot) lcolor(`lc')) // graphregion(margin(zero))	
	graph export "texinput/welfare_ratio_calicbar_`h'_${z}.pdf", replace	
	
}

