clear all

use Data/Cleaned_data/timeuse_stats,replace


local vs cooking childcare cleaning collwf shopping

replace collwf_a_all_uc=. if q_${z}==3


local total
forvalues q=1/3{
	di "~~~~~~~~~`q'~~~~~~~~~"
	local mtotal`q'=0
	foreach v in `vs'{
		sum `v'_a_all_uc if q_${z}==`q'
		local m`v'`q'=round(r(mean),.1)
		local n`v'`q'=r(N)
		if r(mean)==.{
			local mtotal`q'=`mtotal`q''
		}
		else{
			local mtotal`q'=`mtotal`q''+`m`v'`q''
		}
	}
}


local lm0 5 
local lm1 25

local s0 
local s1 _p

local tq1 Low
local tq2 Middle
local tq3 High 

local tvcooking 	Cooking
local tvcleaning	Cleaning
local tvchildcare	Childcare
local tvshopping	Shopping
local tvcollwf		Collecting Water
local tvtotal		Total

local vs `vs' total

forvalues t=0/0{
	
********************************
* Settings
********************************

* Assing file name
global name="timeuse`s`t''_${z}"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"

global digit 1

file open ${name} using "texinput/${name}.tex", write replace		
	
***************************************************************
* Start table
***************************************************************

local ands
forvalues q=1/3{
	local ands `ands' &
} 

local ia 2 // Digits before decimal points
local ib 1 // Digits after deicmal point


$write ("\begin{tabular}{l c c c }") _n 
$write ("\tabularnewline\hline\hline\\[-.`lm`t''cm] ") _n
$write ("& \multicolumn{3}{c}{Country Income Group} \\")

*----------------

forvalues q=1/3{
	$write (" & \;\;\; `tq`q'' \;\;\; ")
}
if `t'==0{
	$write ("\\[-.`lm`t''cm]\\\hline") _n
}
else{
	$write ("\\\hline") _n
}

*----------------

local count=1

foreach v in `vs'{

	$write ("`tv`v''")
	
	* Means
	forvalues q=1/3{
		$write ("&")
		
		* Assign to var the local number you want to be printed
		global var `m`v'`q''
		`do1'
	}	

	if (`t'==0 & "`v'"!="total") {
		$write ("\\[-0.05cm]") _n
		forvalues q=1/3{
			$write ("&")
			$write ("\footnotesize(`n`v'`q'')")
		}
	}
	if `count'!=5{
		$write ("\\") _n
	}
	else{
		$write ("\\\hline") _n
	}	
	local count=`count'+1
}

$write ("\hline") _n

*----------------
${lastl} _n
${close}

}


