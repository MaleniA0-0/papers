clear all

use Data/ptest_corec_allc, clear 

gen cs=ql*10+qh

local cs 13 12 23

*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Core vs Allc table
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
local v hwp // er hwe
local g a
local a all // young prime old

foreach c in `cs'{	
forvalues x=1/3{
	di `c' "   `v' "
	sum d if cs==`c' & v=="`v'" & g=="`g'" & a=="`a'" & x==`x'
	local d`c'`x'=r(mean)
	qui sum p if cs==`c' & v=="`v'" & g=="`g'" & a=="`a'" & x==`x'
	local p`c'`x'=r(mean) 
}
}

local r1 Core Countries
local r2 Core + Partial-Year
local r3 All Countries

*#################################################################
* Tex Table Generation
*#################################################################

********************************
* Settings
********************************

global name="tab_permut_corec_allc_${z}"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"	
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************


$write ("\begin{tabular}{l D{.}{.}{1,2} D{.}{.}{1,2} D{.}{.}{1,2}}") _n
$write ("\tabularnewline\hline\hline") _n
$write ("  & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("&  \multicolumn{1}{c}{ Low-High } & \multicolumn{1}{c}{ Low-Middle } & \multicolumn{1}{c}{  Middle-High } \\\hline") _n


forvalues x=1/3{
	$write ("`r`x''")
	global digit 1
	foreach c in `cs'{
		$write ("& ")
		global var `d`c'`x''		
		`do1'
	}
	$write ("\\[-.2cm]") _n
	global digit 2
	foreach c in `cs'{
		$write ("& ")
		global var `p`c'`x''
		`do2'
	}	
	$write ("\\") _n
}
$write ("\hline") _n


*#################################################################
${lastl}
${close}
*#################################################################

