********************************************************************************************
* Program: TLS_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Timor Leste
********************************************************************************************

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", clear 

* Initialize some variables 
rename pid pid_or
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
rename hh_id hid
replace pid=pid_or

order hid pid
sort hid pid

*-----------------------------------------

* Age
gen age=q01a05y

* Gender
replace male=1 if q01a01==1
replace male=0 if q01a01==2

*Household link
gen hh_link = .
replace hh_link = 1 if   q01a02 == 1 //Reference Person
replace hh_link = 2 if  q01a02 == 2 //Spouse
replace hh_link = 3 if  q01a02 == 3 |  q01a02 == 4 |  q01a02 == 5 //Child, grandchildren 
replace hh_link = 4 if  q01a02 == 7 |  q01a02 == 11  //Ascendant (parents, grandparents)
replace hh_link = 99 if  q01a02 == 6 |  q01a02 == 12 |  q01a02 == 8 |  q01a02 == 9 |  q01a02 == 10 |  q01a02 == 13 //Others

*-----------------------------------------

* Weight
replace wgt=hhweight
gen hh_wgt = hhweight

* Interview dates																	/* First interview date */
replace refdatex = 1
replace refmonth = intmonth
replace refyear = intyear
replace refday = intday
replace refdate = mdy(refmonth, refday, refyear)
replace refweek = week(refdate)


replace startdate=mdy(1,9,2007)	
replace enddate=mdy(1,22,2008)
format startdate enddate refdate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if  q05b13==1
replace educ=0 if  q05b13==2
gen educlvl=.

gen edu = .
replace edu = 1 if  q05a09a == 1 |  q05a09a == 2 
replace edu = 2 if q05a09a == 3 | q05a09a == 4 | q05a09a == 7
replace edu = 3 if q05a09a == 5 | q05a09a == 6
replace edu = 1 if edu == . &  q05a05 == 2

******************************************
* Market work, Questionnaire page 52
******************************************

* Employment status (market work)													/* Universe for market section: Age 10 and above */
replace emp=1 if  q08c01>0 &  q08c01 != .
replace emp=0 if q08c01 == 0 & q08c02 == 2
replace emp=2 if q08c01==0 & q08c02==1 

* Reason for being economically inactive
replace reason=0 if emp<=1
replace reason=2 if  q08c03==4															/* vacation or public holiday*/
replace reason=3 if  q08c03==1															/* sickness */	
replace reason=4 if  q08c03==6															/* labour dispute */
replace reason=5 if  q08c03==2															/* maternity and paternity leave */
replace reason=7 if  q08c03==3 |  q08c03==5 |  q08c03==7 |  q08c03==8 					/* other reasons */

*Work status
replace emp_wj = 1 if q08a02_j1 == "A"
replace emp_se = 1 if q08a02_j1 == "B" | q08a02_j1 == "C"
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------
*Actual months worked last year/hours worked last week
forvalues num = 1/4 {
	*1) months
	local mw_j`num'all 
	foreach abc in a b c d e f g h i j k l {
		replace q08a03`abc'_j`num' = 0 if q08a03`abc'_j`num' == 2
		local mw_j`num'all  `mw_j`num'all' q08a03`abc'_j`num'
	}
	
	egen mw_j`num' = rowtotal(`mw_j`num'all'),m
	
	if `num' == 1 {
		replace  mthsyr_mj = mw_j`num'
	}
	if `num' == 2 {
		replace  mthsyr_sj = mw_j`num'
	}
	*2) hours
	local hrstot_j`num'
	gen days_worked`num' = 0
	foreach abc in a b c d e f g {
		replace days_worked`num' = days_worked`num'+1 if (q08a04`abc'_j`num' > 0 & q08a04`abc'_j`num' != .)
		local hrs_j`num' `hrs_j`num''  q08a04`abc'_j`num'
	}
	egen hrs_j`num' = rowtotal(`hrs_j`num''),m
	if `num' == 1 {
		replace  ahrswk_mj = hrs_j`num'
	}
	if `num' == 2 {
		replace  ahrswk_sj = hrs_j`num'
	}	
	if `num' == 4 {
		egen hrstot = rowtotal(`hrs_j1' `hrs_j2' `hrs_j3' `hrs_j4'),m
			replace ahrswk_aj = hrstot
	}
	
}


*Job nature: We can only infer wage jobs!
local wj_hrs 
forvalues num = 1/4 {
	gen hrs_j`num'_wj =  hrs_j`num' 
	replace hrs_j`num'_wj = . if (q08a02_j`num' == "B" | q08a02_j`num' == "C")
	
	local wj_hrs `wj_hrs' hrs_j`num'_wj
}
egen wjtot = rowtotal(`wj_hrs'),m 
	replace ahrswk_wj = wjtot
 
gen num_jobs = 0
gen indic_se = 0
forvalues num = 1/4 {
	replace num_jobs = num_jobs + 1 if hrs_j`num' > 0 & hrs_j`num' != .
	replace indic_se = indic_se + 1 if (q08a02_j`num' == "B" | q08a02_j`num' == "C")
}

replace ahrswk_wj_mj =  hrs_j1_wj if q08a02_j1 == "A"
replace ahrswk_wj_aj = ahrswk_wj_mj if num_jobs == 1
replace ahrswk_wj_aj = ahrswk_wj if num_jobs > 1								//We cannot go step by step as before (first mj_wj only, then aj_wj)

replace flag_set1 = 1 if num_jobs == 1 & q08a02_j1 == "A" 						//Individual has only one (main) wage job
*Note: Some individuals say they only have one (wage) job, but then have third job in self-employment and no wage hours. These guys are excluded from analysis.
gen diff1 = ahrswk_wj_mj - ahrswk_aj
gen diff2 = ahrswk_wj_aj - ahrswk_aj
replace flag_set1 = 0 if diff1 < 0 & flag_set1 == 1

replace flag_set2 = 1 if flag_set1 == 1 | (q08a02_j1 == "A" & num_jobs > 1 & indic_se == 0)		//Individual has only wage jobs
replace flag_set2 = 0 if diff2 < 0 & flag_set2 == 1

replace flag_set3 = 1 if flag_set2 == 1 | (q08a02_j1 == "A" & num_jobs > 1 & indic_se > 1)		//Individual must have some self employed activities

sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1
*Note: Due to conditioning on main job being wage earning activity, nobody is added to set 3 anymore. If unrestrict q08a02j1 == "A", have 23 ind. more

 
******************************************
* Non-market work
******************************************

* Employment status (non-market work)												/* Universe for non-market section: Age 5 and above */
egen empnm = rowtotal( q08e01 q08e03 q08e05),m 
replace emp_nm = 1 if empnm >= 1 & empnm != .
replace emp_nm = 0 if empnm == 0

* Actual hours worked in non-market work yesterday 									/* Collecting water and wood, domestic job */
egen nm=rowtotal(q08e02 q08e04 q08e06), missing
replace ahrsday_nm=nm
replace ahrsday_nm=0 if nm==. & emp_nm==0 

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2
local comm
forvalues n = 1/4 {
gen com_n`n' = q08b09a_j`n' if q08b09b_j`n' == 2								//number of times
replace com_n`n' = q08b09a_j`n'*days_worked`n'*2 if q08b09b_j`n' == 1

replace q08b10b_j`n' = q08b10b_j`n'/60											//time spent everytime
egen com_t`n' = rowtotal(q08b10a_j`n' q08b10b_j`n'),m

gen commuting`n' = com_n`n'*com_t`n'
local comm `comm' commuting`n'
}
egen tot_com = rowtotal(`comm')

replace commuting = tot_com if emp == 1 | emp == 2
replace chrsday = commuting/7 if emp == 1 | emp == 2

replace chrsday = 0 if emp == 0
replace commuting = 0 if emp == 0


gen ind = . //Industry is only asked to employees				
replace ind = 1 if inrange(indcode_j1,1,5)		
replace ind = 2 if inrange(indcode_j1,6,9)
replace ind = 3 if inrange(indcode_j1,10,15)


*-----------------------------------------
*Income: Wage job income
*-----------------------------------------
*Main job & second job (no third/fourth job wage income in data!)
gen incwjmj_c =  q08b11a_j1 if  q08a02_j1 == "A"
gen incwjmj_ik =  q08b13a_j1 if  q08a02_j1 == "A"
gen incwjsj_c =  q08b11a_j2 if  q08a02_j2 == "A"
gen incwjsj_ik =  q08b13a_j2 if  q08a02_j2 == "A"

foreach var in incwjmj_c   {
	replace `var' = `var'*ahrswk_mj/q08b11b_j1*(52/12) if q08b11c_j1 == 1	//Hourly to monthly
	replace `var' =  `var'*days_worked1*52/12/q08b11b_j1 if q08b11c_j1 == 2		//Daily to monthly
	replace `var' = `var'*(52/12)/q08b11b_j1	if q08b11c_j1 == 3			//Weekly to monthly
	replace `var' = `var'*(12/q08b11b_j1)/12	if q08b11c_j1 == 4			//Monthly (varying periodicities) to monthly
}
foreach var in  incwjsj_c  {
	replace `var' = `var'*ahrswk_sj/q08b11b_j2*(52/12) if q08b11c_j2 == 1	//Hourly to monthly
	replace `var' = `var'*days_worked2*52/12/q08b11b_j2 if q08b11c_j2 == 2			//Daily to monthly
	replace `var' = `var'*(52/12)/q08b11b_j2	if q08b11c_j2 == 3			//Weekly to monthly
	replace `var' = `var'*(12/q08b11b_j2)/12	if q08b11c_j2 == 4

}

foreach var in incwjmj_ik  {
	replace `var' = `var'*ahrswk_mj/q08b13b_j1*(52/12) if q08b13c_j1 == 1		//Hourly to monthly
	replace `var' = `var'*days_worked1*52/12/q08b13b_j1 if q08b13c_j1 == 2				//Daily to monthly
	replace `var' = `var'*(52/12)/q08b13b_j1	if q08b13c_j1 == 3				//Weekly to monthly
	replace `var' = `var'*(12/q08b13b_j1)/12	if q08b13c_j1 == 4

}

foreach var in incwjsj_ik {
	replace `var' = `var'*ahrswk_sj/q08b13b_j2*(52/12) if q08b13c_j2 == 1		//Hourly to monthly
	replace `var' = `var'*days_worked2*52/12/q08b13b_j2 if q08b13c_j2 == 2				//Daily to monthly
	replace `var' = `var'*(52/12)/q08b13b_j2	if q08b13c_j2 == 3				//Weekly to monthly
	replace `var' = `var'*(12/q08b13b_j2)/12	if q08b13c_j2 == 4
 
}

*Reported Hourly wages
gen hrwage_c  = q08b11a_j1 if q08b11c_j1 == 1
gen hrwage_ik = q08b13a_j1 if q08b13c_j1 == 1
egen hrwage = rowtotal(hrwage_c hrwage_ik),m
replace rep_hr_wage = hrwage

replace inc_wj_mj_c_o = incwjmj_c							//Eventhough previous Q asks whether taxes are paid, we do not know if here Q is gross/net. No info in interviewer manual
replace inc_wj_mj_ik_o = incwjmj_ik 

egen wjmj_tot = rowtotal(inc_wj_mj_c_o inc_wj_mj_ik_o),m
	replace inc_wj_mj_tot_o = wjmj_tot
	
egen wjaj_tot = rowtotal(inc_wj_mj_tot_o incwjsj_c incwjsj_ik),m
	replace inc_wj_aj_tot_o = wjaj_tot if q08a02_j1 == "A"

*-----------------------------------------
*Self employment & farmign income
*-----------------------------------------

*Total individual income: Not possible, due to se income on HH level


*1) Household enterprises
gen hh_se = (totrev_ent-totcost_ent)/12

*2) Household farming
egen hh_sn_rev = rowtotal(rev_crop rev_forest rev_products rev_livestock),m
egen hh_sn_cost = rowtotal(ag_inputs ag_equipment ag_labour cost_livestock cost_transport cost_irrigation),m
gen hh_sn_woutfish = (hh_sn_rev - hh_sn_cost)/12
replace earnings_fish = earnings_fish/12
	egen hh_sn = rowtotal(hh_sn_woutfish earnings_fish),m

*Generate household income:
bysort hid: egen hh_wj = total(wjaj_tot),m	
egen hh_inc = rowtotal(hh_se hh_sn hh_wj),m 
	replace inc_hh = hh_inc
	
*check values: 
*sum inc_wj_mj_c_o inc_wj_mj_ik_o inc_wj_mj_tot_o inc_wj_aj_tot_o hh_wj hh_se hh_sn			//THis looks alright
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu hh_link `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
