
local xcorec "keep if coreDummy==1"
local xallc

local specs 1 2 4 5
local fs 3	

foreach spec in `specs'{
	
	if `spec'==1{ // Figure 1
		local xs corec
		local vs hwp 		
		local gs a 
		local as all
		local sc
	}
	else if `spec'==2{ // Figure 3
		local xs corec
		local vs er hwe
		local gs a 
		local as all
		local sc
	}	
	else if `spec'==4{ // Figure C.3
		local xs corec
		local vs hwp
		local gs f m
		local as all
		local sc
	}		
	else if `spec'==5{ // Figure C.1 
		local xs allc
		local vs hwp
		local gs a
		local as all
		local sc
	}		

	foreach x in `xs' {

		use Data/Cleaned_data/repl_master_stats,replace
	
		* Core vs all countries
		`x`x''
		
		* ln gdppc thresholds
		forvalues t=1/2{
			sum t`t'_${z}
			local t`t'=r(mean)
		}

		* Sort data and add three observations for mean 
		sort ln_gdppc_${z}
		count 
		local N=r(N)+3
		set obs `N'
		gen nn=_n
		gsort -nn
		replace nn=_n
		forvalues q=1/3{
			sum ln_gdppc_${z} if q_${z}==`q'
			replace ln_gdppc_${z}=r(mean) if nn==`q'
		}

		* Graph specifiers
		local rhwe 0(5)50
		local thwe Hours per Week
		
		local rhwp 0(5)50
		local thwp Hours per Week
		
		local rer 0(10)100
		local ter Employment Rate (in %)
		
		local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
	

		local xl 7(.5)11
	
		foreach v in `vs'{
		foreach g in `gs'{
		foreach a in `as'{
		foreach f in `fs'{
		
		
			if "`v'"=="er"{
				replace `v'_`g'_`a'=`v'_`g'_`a'*100
			}
		
			forvalues q=1/3{
				sum `v'_`g'_`a' if q_${z}==`q'
				replace  `v'_`g'_`a'=r(mean) if nn==`q'	
			}
			
			local xleglab Income Group Average
	

				local lc gs8
				if "`x'"=="corec"{
					twoway	(scatter `v'_`g'_`a' ln_gdppc_${z} if nn>3, msize(vsmall) mlab(country) mcolor(black) mlabpos(3) ///
							 xline(`t1', lpattern(dot) lcolor(`lc')) xline(`t2', lpattern(dot) lcolor(`lc')) msize(vsmall)) ///					   
							, `options' xtitle(ln(GDP per Capita)) ytitle(`t`v'') ylabel(`r`v'', angle(0) grid gmin gmax) xlabel(`xl') ///
						   	legend(off) `sc' //  	
				}
				else{
					twoway	(scatter `v'_`g'_`a' ln_gdppc_${z} if nn>3 & coreDummy==1, msize(vsmall) mlab(country) mlabcolor(black) mcolor(black) mlabpos(3) msymbol(circle) ///
							 xline(`t1', lpattern(dot) lcolor(black)) xline(`t2', lpattern(dot) lcolor(black)) msize(vsmall)) ///
							(scatter `v'_`g'_`a' ln_gdppc_${z} if nn>3 & coreDummy==0, msize(vsmall) mlab(country) mlabcolor(gs10) mcolor(gs10) mlabpos(3) msymbol(triangle)) ///					 					   
							, `options' xtitle(ln(GDP per Capita)) ytitle(`t`v'') ylabel(`r`v'', angle(0) grid gmin gmax) xlabel(`xl') ///
						   	legend(label(1 Core Countries) label(2 All non-core Countries) rows(1)) //  			
				}
				graph export "texinput/`v'_`g'_`a'_`x'_nox_${z}.pdf", replace	
			
		
		}
		}
		}
		}
	
	} // core vs all countries
} // specs

