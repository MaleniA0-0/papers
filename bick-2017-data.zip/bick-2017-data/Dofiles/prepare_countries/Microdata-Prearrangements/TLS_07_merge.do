*To merge TLS subfiles and set up HH earnings variables (for activities on the HH level)

*Separate the different jobs that one individual has (up to four)
forvalues n = 1/4 {
use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/employment", clear
bysort hh_id pid: gen num = _n
keep if num == `n'

renvars occcode-q08b13c, postfix(_j`n')

save  "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/employment_j`n'", replace

}

*Merge with main file on individual level
use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/indiv", clear
forvalues n = 1/4 {
	
	merge 1:1 hh_id pid using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/employment_j`n'",
	rename _merge _merge`n'
}

merge m:1 hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/basicvars.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

*------------------------------------------------------------*
*Enterprise income
*------------------------------------------------------------*
use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/enterprise", clear

*Need to do our own sum of enterprise costs and revenues, what interviewers did is full of math. mistakes
*I am excluding taxes from the costs, so that we have gross enterprise income!
local entcost_vars 
forvalues n = 3/14 {
	if `n' <= 9 {
		local entcost_vars `entcost_vars' q08d0`n'
	}
	if `n' > 9 {
		local entcost_vars `entcost_vars' q08d`n'
	}
	
}

local entrev_vars 
forvalues n = 17/20 {
	local entrev_vars `entrev_vars' q08d`n'
}

egen totcost_ent = rowtotal(`entcost_vars'),m
egen totrev_ent = rowtotal(`entrev_vars'),m
*gen profits = totrev_ent - totcost_ent

collapse (sum) totrev_ent totcost_ent , by(hh_id)

merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

*------------------------------------------------------------*
*Farming income
*------------------------------------------------------------*
use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/crop", clear
*note: The are up to 13 crop variations mentioned per household. Do not rely on variable "total"
gen rev_crop = q09b02a*q09b04 		//Value of harvested crops, i.e. crops sold & kept for own consumption
collapse (sum) rev_crop, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/ag_input", clear
gen ag_inputs = q09c04				//total spent on manure/herbicides/pesticides/seed etc
	label variable ag_inputs "total spent on manure/herbicides/pesticides/seed etc"
collapse (sum) ag_inputs, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/forestry", clear
gen rev_forest = q09d02
collapse (sum) rev_forest, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/ag_equipment", clear
gen ag_equipment = q09e05*q09e06
	label variable ag_equipment "Cost of renting equipment, days/year*cost/day"
collapse (sum) ag_equipment, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/ag_labour", clear
gen ag_labour = q09f02*q09f03*q09f05
	label variable ag_labour "Labour costs: # workers * # days * wage/day"
collapse (sum) ag_labour, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/by_product", clear
gen rev_products = q09f09
	label variable rev_products "Revenue from sale of food products"
collapse (sum) rev_products, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

use "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/livestock", clear
foreach var in q09g09 q09g07 q09g08 q09g11 {
	gen val_`var' = `var'*q09g04
}
egen rev_livestock = rowtotal(q09g06 val_q09g09)
egen cost_livestock = rowtotal(val_q09g07 val_q09g08 val_q09g11),m
collapse (sum) rev_livestock cost_livestock, by(hh_id)
merge 1:m hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged.dta", nogen
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace

*Fishing, irrigation & transport in other dataset (household level)
merge m:1 hh_id using "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/hhold.dta", keepusing( q09f06a q09f06b q09h08)
rename  q09f06a cost_transport
rename q09f06b cost_irrigation 
rename q09h08 earnings_fish
save "Data\Timor Leste\SLS (LSMS) 2007\TLSLS2DTA/individuals_merged", replace


