clear all

local np0 
local np1 _p

local edu10 All Ages
local edu5 Ages 25+ (\textit{Non-missing Educ.}) // $ ^\dag $
local edu1 Less than Secondary
local edu2 Secondary Completed
local edu3 More than Secondary
local edu4 Missing

local ind10 All
local ind5 All (\textit{Non-missing Sec.}) // $ ^\dag $
local ind1 Agriculture
local ind2 Manufacturing
local ind3 Services

local edut Education
local indt Sector 

local ws 10 5 1 2 3 

forvalues p=1/1{
foreach x in edu ind{
	
	use Data/Cleaned_data/repl_master_stats,replace

	* Core countries
	keep if coreDummy==1
	
	* Variables
	if "`x'"=="ind"{
		local vs hwe
	}
	else{
		local vs hwp
	}
	 
	local g  a // m f 
	*local as non_young // all young prime old 
	
	local thwp Average Hours
	local thwe `thwp'
	local ter  Employment Rates
		
	foreach v in `vs'{
		
		foreach w in `ws' {
			if `w'==10 | "`x'"=="ind"{
				local a all
			}
			else{
				local a non_young
			}
			*----- 
		
			if `w'==10 {
				local s`x'`w' 
			}
			else{
				local s`x'`w' _`x'`w'
			}
			
			if "`v'"=="er"{
				replace `v'_`g'_`a'`s`x'`w''=`v'_`g'_`a'`s`x'`w''*100
			}		
			
			forvalues q=1/3{
				sum `v'_`g'_`a'`s`x'`w'' if q_${z}==`q'	
				local `v'`w'`q'=r(mean)
			}
		}
		
		*#################################################################
		* Tex Table Generation
		*#################################################################
	
		********************************
		* Settings
		********************************
	
		global name="tab_`v'_`g'_`x'`np`p''_${z}"
		global write="file write ${name}"
		global nextl=`"${write} ("\\") _n"'
		global lastl=`"${write} ("\end{tabular}")"'
		global close="file close ${name}"
	
		local do1="do Dofiles/analysis/dcol"
		global fonttype /* ="\textit" */
		global digit 1
	
		file open ${name} using texinput/${name}.tex, write replace
	
		***************************************************************
		* Start table
		***************************************************************
	
		$write ("\begin{tabular}{lccc}") _n
		if `p'==0 $write ("\multicolumn{4}{c}{`t`v'' by Age and Country Income}")
		$write ("\tabularnewline\hline\hline") _n
		$write ("``x't'   & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
		$write ("&   Low  &  Middle    &  High  \\\hline") _n
	
		foreach w in `ws'{
			$write ("``x'`w''")
			forvalues q=1/3{
				$write ("&")
				global var ``v'`w'`q''
				`do1'
			}
			$write ("\\") _n
			if `w'==5{
				if "`x'"=="edu"{
					$write ("\hline {Ages 25+} \\ ") _n			
				}
				else{
					$write ("\hline") _n			
				}
			}
		}
		$write ("\hline") _n
		*#################################################################
		${lastl}
		${close}
		*#################################################################		
	}
	
} // core vs all countries
}
