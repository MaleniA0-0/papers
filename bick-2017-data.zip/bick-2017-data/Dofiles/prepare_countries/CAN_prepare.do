******************************************************************************************
* Program: CAN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Canada
******************************************************************************************

use "Data\Canada\Census of Canada IPUMS 2001\Data\ipumsi_00050", clear 
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hid=string(serial,"%12.0g")
replace pid=pernum
order hid pid
sort hid pid

*-----------------------------------------

* Age 
rename age agex
gen age=agex

* Gender
replace male=1 if sex==1
replace male=0 if sex==2

*-----------------------------------------
* Weight
replace wgt=wtper

* Interview date
replace refdatex=0
replace refdate=mdy(5,15,2001)										/* Replaced with official census date */
format refdate %td

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.

******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe: Age 15 and above */
replace emp=1 if empstat==1
replace emp=0 if empstat==2 | empstat==3							/* Not employed if empstat is unemployed (2) or inactive (3) */
replace emp=. if empstat==0 										/* Replace emp=. if empstat is NIU (0) */

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1

*-----------------------------------------

* Actual hours worked last week (all job)
replace ahrswk_aj=HRSWRK1
replace ahrswk_aj=. if HRSWRK1==999									/* Set hours to missing if HRSWRK1 is NIU (999) */
replace ahrswk_aj=0 if ahrswk_aj==. & emp==0						/* Replace missing hours with 0 if person is clearly not working */

* Months worked last year (all job)
replace mthsyr_aj=wrkmths
replace mthsyr_aj=. if wrkmths==99									/* Set months to missing if wrkmths is NIU (99)*/
replace mthsyr_aj=0 if mthsyr_aj==. & emp==0						/* Replace missing months with 0 if person is clearly not working */

*-----------------------------------------

* Hours worked by job nature										/* Obs with classwk==NIU (0) are not classified. All self-employed jobs can be classified, thus sx is not required */
local time ahrswk mthsyr
foreach t in `time'{
	replace `t'_wj=`t'_aj if classwk==2					
	replace `t'_sa=`t'_aj if classwk==1 & indgen==10
	replace `t'_sn=`t'_aj if classwk==1 & indgen>10 & indgen<999
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													/* Both not explicitly included or excluded from work hours*/
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
