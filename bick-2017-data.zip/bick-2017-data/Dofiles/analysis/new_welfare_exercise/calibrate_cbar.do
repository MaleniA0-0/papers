clear all

use Data/new_welfare_exercise, clear

gen ly=ln(y)

* ln gdppc thresholds
forvalues t=1/2{
	sum t`t'
	local t`t'=r(mean)
}

* Capital Share - Prescott 2004
local theta=0.3224

* Normalized hours
local norm=100

gen hn=h/`norm'

local vs hn 

gen c0=c
gen c1=c+g

gen tau0=0

local t 0
local eps 1

*************************
* Calibration by hand
*************************

gen cbar=892.05/y 

local vs h hn c0 c1 tau0 cbar

foreach v in `vs'{
	forvalues q=1/3{
		sum `v' if q==`q'		
		local `v'`q'=r(mean)
	}
}

gen cin=.

replace cin=c`t'-cbar
local cin=`c`t'3'-`cbar3'

* Solving equation 4 for alpha
scalar a=(1-`theta')*(1-`tau`t'3')/(`hn3'^(1+1/`eps'))/`cin'

* Predciting hours according to equation 4 in weekly hours
gen hp =((1-`theta')*(1-tau`t')/cin/a)^(`eps`p''/(1+`eps'))*`norm'	

sum hp h if q==1 
sum hp h if q==3

gen pref=a

*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
* Figures Data vs Model
*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

local options1=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local options2=`"ylabel(0(10)50, angle(0) grid gmin gmax) xlabel(7(0.5)11) xtitle(ln(GDP per Capita)) ytitle(Hours per Week) "'

		
twoway  (scatter h ly, mcolor(gs10) msize(small) mlab(country) mlabc(gs10) mlabs(vsmall)) ///
		(scatter hp ly, mcolor(black) msize(small) mlab(country) mlabs(vsmall)) ///
	   , legend(label (2 Data) label (1 Model) order(2 1)) `options1' `options2' ///
	    xline(`t1', lpattern(dot) lcolor(black)) xline(`t2', lpattern(dot) lcolor(black)) 
			    
	    
graph export texinput/wf_calicbar_lab_${z}.pdf, replace	
		
*********************

forvalues q=1/3{
	sum hp if q==`q'
	local hp`q'=round(r(mean),.1)
	sum h  if q==`q'
	local h`q'=round(r(mean),.1)
}

save Data/new_welfare_excercise_calicbar_alpha, replace



*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
* Model Input
*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

drop h* pref*

local options1=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local options2=`"ylabel(,grid gmin gmax) xlabel(7(0.5)11) xtitle(ln(GDP per Capita)) "'

forvalues t=1/2{
	sum t`t'_${z}
	local t`t'=r(mean)
}

local t=0
local x

gen cnet`x'`t'=(c`t'-cbar`x')/(1-tau`t')
count if cnet`x'`t'!=.
sum cnet`x'`t' if q==3
gen cnet`x'`t'_n=cnet`x'`t'/r(mean)
sum cnet`x'`t'_n

local lc gs8
twoway	(scatter cnet`x'`t' ly, msize(vsmall) mlab(country) mcolor(black) mlabpos(3)) ///
			, `options1' `options2' legend(off) ytitle("c/y-cbar/y") ///
			xline(`t1', lpattern(dot) lcolor(`lc')) xline(`t2', lpattern(dot) lcolor(`lc')) 

graph export "texinput/model_input_calicbar_${z}.pdf", replace

 	
