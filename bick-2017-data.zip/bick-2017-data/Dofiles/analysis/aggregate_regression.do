clear all

do Dofiles/analysis/construct_gdpph

use Data/gdpph, clear
keep country year gdpph g*${z}
rename g*${z} gdppc

local vs h c
foreach v in `vs'{
	gen ln_`v'=ln(gdpp`v')
	rename gdpp`v' l_`v'
	foreach x in ln l{
		sum `x'_`v' if country=="USA"
		if "`x'"=="ln"{
			gen n_`x'_`v'=`x'_`v'-r(mean)
		}
		else{
			gen n_`x'_`v'=`x'_`v'/r(mean)
		}
	}
}

local tyln ln(GDP per Hour)-ln(US GDP per Hour)
local txln ln(GDP per Capita)-ln(US GDP per Capita)
local labln -4(1)0

local tyl GDP per Hour/US GDP per Hour
local txl GDP per Capita/US GDP per Capita
local labl   0(.2)1.2

local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white))) "'


merge 1:1 country using Data/Cleaned_data/repl_master_stats, keepusing(hwp_a_all coreDummy)
drop _merge

keep if coreDummy==1

rename hwp_a_all hwp
gen ln_hwp=ln(hwp)


twoway	(scatter ln_hwp ln_h, msize(vsmall) mlab(country) mcolor(black) mlabpos(3) ///
		 msize(vsmall)) ///					   
		, `options' xtitle(ln(GDP per Hour)) ytitle(ln (Hours per Week)) ylabel(2.5(.25)3.75, angle(0) grid gmin gmax)  ///
	   	legend(off)  
graph export texinput/ln_hwp_ln_gdpph.pdf, replace


reg ln_hwp ln_h 

