******************************************************************************************
* Program: RUS_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Russia
******************************************************************************************

use "Data\Russia\RLMS\2009\Data\hhind\rrinadlt", clear
rename hid hid12

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs siter familyr
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid=siters+"-"+familyrs

foreach v in `vs'{
	drop `v's
}

replace pid=personr
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age= irintyer - irbirthy

* Gender
replace male=1 if irgender==1
replace male=0 if irgender==2

*-----------------------------------------

* Weight
replace wgt=inwgt_r

* Interview date
replace refdate=mdy(irintmon, irintday,irintyer)
format refdate %td

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate) 

*-----------------------------------------
*Schooling
*Questionnaire does not ask for being enrolled generally, only specifically
gen educ=.
replace educ=1 if irinschl==1
replace educ=0 if irinschl==2
replace educ=1 if irstprf1==2 | irstprf2==2 | irstprf3==2 | irstprf4==2 | irstprf5==2 | irstptf1==2 | irstptf2==2 | irstpts1==2 | irstpts2==2 | irsttec1==2 | irsttec2==2 | irstins1==2 | irstins2==2 | irstgra1==2 | irstgra2==2 
replace educ=0 if irstprf1!=2 & irstprf2!=2 & irstprf3!=2 & irstprf4!=2 & irstprf5!=2 & irstptf1!=2 & irstptf2!=2 & irstpts1!=2 & irstpts2!=2 & irsttec1!=2 & irsttec2!=2 & irstins1!=2 & irstins2!=2 & irstgra1!=2 & irstgra2!=2 & irstprf1!=. & irstprf2!=. & irstprf3!=. & irstprf4!=. & irstprf5!=. & irstptf1!=. & irstptf2!=. & irstpts1!=. & irstpts2!=. & irsttec1!=. & irsttec2!=. & irstins1!=. & irstins2!=. & irstgra1!=. & irstgra2!=. 
*Those who are are enrolled equal 2, those who are not equal either 1 or 3, they do NOT equal 2!
gen educlvl=.
replace educlvl=1 if irstins1==2 | irstins2==2 | irstgra1==2 | irstgra2==2 
replace educlvl=0 if irinschl==1 | irstprf1==2 | irstprf2==2 | irstprf3==2 | irstprf4==2 | irstprf5==2 | irstptf1==2 | irstptf2==2 | irstpts1==2 | irstpts2==2 | irsttec1==2 | irsttec2==2

******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe for entire survey (including employment status qns): Age 13 and above */
replace emp=0 if irwrknow==5										/* 5 "not working" */
replace emp=1 if irwrknow==1 										/* 1 "currently working" */
replace emp=2 if irwrknow==2 | irwrknow==3 | irwrknow==4			/* No obs with 6 "doesn't know" or 7 "RF". Thus, no adjustment made. */

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=1 if irwrknow==2 									/* 2 "on paid leave (maternity leave or taking care of a child under 3 years of age)" */
replace reason=7 if irwrknow==3 | irwrknow==4 						/* 3 "on another kind of paid leave" 4 "on unpaid leave" */

*-----------------------------------------

* Main Job															/* Universe for hours qns: Age 13 and above, has a job, regardless of whether he is presently working or not */

* Usual hours worked per day 										/* No obs with DK or RF, hence no adjustment */
replace uhrsday_mj=irpwrkhr+(irpwrkmn/60)  							/* Convert minutes to hours */
replace uhrsday_mj=0 if uhrsday_mj==. & emp==0						/* Replace missing hour with 0 if person is clearly not employed */

* Usual hours worked per week 
replace uhrswk_mj=irpwrkwh
replace uhrswk_mj=0 if uhrswk_mj==. & emp==0

* Actual days worked in last 30 days 
replace adaysmth_mj=irdaywor
replace adaysmth_mj=0 if adaysmth_mj==. & emp==0			

* Actual hours worked in last 30 days 								/* Total actual hrs= reported actual hrs + hrs worked from home (if this was not included in irhourlm)*/
replace ahrsmth_mj=irhourlm
replace ahrsmth_mj=irhourlm+irhwhome if irintotd==2 & irhwhome>0 & irhwhome<.
replace ahrsmth_mj=irhwhome if irintotd==2 & irhourlm==.
replace ahrsmth_mj=0 if ahrsmth_mj==. & emp==0	

*-----------------------------------------

* Second Job

* Usual hours worked per day 										/* No obs with DK or RF, hence no adjustment*/
replace uhrsday_sj=irowrkhr+(irowrkmn/60)							/* Convert minutes to hours */
replace uhrsday_sj=0 if uhrsday_mj==. & emp==0			

* Usual hours worked per week 
replace uhrswk_sj=irowrkwh
replace uhrswk_sj=0 if uhrswk_sj==. & emp==0		

* Actual hours worked in last 30 days 
replace ahrsmth_sj=irotjhrs
replace ahrsmth_sj=irotjhrs+irhrsiea if irhrsiea>0 & irhrsiea<.		/* Add hours worked in other paid jobs to sec job */
replace ahrsmth_sj=irhrsiea if irhrsiea>0 & irhrsiea<. & irotjhrs==.
replace ahrsmth_sj=0 if ahrsmth_sj==. & emp==0

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													/* Both not explicitly included or excluded from work hours */
replace chrsx=2

replace chrsday=irwcompl/60 if ircomplw==1							/* Convert minutes taken to commute to work and back on an ordinary working day to hour */
replace chrsday=0 if chrsday==.	& ircomplw==2						/* Replace missing hours with 0 if person clearly did not commute to work*/

*-----------------------------------------
*Timeuse
*Data we need: Four categories
local variables irwpfoo irnwpfoo irwprepf irnwprep irwwash irnwwash irwlaun irnwlaun irwclea irnwclea irwlach irnwlach irwplay irnwplay

foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Need to replace daily variables with weekly values: Assume 5 workdays and two leisure days. 
local w_variables irwpfoo irwprepf irwwash irwlaun irwclea irwlach irwplay
local nw_variables irnwpfoo irnwprep irnwwash irnwlaun irnwclea irnwlach irnwplay

foreach w in `w_variables' {
	replace `w'=`w'_hrs*5
}
foreach nw in `nw_variables' {
	replace `nw'=`nw'_hrs*2
}

*need to recode don't knows and refuses to missings
recode irwprepf irnwprep irwwash irnwwash irwlaun irnwlaun irwclea  irnwclea irwlach irnwlach irwplay irnwplay irwpfoo irnwpfoo (997 = .) (998 = .)

	*1) Cooking  (av6)
		gen p_cook = irpredf
		recode p_cook (2=0)
		egen cook = rowtotal(irwprepf irnwprep), missing
		replace cook = 0 if p_cook == 0 & cook == .
		
		gen p_dish = irwashed
		recode p_dish (2=0)
		egen dish = rowtotal(irwwash irnwwash), missing
		replace dish = 0 if p_dish == 2 & dish == .

		*____________________________________________________________________________________*

		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
		
		egen cooking = rowtotal(cook dish)						/* cooking*/
		replace cooking = . if (cook ==. & dish ==.)
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_wash = irlaundr
		recode p_wash (2=0)
		egen wash = rowtotal(irwlaun irnwlaun), missing
		replace wash = 0 if p_wash == 0 & wash == .
		
		gen p_clean = ircleane
		recode p_clean (2=0)
		egen clean = rowtotal(irwclea  irnwclea), missing
		replace clean = 0 if p_clean == 0 & clean == .
		
		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_clean + p_wash >=1) & (p_clean + p_wash != .)
		replace p_cleaning = 0 if (p_clean + p_wash == 0)
				
		egen cleaning =  rowtotal(wash clean)	  					/*laundry and cleaning the house*/
		replace cleaning = . if (clean ==. & wash ==.)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
		
	*3) Childcare (Av11)
		gen p_kid1 = irlaftch
		recode p_kid1 (2=0)
		egen kid1 = rowtotal(irwlach irnwlach), missing
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = irplayed
		recode p_kid2 (2=0)
		egen kid2 = rowtotal(irwplay irnwplay), missing
		replace kid2 = 0 if p_kid2 == 0 & kid2 == .
		
		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)
		
		egen childcare = rowtotal( kid1 kid2)
		replace childcare = . if (kid1 ==. & kid2 == .)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = irpfoodg
		recode p_goods_services (2=0)
		egen goods_services = rowtotal(irwpfoo irnwpfoo), missing			/*going to market*/
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Water and Firewood
		gen coll_wf = .
		gen p_coll_wf = .
	
	*6) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
