******************************************************************************************
* Program: BRA_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Brazil
******************************************************************************************

use "Data\Brazil\PNAD 2009\Data\PNAD_PES2009", clear 

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=string(V0102,"%10.0g")+"-"+string(V0103)
replace pid=(V0301*10000)+(V8005*10)+V0302
order hid pid
sort hid pid

*-----------------------------------------

* Age 	
gen age=V8005

* Gender
replace male=1 if V0302==2
replace male=0 if V0302==4

*-----------------------------------------

* Weight
replace wgt=V4729

* Interview date																	/* Actual reference week in questionnaire: 20 to 26 Sep 2009 */
replace refdatex=1
replace startdate=mdy(9,20,2009)
replace enddate=mdy(9,26,2009)
format startdate enddate %td

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if V0602==2
replace educ=0 if V0602==4
gen educlvl=.
replace educlvl=1 if V6003==5 | V6003==11											
replace educlvl=0 if V6003<=4 | V6003>=6 & V6003!=11 & V6003!=.

******************************************
* Market & non-market work															/* Universe: Age 10 and above */
******************************************

* Employment status
replace emp=1 if V9001==1 | V9003==1 | V9004==2										/* Person is employed if he worked, or held jobs in agri or construction for HH during refweek */
replace emp=2 if V9001==3 & V9002==2												/* If he did not work during refweek and is only temporarily away from paid work  */
replace emp=0 if V9001==3 & V9002==4 & V9003==3 & V9004==4

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*-----------------------------------------

* Main job

* Usual hours per week
replace uhrswk_mj=V9058 
replace uhrswk_mj=0 if V9058==. & (emp==0 | emp==2)									/* Replace missing hours with 0 if person did not work during refweek */

*-----------------------------------------

* Second and third jobs

* Usual hours per week
egen sj= rowtotal(V9101 V9105), missing
replace uhrswk_sj=sj
replace uhrswk_sj=0 if sj==. & (emp==0 | emp==2)

*-----------------------------------------

* Hours worked by job nature

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx
local time uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if (V9008>=1 & V9008<=4) | V9029==1
replace mj_sa=1 if V9008>=5 & V9008<=13
replace mj_sn=1 if V9029>=2 & V9029<=7	

replace sj_wj=1 if V9092==1 | V9092==2
replace sj_sa=1 if (V9092>=3 & V9092<=6) & (V9907>=1101 & V9907<=5002)
replace sj_sn=1 if (V9092>=3 & V9092<=6) & (V9907>=10000 & V9907<=99000)
replace sj_sx=1 if (V9092>=3 & V9092<=6) & V9907==99888

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------
*Timeuse
	
	*1) Cooking  (av6)
		gen cooking = .
		
	*2) Cleaning/Housework (av7)
		gen cleaning = .					
		
	*3) Childcare (Av11)
		gen childcare = .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .		
	
	*5) Sum of four variables
		gen hrs_hw = V9921
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking-hrs_hw
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
