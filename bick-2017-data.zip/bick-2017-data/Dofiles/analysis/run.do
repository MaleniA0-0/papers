quiet{

cd "/Users/abick/Dropbox (ERC Transitions)/Hours/Admin/AER_Acceptance/replication_files/"

global z e9ry

***********************************
* Tables 
***********************************

* Table 1, Panel A
do Dofiles/analysis/table_core_vs_all

* Table 2 (Aggregate HWP,ER,HWE in one table: levels or ratios; also weighting with population size)
do Dofiles/analysis/tables

* Decomposition of HWP Differences in to ER and HWE contribution (reported in Sec 4.3, see Online Appendix A.3 for details)
do Dofiles/analysis/er_hwe_contribution_to_hwp_diffs

* Table 3 (time use)
do Dofiles/analysis/timeuse

* Table 4 
do Dofiles/analysis/tables_age_sex

* Tables 5 & 6 (By education and sector: levels)
do Dofiles/analysis/tables_educ_sec

* Table 7 (hypothetical hours)
do Dofiles/analysis/comp_table_allinone

* Table 9 (age and education combined)
do Dofiles/analysis/tables_educ_age_combined 

* Table 10 (Development Accounting)
do Dofiles/analysis/development_accounting

***********************************
* Figures 
***********************************

* Figures 1,3; C.1, C.3, C.5
do Dofiles/analysis/graphs

* Figure 2 (US time-series)
do Dofiles/analysis/comp_us_time_series

* Figure 4
do Dofiles/analysis/graphs_lifecycle

***********************************
* Section 6 & Everything on Wages 
***********************************

* Requires individual country micro level data, which we are not allowed to post online
* Researchers can apply for access to these data with the individual data providers

* qui do Dofiles/analysis/run_wages

*********************************
* Section 7.2 Welfare Exercise (Table 11 & Figures B.1-B.3)
*********************************

do Dofiles/analysis/new_welfare_exercise/empirical_data
do Dofiles/analysis/new_welfare_exercise/calibrate_cbar		
do Dofiles/analysis/new_welfare_exercise/welfare_numbers_calicbar
do Dofiles/analysis/new_welfare_exercise/welfare_figures_calicbar

*********************************
* Appendix
*********************************
*Figures A.1 & A.2 Survey Coverage, Core & Non-Core Countries
do Dofiles/analysis/Core_NonCore_timeframes

*Figure A.3 Ratio of Income per Worked/GDP per Worked
do Dofiles/analysis/check_income_tabgraph

*Table C.1 Data Sources
do Dofiles/analysis/Appendix_Survey_List

* Table C.2 GDP in PWT and our data
do Dofiles/analysis/tab_tercile_thresholds

* Table C.3 - Time Use Details
do Dofiles/analysis/Timeuse_stats

* Table C.5 (Development Accounting with rgdpo)
global z o9ry
do Dofiles/analysis/development_accounting
global z e9ry

* Figure C.2 (also reports coefficient stated in the Introduction and Sec 4.1)
do Dofiles/analysis/aggregate_regression

* Figures C.6, C.7 (education and sector)
do Dofiles/analysis/graphs_educ_sec
} // quiet

*********************************
* Permuation tests
*********************************
local vs corec_allc basic edu_ind 

* corec_allc: Table 1, Panel B

* basic: comparison of extensive and intensive margin as reported in Sec 4.3 (Table not included in the paper)

* edu_ind: comparison across sectors as reported in Sec 5.3 (Table not included in the paper)


* Data
global reps 10000
foreach v in `vs'{
	di "`v'"
	do Dofiles/analysis/permutation_tests/data_`v' 
}


foreach v in `vs'{ 
	qui do Dofiles/analysis/permutation_tests/tables_`v' 
}

*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

