clear

use "Data\Lesotho\ILFS 2008\Data\lfs_2008.dta" 

***************************************************
* Standard Variables:
	*1) * Age 
		gen age=b3
	*2) Country
		gen country = "LSO"
	*3) Gender
		gen male=.
		replace male=1 if b2==1
		replace male=0 if b2==2
	*4) Year
		gen year = 2008
	*5) Weights
		gen wgt = weights
		
*_Questionnaire page 19/23_______________________________________________________________________________________

*Data we need: Four categories
local variables  g1b g2b g4b g5b  g6b
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

	*1) Cooking  (av6)
		gen cooking = .  					/* cooking*/
		gen p_cooking = .
		
	*2) Cleaning/Housework (av7)
		gen cleaning = . 					/*laundry and cleaning the house*/
		gen p_cleaning = .
		
	*3) Childcare (Av11)
		gen p_childcare = g6a
		recode p_childcare (2=0)
		
		gen childcare =  g6b_hrs 										/*Care of Children AND Elders*/
		replace childcare = 0 if p_childcare == 0 & childcare == .
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_hunt = g4a
		recode p_hunt (2=0)
		gen hunt = g4b_hrs
		replace hunt = 0 if p_hunt == 0 & hunt == .
		replace p_hunt = 0 if hunt > 0 & hunt != .
		
		gen p_prod = g5a 
		recode p_prod (2=0)
		gen prod = g5b_hrs
		replace prod = 0 if p_prod == 0 & prod == .

		*____________________________________________________________________________________*
		gen p_goods_services = 1 if (p_hunt + p_prod == 1) | (p_hunt + p_prod != .)
		replace p_goods_services = 0 if (p_hunt + p_prod == 0)
	
		egen goods_services = rowtotal(hunt prod)
		replace goods_services = . if (hunt == . & prod ==.)
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		*egen goods_services = rowtotal(g4b_hrs g5b_hrs), missing					/*Alternative to shopping goods: Catching fish/food and weaving clothes*/
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
		
	*5) Fetching water and firewood
		gen p_water = g1a
		recode p_water (2=0)
		gen water = g1b_hrs
		replace water = 0 if p_water == 0 & water == .
		
		gen p_wood = g2a
		recode p_wood (2=0)
		gen wood = g2b_hrs
		replace wood = 0 if p_wood == 0 & wood == .
		
		*____________________________________________________________________________________*
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)		
		
		egen coll_wf = rowtotal(water wood)
		replace coll_wf = .  if (water ==. & wood ==.)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}

save "Data/Cleaned_data/LSO_timeuse.dta", replace

