**********************************************************************************************************
* Program: checking_income.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos
*---------------------------------------------------------------------------------------------------------*
* Purpose: 	Uses the harmonized Microdata to generate a dataset containing information on avg. monthly 
*			earnings from paid and/or self-employment earnings. Together with the information from the
*			Penn World Table on GDP per Capita/Employed (saved as gdppc/e_e9ry in our master_stats.dta,
*			that data can be used to compute the ratios of income per worker over GDP per worker (Figure
*			A.3 in the online Appendix).
***********************************************************************************************************

clear

local non_eulfs PER ALB ECU COL GHA TUR VNM KEN TLS RWA IRQ UGA MUS MWI BWA PAK KHM MNG TZA USA //BEL_silc BGR_silc  ROM_silc CHE_silc CYP_silc CZE_silc DEU_silc DNK_silc ESP_silc EST_silc FIN_silc FRA_silc GBR_silc GRC_silc HUN_silc IRL_silc ITA_silc LTU_silc LVA_silc NLD_silc POL_silc PRT_silc  SVK_silc SVN_silc SWE_silc NOR_silc
local eulfs AUT_silc BEL_silc BGR_silc  ROM_silc CHE_silc CYP_silc CZE_silc DEU_silc DNK_silc ESP_silc EST_silc FIN_silc FRA_silc GBR_silc GRC_silc HUN_silc IRL_silc ITA_silc LTU_silc LVA_silc NLD_silc POL_silc PRT_silc  SVK_silc SVN_silc SWE_silc //NOR_silc

local countries non_eulfs eulfs

*quiet {
foreach set in `countries' {
foreach c in ``set'' {

use "Data/Cleaned_data/`c'_all_std.dta", clear
display "`c'  " "`c'  " "`c'  " "`c'  " "`c'  "

local keepvars
local hh_wgtinc

foreach var in wj_mth wj_hr hh_hr hh_pe {
	foreach p in pppr usd {			//*Nominal (National currency), Nominal, but exchange rate adjusted (US$), PPPr adjusted

	*Kick out highest/lowest one percent if we are looking at non-eulfs country (eulfs: this is done while generating deciles)
	sum inc_`var'_`p' if inc_`var'_`p' > 0, d
	replace inc_`var'_`p' = . if inc_`var'_`p' <= r(p1) | inc_`var'_`p' >= r(p99)	//Drop highest/lowest percent of obs. NOT EULFS!
	
	*Replace household income to . if not household head
	if ("`var'" == "hh_hr" | "`var'" == "hh_pe") {
		capture noisily: gen hh_link = .
		sum hh_link 
		if r(N) == 0 {
			bysort hid: replace hh_link = 1 if _n == 1									//Take first person interviewed ig hh_link missing
		}
		replace inc_`var'_`p' = . if hh_link != 1
	}

	sum hh_wgt
	local mean = r(mean)
	local sd = r(sd)

	if r(mean) == 1 & r(sd) == 0 {
		local has_hhwgt = 0
		replace hh_wgt = .			//We changed hh_wgt to 1 if it as missing (see prepare dofile)
	}
	else {
		local has_hhwgt = 1
	}
	
	capture : sum inc_`var'_`p' if inc_`var'_`p' > 0 [aweight = wgt]				//Add the if condition!
			gen m_`var'_`p' = r(mean)*12			
		
	if "`var'" == "hh_hr" | "`var'" == "hh_pe" {
		foreach wgt in hh hhtot hhtot15plus {
		capture : sum inc_`var'_`p' if inc_`var'_`p' > 0 [aweight = `wgt'_wgt]		//Add the if condition!
			gen m_`var'_`p'_`wgt' = r(mean)*12	
			
			label variable m_`var'_`p'_`wgt' "mean hh inc., `wgt' weights"
						
			local hh_wgtinc `hh_wgtinc' m_`var'_`p'_`wgt'
		}
	}

	if `has_hhwgt' == 0 & ("`var'" == "hh_hr" | "`var'" == "hh_pe") {
		replace m_`var'_`p'_hh = m_`var'_`p'_hhtot15plus
	}

	local keepvars `keepvars' m_`var'_`p' `hh_wgtinc'
	}
}

capture noisily: gen country = "`c'"
replace country = ltrim(country)
replace country =  substr(country,1,3) 

if "`set'" == "non_eulfs" {
merge m:1 country using "Data/Cleaned_data/master_stats.dta", keepusing(gdppc_e9ry gdppc_e9ny gdppe_e9ry gdppe_e9ny xr_9y ppp_r ppp_c t1_e9ry t2_e9ry)
keep if _merge == 3
drop _merge
}
gen gdppc_e9usdy = gdppc_e9ny/xr_9y
gen gdppe_e9usdy = gdppe_e9ny/xr_9y			//GDP per employed, in current USD

local pppr = ppp_r[1]
local pppc = ppp_c[1]

gen eulfs = 0
if "`set'" == "eulfs" {
	replace eulfs = 1 
}
merge m:1 country using "Data/Cleaned_data/master_stats.dta", keepusing(q_e9ry t1_e9ry t2_e9ry)
keep if _merge == 3
drop _merge

keep country refyear eulfs `keepvars' ppp_r ppp_c gdppc_e9usdy gdppc_e9ry gdppe_e9usdy gdppe_e9ry q_e9ry t1_e9ry t2_e9ry
keep if _n == 1
	
*Append all countries
if "`c'" != "PER" {
	append using "Data/Cleaned_data/GDPPC_vs_MInc.dta"
} 

order country refyear eulfs
sort eulfs country
saveold "Data/Cleaned_data/GDPPC_vs_MInc.dta", replace version(12)

}
}




