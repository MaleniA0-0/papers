******************************************************************************************
* Program: IRQ_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Iraq
******************************************************************************************

use "Data\Iraq\HSES LSMS 2007\Data\ihses02_individuals_merged", clear 
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=string(xhhkey)
replace pid=xpers
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if q0105 == 1 //Reference Person
replace hh_link = 2 if q0105 == 2 //Spouse/Husband
replace hh_link = 3 if q0105 == 3  | q0105 == 4 | q0105 == 5 //child, child in law, grand child
replace hh_link = 4 if  q0105 == 6 //Ascendant (parent, grand parent)
replace hh_link = 98 if  q0105 == 9 //Not related
replace hh_link = 99 if  q0105 ==7 | q0105 == 8 //Others 

*-----------------------------------------

* Age 	
gen age=q0103

* Gender
replace male=1 if q0102==1
replace male=0 if q0102==2

*-----------------------------------------

* Weight
replace wgt=weight
gen hh_wgt = .

* Interview dates
replace refdatex=0
replace startdate=mdy(11,1,2006)										/* Data collection period */
replace enddate=mdy(11,1,2007)
format startdate enddate %td

*-----------------------------------------

gen educ=.
replace educ=1 if q0402==2 
replace educ=0 if q0402==1 | q0402==3 
gen educlvl=.
replace educlvl=1 if q0410l==5 | q0410l==6 & educ==1
replace educlvl=0 if q0410l<=4

gen edu = .
replace edu =1 if inrange(q0406,1,5)
replace edu =2 if inrange(q0406,6,8)
replace edu =3 if inrange(q0406,9,12)
replace edu =1 if edu == . & q0402==3
******************************************
* Market work															/* Universe for market section: Age 6 and above */
******************************************

* Employment status (market work)										/* People in universe with missing hours also have missing reason. They are assigned emp=. */
replace emp=1 if q0701>0 & q0701<.										/* Person is employed if hours is positive */
replace emp=2 if q0702==4 | q0702==9									/* 4:Have a contract and will start work soon, 9: Temporarily away due to illness/vacation/maternity etc */
replace emp=0 if q0702~=4 & q0702~=9 & q0702~=.							/* 1:Too young, 2:Student, 3:Social reasons, 5:Inability/handicap, 6:Retired, 7:Housewife, 8:No desire, 10:End of work, 11:Dismissed, 12:Unable to get a job, 13:Security reasons, 14:Other */

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*Work status
replace emp_wj = 1 if q1202a == 1
replace emp_se = 1 if q1202b1 == 1 | q1202b2 == 1
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* All jobs																/* Universe for hours question: Age 6 and above */

* Actual hours worked in last 7 days

replace ahrswk_aj=q0701													/* Hours are missing for those NIU and "those in universe but missing hours and reason for not working" are  missing */
replace ahrswk_aj=0 if q0701==. & (emp==0 | emp==2)

*q1204: Gives hours worked on job! How many hours have you worked in the last 7 days?
egen hrs = rowtotal(q1204_01 q1204_02 q1204_03 q1204_04 q1204_05 q1204_06 q1204_07),m
*replace ahrswk_aj ?!?

*Job Nature
replace ahrswk_wj_aj = hrs if q1202a == 1

*Flagging individuals
*We do not know whether individuals have only one job, we just know total hours: Noone makes it into set 1.
*we cannot identify second jobs or second job work status: No one makes it into set 2.
replace flag_set3 = 1 if q1202a == 1 & ahrswk_wj_aj != .						//These guys have main wage job

*-----------------------------------------
gen ind = .
replace ind =1 if inrange( q1302, 11, 50)
replace ind = 2 if inrange( q1302, 103, 410)
replace ind = 3 if inrange( q1302, 451, 990)

replace commuting = q1313/60*7*2 if emp == 1 | emp == 2
replace chrsday = q1313/60*2 if emp == 1 | emp == 2
replace chrsday = 0 if emp == 0
replace commuting = 0 if emp == 0

*-----------------------------------------
*Income	Wage jobs 	
*-----------------------------------------	
	gen days_worked = 0
	forvalues n = 1/7 {
		replace days_worked = days_worked+1 if q1204_0`n' != 0 & q1204_0`n' != .
	
	}
	gen months_worked = 0
	forvalues n = 1/9 {
		replace months_worked = months_worked + 1 if q1203_0`n' != 0 & q1203_0`n' != .
	
	}
		forvalues n = 10/12 {
		replace months_worked = months_worked + 1 if q1203_`n' != 0 & q1203_`n' != .
	
	}
	
	//Q. 1321 is for LAST SALARY RECEIVED, after tax or retirement deductions. I'm checking by mail what this means.
	gen wage = . 					
	replace wage = q1321c/q1322n * days_worked *52/12*months_worked/12 if q1322u == 1 & days_worked != 0	
		//Should be q1321u == 1, but that variable does not exist. Mistake in documentation?
	replace wage = q1321c/q1322n*15*months_worked/12	if q1322u == 1 & days_worked == 0
	replace wage = q1321c/q1322n*52/12*months_worked/12 if q1322u == 2
	replace wage = q1321c/q1322n*2*months_worked/12 if q1322u == 3
	replace wage = q1321c/q1322n*months_worked/12 if q1322u == 4

	
	gen inkind = .
	replace inkind  = q1321k/q1322n*days_worked*months_worked/12 if q1322u == 1
	replace inkind = q1321k/q1322n*52/12*months_worked/12 if q1322u == 2
	replace inkind = q1321k/q1322n*26/12*months_worked/12 if q1322u == 3
	replace inkind = q1321k/q1322n*months_worked/12 if q1322u == 4
	
	egen allowances = rowtotal(q1324c q1324k), m
	replace allowances = allowances/12		//To monthly standardization
	
	*Our standard variables:
	egen wj_c = rowtotal(wage allowances),m	
		replace inc_wj_aj_c_n = wj_c 
	replace inc_wj_aj_ik_n = inkind
	
	egen wj_ajtot = rowtotal(inc_wj_aj_c_n inc_wj_aj_ik_n),m
		replace inc_wj_aj_tot_n = wj_ajtot if q1202a == 1		//Only replace if wage job (makes no difference)

	
	/*
	*Check: 
	sum inc_wj_c_net if q1322u == 1 & days_worked != 0	//~360
	bysort q1322u: sum inc_wj_c_net				//much lower, ~330!
	
	bysort months_worked: sum inc_wj_aj_tot_n wj_ajtot
	
	*/
	
*-----------------------------------------
*2) Employer and self-employed: 
*-----------------------------------------
		*1) Crop production: N/A
		/*Next two lines already done in merge, as are household level variables
		gen rev = q1406a - q1407g //Without deduction of what is given to owner (variable does not exist)
		replace rev = rev * (q1406a/q1406q) */ 
		
		egen cost = rowtotal(q1414_01 q1414_02 q1414_03 q1414_04 q1414_05 q1414_06 q1414_07 q1414_08 q1414_09 q1414_17) 
		egen cost2 = rowtotal(q1406a q1411 q1412 q1413 q1413a),m
		egen cost3 = rowtotal(q1414_14 q1414_15 q1414_16 q1414_19), m
		
		gen profit_crops = (rev - cost - q1406a/cost2*cost3)/12
		drop rev cost cost2 cost3
		
		*2) Animal production
		egen rev = rowtotal(q1411 q1412 q1413), m 
		egen cost = rowtotal(q1414_10 q1414_11 q1414_12 q1414_13 q1414_18), m
		egen cost2 = rowtotal(q1411 q1412 q1413 q1413a)
		egen cost3 = rowtotal(q1406a q1411 q1412 q1413 q1413a), m
		egen cost4 = rowtotal(q1414_14 q1414_15 q1414_16 q1414_19), m
	
		gen profits_animal = (rev - cost - cost2/cost3*cost4)/12
	
		*3) Fishing
		gen profits_fishing = (q1416a + q1416b + q1416c - (q1417a + q1417b))/12
		
		*4) Forestry
		gen profits_forestry = (q1417_b + q1417_c - q1417_d)/12
		
		*5) Industrial
		gen profits_ind = (q1436+ q1437)/12
		
		*6) Trade activity 
		gen profits_trade = q1438/12  
		
		*7) Construction activity 
		gen profits_constr = q1439/12 
		
		*8) Transportation and communication activity
		gen profits_trans = q1440/12
		
		*9) Services activity 
		gen profits_services = q1441/12 
		
		*Not used: 
		/*
		*10) Property Income: Not available
		local property_vars  aglndrntinc aglndinc opsplndinc rsdbldinc nrsdbldinc eqprntinc trnsrntinc othrrntinc sharesinc prtprftnc intrstinc intprpinc
		egen profits_property = rowtotal(`property_vars'), m
		replace profits_property = profits_property/12
		
		*11) Transfer Income: 
		local transfer_vars  cvlpnsinc mltpnsinc inhpnsinc sspnsinc dsbpeninc spfpnsinc fmlcrfinc dsbsalinc mthsalinc socntwinc uneminc emrpyminc ocptralinc sclrshpinc
		egen transfers = rowtotal(`transfer_vars'), m
		replace transfers = transfers/12
		
		*12) Other Transfer
		local other_vars  hhirqcshinc hhabrcshinc govcshinc othirqcshinc othabrassinc hhirqkndinc hhabrkndinc govkndinc othirqkndinc othabrkndinc insrinc almninc zakatinc inherninc ltrprzinc othtrnsinc
		egen others = rowtotal(`other_vars'), m
		replace others = others/12
		
		*13) Capital revenues?
		gen cap_rev = capr_29
		*/

egen semp = rowtotal(profit_crops profits_animal profits_services profits_trans profits_constr profits_trade profits_ind profits_forestry profits_fishing), m	
*Can't really say if this is household or individual level, sometimes single individual answers, sometimes everyone in hh (same values)

*order hid pid inc_wj_aj_tot_n profit_crops profits_animal profits_services profits_trans profits_constr profits_trade semp


/*	We have some households where multiple individuals answer self employment income activities and give same values.
keep if semp != .
bysort hid: gen num = _n
tab num	
order hid pid num inc_wj_aj_tot_n semp
*/

*All households were giving their pay in thousands dinar. I.e., one has to multiply wage cash & inkind income by 1000!
foreach v in inc_wj_aj_tot_n semp {
	replace `v' = `v'*1000
} 	


bysort hid: egen hh_wj = total(inc_wj_aj_tot_n),m						//Include all possible incomes mentioned under wage jobs
egen hh_tot = rowtotal(hh_wj semp),m							//
	replace inc_hh = hh_tot

	
*******************
*Consumption 
*******************

gen expd  = expendp 	//Expenditures at paid prices
//expd = expendm			//Expenditures at market prices 


* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars' 
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
