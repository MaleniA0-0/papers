*******************************************************************************************************
* Program: BIH_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Bosnia and Herzegovina
*******************************************************************************************************

use "Data\Bosnia\LSMS 2001\Data\BIH_merged", clear
rename hid hhid
drop if a5_03==10																	/* Drop those in military service */

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs muncode gnd numist hhid
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid=muncodes+"-"+gnds+"-"+numists+"-"+hhids

foreach v in `vs'{
	drop `v's
}

replace pid=apno
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age= a1_02b

* Gender
replace male=1 if a1_02==1
replace male=0 if a1_02==2

*-----------------------------------------

* Weight 
replace wgt=weight_HHRoster

* Interview dates
replace refdatex=0
replace startdate=mdy(9,26,2001)
replace enddate=mdy(11,23,2001)
format startdate enddate %td

*-----------------------------------------
gen educ=.
replace educ=1 if a3_27==1
replace educ=0 if a3_27==2

gen educlvl=.
replace educlvl=1 if a3_35a>=8 & a3_35a!=.
replace educlvl=0 if a3_35a<8			
*vocational training is 7

******************************************
* Market work
******************************************

* Employment status in previous week												/* Universe: Age 15 and above */
replace emp=1 if a5_04==1 | a5_05==1
replace emp=2 if a5_06==1
replace emp=0 if (a5_04==2 & a5_06==2) | a5_05==2 | a5_03==11						/* Did not work in previous week and did not have a job to go back to, or is incapable to work */

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=4 if emp==2 & a5_07==6
replace reason=3 if emp==2 & a5_07==8
replace reason=5 if emp==2 & a5_07==9
replace reason=2 if emp==2 & a5_07==10
replace reason=7 if emp==2 & (a5_07>=1 & a5_07<=5) | a5_07==7 | (a5_07>=11 & a5_07<=13)
replace reason=. if emp==2 & a5_07==88

*-----------------------------------------

* Main job

* Usual hours worked per week		
replace uhrswk_mj=a5_17
replace uhrswk_mj=. if a5_17==777
replace uhrswk_mj=0 if uhrswk_mj==. & (emp==0 | emp==2)	

* Actual hours worked in previous week		
replace ahrswk_mj=a5_19
replace ahrswk_mj=. if a5_19==777
replace ahrswk_mj=0 if ahrswk_mj==. & (emp==0 | emp==2)							/* Replace missing hours with 0 if person did not work last week */

*-----------------------------------------

* Sec job

* Actual hours worked in previous week		
replace ahrswk_sj=a5_30
replace ahrswk_sj=0 if a5_30==. & (emp==0 | emp==2)								/* Replace missing hours with 0 if person did not work last week */

******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx
local time ahrswk uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}
replace a5_09=. if a5_09==8 													/* 8 is an invalid value */
replace mj_wj=1 if a5_10==7 | a5_10==8 | a5_10==10
replace mj_sa=1 if ((a5_10>=1 & a5_10<=4) | a5_10==5 | a5_10==6 | a5_10==11) & (a5_09>=1 & a5_09<=5)
replace mj_sn=1 if ((a5_10>=1 & a5_10<=4) | a5_10==5 | a5_10==6 | a5_10==11) & (a5_09>=10 & a5_09<=99)
replace mj_sx=1 if ((a5_10>=1 & a5_10<=4) | a5_10==5 | a5_10==6 | a5_10==11) & a5_09==.


replace sj_wj=1 if a5_29==7 | a5_29==8 | a5_29==10
replace sj_sa=1 if ((a5_29>=1 & a5_29<=4) | a5_29==5 | a5_29==6 | a5_29==11) & (a5_32>=1 & a5_32<=5)
replace sj_sn=1 if ((a5_29>=1 & a5_29<=4) | a5_29==5 | a5_29==6 | a5_29==11) & (a5_32>=10 & a5_32<=99)
replace sj_sx=1 if ((a5_29>=1 & a5_29<=4) | a5_29==5 | a5_29==6 | a5_29==11) & a5_32==.


* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
