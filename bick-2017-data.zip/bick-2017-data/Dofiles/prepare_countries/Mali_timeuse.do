clear

use "Data\Mali\EPAM 2010\Data\EPAM_2010_Individu.dta" 
 
*Questionnaire 2010 page 5/11
***************************************************
* Standard Variables:
	*1) Age	
		*gen age=agex
	*2) Country
		gen country = "MLI"
	*3) Gender
		gen male=.
		replace male=1 if sexe==1
		replace male=0 if sexe==2
	*4) Year
		gen year = 2010
	*5) Weight
		gen wgt = iWeight
	
*________________________________________________________________________________________

*Data we need: Four categories

	*1) Cooking  (av6)
		gen p_cooking = EA1C
		recode p_cooking (2=0)
		gen cooking =  EA1C_OUI				  					/* cooking*/
		replace cooking = 0 if p_cooking == 0 & cooking == .
		replace p_cooking = 1 if cooking > 0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_cleaning = EA1B
		recode p_cleaning (2=0)
		gen cleaning =   EA1B_OUI				 					/*laundry and cleaning the house*/
		replace cleaning = 0 if p_cleaning == 0 & cleaning == .
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_childcare = EA1F
		recode p_childcare (2=0)
		gen childcare = EA1F_OUI
		replace childcare = 0 if p_childcare == 0 & childcare == .
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .									/*going to market*/
		gen p_goods_services = .
		
	*5) Fetching water and firewoof
		gen p_wood = EA1D
		recode p_wood (2=0)
		gen wood = EA1D_OUI
		replace wood = 0 if p_wood == 0 & wood == .
		
		gen p_water = EA1E
		recode p_water (2=0)
		gen water = EA1E_OUI
		replace water = 0 if p_water == 0 & water == .

		*____________________________________________________________________________________*
	
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(wood water)
		replace coll_wf = . if (water == . & wood == .)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/MLI_timeuse.dta", replace

