******************************************************************************************
* Program: PAK_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Pakistan
******************************************************************************************

use "Data\Pakistan\LFS 2010-11\Data\lfs2010-11", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id 
drop hid
gen hid=string(PrCode,"%11.0g")
replace pid=Sec4_4_1
order hid pid																	//Pakistan: There is something weird with the hid! Some hid have been handed out multiple times!
sort hid pid

gen hh_link = .
replace hh_link = 1 if  Sec4_4_3 == 1 //Reference Person
replace hh_link = 2 if  Sec4_4_3 == 2 //Spouse/Husband
replace hh_link = 3 if  Sec4_4_3 == 3  |  Sec4_4_3 == 4 //child, married & unmarried
replace hh_link = 4 if   Sec4_4_3 == 5  //Ascendant (parent, grand parent)
replace hh_link = 98 if   Sec4_4_3 == 9 |  Sec4_4_3 ==8 //Not related
replace hh_link = 99 if   Sec4_4_3 ==6 |  Sec4_4_3 ==7  //Others 

*-----------------------------------------

* Age   
gen age= Sec4_4_6

* Gender
replace male=1 if Sec4_4_5==1
replace male=0 if Sec4_4_5==2

*-----------------------------------------

* Weight
replace wgt=weights		//Looks like cluster weight
gen hh_wgt = .	//weights

* Interview date 													/* Interview date is not given. Only survey quarter is given.*/
replace refdatex=0

replace startdate=mdy(7,1,2010) if SurPeriod==1	 					/* SurPeriod: 1=July-Sept, 2=Oct-Dec, 3=Jan-Mar, 4=Apr-Jun*/
replace enddate=mdy(9,30,2010) if SurPeriod==1
replace startdate=mdy(10,1,2010) if SurPeriod==2	 				
replace enddate=mdy(12,31,2010) if SurPeriod==2
replace startdate=mdy(1,1,2011) if SurPeriod==3	 				
replace enddate=mdy(3,31,2011) if SurPeriod==3
replace startdate=mdy(4,1,2011) if SurPeriod==4	 				
replace enddate=mdy(6,30,2011) if SurPeriod==4
format  startdate enddate %td

*-----------------------------------------

gen educ=.
replace educ=1 if Sec4_4_10>=4 & Sec4_4_10!=.
replace educ=0 if Sec4_4_10==1
gen educlvl=.
replace educlvl=1 if Sec4_4_10>=08 & Sec4_4_10!=.
replace educlvl=0 if Sec4_4_10<8 & Sec4_4_10>=4

gen edu = .
replace edu= 1 if inrange( Sec4_4_9, 1,5)
replace edu= 2 if inrange( Sec4_4_9, 6,7)
replace edu= 3 if inrange( Sec4_4_9, 8,14)

******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe for employment status qns: Age 10 and above */
replace emp=1 if Sec5_5_2==1 | Sec5_5_3==1
replace emp=0 if Sec5_5_2==2 & Sec5_5_3==2 & (Sec5_5_4==3 | Sec5_5_4==4)
replace emp=2 if Sec5_5_2==2 & Sec5_5_3==2 & (Sec5_5_4==1 | Sec5_5_4==2)

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=2 if emp==2 & Sec5_5_5==3
replace reason=3 if emp==2 & Sec5_5_5==1
replace reason=4 if emp==2 & Sec5_5_5==2
replace reason=5 if emp==2 & Sec5_5_5==9
replace reason=7 if emp==2 & ((Sec5_5_5>=4 & Sec5_5_5<=8) | (Sec5_5_5>=10 & Sec5_5_5<=12))

*Work status
replace emp_wj = 1 if Sec5_5_8 == 1 | Sec5_5_8 == 2 | Sec5_5_8 == 3 | Sec5_5_8 == 4
replace emp_se = 1 if inrange(Sec5_5_8,5,11)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Main Job															/* Universe for hours qns: Age 10 and above, and is employed */

* Actual hours worked last week
replace ahrswk_mj=Sec5_5_17_1 
replace ahrswk_mj=0 if Sec5_5_17_1==. & (emp==0 | emp==2)

*-----------------------------------------

* Second Job

* Actual hours worked last week
replace ahrswk_sj=Sec5_5_26
replace ahrswk_sj=0 if Sec5_5_26==. & (emp==0 | emp==2)


******************************************
* Non-market work													/* Universe: Age 10 and above and did not work last week, did not have a job to return to, is not available for work last week due to housekeeping or being unwilling to work, and the last time sought work was some months ago */
******************************************

egen nm=anymatch(Sec10_10_1_i_1 Sec10_10_1_ii_1 Sec10_10_1_iii_1 Sec10_10_1_iv_1 Sec10_10_1_vi_1 Sec10_10_1_vii_1  Sec10_10_1_viii_1), value(1)
replace nm=. if Sec10_10_1_i_1==. & Sec10_10_1_ii_1==. & Sec10_10_1_iii_1==. & Sec10_10_1_iv_1==. & Sec10_10_1_vi_1==. & Sec10_10_1_vii_1==. & Sec10_10_1_viii_1==.
replace emp_nm=nm

* Actual hours worked last week in non-market activities
egen ahrswk_nmsa=rowtotal(Sec10_10_1_i_2 Sec10_10_1_ii_2 Sec10_10_1_iii_2 Sec10_10_1_iv_2 Sec10_10_1_vi_2 Sec10_10_1_vii_2), missing 
replace ahrswk_nmsa=0 if ahrswk_nmsa==. & emp_nm==0

gen ahrswk_nmsn=Sec10_10_1_viii_2
replace ahrswk_nmsn=0 if ahrswk_nmsn==. & emp_nm==0

egen nmtot=rowtotal(ahrswk_nmsa ahrswk_nmsn), missing
replace ahrswk_nm=nmtot

******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

#delimit ;

replace mj_wj=1 if Sec5_5_8>=1 & Sec5_5_8<=4 ;
replace mj_sa=1 if (Sec5_5_8>=7 & Sec5_5_8<=9) | 
((Sec5_5_8==5 | Sec5_5_8==6 | Sec5_5_8==10 | Sec5_5_8==11) & Sec5_5_10<=5) ;
replace mj_sn=1 if (Sec5_5_8==5 | Sec5_5_8==6 | Sec5_5_8==10 | Sec5_5_8==11) & Sec5_5_10>5 & Sec5_5_10<. ;
replace mj_sx=1 if (Sec5_5_8==5 | Sec5_5_8==6 | Sec5_5_8==10 | Sec5_5_8==11) & Sec5_5_10==. ;
replace mj_uc=1 if Sec5_5_8==12 | Sec5_5_8==72;						/* '12' is the largest option available. '72' is likely to be an error */

replace sj_wj=1 if Sec5_5_19>=1 & Sec5_5_19<=4 ;
replace sj_sa=1 if (Sec5_5_19>=7 & Sec5_5_19<=9) | 
((Sec5_5_19==5 | Sec5_5_19==6 | Sec5_5_19==10 | Sec5_5_19==11) & Sec5_5_21<=5) ;
replace sj_sn=1 if (Sec5_5_19==5 | Sec5_5_19==6 | Sec5_5_19==10 | Sec5_5_19==11) & Sec5_5_21>5 & Sec5_5_21<. ;
replace sj_sx=1 if (Sec5_5_19==5 | Sec5_5_19==6 | Sec5_5_19==10 | Sec5_5_19==11) & Sec5_5_21==. ;
replace sj_uc=1 if Sec5_5_19==12 ;

#delimit cr

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen satot=rowtotal(ahrswk_sa ahrswk_nmsa), missing
replace ahrswk_sa=satot
egen sntot=rowtotal(ahrswk_sn ahrswk_nmsn), missing
replace ahrswk_sn=sntot

*Paul: 10.02.2017: Filter mian wage job hours (we only have main wage job income)
replace ahrswk_wj_mj = ahrswk_mj if mj_wj == 1									//These guys have main job wage activity!
replace ahrswk_wj_aj = ahrswk_wj_mj if Sec5_5_18 == 2							//This is total hours in wage activities
replace ahrswk_wj_aj = ahrswk_wj if Sec5_5_18 == 1 & (Sec5_5_19 == 1 | Sec5_5_19 == 2 | Sec5_5_19 == 3 )	//These guys have a secondary wage occupation

replace flag_set1 = 1 if (Sec5_5_8>=1 & Sec5_5_8<=4 ) & Sec5_5_18 == 2			//Main wj = total hours: Ind. has only one job!
*Note: 9 individuals state they do not have secondary occupations, but then have additional hours. These guys are taken out of set 1.	
egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
replace flag_set1 = 0 if flag_set1 == 1 & diff1 < 0

*Since we do NOT have second/third wj income, we cannot add any additional individuals to set 2 or three.
replace flag_set2 = 1 if flag_set1 == 1
replace flag_set3 = 1 if flag_set2 == 1 | ((Sec5_5_8>=1 & Sec5_5_8<=4 ) & Sec5_5_18 == 1 & (Sec5_5_19>=1 & Sec5_5_19<=4)) 
//These guys have a main job employee (for which we know income) but additional jobs are non-wage!

sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1
	
	
*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													/* Not stated */
replace chrsx=2

*-----------------------------------------

gen ind = .
replace ind = 1 if inrange( Sec5_5_10, 1,5)
replace ind = 2 if inrange( Sec5_5_10, 10,41)
replace ind = 3 if inrange( Sec5_5_10, 45,99)

*-----------------------------------------
*Income (for paid employees only)
*-----------------------------------------
gen inc_mj = Sec7_7_4										//Monthly earnings, cash and inkind, net
	replace inc_mj =  Sec7_7_3*52/12 if inc_mj == .			//Weekly earnings, in case 7.7.4 is missing
	
gen inc_bonus = Sec7_7_5/12

*Our standard variable
egen mj_tot = rowtotal(inc_mj inc_bonus), m
	replace inc_wj_mj_tot_n = mj_tot if Sec5_5_8 == 1 | Sec5_5_8 == 2 | Sec5_5_8 == 3 | Sec5_5_8 == 4	//Include: Casual Employees (Sec5_5_8 == 2)

bysort hid: egen hh_sewj = total(mj_tot),m		//Include all incomes, not only wages, but also self employment incomes in household
	replace inc_hh = hh_sewj
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars' ahrswk_wj_mj
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
