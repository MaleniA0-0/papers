*******************************************************************************************
* Program: ALB_prepar.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Albania
*******************************************************************************************

use "Data\Albania\LFS/LFS 2012", clear

* Initialize some variables 
qui do Dofiles/initialize_variables


* Generate household and personal id
tostring PSU HH QUARTER, generate(psu hh quarter)
gen hhid = quarter+""+psu+""+hh
drop hid
gen hid = hhid
replace pid=ID_PERSON
*Note: Looks like there are follow up interviews in the dataset
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=AGE

* Gender
replace male=1 if SEX==1
replace male=0 if SEX==2

*-----------------------------------------

* Weight
replace wgt=Final_weight_REV
gen hh_wgt = .

* Interview date
replace refdatex=0
replace refyear=YEAR

gen hh_link = HHLINK
replace hh_link = 98 if HHLINK == 6
replace hh_link = 99 if HHLINK == 5

*-----------------------------------------
*School
gen edu = .
replace edu = 1 if inrange(Q128,1,2)
replace edu = 2 if inrange(Q128,3,6)
replace edu = 3 if inrange(Q128,7,12)


******************************************
* Market work		Questionnaire page 																/* Universe: Age 15 and above */
******************************************

* Employment status in the last 7 days
replace emp = 1 if inrange(Q21,1,5)
replace emp = 0 if Q21 == 6
replace emp = 2 if Q21 == 6 & Q22 == 1

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=2 if NOWKREAS==7	| NOWKREAS==6						 /* vacation or public holiday*/
replace reason=3 if	NOWKREAS==12									 /* sickness */		
replace reason=4 if NOWKREAS==5										 /* labour dispute */
replace reason=5 if NOWKREAS==11									 /* maternity and paternity leave */
replace reason=7 if inrange(NOWKREAS,2,4)
replace reason = 7 if NOWKREAS == 8 | NOWKREAS == 9 | NOWKREAS == 10 /* other reasons */

replace emp_wj = 1 if Q26 == 1
replace emp_wj = 1 if Q31 == 1
replace emp_se = 1 if inrange(Q26,2,4)
replace emp_se = 1 if inrange(Q31,2,4)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .

*-----------------------------------------
*All Jobs
replace ahrswk_aj = Q84

* Main job
* Actual hours worked in last 7 days
replace ahrswk_mj=Q55
replace ahrswk_mj= . if Q55 == 99									 //Don't know

* Usual Hours 
 replace uhrswk_mj =  Q54
replace uhrswk_mj= . if Q54 == 99


*-----------------------------------------

* Sec job
* Actual hours worked in last 7 days
replace ahrswk_sj=Q83
replace ahrswk_sj=. if Q83 == 99

******************************************
* Hours worked by job characteristics
******************************************


* Generate indicators for main and sec jobs
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

gen mj_agr = 1 if  inrange(NACE2J2D,1,14)
gen mj_nonagr = 1 if inrange(NACE2J2D,15,99)
replace mj_wj=1 if emp_wj == 1
replace mj_sa=1 if emp_se == 1 & mj_agr == 1
replace mj_sn=1 if emp_se == 1 & mj_nonagr == 1

replace sj_wj=1 if Q82 == 1
gen sj_se = 1 if inlist(Q82,2,4)
*We do not know industry of second job (Q81_2 is a string in albanian), so we can't code se hours by job nature

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
replace ahrswk_wj_mj = ahrswk_mj if emp_wj == 1
replace ahrswk_wj_aj = ahrswk_wj_mj if Q79 == 2
replace ahrswk_wj_aj = hrs if Q79 == 1 & sj_wj == 1


replace flag_set1 = 1 if emp_wj==1 & Q79 == 2									//Person has only one job (q41), which is wage
replace flag_set2 = 1 if flag_set1 == 1											//Don't know additional wj income
replace flag_set3 = 1 if flag_set2 == 1 | (emp_wj == 1 & Q79 == 1 & sj_se == 1)

*-----------------------------------------
* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

gen ind = .
replace ind = 1 if inrange(NACE2J2D,1,14)
replace ind = 2 if inrange(NACE2J2D,15,45)
replace ind = 3 if inrange(NACE2J2D,46,99)

*-----------------------------------------
*Income
*Wage jobs
*Main job: Payment in OLD LEKs 10 old = 1 new lek)
gen inc_mjc = .
replace inc_mjc = Q65 if Q66 == 1												//Monthly
replace inc_mjc = Q65*26/12 if Q66 == 2											//Biweek-->Month
replace inc_mjc = Q65*52/12 if Q66 == 3											//Week-->Month
replace inc_mjc = . if Q66 == 4													//Daily: Not possible

gen inc_mjb = Q70/Q71															//Bous*(times per year)/12
gen inc_mjik = Q73/12
	
egen wj_tot = rowtotal(inc_mjc inc_mjb inc_mjik),m
replace inc_wj_mj_tot_n = wj_tot/10 if emp_wj == 1

*Self Employed
*Main Job: Use reported profits directly, rev - costs doesn't look too good
*gen se_rev = Q74
*egen se_cost = rowtotal(Q75_1 Q75_2 Q75_4 Q75_5 Q75_6 Q75_7),m
*gen se_profits = se_rev - se_cost
gen se_profits = Q77
replace se_profits = Q78*(-1) if (Q78 > 0 & Q78 != .) & Q77 == .

replace inc_se_mj_tot_n = se_profits/10


*Total individual income
egen tot_wjse = rowtotal(inc_wj_mj_tot_n inc_se_mj_tot_n),m
replace ind_tot_wjse = tot_wjse


*Household income
bysort hid: egen hh_wj = total(inc_wj_mj_tot_n),m
bysort hid: egen hh_se = total(inc_se_mj_tot_n),m
egen hh_tot = rowtotal(hh_wj hh_se),m 
	replace inc_hh = hh_tot
	
* Keep standardized variables
keep hid pid ahrsday_aj-age edu ind quarter
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
