
clear all

***********************************************************************************************
**Run through and Put all countryfiles together
***********************************************************************************************
local countries Benin Brazil Egypt Ghana Guatemala Iraq Kazakhstan Lesotho Mali Pakistan Russia Tajikistan Mongolia Tanzania Uganda China Kyrgyzstan TimorLeste
foreach c in `countries' {

qui do "Dofiles\Paul\Time Use Standardization/`c'_timeuse"

save "Data\Cleaned_data/`c'_timeuse", replace
}

use "Data/Cleaned_data/Benin_timeuse.dta"

foreach c in `countries' {
	if "`c'"!="Benin" {
	append using "Data/Cleaned_data/`c'_timeuse.dta"
	}
}
keep age-coll_wf 
order country year age male cooking-goods_services coll_wf hrs_hw
gen MTUS=0

append using "MTUS\Data/MTUS_W53_copy.dta"
keep country year age-hrs_hw MTUS p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

rename goods_services shopping
rename coll_wf collwf
rename hrs_hw totalhrs
*replace totalhrs=0 if country!="BRA" | country!="MNG"

save "Data/Cleaned_data/Timeuse_merged.dta", replace

