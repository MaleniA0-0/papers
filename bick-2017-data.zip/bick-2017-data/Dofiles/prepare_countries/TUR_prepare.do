******************************************************************************************
* Program: TUR_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Turkey
******************************************************************************************

use "Data\Turkey\HLFS 2011\Data\2011yil", clear 

* Initialize some variables 
qui do Dofiles/initialize_variables

* Destring key variables
local vs s1 s26 s27 s28 s29 s55a s56a_top s56b_top s33kod s53kod s39 s54 s55a 
foreach v in `vs'{
	destring `v', replace
}

*-----------------------------------------

* Generate household and personal id
replace hid=string(formno,"%12.0g")
replace pid=s1
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if  s11 == 1 //Reference Person
replace hh_link = 2 if  s11 == 2 | s11 == 4 //Spouse/Husband
replace hh_link = 3 if  s11 == 3 | s11 == 5 //child, grand child
replace hh_link = 4 if   s11 == 6 //Ascendant (parent, grand parent, parent in law)
replace hh_link = 98 if  s11 == 8 //Not related
replace hh_link = 99 if   s11 == 7   //Others 

*-----------------------------------------

* Age 	
gen age=s6

* Gender
replace male=1 if s3=="1"
replace male=0 if s3=="2"

*-----------------------------------------

* Weight
replace wgt=faktor
gen hh_wgt = .		//No household weight

* Interview date																	/*  This survey is conducted monthly throughout the year */
replace refdatex=0
replace startdate=mdy(1,1,2011)
replace enddate=mdy(12,31,2011)
format startdate enddate %td

*-----------------------------------------
*schooling
gen educ=.
replace educ=1 if s17=="1"
replace educ=0 if s17=="2"
gen educlvl=.
replace educlvl=1 if s18=="5" | s18=="6"
replace educlvl=0 if s18=="4" | s18=="3" | s18=="2" | s18=="1"

*Educational status N/A
gen edu = .
replace edu = 1 if s13 == 1 | s13 == 2
replace edu = 2 if s13 == 3 | s13 == 4 | s13 == 5
replace edu = 3 if s13 == 6


******************************************
* Market work Questionnaire page 5
******************************************

* Employment status (market work)													/* Universe for market section: Age 15 and above */
replace emp=1 if s26==1 | s27==1													/* Worked to earn income in cash or in kind? ; even if you are a housewife, student or retired person, did you worked as paid of unpaid worker even for one hour in refweek? */
replace emp=2 if s28==1																/* Temporarily absent from business or job */
replace emp=0 if s26==2 & s27==2 & s28==2

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=2 if emp==2 & s29==3
replace reason=3 if emp==2 & s29==1
replace reason=5 if emp==2 & s29==2
replace reason=7 if emp==2 & s29>=4 & s29<=9

*Work status
replace emp_wj = 1 if s39 == 1 
replace emp_se = 1 if inrange(s39,2,4)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Main job

* Usual hours per week
replace uhrswk_mj=s55a 
replace uhrswk_mj=0 if s55a==. & (emp==0 | emp==2)									/* Replace missing hrs with 0 if person did not work during refweek */

* Actual hours worked during reference week
replace ahrswk_mj=s56a_top 
replace ahrswk_mj=0 if s56a_top==. & (emp==0 | emp==2)

*-----------------------------------------

* Sec job

* Actual hours worked during reference week
replace ahrswk_sj=s56b_top
replace ahrswk_sj=0 if s56b_top==. & (emp==0 | emp==2)

* Usual hours per week


*-----------------------------------------
		
* Hours worked by job nature 
local jobs mj sj
local nature wj sa sn
local time ahrswk uhrswk

* Generate indicator for each job nature
foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if s39==1 
replace mj_sa=1 if s39>=2 & s39<=4 & s33kod<=3
replace mj_sn=1 if s39>=2 & s39<=4 & s33kod>=4 & s33kod<=99

replace sj_wj=1 if s54==1 
replace sj_sa=1 if s54>=2 & s54<=4 & s53kod==1
replace sj_sn=1 if s54>=2 & s54<=4 & s53kod>=2 & s53kod<=4

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen hrs = rowtotal(ahrswk_mj ahrswk_sj), m
destring s52, replace
*We have main wage job income and need to filter those with only one job (in wage activity). Cannot additionally add anyone to sets 2 and 3.
replace ahrswk_wj_mj = ahrswk_mj if s39==1 										//Employee status
replace ahrswk_wj_aj = ahrswk_wj_mj if s52 == 2 & s39==1 							//Only one employee job
replace ahrswk_wj_aj = ahrswk_wj if s52 == 1 & s54==1 							//Multiple employee wage jobs

replace flag_set1 = 1 if s39==1 & s52 == 2										//Only one employee job
*Since we do not have total wage job income, cannot add individuals to set 2 or 3
replace flag_set2 = 1 if flag_set1 == 1
replace flag_set3 = 1 if flag_set2 == 1 | (s52 == 1 & (s54 != 1 & s54 != .))

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

gen ind = .
replace ind = 1 if inrange(s33kod,1,9)
replace ind = 2 if inrange(s33kod,10,44)
replace ind = 3 if inrange(s33kod,44,99)


*-----------------------------------------
*Income from main wage job
*-----------------------------------------
*employees, main job, for those who in Question 39 (What is you employment status) have codes 
		//1: Regular/casual employee, 
		//2: Employed, or
		//3: Self-Employed.
*--> However, only code 1 is asked income question: bysort s39: sum inc_wj_mj_tot_n

destring s69, gen(inc_wj)
destring s70, gen(inc_wj_ben)

replace inc_wj_mj_tot_n = inc_wj if s39 == 1 	//Only wage incomes matter

bysort hid: egen hh_wj = total(inc_wj),m	//Rely on all incomes, irrespective of wage/self employed
	replace inc_hh = hh_wj

	/*
gen income_wj = inc_wj_mj_tot_n if income_wj == .

gen inc_wj_hr = income_wj/hrs
gen hr_wage = income_wj/ahrswk_wj_mj		
	*/
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl hh_link hh_wgt `income_vars' edu ind
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
