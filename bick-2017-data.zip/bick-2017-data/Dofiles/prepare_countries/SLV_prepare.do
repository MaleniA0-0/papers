********************************************************************************************
* Program: SLV_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for El Salvador
********************************************************************************************

use "Data\El Savador\VI Population and V Housing Census (IPUMS) 2007\Data\ipumsi_00057", clear						
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hid=string(serial,"%12.0g")
replace pid=pernum
order hid pid
sort hid pid

*-----------------------------------------

* Age 
rename age agex
gen age=agex

* Gender
replace male=1 if sex==1
replace male=0 if sex==2

*-----------------------------------------

* Weight
replace wgt=wtper

* Interview date
replace refdatex=0
replace startdate=mdy(5,12,2007)	
replace enddate=mdy(5,27,2007)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.
*IPUMS Data - no information on schooling available

******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe: Age 10 and above */
replace emp=1 if empstat==1
replace emp=0 if empstat==2 | empstat==3							/* Not employed if empstat is unemployed (2) or inactive (3) */

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1

*-----------------------------------------

* Actual hours worked last week (all job)							/* Hours worked in the week prior to the beginning of the census, or in your last job*/
replace ahrswk_aj=HRSWRK1
replace ahrswk_aj=. if HRSWRK1==999									/* Set hours to missing if HRSWRK1 is NIU (999)*/
replace ahrswk_aj=0 if ahrswk_aj==. & emp==0						/* Replace missing hours with 0 if person is clearly not working */

*-----------------------------------------

* Hours worked by job nature							
local time ahrswk
foreach t in `time'{
	replace `t'_wj=`t'_aj if classwk==2
	replace `t'_sa=`t'_aj if (classwk==1 | classwk==3) & indgen==10
	replace `t'_sn=`t'_aj if (classwk==1 | classwk==3) & indgen>10 & indgen<999
	replace `t'_sx=`t'_aj if ((classwk==1 | classwk==3) & indgen==999) 
	replace `t'_uc=`t'_aj if classwk==9	| classwk==4							/* Hours with classwk=="Unknown/missing 9" or "others 4" are not classified */
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
