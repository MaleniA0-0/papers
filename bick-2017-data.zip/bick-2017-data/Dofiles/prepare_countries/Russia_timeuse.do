clear

use "Data\Russia\RLMS\2009\Data\hhind\rrinadlt.dta" 
 
***************************************************
* Standard Variables:
	*1) Age	
		gen age= irintyer - irbirthy
	*2) Country
		gen country = "RUS"
	*3) Gender
		gen male=.
		replace male=1 if irgender==1
		replace male=0 if irgender==2
	*4) Year
		gen year = 2009
	*5) Weight
		gen wgt = inwgt_r
	
*___Questionnaire Page 40/62_____________________________________________________________________________________

*Data we need: Four categories
local variables irwpfoo irnwpfoo irwprepf irnwprep irwwash irnwwash irwlaun irnwlaun irwclea irnwclea irwlach irnwlach irwplay irnwplay

foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Need to replace daily variables with weekly values: Assume 5 workdays and two leisure days. 
local w_variables irwpfoo irwprepf irwwash irwlaun irwclea irwlach irwplay
local nw_variables irnwpfoo irnwprep irnwwash irnwlaun irnwclea irnwlach irnwplay

foreach w in `w_variables' {
	replace `w'=`w'_hrs*5
}
foreach nw in `nw_variables' {
	replace `nw'=`nw'_hrs*2
}

*need to recode don't knows and refuses to missings
recode irwprepf irnwprep irwwash irnwwash irwlaun irnwlaun irwclea  irnwclea irwlach irnwlach irwplay irnwplay irwpfoo irnwpfoo (997 = .) (998 = .)

	*1) Cooking  (av6)
		gen p_cook = irpredf
		recode p_cook (2=0)
		egen cook = rowtotal(irwprepf irnwprep), missing
		replace cook = 0 if p_cook == 0 & cook == .
		
		gen p_dish = irwashed
		recode p_dish (2=0)
		egen dish = rowtotal(irwwash irnwwash), missing
		replace dish = 0 if p_dish == 2 & dish == .

		*____________________________________________________________________________________*

		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
		
		egen cooking = rowtotal(cook dish)						/* cooking*/
		replace cooking = . if (cook ==. & dish ==.)
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_wash = irlaundr
		recode p_wash (2=0)
		egen wash = rowtotal(irwlaun irnwlaun), missing
		replace wash = 0 if p_wash == 0 & wash == .
		
		gen p_clean = ircleane
		recode p_clean (2=0)
		egen clean = rowtotal(irwclea  irnwclea), missing
		replace clean = 0 if p_clean == 0 & clean == .
		
		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_clean + p_wash >=1) & (p_clean + p_wash != .)
		replace p_cleaning = 0 if (p_clean + p_wash == 0)
				
		egen cleaning =  rowtotal(wash clean)	  					/*laundry and cleaning the house*/
		replace cleaning = . if (clean ==. & wash ==.)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
		
	*3) Childcare (Av11)
		gen p_kid1 = irlaftch
		recode p_kid1 (2=0)
		egen kid1 = rowtotal(irwlach irnwlach), missing
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = irplayed
		recode p_kid2 (2=0)
		egen kid2 = rowtotal(irwplay irnwplay), missing
		replace kid2 = 0 if p_kid2 == 0 & kid2 == .
		
		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)
		
		egen childcare = rowtotal( kid1 kid2)
		replace childcare = . if (kid1 ==. & kid2 == .)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = irpfoodg
		recode p_goods_services (2=0)
		egen goods_services = rowtotal(irwpfoo irnwpfoo), missing			/*going to market*/
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Water and Firewood
		gen coll_wf = .
		gen p_coll_wf = .
	
	*6) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/RUS_timeuse.dta", replace

