*******************************************************************************************
* Program: TJK_07_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Tajikistan
*******************************************************************************************

use "Data\Tajikistan\LSMS 2007\Data\TJK07_merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hid=string(hhid)
replace pid=memid
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=m1q3

* Gender
replace male=1 if m1q2==1
replace male=0 if m1q2==2

*-----------------------------------------

* Weight
replace wgt=popw

* Interview date
replace refdatex=1
replace refdate=mdy(datemont, dateday, 2007)
format refdate %td

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if m3bq7==1
replace educ=0 if m3bq7==2
gen educlvl=.
replace educlvl=1 if m3bq9a==6 | m3bq9a==7
replace educlvl=0 if m3bq9a<=5


******************************************
* Market work																		/* Universe: Age 14 and above */
******************************************

* Employment status (market work) in the last 14 days
replace emp=1 if m5aq4==1 | m5aq5==1					//why not worked on own account?!
replace emp=0 if m5aq4==2 & m5aq5==2
replace emp=2 if m5aq4==2 & m5aq5==2 & m5aq6==1

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1 
replace reason=3 if emp==2 & m5aq7==1
replace reason=5 if emp==2 & m5aq7==2
replace reason=2 if emp==2 & (m5aq7==4 | m5aq7==10)
replace reason=7 if emp==2 & (m5aq7==3 | (m5aq7>=5 & m5aq7<=9) | (m5aq7>=11 & m5aq7<=14))

*-----------------------------------------

* Main job

* Actual hours worked per week in last 14 days
replace ahrswk_mj=ahrswk_mjx
replace ahrswk_mj=0 if (emp==0 | emp==2) & ahrswk_mjx==.

* Actual days worked per week in last 14 days	
replace adayswk_mj=adayswk_mjx
replace adayswk_mj=0 if (emp==0 | emp==2) & adayswk_mjx==.

* Actual weeks worked in last 12 months
replace wksyr_mj=wksyr_mjx
replace wksyr_mj=0 if (emp==0 | emp==2) & wksyr_mjx==.

*-----------------------------------------

* Sec job

* Actual hours worked per week in last 14 days
replace ahrswk_sj=ahrswk_sjx
replace ahrswk_sj=0 if (emp==0 | emp==2) & ahrswk_sjx==.

* Actual days worked per week in last 14 days	
replace adayswk_sj=adayswk_sjx
replace adayswk_sj=0 if (emp==0 | emp==2) & adayswk_sjx==.

* Actual weeks worked in last 12 months
replace wksyr_sj=wksyr_sjx
replace wksyr_sj=0 if (emp==0 | emp==2) & wksyr_sjx==.

******************************************
* Non-market work																		/* Universe: All females age 15 to 49 */
******************************************

* Actual hours worked in last 7 days
local freq fa63 fa64 fa65 fa66 fa67 fa71

foreach f in `freq'{ 
	gen `f'_3a=`f'_3 /60																/* Convert minutes to hours  */
	egen `f'_hrs=rowtotal(`f'_2 `f'_3a),missing											/* Hours spent on each activity each time  */
	gen `f'_tot=`f'_1*`f'_hrs															/* Total hours spent on each activity each week= Freq*Hour */
	replace `f'_tot=0 if `f'_1==0 & `f'_hrs==.
}

egen ahrswk_nmsa=rowtotal(fa63_tot fa64_tot fa65_tot fa66_tot fa67_tot), missing
gen ahrswk_nmsn=fa71_tot
egen nmtot=rowtotal(ahrswk_nmsa ahrswk_nmsn), missing
replace ahrswk_nm=nmtot

******************************************
* Hours worked by job characteristics
******************************************

*Generate indicators for main and sec job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk adayswk wksyr

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if (m5cq5==1 | m5cq5==2)
replace mj_sa=1 if (m5cq5>=3 & m5cq5<=5) & (sector_mjx==1 |sector_mjx==2 |sector_mjx==5)
replace mj_sn=1 if (m5cq5>=3 & m5cq5<=5) & (sector_mjx>5 & sector_mjx<=99)
replace mj_sx=1 if (m5cq5>=3 & m5cq5<=5) & sector_mjx==.
replace mj_uc=1 if m5cq5==6

replace sj_wj=1 if (m5cq37==1 | m5cq37==2)
replace sj_sa=1 if (m5cq37>=3 & m5cq37<=5) & (sector_sjx==1 |sector_sjx==2 |sector_sjx==5)
replace sj_sn=1 if (m5cq37>=3 & m5cq37<=5) & (sector_sjx>5 & sector_sjx<=99)
replace sj_sx=1 if (m5cq37>=3 & m5cq37<=5) & sector_sjx==.
replace sj_uc=1 if m5cq37==6

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen satot=rowtotal(ahrswk_sa ahrswk_nmsa), missing
replace ahrswk_sa=satot
egen sntot=rowtotal(ahrswk_sn ahrswk_nmsn), missing
replace ahrswk_sn=sntot

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------
*Timeuse
local variables  fa68_3 fa69_3 fa70_3 fa72_3 fa63_3 fa64_3
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

local var fa68 fa69 fa70 fa72 fa63 fa64

foreach v in `var' {
egen `v'_time = rowtotal(`v'_2 `v'_3_hrs)
}

	*1) Cooking  (av6)
		gen p_cooking = 1 if fa69_1 >= 1 & fa69_1 != .
		replace p_cooking = 0 if fa69_1 == 0
		gen cooking = fa69_1*(fa69_time)  					/* cooking*/
		replace p_cooking = 1 if cooking > 0 & cooking != .
		*egen cooking = rowtotal(fa69_2 fa69_3_hrs)
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen cleaning =  fa70_1*(fa70_time) 					/*laundry and cleaning the house*/
		gen p_cleaning = 1 if fa70_1 >= 1 & fa70_1 != .
		replace p_cleaning = 0 if fa70_1 == 0
		replace p_cleaning = 1 if cleaning > 0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_childcare = 1 if fa72_1 >= 1 & fa72_1 != .
		replace p_childcare = 0 if fa72_1 == 0
		gen childcare =  fa72_1*(fa72_time)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = 1 if fa68_1 >= 1 & fa68_1 != .
		replace p_goods_services = 0 if fa68_1 == 0
		gen goods_services = fa68_1*(fa68_time)			/*going to market*/
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Fetching water and firewood
		gen p_water = 1 if fa63_1>=1 & fa63_1 != .
		replace p_water = 0 if fa63_1 == 0
		gen water = fa63_1*(fa63_time)
		
		gen p_wood = 1 if fa64_1>=1 & fa64_1 != .
		replace p_wood = 0 if fa64_1 == 0
		gen wood = fa64_1*(fa64_time)
		
		*____________________________________________________________________________________*
		
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(water wood), missing
		replace coll_wf = . if (water == . & wood == .)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .

	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
		
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking-hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf
drop water wood
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
