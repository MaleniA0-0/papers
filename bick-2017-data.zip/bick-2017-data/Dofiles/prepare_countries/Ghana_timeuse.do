clear

use "Data\Ghana\LSS 1998-99\Data\Household\SEC4J.DTA"

merge 1:1 nh pid clust using "Data\Ghana\LSS 1998-99\Data\Household\SEC1.DTA" , nogen
merge 1:1 nh pid clust using "Data\Ghana\LSS 1998-99\Data\Household\GHA_98_Merged", keepusing(weight) nogen

*Questions asked to all HH members aged 7 and older
***************************************************
* Standard Variables:
	*1) Age
		rename agey age
	*2) Country
		gen country = "GHA"
	*3) Gender
		gen male=.
		replace male=1 if sex==1
		replace male=0 if sex==2	
	*4) Year
		gen year = 1998
	*5) Weights
		gen wgt = weight
*___________________Questionnaire page 42/52_____________________________________________________________________

*Data we need: Four categories
	*1) Cooking  (av6)
		*Generate hours of single variables
		gen p_cook = s4jq15
		recode p_cook (2=0)
		gen cook = s4jq16
		replace cook = 0 if p_cook == 0 & cook == .
		
		gen p_dish = s4jq21
		recode p_dish (2=0)
		gen dish = s4jq22
		replace dish = 0 if p_dish == 0 & dish == .
	
	*____________________________________________________________________________________*
		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
	
		*Sum up hours of selected variables
		egen cooking = rowtotal(cook dish)			/* (cooking + washing dishes)*/
		replace cooking = . if (cook ==. & dish ==.)
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_iron = s4jq5
		recode p_iron (2=0)
		gen iron = s4jq6
		replace iron = 0 if p_iron == 0 & iron == .
		
		gen p_clean = s4jq11
		recode p_clean (2=0)
		gen clean = s4jq12
		replace clean = 0 if p_clean == 0 & clean == .
		
		gen p_garb = s4jq13
		recode p_garb (2=0)
		gen garb = s4jq14
		replace s4jq14 = 0 if p_garb == 0 & garb == .
		
		*____________________________________________________________________________________*
		
		gen p_cleaning =  1 if (p_clean + p_iron + p_garb >=1) & (p_clean + p_iron + p_garb!=.)
		replace p_cleaning = 0 if (p_clean + p_iron + p_garb == 0)
		
		egen cleaning = rowtotal(iron clean garb) 							/*Ironing + Sweeping + disposing garbage;  s4jq24 is other housework, not included*/
		replace cleaning = . if (iron ==. & clean ==. & garb ==.)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
	
	*3) Childcare (Av11)
		gen p_childcare = s4jq7
		recode p_childcare (2=0)
		gen childcare = s4jq8
		replace childcare = 0 if p_childcare == 0 & childcare == .
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_shop = s4jq17
		recode p_shop (2=0)
		gen shop = s4jq18
		replace shop = 0 if p_shop == 0 & shop == .
		
		gen p_erra = s4jq19
		recode p_erra (2=0)
		gen erra = s4jq20
		replace erra = 0 if p_erra == 0 & erra == .

		*____________________________________________________________________________________*

		gen p_goods_services = 1 if (p_shop + p_erra >=1) & (p_shop + p_erra!=.)
		replace p_goods_services = 0 if (p_shop + p_erra) == 0
		
		egen goods_services = rowtotal(shop erra) 
		replace goods_services = . if (shop ==. & erra ==.)
		replace p_goods_services = 1 if goods_services>0 & goods_services!=.
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Fetching water and firewood
		gen p_wood = s4jq1
		recode p_wood (2=0)
		gen wood = s4jq2
		replace wood = 0 if p_wood == 0 & wood == .
		
		gen p_water = s4jq3
		recode p_water (2=0)		
		gen water = s4jq4
		replace water = 0 if p_water == 0 & water == .
		
		*____________________________________________________________________________________*

		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)

		egen coll_wf = rowtotal(wood water)
		replace coll_wf = . if (wood ==. & water ==.)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/GHA_timeuse.dta", replace

