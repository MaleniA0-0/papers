* Penne World Table 9.0
use Data/External_data/pwt90, clear
keep countrycode year csh_c csh_g pop *gdp*

rename rgdpe gdp_e9ry
rename rgdpo gdp_o9ry
rename cgdpe gdp_e9cy
rename cgdpo gdp_o9cy

rename csh_c cc
rename csh_g cg
rename countrycode country

replace country = "TAI" if country == "TWN"
replace country = "ROM" if country == "ROU"
replace country = "ZAR" if country == "COD"
replace country = "HTI" if country == "HTI"


if "${z}"=="e9ry" | "${z}"=="o9ry" | "${z}"=="e9cy" | "${z}"=="o9cy"{
	rename year refyear
	local ky refyear
}
else{
	local ky year
}

gen c=cc
gen g=cg

* Subsistence consumption I: 5% of US GDP in 1956 as in Ohanian, Raffo and Rogerson (JME, 2008)
sum gdp_${z} if country=="USA" & `ky'==1956
gen cbar1=0.05*r(mean)
sum pop if country=="USA" & `ky'==1956
replace cbar1=cbar1/r(mean)
sum cbar1 

keep country `ky' c g cbar1
save Data/aux1, replace

***************

use Data/Cleaned_data/repl_master_stats, clear

keep country `ky' coreDummy hwp_a_all er_a_all hwe_a_all q_${z} gdppc_${z} t1_${z} t2_${z}

merge 1:1 country `ky' using data/aux1
tab _merge
tab _merge coreDummy

* Use PWT 7.1 values for Timor Leste
replace c=0.8566970726	if country=="TLS"
replace g=0.5199848774  if country=="TLS"

keep if coreDummy==1 
drop coreDummy _merge

rename hwp_a_all h
rename er_a_all e
rename hwe_a_all he
rename q_${z} q
rename gdppc_${z} y

***************

save Data/new_welfare_exercise, replace

