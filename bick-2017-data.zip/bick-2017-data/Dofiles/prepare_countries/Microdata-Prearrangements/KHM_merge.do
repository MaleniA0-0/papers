*Cambodia: Merge subfiles and compute HH level earnings from agricultural and non-agricultural activities

clear all

*Set Path
* cd ""


* Part 1: Purpose is to merge relevant files into one file for Cambodia CSES 2011
**************************************************************************
* Merge wgts file to HH roster file
use "Data\Cambodia\CSES 2011\Data\hhmembers.dta", clear
*keep  q01ac01 q01ac03 q01ac05 pkid hhid persid

merge 1:1 persid using "Data\Cambodia\CSES 2011\Data\weightpersons.dta", keepusing( hw11a pw11a )
drop _merge

* Merge employment files
merge 1:1 persid using "Data\Cambodia\CSES 2011\Data\personecocurrent.dta"
drop _merge

save "Data\Cambodia\CSES 2011\Data\KHM_Merged", replace


*Paul 2015: Merge with education
use "Data\Cambodia\CSES 2011\Data\KHM_Merged.dta"
merge 1:1 persid using "Data\Cambodia\CSES 2011\Data\PersonEducation.dta"

save "Data\Cambodia\CSES 2011\Data\KHM_Merged.dta", replace

**************************************************************************
*Part 2: Generate Farm income variables
**************************************************************************
use "Data\Cambodia\CSES 2011\Data/HHProductionCrops.dta"
gen croplost=-Q05BC07
egen cropsold=rowtotal(Q05BC06 croplost)
gen croprevenue = cropsold*Q05BC09
collapse(sum) croprevenue , by(hhid)
save "Data\Cambodia\CSES 2011\Data/CropRevenueaux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHCostCultivationCrops.dta", clear
collapse(sum)  Q05CC16 , by(hhid)
rename Q05CC16 cropcosts
save "Data\Cambodia\CSES 2011\Data/CropCostsaux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHLivestock1.dta", clear
egen livestockrevenue=rowtotal(Q05E1C09 Q05E1C11 Q05E1C12 Q05E1C13 Q05E1C14 Q05E1C15)
rename Q05E1C10 livestockpurchases
collapse(sum)  livestockrevenue livestockpurchases, by(hhid)
save "Data\Cambodia\CSES 2011\Data/Livestock1aux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHLivestock2.dta", clear
rename Q05E2C03 livestockcosts
collapse(sum)  livestockcosts, by(hhid)
save "Data\Cambodia\CSES 2011\Data/Livestock2aux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHFishCultivation2.dta", clear
rename Q05F2C03 fishcosts
collapse(sum)  fishcosts, by(hhid)
save "Data\Cambodia\CSES 2011\Data/FishCultivation2aux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHFishCultivation3.dta", clear
rename Q05F3C03 fishrevenue
collapse(sum)  fishrevenue, by(hhid)
save "Data\Cambodia\CSES 2011\Data/FishCultivation3aux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHForestryHunting1.dta", clear
rename Q05G1C06 forestryrevenue
collapse(sum)  forestryrevenue, by(hhid)
save "Data\Cambodia\CSES 2011\Data/ForestryHunting1aux.dta", replace

use "Data\Cambodia\CSES 2011\Data/HHForestryHunting2.dta", clear
rename Q05G2C03 forestrycosts
collapse(sum)  forestrycosts, by(hhid)
save "Data\Cambodia\CSES 2011\Data/ForestryHunting2aux.dta", replace


merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/ForestryHunting1aux.dta", nogen 
merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/FishCultivation3aux.dta", nogen
merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/FishCultivation2aux.dta", nogen 
merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/Livestock2aux.dta", nogen 
merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/Livestock1aux.dta", nogen 
merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/CropCostsaux.dta", nogen 
merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data/CropRevenueaux.dta", nogen 

save "Data\Cambodia\CSES 2011\Data/Farmincome.dta", replace


use "Data\Cambodia\CSES 2011\Data\KHM_Merged.dta"
	merge 1:1 persid using  "Data\Cambodia\CSES 2011\Data\hhmembers.dta", keepusing(q01ac06) nogen
	merge m:1 hhid using "Data\Cambodia\CSES 2011\Data\Farmincome.dta", nogen 
save "Data\Cambodia\CSES 2011\Data\KHM_Merged.dta", replace

**************************************************************************
* Part 3: HH Nonagricultural Earnings
**************************************************************************
*Dataset 1:
forvalues n = 1/4 {
use "Data\Cambodia\CSES 2011\Data\HHNonAgriculture1.dta", clear
	bysort hhid: gen actnum=_n
	keep if actnum == `n'
	renvars  Q05H1C01 - Q05H1C06H, postfix(_`n')
	
	save "Data\Cambodia\CSES 2011\Data\HH_Nonagric1_act`n'.dta", replace
}
use "Data\Cambodia\CSES 2011\Data\HH_Nonagric1_act1.dta", clear

forvalues n = 1/4 {
	merge 1:1 pkid hhid using "Data\Cambodia\CSES 2011\Data\HH_Nonagric1_act`n'.dta", nogen
}
save "Data\Cambodia\CSES 2011\Data\HH_Nonagric1.dta", replace

*Dataset 2: Costs on activities. Dataset is constructed so as to have each activity as one variable, where hhid is repeated for each accounting position
use "Data\Cambodia\CSES 2011\Data\HHNonAgriculture2.dta", clear
bysort hhid: gen actnum=_n
drop if Q05H2C01 == 15 											//Make it gross, this is tax payments
collapse (sum) Q05H2C03 Q05H2C04 Q05H2C05 Q05H2C06 Q05H2C07 , by(hhid)
save "Data\Cambodia\CSES 2011\Data\HH_Nonagric2.dta", replace


*Dataset 3: Revenues on activities: Same here as above
use "Data\Cambodia\CSES 2011\Data\HHNonAgriculture3.dta", clear
bysort hhid: gen actnum=_n

collapse (sum)  Q05H3C03 Q05H3C04 Q05H3C05 Q05H3C06 Q05H3C07 , by(hhid)
save "Data\Cambodia\CSES 2011\Data\HH_Nonagric3.dta", replace

merge 1:1 hhid using "Data\Cambodia\CSES 2011\Data\HH_Nonagric2.dta", nogen
save "Data\Cambodia\CSES 2011\Data\HH_Nonagric_RevCost.dta", replace

use "Data\Cambodia\CSES 2011\Data\KHM_Merged.dta", clear
merge m:m hhid using "Data\Cambodia\CSES 2011\Data\HH_Nonagric_RevCost.dta", nogen

save "Data\Cambodia\CSES 2011\Data\KHM_Merged.dta", replace





