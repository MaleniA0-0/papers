clear all

use Data/new_welfare_excercise_calicbar_alpha, clear

keep country c0 cbar h pref ly q y he e t1_${z} t2_${z}

* Capital Share - Prescott 2004
local theta=0.3224

* Normalized hours
local norm=100

sum he if q==3 
gen h1=e*r(mean)/`norm'
gen h2=h/`norm'

rename c0 c

local vs c cbar

* Need to express everything in levels not relative to output
foreach v in `vs'{
	replace `v'=`v'*y
}

* Means by tercile
local vs h1 h2 `vs'
forvalues q=1/3{
	foreach v in `vs'{
		sum `v' if q==`q' 
		local `v'`q'=r(mean)
	}
}


sum pref
scalar a=r(mean)

local eps=1
local epst=1+1/`eps'

* Generate consumption equivalent variation
forvalues h=1/2{
	gen w1_`h'=c/`c3'*100
	
	gen f=`epst'*(`h`h'3'^`epst'-h`h'^`epst')
	
	gen w2_`h'=((c-cbar)*exp(a*f)+`cbar3')/`c3'*100 
	drop f

	forvalues w=1/2{
		gen w`w'4_`h'=1/w`w'_`h'*100
	}
	
	forvalues q=1/2{
		sum w1_`h' if q==`q'
		global w1`q'_`h'=r(mean)
		
		sum w2_`h' if q==`q'
		global w2`q'_`h'=r(mean)
	}
	
	forvalues w=1/2{
		global w`w'4_`h'=1/${w`w'1_`h'}*100
	}		
}

save Data/new_welfare_calicbar, replace
	

*#################################################################
* Welfare Table - Only Hours
*#################################################################

********************************
* Settings
********************************

global name="tab_welfare_calicbar_brief_${z}"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"	
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{lcccc}") _n
$write ("\tabularnewline\hline\hline") _n
$write (" \;\;\;  & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("& \;\;\;  Low \;\;\; & \;\;\; Middle \;\;\;   & \;\;\; High \;\;\;  & \;\;\; High/Low \;\;\; \\\hline") _n
	
local w 1
local h 1
$write (" Consumption")
forvalues q=1/2{
	$write ("&")
	global var ${w`w'`q'_`h'}
	`do1'
}
$write (" & 100 ")
forvalues q=4/4{
	$write ("&")
	global var ${w`w'`q'_`h'}
	`do1'
}	
$write ("\\") _n


*%%%%%%%%%%%%%%%%%%%%%%%%%%%

local w 2
local h 2
$write(" + Hours ") _n
forvalues q=1/2{
	$write ("&")
	global var ${w`w'`q'_`h'}
	`do1'
}
$write (" & 100 ")
forvalues q=4/4{
	$write ("&")
	global var ${w`w'`q'_`h'}
	`do1'
}	

$write ("\\\hline") _n

*#################################################################
${lastl}
${close}
*#################################################################	
