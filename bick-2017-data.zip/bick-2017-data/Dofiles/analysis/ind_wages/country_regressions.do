quiet{

local da
local dm drop if male==0
local dw drop if male==1

local o0
local o1 keep if ind==1
local o2 keep if ind==2
local o3 keep if ind==3

local fo0 
local fo1 _agr
local fo2 _man
local fo3 _ser

local ba Both Sexes
local bm Men
local bw Women

*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
* Costa 

local l01="USA-1895"
local l02="USA-1973"
local l03="USA-1991"

* GDP per capita
local y01=8.65498
local y02=10.22199
local y03=10.53143

* Coefficients Men
local m01=-.117
local m02=-.083
local m03= .044
local mp=1

* Coefficients Women
local w01=-.146
local w02= .009
local w03= .116
local wp=10

*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

forvalues s=5/5{
foreach i in m w{
forvalues o=0/0{

use data/simplified_wj_world_data, clear

`d`i''
`o`o''

keep if flag_set`s'==1

rename lhm_n lhm
rename w_n w

keep if lhm!=. & w!=.

gen xyz=y
replace xyz=10000000000 if country=="USA"
sort xyz
tab xyz, gen(zid)
by xyz:	gen n=_n

count if n==1
local N=r(N)

local x1
local x2 age age2
local x3 `x2' edu1 edu2
local x4 `x2'

local t1 nc
local t2 age
local t3 age_deduc
local t4 costa_sample

forvalues c=1/`N'{
foreach x in 2{
	qui reg lhm w `x`x'' if zid`c'==1
	mat x =e(b)
	local b`c'`x'=x[1,1]
	local N`c'`x'=e(N)
}
local x=4
qui reg lhm w `x`x'' if zid`c'==1 & age>=25 & age<=64
mat x =e(b)
local b`c'`x'=x[1,1]
local N`c'`x'=e(N)


}

keep if n==1
foreach x in 2{
gen beta_`x'`s'=.
gen N_`x'`s'=.
forvalues c=1/`N'{
	replace beta_`x'`s'=`b`c'`x'' if zid`c'==1
	replace N_`x'`s'=`N`c'`x'' if zid`c'==1	
}
}


save data/world_analysis_individual_beta_`i'`s'`fo`o'', replace


local t1=8.40286
local t2=9.717068 
local lc gs8

local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local xl 7(.5)11


*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
* Costa

if `o'==0{
local mc  gs8

	local NN=`N'+3
	set obs `NN'
	gen nN=_n
	foreach x in 2{
		forvalues n=1/3{
			local nn=`N'+`n'
			replace y=`y0`n'' if nN==`nn'
			replace country="`l0`n''" if nN==`nn'
			replace beta_`l'`x'=``i'0`n'' if nN==`nn'
		}
		
		
		twoway	(scatter beta_`l'`x' y if nN<=`N', msize(vsmall) mlab(country) mcolor(black) mlabpos(3) ///
				xline(`t1', lpattern(dot) lcolor(`lc')) xline(`t2', lpattern(dot) lcolor(`lc')) msize(vsmall)) ///			
				(scatter beta_`l'`x' y if nN>`N', msize(medsmall) msym(square) mlab(country) mcolor(`mc') mlabcolor(`mc') mlabpos(``i'p')) ///
				, `options' xtitle(ln(GDP per Capita)) ytitle({&beta}{sub:w}) ylabel(-.3(.1).2, grid gmin gmax) xlabel(`xl') ///
				legend(off) yline(0,lcolor(black) lpattern(solid) lwidth(medthick)) 			   	
		graph export texinput/world_analysis_individual_figc_`i'`s'_`x'`fo`o''.pdf, replace
	}
	drop if nN>`N'
}
}

*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

}
}
} // quiet
