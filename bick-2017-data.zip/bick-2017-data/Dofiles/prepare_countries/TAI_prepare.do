******************************************************************************************
* Program: TAI_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Taiwan
******************************************************************************************

use "Data\Taiwan\Data\lb2011.dta", clear
drop if v18==12																		/* Drop armed forces */			

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs v1 v2 v3 v4 v5 v6
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid=v1s+"-"+v2s+"-"+v3s+"-"+v4s+"-"+v5s+"-"+v6s

foreach v in `vs'{
	drop `v's
}

replace pid=v8
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=v12

* Gender
replace male=1 if v11==1
replace male=0 if v11==2

*-----------------------------------------

* Weights
replace wgt=v41

* Interview date																	/* Interviews are conducted every month throughout the year */
replace refdatex=0

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if v14==1
replace educ=0 if v14!=1 & v14!=.
gen educlvl=.

******************************************
* Market work
******************************************

* Employment status																	/* Universe: Age 15 and above */
replace emp=1 if v18>=1 & v18<=3
replace emp=0 if v18>=4 & v18<=13

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* Main job

* Actual hours worked last week
replace ahrswk_mj=v21																/* No missing value */										

*-----------------------------------------

* Sec job

* Actual hours worked last week
replace ahrswk_sj=v22																/* No missing value */


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj
local nature wj sa sn sx
local time ahrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}
replace mj_wj=1 if v39==3 | v39==4
replace mj_sa=1 if (v39==1 | v39==2 | v39==5) & (v34>=1 & v34<=3)
replace mj_sn=1 if (v39==1 | v39==2 | v39==5) & (v34>=5 & v34<=95)
replace mj_sx=1 if (v39==1 | v39==2 | v39==5) & v34==96

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 

