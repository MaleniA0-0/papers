clear all

local np0 
local np1 _p

local edu10 All
local edu5 All (\textit{Ages 25+, Non-missing Educ.}) // $ ^\dag $
local edu1 Less than Secondary
local edu2 Secondary Completed
local edu3 More than Secondary
local edu4 Missing

forvalues p=1/1{
foreach x in edu{
	
	use Data/Cleaned_data/repl_master_stats,replace

	* Core countries
	keep if coreDummy==1
	
	* Variables
	if "`x'"=="ind"{
		local vs hwe
	}
	else{
		local vs er // hwp er hwe
	}
	 
	local gs f m
	local as prime old
	
	local thwp Average Hours
	local thwe `thwp'
	local ter  Employment Rates

	foreach g in `gs'{
	foreach a in `as'{	
	if "`a'"=="prime"{
		local edu10 Prime
		local edu5 Prime (\textit{Non-missing Educ.}) // $ ^\dag $	
	}
	else{
		local edu10 Old
		local edu5 Old (\textit{Non-missing Educ.}) // $ ^\dag $	
	} 
	
	local ws 10 5 1 2 3 

	
	foreach v in `vs'{
		
		foreach w in `ws' {
		
			if `w'==10 {
				local s`x'`w' 
			}
			else{
				local s`x'`w' _`x'`w'
			}
			
			if "`v'"=="er"{
				replace `v'_`g'_`a'`s`x'`w''=`v'_`g'_`a'`s`x'`w''*100
			}		
			
			forvalues q=1/3{
				sum `v'_`g'_`a'`s`x'`w'' if q_${z}==`q'	
				local `v'`w'`q'`g'`a'=r(mean)
			}
		}
		
		
	} // v 
	} // g
	} // a
	
	foreach v in `vs'{
	foreach a in `as'{
	
		if "`a'"=="prime"{
			local edu10 Prime
			local edu5 Prime (\textit{Non-missing Educ.}) // $ ^\dag $	
		}
		else{
			local edu10 Old
			local edu5 Old (\textit{Non-missing Educ.}) // $ ^\dag $	
		} 	
	
		*#################################################################
		* Tex Table Generation
		*#################################################################
		
		local ws 1 2 3 	
			
		********************************
		* Settings
		********************************
	
		global name="tab_`v'_mf_`a'_`x'`np`p''_${z}"
		global write="file write ${name}"
		global nextl=`"${write} ("\\") _n"'
		global lastl=`"${write} ("\end{tabular}")"'
		global close="file close ${name}"
	
		local do1="do Dofiles/analysis/dcol"	
		global fonttype /* ="\textit" */
		global digit 1
	
		file open ${name} using texinput/${name}.tex, write replace
	
		***************************************************************
		* Start table
		***************************************************************
	
		$write ("\begin{tabular}{lcccccc}") _n
		if `p'==0 $write ("\multicolumn{4}{c}{`t`v'' by Age and Country Income}")
		$write ("\tabularnewline\hline\hline") _n
		$write ("``x't'   & \multicolumn{6}{c}{Country Income Group}\tabularnewline") _n
		$write ("&   \multicolumn{2}{c}{Low}  &  \multicolumn{2}{c}{Middle}    &  \multicolumn{2}{c}{High} \\")  _n
		forvalues q=1/3{
			$write (" & Men & Women ") 
		}
		$write ("\\\hline") _n
	
		foreach w in `ws'{
			$write ("``x'`w''")
			forvalues q=1/3{
				foreach g in m f{
					$write ("&")
					global var ``v'`w'`q'`g'`a''
					`do1'
				}
			}
			$write ("\\") _n
			if `w'==5{
				$write ("\hline") _n			
			}
		}
		$write ("\hline") _n
		*#################################################################
		${lastl}
		${close}
		*#################################################################		
	
	} // a
	} // v
	
} // x
} // p
