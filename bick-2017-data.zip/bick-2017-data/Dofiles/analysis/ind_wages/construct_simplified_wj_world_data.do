use Data/Cleaned_data/wj_world_dataset,clear

drop pid hid

aorder
order country
drop if hr_wage_pct==1 | hr_wage_pct==100

rename hrs_wj  hm_n
rename hr_wage wl_n

gen age2=age^2

rename hrs hm_o
rename inc_wj_hr wl_o

foreach x in n o{
gen w_`x'=ln(wl_`x')
gen lhm_`x'=ln(hm_`x')
}

merge m:1 country using data/gdpph

tab _merge
keep if _merge==3
drop _merge

rename q_ q

gen p=ln(gdpph)
rename gdpph pl

gen y=ln(gdppc)
rename gdppc yl

drop g*

aorder 
order country

drop pop* 

tab edu, gen(edu)

save data/simplified_wj_world_data, replace
