******************************************************************************************
* Program: KEN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Kenya
******************************************************************************************

use "Data\Kenya\KIHBS 2005\Data/individuals_merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid pid
gen hid = string(id_clust)+"0000"+string(id_hh)+"00"
gen pid = b_id
order hid pid
sort hid pid

*-----------------------------------------
* Age 
gen age=b05a 

* Gender
replace male=1 if b04==1
replace male=0 if b04==2

gen hh_link = .
replace hh_link = 1 if b03 == 1 //Reference Person
replace hh_link = 2 if b03 == 2 //Spouse
replace hh_link = 3 if b03 == 3 | b03 == 4 | b03 == 7	//Child in law, step child, grand child
replace hh_link = 4 if  b03 == 5  // Ascendants (parent, grand parent)
replace hh_link = 98 if  b03 == 10  //Not related
replace hh_link = 99 if  b03 == 6 | b03 == 8 //Others, newphew/niece

*-----------------------------------------

* Weight
replace wgt=weight					//This is cluster weight, but best we can get!
gen hh_wgt = . //weight

* Interview date					/* Data collection started on 26.05.2005 and ended 27.04.2006 */
replace refdatex = 1
replace refmonth = dmonth
replace refyear = dyear
replace refday = dvisit
replace refdate = mdy(refmonth, refday, refyear)
replace refweek = week(refdate)

*-----------------------------------------
gen educ=.
replace educ=1 if c10==1
replace educ=0 if c10==2
gen educlvl=.

gen edu = .
replace edu = 1 if inrange(c04a,1,8)
replace edu = 1 if c04a == 20
replace edu = 2 if inrange(c04a,9,14)
replace edu = 3 if inrange(c04a,15,19)

******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe for employment status qns: Age 5 and above */
egen hrs_m = rowtotal( e05 e06 e07),m
replace emp = 1 if hrs_m>0 & hrs_m != .
replace emp = 0 if hrs_m == 0										
replace emp = 0 if hrs_m == . & e09 == 2							//Because Questionnaire skips hours questions (hrs_m =.), dep. on e03.
replace emp = 2 if hrs_m == 0 & e09 == 1									
replace emp = 2 if hrs_m == . & e09 == 1							//Because Q. skips hours questions (hrs_m =.), dep. on e03.


* Reason for being economically inactive
replace reason=0 if emp<=1
*replace reason=2 if  e10==4															/* vacation or public holiday*/
replace reason=3 if  e10==1																/* sickness */	
*replace reason=4 if  q08c03==6															/* labour dispute */
*replace reason=5 if  q08c03==2															/* maternity and paternity leave */
replace reason=7 if  inrange(e10, 2,10)								 					/* other reasons */


*Work status
replace emp_wj = 1 if e04 == 1 | e04 == 5 
replace emp_se = 1 if e04 == 2 | e04 == 3 | e04 == 4 
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .

*-----------------------------------------
* Actual hours worked last week (all jobs)							/* Universe for hours qns: Age 5 and above and has a job */
replace ahrswk_aj = hrs_m
replace ahrswk_aj = 0 if hrs_m == . & emp == 0
replace ahrswk_aj = 0 if hrs_m == . & emp == 2

*Usual hours worked per week, main job/months worked last year
replace mthsyr_mj = e18
	replace mthsyr_mj = . if  mthsyr_mj == 0

replace uhrsday_mj = e19

*-----------------------------------------
* Hours worked by job nature 										
*N/A
*Use hours questions that separate by work status
replace ahrswk_wj = e05
	replace ahrswk_wj_aj = e05												//e05 is total wage job hours, 21K
	replace ahrswk_wj_mj = e05 if e13 == 1									//Individual engaged in only one single activity: -3000 obs., ~18K

gen indic_wj = 0
replace indic_wj = indic_wj + 1 if e05 > 0 & e05 != .	
	
*Those with only a single activity, which is wage job, are coded to set 1
replace flag_set1 = 1 if indic_wj == 1 & e13 == 1	
*we cannot add anyone else to sets 2 or three since we do not have all wage job incomes.
replace flag_set2 = 1 if flag_set1 == 1
replace flag_set3 = 1 if flag_set2 == 1	

egen hrs = rowtotal(ahrswk_wj ahrswk_sn ahrswk_sa),m
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1

replace ahrswk_sa = e06
replace ahrswk_sn = e07

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													/* Both not explicitly included or excluded from work hours, chrs and mhrs are not available */
replace chrsx=2

replace chrsday = e30a/60*2 if emp == 1 | emp == 2
replace commuting = chrsday*7 if emp == 1 | emp == 2
replace chrsday = 0 if emp == 0
replace commuting = 0 if emp == 0
*-----------------------------------------

gen ind = .															//To be checked by David
replace ind = 1 if inrange(e16,1111,2909)					
replace ind = 2 if inrange(e16,3111,5202)			
replace ind = 3 if inrange(e16,6001,9600)
replace ind = 3 if e16 == 1120

*-----------------------------------------
*Income: Main job, wage & self employed
*-----------------------------------------
*1) General income variable (employees and self employed)
gen inc_c = e20														//Monthly
egen inc_ik = rowtotal(e21 e22 e23),m
egen inc_tot = rowtotal(inc_c inc_ik),m

*2) Wage:	Use employment status e04
	local if_emp if e04 == 1 | e04 == 5		
	replace inc_wj_mj_c_o = inc_c `if_emp'
	replace inc_wj_mj_ik_o = inc_ik `if_emp'
	replace inc_wj_mj_tot_o = inc_tot `if_emp'
	
	*test:
	*sum inc_wj_mj_tot_o, d
	*keep if inc_wj_mj_tot_o >= r(p1) & inc_wj_mj_tot_o <= r(p99)
	*sum inc_wj_mj_tot_o
	
*3) Self employed
	local ifself_emp if e04 == 2 | e04 == 3 | e04 == 4 
	replace inc_se_mj_c_o = inc_c `ifself_emp'
	replace inc_se_mj_ik_o = inc_ik `ifself_emp'
	replace inc_se_mj_tot_o = inc_tot `ifself_emp'

*Total individual income
egen tot_wjse = rowtotal(inc_wj_mj_tot_o inc_se_mj_tot_o),m
replace ind_tot_wjse = tot_wjse

*-----------------------------------------
*Household income
*-----------------------------------------
	//In order to generate household income, rely solely on wage income and household enterprise income. I don't want to 
	//count self employed income double!
	
bysort hid: egen hh_wj = total(inc_wj_mj_tot_o),m	

gen hh_sn = (rev_hhent - cost_hhent)											//This is monthly

egen hh_sa_rev = rowtotal( ls_revprod ls_revsale ls_revoc ag_revoc ag_revsale),m	
egen hh_sa_cost = rowtotal( ls_costlost ls_costpurch ls_costlabour ls_costinputs ag_costseeds ag_costlabour ag_costrent ag_costirrig ag_costfert ag_costinputs ag_costother),m	
gen hh_sa = (hh_sa_rev - hh_sa_cost)/12

egen hhinc = rowtotal(hh_wj hh_sn hh_sa ),m
	replace inc_hh = hhinc
	
sum inc_wj_mj_tot_o inc_se_mj_tot_o hh_wj hh_sn hh_sa inc_hh
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link `income_vars' 
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
