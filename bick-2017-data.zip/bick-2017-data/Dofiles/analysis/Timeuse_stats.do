**************************************************************************
*Statistics from Table C.3 in the Online Appendix: 
**************************************************************************

set more off 

clear

use "Data/Cleaned_data/timeuse_stats"

gen timeuse = 0
replace timeuse = 1 if country == "BEN"  | country == "EGY"| country == "GHA"| country == "GTM" |country == "IRQ" | country == "LSO" | country == "MLI" | country == "RWA"  | country == "PAK" | country == "RUS"  | country == "FRA" | country == "DEU" | country == "NLD" | country == "ESP" | country == "GBR" | country == "USA" | country == "ITA" | country == "ZAF" | country == "AUT" | country == "MNG" | country == "KGZ" | country == "CHN" | country == "KAZ" | country == "TLS"
keep if timeuse == 1

local save_in texinput 
local Q=3
local vars all 
local gender a //m f
local indicators cooking cleaning childcare shopping collwf 
*totalhrs

sort q_e9ry country

bysort q_e9ry: gen num=_N
local N=_N

*Run sum command over all unconditional hours to save all gender/age group variabes as locals and plug them into tex lateron
foreach g in `gender'{
	foreach v in `vars'{
		forvalues q=1/`Q'{
			foreach i in `indicators' {
	
			sum `i'_`g'_`v'_uc if q_e9ry==`q' 
			local `i'_`g'_`v'_`q'_uc = round(r(mean),0.1)
			local `i'_`g'_`v'_`q'_sd = round(r(sd),1)
		
			sum `i'_`g'_`v'_m if q_e9ry==`q' 
			local `i'_`g'_`v'_`q'_m = round(r(mean),0.1)
			local `i'_`g'_`v'_`q'_sd = round(r(sd),1)
		
			}
		local totalhrs_`g'_`v'_`q'_uc = `childcare_`g'_`v'_`q'_uc' + `cooking_`g'_`v'_`q'_uc' + `cleaning_`g'_`v'_`q'_uc' + `shopping_`g'_`v'_`q'_uc' + `collwf_`g'_`v'_`q'_uc'
		display `totalhrs_`g'_`v'_`q'_uc'
		
		local totalhrs_`g'_`v'_`q'_m = `childcare_`g'_`v'_`q'_m' + `cooking_`g'_`v'_`q'_m' + `cleaning_`g'_`v'_`q'_m' + `shopping_`g'_`v'_`q'_m' + `collwf_`g'_`v'_`q'_m'
		display `totalhrs_`g'_`v'_`q'_m'

		}
	}
}


****************************************************************************************************
****Individual countrytable: Table C.3: Home production Hours by Individual Country and Category****
****************************************************************************************************
local indicators cooking cleaning childcare shopping collwf
sort q_e9ry country

local Q=5

* Assing file name
global name="IndividualCountrytable_uc"				
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"

global digit 1
	
foreach s in `save_in' {

		if "`s'"=="texinput" {
		file open ${name} using "`s'/${name}.tex", write replace	
		}
		
		
***************************************************************
* Start table
***************************************************************

local ands
forvalues q=1/`Q'{
	local ands `ands' &
} 

local ia 2 // Digits before decimal points
local ib 1 // Digits after deicmal point

*---------------

$write ("\begin{tabular}{l c c c c c c") 
local ccount=1
forvalues q=1/`Q'{
	
	*$write ("D{.}{.}{`ia',`ib'}")
	local ccount=`ccount'+1
}
$write ("} " ) _n
$write "\\\midrule \midrule" _n
*----------------

foreach i in `indicators' {
	$write ("& \multicolumn{1}{c}{ \bf `i' } ") _n
}
	$write ("& \multicolumn{1}{c}{ \bf Tercile } ") _n
$write ("\\[0.05cm]\hline `ands' \\[-0.15cm]") _n

*----------------

*foreach v in `vars'{
*foreach i in `indicators' {
	
forvalues n=1/`N' {
	$write ("")
	foreach value in country {
	local x=`value'[`n']
	$write (" \textbf{`x'} ") 			//could let country be bold using command \textbf{}
		}
	foreach value in cooking_a_all_uc cleaning_a_all_uc childcare_a_all_uc shopping_a_all_uc collwf_a_all_uc  {
	
	local x=`value'[`n'] 
	
	if `value'[`n'] == . {
		local x = .
	}

		$write (" & ")
		global var `x'
		`do1'
	*$write (" & `x' ") 			//could let country be bold using command \textbf{}
	}
foreach value in q_e9ry {
		local x=round(`value'[`n'], 1)
		$write (" & `x' ")
	}
		
		$write "\\[-0.05cm]"
	
	foreach value in q_e9ry {
	 if `value'[`n'+1]-`value'[`n']==1 {
	 $write "\midrule" _n
	 }
	 if `value'[`n'+1]-`value'[`n']!=1 & `n'!=`N' {
	 $write "\cmidrule{2-7}" _n
	 }
	 if `n'==`N' {
	 $write "\midrule"
	 }
	}
	
}

*----------------
${lastl}
*$write ("\end{document}") _n
${close}

*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     
} 	//savein

*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

