* Purpose: To run dictionary for each of the quarterly microdata and save each file
* Afterwards, to merge 4 quarterly data files into 1 file, lines 2702 ff.

*******************************************************
* January

infile using "Data\Philippines\LFS 2010\Data\Dictionaries\dicPLFSjan.dct"

label variable reg      "Region"
label variable stratum  "Stratum"
label variable psu      "Primary Sampling Unit - PSU"
label variable hhnum    "Household Unique Sequential Number"
label variable urb2k70  "C2K Urban Rural Classification (Based on 1970 Definition)"
label variable fwgt     "Final Weight"
label variable svymo    "Survey Month"
label variable svyyr    "Survey Year"
label variable c101_lno "C101-Line Number"
label variable c05_rel  "C05-Relationship to Household Head"
label variable c06_sex  "C06-Sex"
label variable c07_age  "C07-Age as of Last Birthday"
label variable c08_ms   "C08-Marital Status"
label variable c09_grd  "C09-Highest Grade Completed"
label variable a02_csch "Currently Attending School (April 2005)"
label variable c10_cnwr "C10-Contract/Overseas Worker Indicator"
label variable j01_usoc "C12-Usual Occupation (July 2003 - Jan 2005)"
label variable c13_work "C13-Did do any Work for at Least one Hour during the Past Week?"
label variable c14_job  "C14-Did Have a Job/Business during the Past Week?"
label variable c16_proc "C16-Primary Occupation"
label variable c18_pkb  "C18-Kind of Business (Primary Occupation)"
label variable c19pclas "C19-Class of Worker (Primary Occupation)"
label variable c20_ntem "C20-Nature of Employment (Primary Occupation)"
label variable c21_pwhr "C21-Normal Working Hours for the Day for the Past Week"
label variable c22_phrs "C22-Total Number of Hours Worked During the Past Week"
label variable c23_pwmr "C23-Did Want more Hours of Work During the Past Week"
label variable c24_plaw "C24-Did Look for Additional Work During the Past Week"
label variable c25_pfwk "C25-Was this his first time to do any Work?"
label variable c26_pbis "C26-Basis of Payment (Primary Occupation)"
label variable c27_pbsc "C27-Basic Pay per Day (Primary Occupation)"
label variable c28_ojob "C28-Other Job Indicator"
label variable j02_otoc "C30-Other Occupation (July 2003 - Jan 2005)"
label variable j03_okb  "C32-Kind of Business (Other Occupation) (July 2003 - Jan 2005)"
label variable j04_ocls "C33-Class of Worker (Other Occupation) (July 2003 - Jan 2005)"
label variable j05_ohrs "C34-Number of Hours Worked (Other Occupation) (July 2003 - Jan 2005)"
label variable j06_obis "C35-Basis of Payment (Other Occupation) (July 2003 - Jan 2005)"
label variable c36_obic "C36-Basic Pay per Day (Other Occupation) (July 2003 - Jan 2005)"
label variable a03_jobs "Number of Jobs during the past week (April 2005)"
label variable a04_thrs "Total Hours Worked for all Jobs (April 2005)"
label variable a05_r48h "Reasons for Working More than 48 Hours during the past week (April 2005)"
label variable c37_avil "C37-Was Available for Work During the Past Week?"
label variable c38_lokw "C38-Did Look For Work Anytime During the Past Week?"
label variable c39_jbsm "C39-What Was He Has Been Doing to Find Work During the Past Week?"
label variable c40_wks  "C40-Number of Weeks Spent in Looking for Work"
label variable c41_flwk "C41-Was This His First Time to Look For Work?"
label variable c42_wynt "C42-Why Did He not Look for Work?"
label variable a06_llkw "When Last Looked for Work (April 2005)"
label variable a07_wlng "Willingness to take up work during the past week (April 2005)"
label variable c43_lbef "C43-Did He Ever Work At Anytime Before?"
label variable c45_pocc "C45-Previous Occupation"
label variable a08_pqtr "Did work or had a job during the past quarter (April 2005)"
label variable a09_pqkb "Kind of Business (past quarter) (April 2005)"
label variable cempst1  "Employment Status (without Availability criterion)"
label variable newempst "Employment Status (Based on New Criteria on Unemployment) (April 2005)"

#delimit ;
label define REG     
    13 "National Capital Region"
    14 "Cordillera Administrative Region"
     1 "Region I - Ilocos Region"
     2 "Region II - Cagayan Valley"
     3 "Region III - Central Luzon"
    41 "Region IVA - CALABARZON"
    42 "Region IVB - MIMAROPA"
     5 "Region V- Bicol"
     6 "Region VI - Western Visayas"
     7 "Region VII - Central Visayas"
     8 "Region VIII - Eastern Visayas"
     9 "Region IX - Zamboanga Peninsula"
    10 "Region X - Northern Mindanao"
    11 "Region XI - Davao"
    12 "Region XII - SOCCSKSARGEN"
    16 "Caraga"
    15 "Autonomous Region in Muslim Mindanao"
;
label define URB2K70 
     1 "Urban"
     2 "Rural"
;
label define SVYMO   
     1 "January"
     4 "April"
     7 "July"
    10 "October"
;
label define SVYYR   
  2003 "2003"
  2004 "2004"
  2005 "2005"
  2006 "2006"
  2007 "2007"
  2008 "2008"
;
label define C05_REL 
     1 "Head"
     2 "Wife/Spouse"
     3 "Son/daughter"
     4 "Brothers/sisters"
     5 "Son/daughter_law"
     6 "Grandchildren"
     7 "Father/Mother"
     8 "Other Relative"
     9 "Boarder"
    10 "Domestic Helper"
    11 "Non_Relative"
;
label define C06_SEX 
     1 "Male"
     2 "Female"
;
label define C07_AGE 
    99 "Not reported"
;
label define C08_MS  
     1 "Single"
     2 "Married"
     3 "Widowed"
     4 "Divorce/Separate"
     5 "Unknown"
;
label define C09_GRD 
     0 "No Grade Completed"
     1 "Elementary Undegraduate"
     2 "Elementary Graduate"
     3 "Highschool Undergraduate"
     4 "Highschool Graduate"
     5 "Collge Undergraduate"
    99 "Not reported"
;
label define A02_CSCH
     1 "Currently attending school"
     2 "Not currently attending school"
;
label define C10_CNWR
     1 "OCW"
     2 "Workers other than OCW"
     3 "Employees in Phil. Embassy, Consulates and other Missions"
     4 "Students Abroad/Tourist"
     5 "Others"
;
label define J01_USOC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C13_WORK
     1 "Worked at Least One Hour"
     2 "Did not Work at Least One Hour"
;
label define C14_JOB 
     1 "With Job/Business During the Past Week"
     2 "No Job/Business During the Past Week"
;
label define C16_PROC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C18_PKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define C19PCLAS
     0 "Worked for private household"
     1 "Worked for private establishment"
     2 "Worked for gov't/gov't corporation"
     3 "Self employed without any paid employee"
     4 "Employer in own family-operated farm or business"
     5 "Worked with pay in own family-operated farm or business"
     6 "Worked without pay in own family-operated farm or business Business)"
     9 "Not Reported"
;
label define C20_NTEM
     1 "Permanent Job"
     2 "Short_term"
     3 "Different Employer"
;
label define C22_PHRS
     0 "with a job, not at work"
   999 "Not Reported"
;
label define C23_PWMR
     1 "Want More Hours of Work"
     2 "Did not Want More Hours of Work"
;
label define C24_PLAW
     1 "Looked for Additional Work"
     2 "Did not Look for Additional Work"
;
label define C25_PFWK
     1 "First Time to Do Any Work"
     2 "Not First Time to Do Any Work"
;
label define C26_PBIS
     0 "In Kind only"
     1 "Per piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Other S./Wages"
     7 "Commission Basis"
;
label define C27_PBSC
     0 "No Wages"
 99999 "Not Reported"
;
label define C28_OJOB
     1 "With Other Occupation"
     2 "No Other Occupation"
;
label define J02_OTOC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define J03_OKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define J04_OCLS
     0 "Private Household"
     1 "Private Establishment"
     2 "Gov't/Gov't Corporation"
     3 "Self Employed"
     4 "Employer"
     5 "With Pay (Family Owned Business)"
     6 "Without Pay (Family Owned Business("
     9 "Not Reported"
;
label define J06_OBIS
     0 "In Kind only"
     1 "Per Piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Others"
     7 "Commission Basis"
;
label define A05_R48H
     1 "Wanted More Earnings"
     2 "Requirements of the Job"
     3 "Exceptional week"
     4 "Ambition, passion for job"
     5 "Other reasons"
;
label define C37_AVIL
     1 "Available for Work During the Past Week"
     2 "Not Available for Work During the Past Week"
;
label define C38_LOKW
     1 "Looked for Work Anytime During the Past Week"
     2 "Did not Look for Work Anytime During the Past Week"
;
label define C39_JBSM
     2 "Registered in Private Employment Agency"
     1 "Registered in Public Employment Agency"
     3 "Approached Employer Directly"
     4 "Approached Relatives or Friends"
     5 "Placed or Answered Advertisements"
     6 "Others"
     9 "Not Reported"
;
label define C41_FLWK
     1 "First Time to Look for Work"
     2 "Not First Time to Look For Work"
;
label define C42_WYNT
     1 "Believe no Work Available"
     2 "Awaiting Results of Previous Job Application"
     3 "Temporary Illness/Disability"
     4 "Bad Weather"
     5 "Wait for rehire/Job Recall"
     6 "Too young/old or Retired/Permanent Disability"
     7 "Housekeeping"
     8 "Schooling"
     9 "Others"
;
label define A06_LLKW
     1 "Within last month"
     2 "One to six months ago"
     3 "More than six months ago"
;
label define A07_WLNG
     1 "Willing to take up work during the past week"
     2 "Not willing to take up work during the past week"
;
label define C43_LBEF
     1 "Worked at Anytime Before"
     2 "Did not Work at Anytime Before"
;
label define C45_POCC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define A08_PQTR
     1 "Yes"
     2 "No"
;
label define A09_PQKB
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define CEMPST1 
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;
label define NEWEMPST
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;

#delimit cr
label values reg      REG     
label values urb2k70  URB2K70 
label values svymo    SVYMO   
label values svyyr    SVYYR   
label values c05_rel  C05_REL 
label values c06_sex  C06_SEX 
label values c07_age  C07_AGE 
label values c08_ms   C08_MS  
label values c09_grd  C09_GRD 
label values a02_csch A02_CSCH
label values c10_cnwr C10_CNWR
label values j01_usoc J01_USOC
label values c13_work C13_WORK
label values c14_job  C14_JOB 
label values c16_proc C16_PROC
label values c18_pkb  C18_PKB 
label values c19pclas C19PCLAS
label values c20_ntem C20_NTEM
label values c22_phrs C22_PHRS
label values c23_pwmr C23_PWMR
label values c24_plaw C24_PLAW
label values c25_pfwk C25_PFWK
label values c26_pbis C26_PBIS
label values c27_pbsc C27_PBSC
label values c28_ojob C28_OJOB
label values j02_otoc J02_OTOC
label values j03_okb  J03_OKB 
label values j04_ocls J04_OCLS
label values j06_obis J06_OBIS
label values a05_r48h A05_R48H
label values c37_avil C37_AVIL
label values c38_lokw C38_LOKW
label values c39_jbsm C39_JBSM
label values c41_flwk C41_FLWK
label values c42_wynt C42_WYNT
label values a06_llkw A06_LLKW
label values a07_wlng A07_WLNG
label values c43_lbef C43_LBEF
label values c45_pocc C45_POCC
label values a08_pqtr A08_PQTR
label values a09_pqkb A09_PQKB
label values cempst1  CEMPST1 
label values newempst NEWEMPST

save "Data\Philippines\LFS 2010\Data\Final data\PLFSjan.dta", replace
clear

*******************************************************
* April

infile using "Data\Philippines\LFS 2010\Data\Dictionaries\dicPLFSapr.dct"

label variable reg      "Region"
label variable stratum  "Stratum"
label variable psu      "Primary Sampling Unit - PSU"
label variable hhnum    "Household Unique Sequential Number"
label variable urb2k70  "C2K Urban Rural Classification (Based on 1970 Definition)"
label variable fwgt     "Final Weight"
label variable svymo    "Survey Month"
label variable svyyr    "Survey Year"
label variable c101_lno "C101-Line Number"
label variable c05_rel  "C05-Relationship to Household Head"
label variable c06_sex  "C06-Sex"
label variable c07_age  "C07-Age as of Last Birthday"
label variable c08_ms   "C08-Marital Status"
label variable c09_grd  "C09-Highest Grade Completed"
label variable a02_csch "Currently Attending School (April 2005)"
label variable c10_cnwr "C10-Contract/Overseas Worker Indicator"
label variable j01_usoc "C12-Usual Occupation (July 2003 - Jan 2005)"
label variable c13_work "C13-Did do any Work for at Least one Hour during the Past Week?"
label variable c14_job  "C14-Did Have a Job/Business during the Past Week?"
label variable c16_proc "C16-Primary Occupation"
label variable c18_pkb  "C18-Kind of Business (Primary Occupation)"
label variable c19pclas "C19-Class of Worker (Primary Occupation)"
label variable c20_ntem "C20-Nature of Employment (Primary Occupation)"
label variable c21_pwhr "C21-Normal Working Hours for the Day for the Past Week"
label variable c22_phrs "C22-Total Number of Hours Worked During the Past Week"
label variable c23_pwmr "C23-Did Want more Hours of Work During the Past Week"
label variable c24_plaw "C24-Did Look for Additional Work During the Past Week"
label variable c25_pfwk "C25-Was this his first time to do any Work?"
label variable c26_pbis "C26-Basis of Payment (Primary Occupation)"
label variable c27_pbsc "C27-Basic Pay per Day (Primary Occupation)"
label variable c28_ojob "C28-Other Job Indicator"
label variable j02_otoc "C30-Other Occupation (July 2003 - Jan 2005)"
label variable j03_okb  "C32-Kind of Business (Other Occupation) (July 2003 - Jan 2005)"
label variable j04_ocls "C33-Class of Worker (Other Occupation) (July 2003 - Jan 2005)"
label variable j05_ohrs "C34-Number of Hours Worked (Other Occupation) (July 2003 - Jan 2005)"
label variable j06_obis "C35-Basis of Payment (Other Occupation) (July 2003 - Jan 2005)"
label variable c36_obic "C36-Basic Pay per Day (Other Occupation) (July 2003 - Jan 2005)"
label variable a03_jobs "Number of Jobs during the past week (April 2005)"
label variable a04_thrs "Total Hours Worked for all Jobs (April 2005)"
label variable a05_r48h "Reasons for Working More than 48 Hours during the past week (April 2005)"
label variable c37_avil "C37-Was Available for Work During the Past Week?"
label variable c38_lokw "C38-Did Look For Work Anytime During the Past Week?"
label variable c39_jbsm "C39-What Was He Has Been Doing to Find Work During the Past Week?"
label variable c40_wks  "C40-Number of Weeks Spent in Looking for Work"
label variable c41_flwk "C41-Was This His First Time to Look For Work?"
label variable c42_wynt "C42-Why Did He not Look for Work?"
label variable a06_llkw "When Last Looked for Work (April 2005)"
label variable a07_wlng "Willingness to take up work during the past week (April 2005)"
label variable c43_lbef "C43-Did He Ever Work At Anytime Before?"
label variable c45_pocc "C45-Previous Occupation"
label variable a08_pqtr "Did work or had a job during the past quarter (April 2005)"
label variable a09_pqkb "Kind of Business (past quarter) (April 2005)"
label variable cempst1  "Employment Status (without Availability criterion)"
label variable newempst "Employment Status (Based on New Criteria on Unemployment) (April 2005)"

#delimit ;
label define REG     
    13 "National Capital Region"
    14 "Cordillera Administrative Region"
     1 "Region I - Ilocos Region"
     2 "Region II - Cagayan Valley"
     3 "Region III - Central Luzon"
    41 "Region IVA - CALABARZON"
    42 "Region IVB - MIMAROPA"
     5 "Region V- Bicol"
     6 "Region VI - Western Visayas"
     7 "Region VII - Central Visayas"
     8 "Region VIII - Eastern Visayas"
     9 "Region IX - Zamboanga Peninsula"
    10 "Region X - Northern Mindanao"
    11 "Region XI - Davao"
    12 "Region XII - SOCCSKSARGEN"
    16 "Caraga"
    15 "Autonomous Region in Muslim Mindanao"
;
label define URB2K70 
     1 "Urban"
     2 "Rural"
;
label define SVYMO   
     1 "January"
     4 "April"
     7 "July"
    10 "October"
;
label define SVYYR   
  2003 "2003"
  2004 "2004"
  2005 "2005"
  2006 "2006"
  2007 "2007"
  2008 "2008"
;
label define C05_REL 
     1 "Head"
     2 "Wife/Spouse"
     3 "Son/daughter"
     4 "Brothers/sisters"
     5 "Son/daughter_law"
     6 "Grandchildren"
     7 "Father/Mother"
     8 "Other Relative"
     9 "Boarder"
    10 "Domestic Helper"
    11 "Non_Relative"
;
label define C06_SEX 
     1 "Male"
     2 "Female"
;
label define C07_AGE 
    99 "Not reported"
;
label define C08_MS  
     1 "Single"
     2 "Married"
     3 "Widowed"
     4 "Divorce/Separate"
     5 "Unknown"
;
label define C09_GRD 
     0 "No Grade Completed"
     1 "Elementary Undegraduate"
     2 "Elementary Graduate"
     3 "Highschool Undergraduate"
     4 "Highschool Graduate"
     5 "Collge Undergraduate"
    99 "Not reported"
;
label define A02_CSCH
     1 "Currently attending school"
     2 "Not currently attending school"
;
label define C10_CNWR
     1 "OCW"
     2 "Workers other than OCW"
     3 "Employees in Phil. Embassy, Consulates and other Missions"
     4 "Students Abroad/Tourist"
     5 "Others"
;
label define J01_USOC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C13_WORK
     1 "Worked at Least One Hour"
     2 "Did not Work at Least One Hour"
;
label define C14_JOB 
     1 "With Job/Business During the Past Week"
     2 "No Job/Business During the Past Week"
;
label define C16_PROC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C18_PKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define C19PCLAS
     0 "Worked for private household"
     1 "Worked for private establishment"
     2 "Worked for gov't/gov't corporation"
     3 "Self employed without any paid employee"
     4 "Employer in own family-operated farm or business"
     5 "Worked with pay in own family-operated farm or business"
     6 "Worked without pay in own family-operated farm or business Business)"
     9 "Not Reported"
;
label define C20_NTEM
     1 "Permanent Job"
     2 "Short_term"
     3 "Different Employer"
;
label define C22_PHRS
     0 "with a job, not at work"
   999 "Not Reported"
;
label define C23_PWMR
     1 "Want More Hours of Work"
     2 "Did not Want More Hours of Work"
;
label define C24_PLAW
     1 "Looked for Additional Work"
     2 "Did not Look for Additional Work"
;
label define C25_PFWK
     1 "First Time to Do Any Work"
     2 "Not First Time to Do Any Work"
;
label define C26_PBIS
     0 "In Kind only"
     1 "Per piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Other S./Wages"
     7 "Commission Basis"
;
label define C27_PBSC
     0 "No Wages"
 99999 "Not Reported"
;
label define C28_OJOB
     1 "With Other Occupation"
     2 "No Other Occupation"
;
label define J02_OTOC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define J03_OKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define J04_OCLS
     0 "Private Household"
     1 "Private Establishment"
     2 "Gov't/Gov't Corporation"
     3 "Self Employed"
     4 "Employer"
     5 "With Pay (Family Owned Business)"
     6 "Without Pay (Family Owned Business("
     9 "Not Reported"
;
label define J06_OBIS
     0 "In Kind only"
     1 "Per Piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Others"
     7 "Commission Basis"
;
label define A05_R48H
     1 "Wanted More Earnings"
     2 "Requirements of the Job"
     3 "Exceptional week"
     4 "Ambition, passion for job"
     5 "Other reasons"
;
label define C37_AVIL
     1 "Available for Work During the Past Week"
     2 "Not Available for Work During the Past Week"
;
label define C38_LOKW
     1 "Looked for Work Anytime During the Past Week"
     2 "Did not Look for Work Anytime During the Past Week"
;
label define C39_JBSM
     2 "Registered in Private Employment Agency"
     1 "Registered in Public Employment Agency"
     3 "Approached Employer Directly"
     4 "Approached Relatives or Friends"
     5 "Placed or Answered Advertisements"
     6 "Others"
     9 "Not Reported"
;
label define C41_FLWK
     1 "First Time to Look for Work"
     2 "Not First Time to Look For Work"
;
label define C42_WYNT
     1 "Believe no Work Available"
     2 "Awaiting Results of Previous Job Application"
     3 "Temporary Illness/Disability"
     4 "Bad Weather"
     5 "Wait for rehire/Job Recall"
     6 "Too young/old or Retired/Permanent Disability"
     7 "Housekeeping"
     8 "Schooling"
     9 "Others"
;
label define A06_LLKW
     1 "Within last month"
     2 "One to six months ago"
     3 "More than six months ago"
;
label define A07_WLNG
     1 "Willing to take up work during the past week"
     2 "Not willing to take up work during the past week"
;
label define C43_LBEF
     1 "Worked at Anytime Before"
     2 "Did not Work at Anytime Before"
;
label define C45_POCC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define A08_PQTR
     1 "Yes"
     2 "No"
;
label define A09_PQKB
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define CEMPST1 
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;
label define NEWEMPST
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;

#delimit cr
label values reg      REG     
label values urb2k70  URB2K70 
label values svymo    SVYMO   
label values svyyr    SVYYR   
label values c05_rel  C05_REL 
label values c06_sex  C06_SEX 
label values c07_age  C07_AGE 
label values c08_ms   C08_MS  
label values c09_grd  C09_GRD 
label values a02_csch A02_CSCH
label values c10_cnwr C10_CNWR
label values j01_usoc J01_USOC
label values c13_work C13_WORK
label values c14_job  C14_JOB 
label values c16_proc C16_PROC
label values c18_pkb  C18_PKB 
label values c19pclas C19PCLAS
label values c20_ntem C20_NTEM
label values c22_phrs C22_PHRS
label values c23_pwmr C23_PWMR
label values c24_plaw C24_PLAW
label values c25_pfwk C25_PFWK
label values c26_pbis C26_PBIS
label values c27_pbsc C27_PBSC
label values c28_ojob C28_OJOB
label values j02_otoc J02_OTOC
label values j03_okb  J03_OKB 
label values j04_ocls J04_OCLS
label values j06_obis J06_OBIS
label values a05_r48h A05_R48H
label values c37_avil C37_AVIL
label values c38_lokw C38_LOKW
label values c39_jbsm C39_JBSM
label values c41_flwk C41_FLWK
label values c42_wynt C42_WYNT
label values a06_llkw A06_LLKW
label values a07_wlng A07_WLNG
label values c43_lbef C43_LBEF
label values c45_pocc C45_POCC
label values a08_pqtr A08_PQTR
label values a09_pqkb A09_PQKB
label values cempst1  CEMPST1 
label values newempst NEWEMPST

save "Data\Philippines\LFS 2010\Data\Final data\PLFSapr.dta", replace
clear

*******************************************************
* July

infile using "Data\Philippines\LFS 2010\Data\Dictionaries\dicPLFSjul.dct"

label variable reg      "Region"
label variable stratum  "Stratum"
label variable psu      "Primary Sampling Unit - PSU"
label variable hhnum    "Household Unique Sequential Number"
label variable urb2k70  "C2K Urban Rural Classification (Based on 1970 Definition)"
label variable fwgt     "Final Weight"
label variable svymo    "Survey Month"
label variable svyyr    "Survey Year"
label variable c101_lno "C101-Line Number"
label variable c05_rel  "C05-Relationship to Household Head"
label variable c06_sex  "C06-Sex"
label variable c07_age  "C07-Age as of Last Birthday"
label variable c08_ms   "C08-Marital Status"
label variable c09_grd  "C09-Highest Grade Completed"
label variable a02_csch "Currently Attending School (April 2005)"
label variable c10_cnwr "C10-Contract/Overseas Worker Indicator"
label variable j01_usoc "C12-Usual Occupation (July 2003 - Jan 2005)"
label variable c13_work "C13-Did do any Work for at Least one Hour during the Past Week?"
label variable c14_job  "C14-Did Have a Job/Business during the Past Week?"
label variable c16_proc "C16-Primary Occupation"
label variable c18_pkb  "C18-Kind of Business (Primary Occupation)"
label variable c19pclas "C19-Class of Worker (Primary Occupation)"
label variable c20_ntem "C20-Nature of Employment (Primary Occupation)"
label variable c21_pwhr "C21-Normal Working Hours for the Day for the Past Week"
label variable c22_phrs "C22-Total Number of Hours Worked During the Past Week"
label variable c23_pwmr "C23-Did Want more Hours of Work During the Past Week"
label variable c24_plaw "C24-Did Look for Additional Work During the Past Week"
label variable c25_pfwk "C25-Was this his first time to do any Work?"
label variable c26_pbis "C26-Basis of Payment (Primary Occupation)"
label variable c27_pbsc "C27-Basic Pay per Day (Primary Occupation)"
label variable c28_ojob "C28-Other Job Indicator"
label variable j02_otoc "C30-Other Occupation (July 2003 - Jan 2005)"
label variable j03_okb  "C32-Kind of Business (Other Occupation) (July 2003 - Jan 2005)"
label variable j04_ocls "C33-Class of Worker (Other Occupation) (July 2003 - Jan 2005)"
label variable j05_ohrs "C34-Number of Hours Worked (Other Occupation) (July 2003 - Jan 2005)"
label variable j06_obis "C35-Basis of Payment (Other Occupation) (July 2003 - Jan 2005)"
label variable c36_obic "C36-Basic Pay per Day (Other Occupation) (July 2003 - Jan 2005)"
label variable a03_jobs "Number of Jobs during the past week (April 2005)"
label variable a04_thrs "Total Hours Worked for all Jobs (April 2005)"
label variable a05_r48h "Reasons for Working More than 48 Hours during the past week (April 2005)"
label variable c37_avil "C37-Was Available for Work During the Past Week?"
label variable c38_lokw "C38-Did Look For Work Anytime During the Past Week?"
label variable c39_jbsm "C39-What Was He Has Been Doing to Find Work During the Past Week?"
label variable c40_wks  "C40-Number of Weeks Spent in Looking for Work"
label variable c41_flwk "C41-Was This His First Time to Look For Work?"
label variable c42_wynt "C42-Why Did He not Look for Work?"
label variable a06_llkw "When Last Looked for Work (April 2005)"
label variable a07_wlng "Willingness to take up work during the past week (April 2005)"
label variable c43_lbef "C43-Did He Ever Work At Anytime Before?"
label variable c45_pocc "C45-Previous Occupation"
label variable a08_pqtr "Did work or had a job during the past quarter (April 2005)"
label variable a09_pqkb "Kind of Business (past quarter) (April 2005)"
label variable cempst1  "Employment Status (without Availability criterion)"
label variable newempst "Employment Status (Based on New Criteria on Unemployment) (April 2005)"

#delimit ;
label define REG     
    13 "National Capital Region"
    14 "Cordillera Administrative Region"
     1 "Region I - Ilocos Region"
     2 "Region II - Cagayan Valley"
     3 "Region III - Central Luzon"
    41 "Region IVA - CALABARZON"
    42 "Region IVB - MIMAROPA"
     5 "Region V- Bicol"
     6 "Region VI - Western Visayas"
     7 "Region VII - Central Visayas"
     8 "Region VIII - Eastern Visayas"
     9 "Region IX - Zamboanga Peninsula"
    10 "Region X - Northern Mindanao"
    11 "Region XI - Davao"
    12 "Region XII - SOCCSKSARGEN"
    16 "Caraga"
    15 "Autonomous Region in Muslim Mindanao"
;
label define URB2K70 
     1 "Urban"
     2 "Rural"
;
label define SVYMO   
     1 "January"
     4 "April"
     7 "July"
    10 "October"
;
label define SVYYR   
  2003 "2003"
  2004 "2004"
  2005 "2005"
  2006 "2006"
  2007 "2007"
  2008 "2008"
;
label define C05_REL 
     1 "Head"
     2 "Wife/Spouse"
     3 "Son/daughter"
     4 "Brothers/sisters"
     5 "Son/daughter_law"
     6 "Grandchildren"
     7 "Father/Mother"
     8 "Other Relative"
     9 "Boarder"
    10 "Domestic Helper"
    11 "Non_Relative"
;
label define C06_SEX 
     1 "Male"
     2 "Female"
;
label define C07_AGE 
    99 "Not reported"
;
label define C08_MS  
     1 "Single"
     2 "Married"
     3 "Widowed"
     4 "Divorce/Separate"
     5 "Unknown"
;
label define C09_GRD 
     0 "No Grade Completed"
     1 "Elementary Undegraduate"
     2 "Elementary Graduate"
     3 "Highschool Undergraduate"
     4 "Highschool Graduate"
     5 "Collge Undergraduate"
    99 "Not reported"
;
label define A02_CSCH
     1 "Currently attending school"
     2 "Not currently attending school"
;
label define C10_CNWR
     1 "OCW"
     2 "Workers other than OCW"
     3 "Employees in Phil. Embassy, Consulates and other Missions"
     4 "Students Abroad/Tourist"
     5 "Others"
;
label define J01_USOC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C13_WORK
     1 "Worked at Least One Hour"
     2 "Did not Work at Least One Hour"
;
label define C14_JOB 
     1 "With Job/Business During the Past Week"
     2 "No Job/Business During the Past Week"
;
label define C16_PROC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C18_PKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define C19PCLAS
     0 "Worked for private household"
     1 "Worked for private establishment"
     2 "Worked for gov't/gov't corporation"
     3 "Self employed without any paid employee"
     4 "Employer in own family-operated farm or business"
     5 "Worked with pay in own family-operated farm or business"
     6 "Worked without pay in own family-operated farm or business Business)"
     9 "Not Reported"
;
label define C20_NTEM
     1 "Permanent Job"
     2 "Short_term"
     3 "Different Employer"
;
label define C22_PHRS
     0 "with a job, not at work"
   999 "Not Reported"
;
label define C23_PWMR
     1 "Want More Hours of Work"
     2 "Did not Want More Hours of Work"
;
label define C24_PLAW
     1 "Looked for Additional Work"
     2 "Did not Look for Additional Work"
;
label define C25_PFWK
     1 "First Time to Do Any Work"
     2 "Not First Time to Do Any Work"
;
label define C26_PBIS
     0 "In Kind only"
     1 "Per piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Other S./Wages"
     7 "Commission Basis"
;
label define C27_PBSC
     0 "No Wages"
 99999 "Not Reported"
;
label define C28_OJOB
     1 "With Other Occupation"
     2 "No Other Occupation"
;
label define J02_OTOC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define J03_OKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define J04_OCLS
     0 "Private Household"
     1 "Private Establishment"
     2 "Gov't/Gov't Corporation"
     3 "Self Employed"
     4 "Employer"
     5 "With Pay (Family Owned Business)"
     6 "Without Pay (Family Owned Business("
     9 "Not Reported"
;
label define J06_OBIS
     0 "In Kind only"
     1 "Per Piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Others"
     7 "Commission Basis"
;
label define A05_R48H
     1 "Wanted More Earnings"
     2 "Requirements of the Job"
     3 "Exceptional week"
     4 "Ambition, passion for job"
     5 "Other reasons"
;
label define C37_AVIL
     1 "Available for Work During the Past Week"
     2 "Not Available for Work During the Past Week"
;
label define C38_LOKW
     1 "Looked for Work Anytime During the Past Week"
     2 "Did not Look for Work Anytime During the Past Week"
;
label define C39_JBSM
     2 "Registered in Private Employment Agency"
     1 "Registered in Public Employment Agency"
     3 "Approached Employer Directly"
     4 "Approached Relatives or Friends"
     5 "Placed or Answered Advertisements"
     6 "Others"
     9 "Not Reported"
;
label define C41_FLWK
     1 "First Time to Look for Work"
     2 "Not First Time to Look For Work"
;
label define C42_WYNT
     1 "Believe no Work Available"
     2 "Awaiting Results of Previous Job Application"
     3 "Temporary Illness/Disability"
     4 "Bad Weather"
     5 "Wait for rehire/Job Recall"
     6 "Too young/old or Retired/Permanent Disability"
     7 "Housekeeping"
     8 "Schooling"
     9 "Others"
;
label define A06_LLKW
     1 "Within last month"
     2 "One to six months ago"
     3 "More than six months ago"
;
label define A07_WLNG
     1 "Willing to take up work during the past week"
     2 "Not willing to take up work during the past week"
;
label define C43_LBEF
     1 "Worked at Anytime Before"
     2 "Did not Work at Anytime Before"
;
label define C45_POCC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define A08_PQTR
     1 "Yes"
     2 "No"
;
label define A09_PQKB
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define CEMPST1 
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;
label define NEWEMPST
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;

#delimit cr
label values reg      REG     
label values urb2k70  URB2K70 
label values svymo    SVYMO   
label values svyyr    SVYYR   
label values c05_rel  C05_REL 
label values c06_sex  C06_SEX 
label values c07_age  C07_AGE 
label values c08_ms   C08_MS  
label values c09_grd  C09_GRD 
label values a02_csch A02_CSCH
label values c10_cnwr C10_CNWR
label values j01_usoc J01_USOC
label values c13_work C13_WORK
label values c14_job  C14_JOB 
label values c16_proc C16_PROC
label values c18_pkb  C18_PKB 
label values c19pclas C19PCLAS
label values c20_ntem C20_NTEM
label values c22_phrs C22_PHRS
label values c23_pwmr C23_PWMR
label values c24_plaw C24_PLAW
label values c25_pfwk C25_PFWK
label values c26_pbis C26_PBIS
label values c27_pbsc C27_PBSC
label values c28_ojob C28_OJOB
label values j02_otoc J02_OTOC
label values j03_okb  J03_OKB 
label values j04_ocls J04_OCLS
label values j06_obis J06_OBIS
label values a05_r48h A05_R48H
label values c37_avil C37_AVIL
label values c38_lokw C38_LOKW
label values c39_jbsm C39_JBSM
label values c41_flwk C41_FLWK
label values c42_wynt C42_WYNT
label values a06_llkw A06_LLKW
label values a07_wlng A07_WLNG
label values c43_lbef C43_LBEF
label values c45_pocc C45_POCC
label values a08_pqtr A08_PQTR
label values a09_pqkb A09_PQKB
label values cempst1  CEMPST1 
label values newempst NEWEMPST

save "Data\Philippines\LFS 2010\Data\Final data\PLFSjul.dta", replace
clear

*******************************************************
* October

infile using "Data\Philippines\LFS 2010\Data\Dictionaries\dicPLFSoct.dct"

label variable reg      "Region"
label variable stratum  "Stratum"
label variable psu      "Primary Sampling Unit - PSU"
label variable hhnum    "Household Unique Sequential Number"
label variable urb2k70  "C2K Urban Rural Classification (Based on 1970 Definition)"
label variable fwgt     "Final Weight"
label variable svymo    "Survey Month"
label variable svyyr    "Survey Year"
label variable c101_lno "C101-Line Number"
label variable c05_rel  "C05-Relationship to Household Head"
label variable c06_sex  "C06-Sex"
label variable c07_age  "C07-Age as of Last Birthday"
label variable c08_ms   "C08-Marital Status"
label variable c09_grd  "C09-Highest Grade Completed"
label variable a02_csch "Currently Attending School (April 2005)"
label variable c10_cnwr "C10-Contract/Overseas Worker Indicator"
label variable j01_usoc "C12-Usual Occupation (July 2003 - Jan 2005)"
label variable c13_work "C13-Did do any Work for at Least one Hour during the Past Week?"
label variable c14_job  "C14-Did Have a Job/Business during the Past Week?"
label variable c16_proc "C16-Primary Occupation"
label variable c18_pkb  "C18-Kind of Business (Primary Occupation)"
label variable c19pclas "C19-Class of Worker (Primary Occupation)"
label variable c20_ntem "C20-Nature of Employment (Primary Occupation)"
label variable c21_pwhr "C21-Normal Working Hours for the Day for the Past Week"
label variable c22_phrs "C22-Total Number of Hours Worked During the Past Week"
label variable c23_pwmr "C23-Did Want more Hours of Work During the Past Week"
label variable c24_plaw "C24-Did Look for Additional Work During the Past Week"
label variable c25_pfwk "C25-Was this his first time to do any Work?"
label variable c26_pbis "C26-Basis of Payment (Primary Occupation)"
label variable c27_pbsc "C27-Basic Pay per Day (Primary Occupation)"
label variable c28_ojob "C28-Other Job Indicator"
label variable j02_otoc "C30-Other Occupation (July 2003 - Jan 2005)"
label variable j03_okb  "C32-Kind of Business (Other Occupation) (July 2003 - Jan 2005)"
label variable j04_ocls "C33-Class of Worker (Other Occupation) (July 2003 - Jan 2005)"
label variable j05_ohrs "C34-Number of Hours Worked (Other Occupation) (July 2003 - Jan 2005)"
label variable j06_obis "C35-Basis of Payment (Other Occupation) (July 2003 - Jan 2005)"
label variable c36_obic "C36-Basic Pay per Day (Other Occupation) (July 2003 - Jan 2005)"
label variable a03_jobs "Number of Jobs during the past week (April 2005)"
label variable a04_thrs "Total Hours Worked for all Jobs (April 2005)"
label variable a05_r48h "Reasons for Working More than 48 Hours during the past week (April 2005)"
label variable c37_avil "C37-Was Available for Work During the Past Week?"
label variable c38_lokw "C38-Did Look For Work Anytime During the Past Week?"
label variable c39_jbsm "C39-What Was He Has Been Doing to Find Work During the Past Week?"
label variable c40_wks  "C40-Number of Weeks Spent in Looking for Work"
label variable c41_flwk "C41-Was This His First Time to Look For Work?"
label variable c42_wynt "C42-Why Did He not Look for Work?"
label variable a06_llkw "When Last Looked for Work (April 2005)"
label variable a07_wlng "Willingness to take up work during the past week (April 2005)"
label variable c43_lbef "C43-Did He Ever Work At Anytime Before?"
label variable c45_pocc "C45-Previous Occupation"
label variable a08_pqtr "Did work or had a job during the past quarter (April 2005)"
label variable a09_pqkb "Kind of Business (past quarter) (April 2005)"
label variable cempst1  "Employment Status (without Availability criterion)"
label variable newempst "Employment Status (Based on New Criteria on Unemployment) (April 2005)"

#delimit ;
label define REG     
    13 "National Capital Region"
    14 "Cordillera Administrative Region"
     1 "Region I - Ilocos Region"
     2 "Region II - Cagayan Valley"
     3 "Region III - Central Luzon"
    41 "Region IVA - CALABARZON"
    42 "Region IVB - MIMAROPA"
     5 "Region V- Bicol"
     6 "Region VI - Western Visayas"
     7 "Region VII - Central Visayas"
     8 "Region VIII - Eastern Visayas"
     9 "Region IX - Zamboanga Peninsula"
    10 "Region X - Northern Mindanao"
    11 "Region XI - Davao"
    12 "Region XII - SOCCSKSARGEN"
    16 "Caraga"
    15 "Autonomous Region in Muslim Mindanao"
;
label define URB2K70 
     1 "Urban"
     2 "Rural"
;
label define SVYMO   
     1 "January"
     4 "April"
     7 "July"
    10 "October"
;
label define SVYYR   
  2003 "2003"
  2004 "2004"
  2005 "2005"
  2006 "2006"
  2007 "2007"
  2008 "2008"
;
label define C05_REL 
     1 "Head"
     2 "Wife/Spouse"
     3 "Son/daughter"
     4 "Brothers/sisters"
     5 "Son/daughter_law"
     6 "Grandchildren"
     7 "Father/Mother"
     8 "Other Relative"
     9 "Boarder"
    10 "Domestic Helper"
    11 "Non_Relative"
;
label define C06_SEX 
     1 "Male"
     2 "Female"
;
label define C07_AGE 
    99 "Not reported"
;
label define C08_MS  
     1 "Single"
     2 "Married"
     3 "Widowed"
     4 "Divorce/Separate"
     5 "Unknown"
;
label define C09_GRD 
     0 "No Grade Completed"
     1 "Elementary Undegraduate"
     2 "Elementary Graduate"
     3 "Highschool Undergraduate"
     4 "Highschool Graduate"
     5 "Collge Undergraduate"
    99 "Not reported"
;
label define A02_CSCH
     1 "Currently attending school"
     2 "Not currently attending school"
;
label define C10_CNWR
     1 "OCW"
     2 "Workers other than OCW"
     3 "Employees in Phil. Embassy, Consulates and other Missions"
     4 "Students Abroad/Tourist"
     5 "Others"
;
label define J01_USOC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C13_WORK
     1 "Worked at Least One Hour"
     2 "Did not Work at Least One Hour"
;
label define C14_JOB 
     1 "With Job/Business During the Past Week"
     2 "No Job/Business During the Past Week"
;
label define C16_PROC
    11 "Officials of Government and Special-Interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers or Managing-Proprietors"
    14 "Supervisors"
    21 "Physicists, Mathematical and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Services Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trade Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     2 "Non-Gainful Occupations"
     9 "Other Occupations Not Classifiable"
;
label define C18_PKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define C19PCLAS
     0 "Worked for private household"
     1 "Worked for private establishment"
     2 "Worked for gov't/gov't corporation"
     3 "Self employed without any paid employee"
     4 "Employer in own family-operated farm or business"
     5 "Worked with pay in own family-operated farm or business"
     6 "Worked without pay in own family-operated farm or business Business)"
     9 "Not Reported"
;
label define C20_NTEM
     1 "Permanent Job"
     2 "Short_term"
     3 "Different Employer"
;
label define C22_PHRS
     0 "with a job, not at work"
   999 "Not Reported"
;
label define C23_PWMR
     1 "Want More Hours of Work"
     2 "Did not Want More Hours of Work"
;
label define C24_PLAW
     1 "Looked for Additional Work"
     2 "Did not Look for Additional Work"
;
label define C25_PFWK
     1 "First Time to Do Any Work"
     2 "Not First Time to Do Any Work"
;
label define C26_PBIS
     0 "In Kind only"
     1 "Per piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Other S./Wages"
     7 "Commission Basis"
;
label define C27_PBSC
     0 "No Wages"
 99999 "Not Reported"
;
label define C28_OJOB
     1 "With Other Occupation"
     2 "No Other Occupation"
;
label define J02_OTOC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define J03_OKB 
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define J04_OCLS
     0 "Private Household"
     1 "Private Establishment"
     2 "Gov't/Gov't Corporation"
     3 "Self Employed"
     4 "Employer"
     5 "With Pay (Family Owned Business)"
     6 "Without Pay (Family Owned Business("
     9 "Not Reported"
;
label define J06_OBIS
     0 "In Kind only"
     1 "Per Piece"
     2 "Per Hour"
     3 "Per Day"
     4 "Monthly"
     5 "Pakyaw"
     6 "Others"
     7 "Commission Basis"
;
label define A05_R48H
     1 "Wanted More Earnings"
     2 "Requirements of the Job"
     3 "Exceptional week"
     4 "Ambition, passion for job"
     5 "Other reasons"
;
label define C37_AVIL
     1 "Available for Work During the Past Week"
     2 "Not Available for Work During the Past Week"
;
label define C38_LOKW
     1 "Looked for Work Anytime During the Past Week"
     2 "Did not Look for Work Anytime During the Past Week"
;
label define C39_JBSM
     2 "Registered in Private Employment Agency"
     1 "Registered in Public Employment Agency"
     3 "Approached Employer Directly"
     4 "Approached Relatives or Friends"
     5 "Placed or Answered Advertisements"
     6 "Others"
     9 "Not Reported"
;
label define C41_FLWK
     1 "First Time to Look for Work"
     2 "Not First Time to Look For Work"
;
label define C42_WYNT
     1 "Believe no Work Available"
     2 "Awaiting Results of Previous Job Application"
     3 "Temporary Illness/Disability"
     4 "Bad Weather"
     5 "Wait for rehire/Job Recall"
     6 "Too young/old or Retired/Permanent Disability"
     7 "Housekeeping"
     8 "Schooling"
     9 "Others"
;
label define A06_LLKW
     1 "Within last month"
     2 "One to six months ago"
     3 "More than six months ago"
;
label define A07_WLNG
     1 "Willing to take up work during the past week"
     2 "Not willing to take up work during the past week"
;
label define C43_LBEF
     1 "Worked at Anytime Before"
     2 "Did not Work at Anytime Before"
;
label define C45_POCC
    11 "Officials of Government and Special-interest Organizations"
    12 "Corporate Executives and Specialized Managers"
    13 "General Managers/Managing-Proprietors"
    14 "Supervisors"
    21 "Physical, Mathematical, and Engineering Science Professionals"
    22 "Life Science and Health Professionals"
    23 "Teaching Professionals"
    24 "Other Professionals"
    31 "Physical Science and Engineering Associate Professionals"
    32 "Life Science and Health Associate Professionals"
    33 "Teaching Associate Professionals"
    34 "Related Associate Professionals"
    41 "Office Clerks"
    42 "Customer Service Clerks"
    51 "Personal and Protective Service Workers"
    52 "Models, Salespersons and Demonstrators"
    61 "Farmers and Other Plant Growers"
    62 "Animal Producers"
    63 "Forestry and Related Workers"
    64 "Fishermen"
    65 "Hunters and Trappers"
    71 "Mining, Construction and Related Trades Workers"
    72 "Metal, Machinery and Related Trades Workers"
    73 "Precision, Handicraft, Printing and Related Trades Workers"
    74 "Other Craft and Related Trades Workers"
    81 "Stationary, Plant and Related Operators"
    82 "Machine Operators and Assemblers"
    83 "Drivers and Mobile-Plant Operators"
    91 "Sales and Services Elementary Occupations"
    92 "Agricultural, Forestry, Fishery and Related Laborers"
    93 "Laborers in Mining, Construction, Manufacturing and Transport"
     1 "Armed Forces"
     9 "Other Occupation not Classifiable"
;
label define A08_PQTR
     1 "Yes"
     2 "No"
;
label define A09_PQKB
     1 "Growing of Crops"
     2 "Farming Animals"
     3 "Agricultural and Animal Husbandry Service Activities, Except Veterinary Activities"
     4 "Hunting, Trapping and Game Propagation"
     5 "Forestry, Logging and Related Service Activities"
     6 "Fishing"
    10 "Metallic Ore Mining"
    11 "Non-Metallic Mining and Quarrying"
    15 "Manufacture of Food Products and Beverages"
    16 "Manufacture of Tobacco Products"
    17 "Manufacture of Textiles"
    18 "Manufacture of Wearing Apparel"
    19 "Tanning and Dressing of Leather, Manufacture Luggage, Handbags and Footwear"
    20 "Manufacture of Wood, Wood Products and Cork, Except Furniture; Manufacture of Articles of Bamboo, Cane Rattan and the Like; Manufacture of Plaiting Materials"
    21 "Manufacture of Paper and Paper Products"
    22 "Publishing, Printing and Reproduction of Recorded Media"
    23 "Manufacture of Coke, Refined Petroleum and Other Fuel Products"
    24 "Manufacture of Chemicals and Chemical Products"
    25 "Manufacture of Rubber and Plastic Products"
    26 "Manufacture of Other Non-Metallic Mineral Products"
    27 "Manufacture of Basic Metals"
    28 "Manufacture of Fabricated Metal Products, Except Machinery and Equipment"
    29 "Manufacture of Machinery and Equipment, NEC"
    30 "Manufacture of Office, Accounting and Computing Machinery"
    31 "Manufacture of Electrical Machinery and Apparatus, NEC"
    32 "Manufacture of Radio, Television and Communication Equipment and Apparatus"
    33 "Manufacture of Medical, Precision and Optical Instruments, Watches and Clocks"
    34 "Manufacture of Motor Vehicles, Trailers and Semi-Trailers"
    35 "Manufacture of Other Transport Equipment"
    36 "Manufacture and Repair of Furniture"
    37 "Recycling"
    39 "Manufacture, NEC"
    40 "Electricity, Gas Steam and Hot Water Supply"
    41 "Collection, Purification and Distribution of Water"
    45 "Construction"
    50 "Sale, Maintenance and Repair of Motor Vehicles and Motorcycles, Retail Sale of Automotive Fuel"
    51 "Wholesale Trade and Commission Trade, Except of Motor Vehicles and Motorcycles"
    52 "Retail Trade, Except of Motor Vehicles and Motorcycles, Repair of Personal and Household Goods"
    55 "Hotels and Restaurants"
    60 "Land Transport; Transport via Pipelines"
    61 "Water Transport"
    62 "Air Transport"
    63 "Supporting and Auxiliary Transport Activities; Activities of Travel Aggencies"
    64 "Postal and Telecommunications Services"
    65 "Banking Institutions"
    66 "Non-Bank Financial Intermediation"
    67 "Insurance and Pension Funding, Except Compulsory Social Security"
    68 "Activities Auxiliary to Financial Intermediation"
    70 "Real Estate Activities"
    71 "Renting of Machinery and Equipment Without Operator; Personal and Household Goods"
    72 "Computer and Related Activities"
    73 "Research and Development"
    74 "Miscellaneous Business Activities"
    75 "Public Administration and Defense; Compulsory Social Security"
    80 "Public Education Services"
    81 "Private Education Services"
    85 "Health and Social Work"
    90 "Sewage and Refuse Disposal, Sanitation and Similar Activities"
    91 "Activities of Membership Organizations, NEC"
    92 "Recreational, Cultural and Sporting Activities"
    93 "Other Service Activities"
    95 "Private Households with Employed Persons"
    99 "Extra-Territorial Organizations and Bodies"
;
label define CEMPST1 
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;
label define NEWEMPST
     1 "Employed"
     2 "Unemployed"
     3 "Not in the labor force"
;

#delimit cr
label values reg      REG     
label values urb2k70  URB2K70 
label values svymo    SVYMO   
label values svyyr    SVYYR   
label values c05_rel  C05_REL 
label values c06_sex  C06_SEX 
label values c07_age  C07_AGE 
label values c08_ms   C08_MS  
label values c09_grd  C09_GRD 
label values a02_csch A02_CSCH
label values c10_cnwr C10_CNWR
label values j01_usoc J01_USOC
label values c13_work C13_WORK
label values c14_job  C14_JOB 
label values c16_proc C16_PROC
label values c18_pkb  C18_PKB 
label values c19pclas C19PCLAS
label values c20_ntem C20_NTEM
label values c22_phrs C22_PHRS
label values c23_pwmr C23_PWMR
label values c24_plaw C24_PLAW
label values c25_pfwk C25_PFWK
label values c26_pbis C26_PBIS
label values c27_pbsc C27_PBSC
label values c28_ojob C28_OJOB
label values j02_otoc J02_OTOC
label values j03_okb  J03_OKB 
label values j04_ocls J04_OCLS
label values j06_obis J06_OBIS
label values a05_r48h A05_R48H
label values c37_avil C37_AVIL
label values c38_lokw C38_LOKW
label values c39_jbsm C39_JBSM
label values c41_flwk C41_FLWK
label values c42_wynt C42_WYNT
label values a06_llkw A06_LLKW
label values a07_wlng A07_WLNG
label values c43_lbef C43_LBEF
label values c45_pocc C45_POCC
label values a08_pqtr A08_PQTR
label values a09_pqkb A09_PQKB
label values cempst1  CEMPST1 
label values newempst NEWEMPST

save "Data\Philippines\LFS 2010\Data\Final data\PLFSoct.dta", replace
clear


*******************************************************
*Merge Files
* Adjust HH id

use "Data\Philippines\LFS 2010\Data\Final data\PLFSjan.dta", clear
gen hid1=string(hhnum)+"-"+string(svymo)
save "Data\Philippines\LFS 2010\Data\Final data\PLFSjan.dta", replace

use "Data\Philippines\LFS 2010\Data\Final data\PLFSapr.dta", clear
gen hid1=string(hhnum)+"-"+string(svymo)
save "Data\Philippines\LFS 2010\Data\Final data\PLFSapr.dta", replace

use "Data\Philippines\LFS 2010\Data\Final data\PLFSjul.dta", clear
gen hid1=string(hhnum)+"-"+string(svymo)
save "Data\Philippines\LFS 2010\Data\Final data\PLFSjul.dta", replace

use "Data\Philippines\LFS 2010\Data\Final data\PLFSoct.dta", clear
gen hid1=string(hhnum)+"-"+string(svymo)
save "Data\Philippines\LFS 2010\Data\Final data\PLFSoct.dta", replace

* Append

use "Data\Philippines\LFS 2010\Data\Final data\PLFSjan.dta", clear
append using "Data\Philippines\LFS 2010\Data\Final data\PLFSapr.dta"
append using "Data\Philippines\LFS 2010\Data\Final data\PLFSjul.dta"
append using "Data\Philippines\LFS 2010\Data\Final data\PLFSoct.dta"
save "Data\Philippines\LFS 2010\Data\Final data\PLFS_Final.dta", replace


