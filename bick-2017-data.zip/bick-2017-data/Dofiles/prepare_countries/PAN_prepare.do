*******************************************************************************************
* Program: PAN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Panama
*******************************************************************************************

use "Data\Panama\LSS (LSMS) 2008\Data\04persona", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs upm vivienda hogar
foreach v in `vs'{
	gen `v's=string(`v')	
}

replace hid=upms+"-"+viviendas+"-"+hogars

foreach v in `vs'{
	drop `v's
}

replace pid=cp_perso
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=p4_edad

* Gender
replace male=1 if p3_sexo==1
replace male=0 if p3_sexo==2

*-----------------------------------------

* Weight
replace wgt=factor

* Interview date
replace refdatex=0

*-----------------------------------------

gen educ=.
replace educ=1 if s5p19==1
replace educ=0 if s5p19==2
gen educlvl=.
replace educlvl=1 if s5p21a>=7 & s5p21a<=9
replace educlvl=0 if s5p21a>=3 & s5p21a<=6 
replace educlvl=0 if s5p21a>=10 & s5p21a!=.

******************************************
* Market work																		/* Universe: Age 10 and above */
******************************************

* Employment status (market work) in the last 14 days
replace emp=1 if s7p1b==1 | s7p2==1
replace emp=0 if s7p1b==2 & s7p2==2
replace emp=2 if s7p1b==2 & s7p2==2 & s7p3==1

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=1 if emp==2

*-----------------------------------------

* Main job

* Months worked in last 12 months
replace mthsyr_mj=s7p18
replace mthsyr_mj=0 if (emp==0 | emp==2) & s7p18==.

* Actual days worked per week
replace adayswk_mj=s7p19
replace adayswk_mj=0 if (emp==0 | emp==2) & s7p19==.

* Actual hours worked per week	
replace ahrswk_mj=s7p20
replace ahrswk_mj=. if s7p20==999
replace ahrswk_mj=0 if (emp==0 | emp==2) & ahrswk_mj==.

*-----------------------------------------

* Sec job

* Months worked in last 12 months
replace mthsyr_sj=s7p41
replace mthsyr_sj=0 if (emp==0 | emp==2) & s7p41==.

* Actual days worked per week
replace adayswk_sj=s7p42
replace adayswk_sj=0 if (emp==0 | emp==2) & s7p42==.

* Actual hours worked per week	
replace ahrswk_sj=s7p43
replace ahrswk_sj=0 if (emp==0 | emp==2) & s7p43==.


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicators for main and sec jobs
local jobs mj sj
local nature wj sa sn sx uc
local time mthsyr adayswk ahrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if s7p23>=1 & s7p23<=6
replace mj_sa=1 if (s7p23>=7 & s7p23<=11) & (s7p16>=1 & s7p16<=5)
replace mj_sn=1 if (s7p23>=7 & s7p23<=11) & (s7p16>=10 & s7p16<=98)
replace mj_sx=1 if (s7p23>=7 & s7p23<=11) & s7p16==99
replace mj_uc=1 if s7p23==.

replace sj_wj=1 if s7p45>=1 & s7p45<=6
replace sj_sa=1 if (s7p45>=7 & s7p45<=11) & (s7p40>=1 & s7p40<=5)
replace sj_sn=1 if (s7p45>=7 & s7p45<=11) & (s7p40>=10 & s7p40<=98)
replace sj_sx=1 if (s7p45>=7 & s7p45<=11) & s7p40==99
replace sj_uc=1 if s7p45==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

replace chrsday=(s7p37/60)*2														/* Mutiply by 2 to obtain time taken for a round trip */

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
