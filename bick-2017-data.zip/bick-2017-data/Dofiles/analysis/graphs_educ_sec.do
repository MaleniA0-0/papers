foreach x in edu ind{

	* Variables
	if "`x'"=="ind"{
		local vs hwe
		local as all

	}
	else{
		local vs hwp // er hwe
		local as non_young // prime old
	}
	
	use Data/Cleaned_data/repl_master_stats,replace

	keep if coreDummy==1
		
	forvalues t=1/2{
		sum t`t'_${z}
		local t`t'=r(mean)
	}


	* Sort data and add three observations for mean 
	sort ln_gdppc_${z}
	count 
	local N=r(N)+3
	set obs `N'
	gen nn=_n
	gsort -nn
	replace nn=_n
	forvalues q=1/3{
		sum ln_gdppc_${z} if q_${z}==`q'
		replace ln_gdppc_${z}=r(mean) if nn==`q'
	}
		
	* Graph specifiers
	local rhwe 0(5)50
	local thwe Hours per Week
	
	local rhwp 0(5)50
	local thwp Hours per Week
	
	local rer 0(10)100
	local ter Employment Rate (in %)
	
	local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'

	local xl 7(.5)11
	
	local g a

	foreach a in `as'{
	foreach v in `vs'{
	forvalues z=1/3{
	
		if "`v'"=="er"{
			replace `v'_`g'_`a'_`x'`z'=`v'_`g'_`a'_`x'`z'*100
		}
	
		forvalues q=1/3{
			sum `v'_`g'_`a'_`x'`z' if q_${z}==`q'
			replace  `v'_`g'_`a'_`x'`z'=r(mean) if nn==`q'	
		}
		

		local xleglab Income Group Average

		
		local lc gs8
		twoway	(scatter `v'_`g'_`a'_`x'`z' ln_gdppc_${z} if nn>3, msize(vsmall) mlab(country) mcolor(black) mlabpos(3) ///
				 xline(`t1', lpattern(dot) lcolor(`lc')) xline(`t2', lpattern(dot) lcolor(`lc')) msize(vsmall)) ///					   
				, `options' xtitle(ln(GDP per Capita)) ytitle(`t`v'') ylabel(`r`v'', angle(0) grid gmin gmax) xlabel(`xl') ///
			   	legend(off) ysize(3.3) xsize(6) // graphregion(margin(zero)) 
		graph export "texinput/`v'_`g'_`a'_`x'`z'_nox_${z}.pdf", replace		   	  			
		
	}
	}
	}

} // core vs all countries
