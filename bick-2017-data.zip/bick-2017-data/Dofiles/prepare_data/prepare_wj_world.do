**********************************************************************************************************
* Program: prepare_wj_world.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos
*---------------------------------------------------------------------------------------------------------*
* Purpose: 	Loops over the harmonized country Datafiles to compute a micro world-dataset containing hours and
*			wage rates based on earnings from paid employment activities. 
* Structure:
*			1) 	Read in country dataset. For section (6) of the published paper, the analysis builds on 
*				EU-SILC data instead of the EU-LFS surveys. Cleaning & Identifying relevant observations. 
*			2)	Checks: Compute share of missing observations
*			3) 	Construct deciles for wage rates and classify the individuals accordingly. Repeat for wage 
*				percentiles.
*			4)	Keep relevant variables and append all country datasets
**********************************************************************************************************
clear all

/*
*Generate an empty dataset to be filled while running. Unmarking this section rewrites the original dataset.
set obs 1
gen country = "."
gen hid = "."
gen pid = .
saveold "Data\Cleaned_data/wj_world_dataset.dta", version(12) replace
clear
*/

local non_eulfs  ALB ECU PER COL GHA TUR VNM KEN TLS RWA IRQ UGA MUS MWI BWA PAK KHM MNG TZA USA  //BEL_silc BGR_silc  ROM_silc CHE_silc CYP_silc CZE_silc DEU_silc DNK_silc ESP_silc EST_silc FIN_silc FRA_silc GBR_silc GRC_silc HUN_silc IRL_silc ITA_silc LTU_silc LVA_silc NLD_silc POL_silc PRT_silc  SVK_silc SVN_silc SWE_silc NOR_silc
local eulfs AUT BEL BGR  ROM CHE CYP CZE DEU DNK ESP EST FIN FRA GBR GRC HUN IRL ITA LTU LVA NLD POL PRT SVK SVN SWE

local countries non_eulfs eulfs
local a all

*quiet {
foreach set in `countries' {
foreach country in ``set'' {

local incvar hr_wage
local t hr
local sample flag_set5 == 1

global income_stats country	
local income_vars inc_`incvar'_`t'
	
	if "`set'" == "non_eulfs"	{
		use "Data\Cleaned_data/`country'_all_std.dta", clear
	}
	if "`set'" == "eulfs" {	
		use "Data\Cleaned_data/`country'_silc_all_std.dta", clear			
	}

	replace flag_set4=1 if flag_set3==1
	replace flag_set4=0 if flag_set4==.

	gen flag_set5=flag_set4
	*identify available wages
	replace flag_set5=1 if (hrs_wj==. & hrs!=.) & (hr_wage==. & inc_wj_hr!=.) & flag_set4==0

	*Replace new wage and hrs_wj = old wage and hrs if set5:
	replace hrs_wj = hrs if flag_set5==1 & flag_set4==0 
	replace hr_wage = inc_wj_hr if flag_set5==1 & flag_set4==0 
	
	*Housekeeping
	display "We are in `country' `incvar' `a' Loop!"
	capture noisily: gen country = "`country'"

	egen totwgt = total(wgt)
	gen unit_wgt = wgt/totwgt													//Standardized to unity weights

	gen i = 0
	replace i = 1 if (`incvar' > 0 & `incvar' != .) & age_`a' == 1	& `sample'	//Indicator for available wage job/hh_pe income	

*	Check missings
*	1) 	Generate share of employed with income data over all employed observations
		gen wgt_test = wgt if employed == 1 & age_`a' == 1
		egen wgt_emp_`a' = total(wgt_test),m
			drop wgt_test
			label variable wgt_emp_`a' "Sum of weights for `a' emp == 1"
		
		gen wgt_test = wgt if (`incvar' != .) & employed == 1  & age_`a' == 1
		egen wgt_incemp = total(wgt_test),m
			drop wgt_test
	
		gen sh_wj_`t'_`a' = wgt_incemp/wgt_emp_`a'								//Captures # of observations with available incomes from total population
			label variable sh_wj_`t'_`a' "Share avail. `t'ly wage over working pop. aged `a'"	
			drop wgt_incemp
	
*	2)	Generate share of observations with missing wj income over work status employee
		gen wgt_test = wgt if `incvar' == . & employed == 1  & age_`a' == 1 & emp_wj == 1
		egen wgt_incemp = total(wgt_test),m
		count if `incvar' == . & employed == 1  & age_`a' == 1 & emp_wj == 1
			if r(N) == 0 {
				replace wgt_incemp = 0
			}
			drop wgt_test
		
		gen wgt_test = wgt if employed == 1  & age_`a' == 1 & emp_wj == 1
		egen wgt_wsemp = total(wgt_test),m
			drop wgt_test	
		gen sh_mwj_ws_`t'_`a' = wgt_incemp/wgt_wsemp
			label variable sh_mwj_ws_`t'_`a' "Share missing wage job income/work status = employee"
		drop wgt_incemp wgt_wsemp
	
	
	
	
	*Keep all w/ available wage rate and in age category and in samples 1-5:
	keep if i == 1
	gen num_obs = _N
	
	*Classify observations into deciles (based on monthly/hourly income rate), based on age subsample
	sort `incvar'																//Sorting based on income variable and hourly/monthly income rate values
	gen n = sum(wgt)															//Sum of weights up to observation _n
	egen N = total(wgt)															//Total sum of weights
	gen `incvar'_pctl = n/N
		label variable `incvar'_pctl "Percentile, based on `incvar'"
	gen `incvar'_dec = 0
		label variable `incvar'_dec "Decile, based on `incvar'"
	
	*Classify observations into deciles (based on hourly work income)
	forvalues num = 0/9 {
		replace `incvar'_dec = `incvar'_dec + 1 if n/N >= `num'/10
	}
	forvalues num = 1/10 {
		sum `incvar' [aweight = wgt] if `incvar'_dec == `num' 
			local dec`num'_min = r(min)
			local dec`num'_max = r(max)
		
		local num_m1 = `num'-1
		local t`num' = (`dec_`num_m1'_max' + `dec`num'_min')/2
		
		replace `incvar'_dec = `incvar'_dec - 1 if `incvar' <= `t`num'' & `incvar'_dec == `num'
	}
	
	*Classify observations into percentiles (based on hourly work income)	
	forvalues num = 1/100 {
		replace `incvar'_pctl = `num' if (`incvar'_pctl < `num'/100 & `incvar'_pctl >= (`num'-1)/100)
	}
	forvalues num = 1/100 {
		sum `incvar' [aweight = wgt] if `incvar'_pctl == `num' 
			local dec`num'_min = r(min)
			local dec`num'_max = r(max)
		
		local num_m1 = `num'-1
		local t`num' = (`dec_`num_m1'_max' + `dec`num'_min')/2
		
		replace `incvar'_pctl = `incvar'_pctl - 1 if `incvar' <= `t`num'' & `incvar'_pctl == `num'
	}	
		
local income_vars inc_wj_hr hr_wage rep_hr_wage hr_wage_mj `incvar'_dec `incvar'_pctl sh_mwj_ws_`t'_`a' sh_wj_`t'_`a'
local hrs_vars hrs hrs_wj hrs_u hrs_u_mj hrs_u_aj 
local flags flag_set1 flag_set2 flag_set3 flag_set4 flag_set5
local covars country hid pid age age_`a' male edu ind unit_wgt num_obs 

keep `income_vars' `hrs_vars' `flags' `covars' 
order `income_vars' `hrs_vars' `flags' `covars' 
		
	*resolve some trouble with string hh identifiers	
	if "`country'" == "RWA" { // | "`country'" == "TLS" {
		gen hidt = "." 
		replace hidt = string(hid)
		drop hid
		rename hidt hid
	}	
	if "`country'" == "TLS" | "`set'" == "eulfs"{
		gen hidt = "." 
		replace hidt = string(hid, "%02.0f")
		drop hid
			rename hidt hid	
		}
	
if "`country'" == "ALB" {
	merge m:m country pid using "Data\Cleaned_data/wj_world_dataset.dta", 
	
}
if "`country'" != "ALB" {
	merge 1:m country hid pid using "Data\Cleaned_data/wj_world_dataset.dta", 
}
	drop _merge
	
	
drop if country == "."	
saveold "Data\Cleaned_data/wj_world_dataset.dta", version(12) replace

}
}

use "Data\Cleaned_data/wj_world_dataset.dta", clear
bysort country: keep if _n == 1
keep country sh_mwj_ws_hr_all sh_wj_hr_all

merge 1:1 country using "Data/Cleaned_data/master_stats.dta", 
drop _merge
saveold "Data/Cleaned_data/master_stats.dta", replace version(12)


