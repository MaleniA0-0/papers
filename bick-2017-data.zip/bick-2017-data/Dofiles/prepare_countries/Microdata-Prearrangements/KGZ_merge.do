clear

* Merge files for Kyrgyzstan LSMS 1998

* Prepare HH roster subfile
use "Data\Kyrgyzstan\LSMS 1998\Data\SECT_01A", clear
rename a01cod pidb
sort fprimary pidb
keep fprimary pidb a0102 a0103 a0105a a0105b a0106

duplicates tag fprimary pidb, generate(duple)
drop if duple>=1
drop duple
save "Data\Kyrgyzstan\LSMS 1998\Data\SECT_01A_edited", replace


* Prepare employment subfile
use "Data\Kyrgyzstan\LSMS 1998\Data\sect_05"
sort fprimary pidb
duplicates tag fprimary pidb, generate(duple)
drop if duple>=1
drop duple
save "Data\Kyrgyzstan\LSMS 1998\Data\sect_05_edited", replace


* Merge HH roster with employment and weights subfiles
use "Data\Kyrgyzstan\LSMS 1998\Data\SECT_01A_edited", clear

merge 1:1 fprimary pidb using "Data\Kyrgyzstan\LSMS 1998\Data\sect_05_edited"
drop _merge

merge m:1 fprimary using "Data\Kyrgyzstan\LSMS 1998\Data\expend98", keepusing(hhsize expfact weight)
drop _merge

save "Data\Kyrgyzstan\LSMS 1998\Data\KGZ_merged", replace
