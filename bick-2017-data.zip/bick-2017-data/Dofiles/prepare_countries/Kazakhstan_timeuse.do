clear

use "Data\Kazakhstan\LSMS 1996\Data\KZ96TMB.DTA" , clear

merge 1:1 respond rn personnr using "Data\Kazakhstan\LSMS 1996\Data\KAZ_Merged.dta" , keepusing(age)


*hhq2 questionnaire page 38/45
*Questions for adults and children
***************************************************
* Standard Variables:
	*1) Age	
		*gen age=agex
		replace age=. if age==-3	
	*2) Country
		gen country = "KAZ"
	*3) Gender
		gen male=.
		replace male=1 if a_001_==1
		replace male=0 if a_001==2
	*4) Year
		gen year = 1996
	*5) Weight
		gen wgt = .
*________________________________________________________________________________________

drop if age == .

local variables h_015_m hw017_m hw019_m h_021_m h_023_m h_025_m h_027_m h_029_m h_031_m
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Data we need: Four categories
	*1) Cooking  (av6)
		gen p_cooking = h_020_
		recode p_cooking (2=0)
		egen cooking = rowtotal ( h_021_h h_021_m_hrs), missing			/* (cooking + washing dishes)*/
		replace cooking = 0  if p_cooking == 0 & cooking == .
		replace p_cooking = 1 if cooking > 0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_clean = h_022_
		recode p_clean (2=0)
		egen clean = rowtotal( h_023_h h_023_m_hrs), missing
		replace clean = 0  if p_clean == 0 & clean == .
		
		gen p_wash = h_024_
		recode p_wash (2=0)
		egen wash = rowtotal(h_025_h h_025_m_hrs), missing
		replace wash = 0 if p_wash == 0 & wash == .

		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_wash+p_clean >=1 ) & (p_wash + p_clean != .)
		replace p_cleaning = 0 if (p_wash + p_clean == 0)
		
		egen cleaning = rowtotal(clean wash), missing 	/*cleaning + cleaning clothes  */
		replace cleaning = . if (clean ==. & wash ==.)			/*Replace cleaning = missing if both partial hours are missing*/
		replace p_cleaning = 1 if cleaning >0 & cleaning != .	/*Set participation to 1 if hours larger than zero*/		
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = h_026_
		recode p_kid1 (2=0)
		egen kid1 = rowtotal(h_027_h h_027_m_hrs), missing
		replace kid1 = 0 if  p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = h_028_
		recode p_kid2 (2=0)
		egen kid2 = rowtotal(h_029_h h_029_m_hrs), missing
		replace kid2 = 0 if  p_kid2 == 0 & kid2 == .
		 
		gen p_kid3 = h_030_
		recode p_kid3 (2=0)
		egen kid3 = rowtotal(h_031_h h_031_m_hrs), missing
		replace kid3 = 0 if  p_kid3 == 0 & kid3 == .
	
		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 + p_kid3 >=1 1) & (p_kid1 + p_kid2 + p_kid3 != .)
		replace p_childcare = 0 if (p_kid1 + p_kid2 + p_kid3 == 0)
		
		egen childcare = rowtotal( kid1 kid2 kid3)
		replace childcare = . if (kid1 == . & kid2 == . & kid3 == .)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_food = h_014_
		recode p_food (2=0)
		egen food = rowtotal(h_015_h h_015_m_hrs), missing
		replace food = 0 if p_food == 0 & food == .
		
		gen p_nonfood = hw016_
		recode p_nonfood (2=0)
		egen nonfood = rowtotal(hw017_h hw017_m_hrs), missing
		replace nonfood = 0 if p_nonfood == 0 & nonfood == .
		
		gen p_services = hw018_
		recode p_services (2=0)
		egen services = rowtotal(hw019_h hw019_m_hrs), missing
		replace services = 0 if p_services == 0 & services == .

		*____________________________________________________________________________________*
		gen p_goods_services = 1 if (p_food + p_nonfood + p_services >= 1) | (p_food + p_nonfood + p_services !=.)
		replace p_goods_services = 0 if (p_food + p_nonfood + p_services == 0)
		
		egen goods_services = rowtotal( food nonfood services)
		replace goods_services = . if (food == . & nonfood == . & services == .)
		*egen goods_services = rowtotal( h_015_h hw017_h hw019_h h_015_m_hrs hw017_m_hrs hw019_m_hrs), missing	/*Shopping food and non food goods, services*/
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .	
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Water and firewood
		gen coll_wf = .
		gen p_coll_wf = .
		
	*6) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}

save "Data/Cleaned_data/KAZ_timeuse.dta", replace

