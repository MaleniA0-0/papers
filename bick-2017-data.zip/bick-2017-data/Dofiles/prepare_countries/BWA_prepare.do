******************************************************************************************
* Program: BWA_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Botswana
******************************************************************************************

use "Data\Botswana\Data\blfs_final_2005-06-annon", clear
rename emp empx

* Initialize some variables 
qui do Dofiles/initialize_variables

* Age 
gen age=p05

* Generate household and personal id											/* Do not drop duplicate records as impact on hours is minor. */
sort stratum district village dwelling hhold_nu date serial_n
local vs stratum district village dwelling hhold_nu date
foreach v in `vs'{
	gen `v's=string(`v')	
}

replace hid=stratums+"-"+districts+"-"+villages+"-"+dwellings+"-"+hhold_nus+"-"+dates
replace pid=serial_n*1000 + age*10 + p04
order hid pid
sort hid pid

*We cannot identify 140 individuals uniquely. Drop these.
bysort hid pid: gen num = _n
drop if num >= 2


gen hh_link = .
replace hh_link = 1 if p03 == 0 //Reference Person
replace hh_link = 2 if p03 == 1 //Spouse
replace hh_link = 3 if p03 == 2 | p03 == 3 | p03 == 4 | p03 == 5 //Child in law, step child, grand child
replace hh_link = 4 if  p03 == 6 | p03 == 7 | p03 == 8 //Ascendant (parent, grand parent)
replace hh_link = 98 if  p03 == 12 //Not related
replace hh_link = 99 if  p03 == 11 | p03 == 10 | p03 == 9 //Others (brother/sister, newphew/niece)

*-----------------------------------------

* Gender
replace male=1 if p04==1
replace male=0 if p04==2

*-----------------------------------------

* Weight 
replace wgt= weight_2		// looks like a household weight
gen hh_wgt = weight_2		 

* Interview date
replace refdatex=0
replace startdate=mdy(6,1,2005)
replace enddate=mdy(5,31,2006)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if p12==1
replace educ=0 if p12==2 | p12==3
gen educlvl=.
replace educlvl=0 if p13>=1 & p13!=. & educ==1
replace educlvl=1 if p16>=34 & p16!=. & p15==1

gen edu = .
replace edu = 1 if inrange(p14,0,19)
replace edu = 1 if inrange(p14,60,69)
replace edu = 2 if inrange(p14,21,29)
replace edu = 3 if inrange(p16,42,43)
replace edu = 3 if p16 == 51
replace edu = 1 if edu == . & p12 == 3

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for employment status question: Age 7 and above */
egen work=anymatch(q10a q10b q10c q10d q10e), values(1)
replace work=. if q10a==. & q10b==. & q10c==. & q10d==. & q10e==.
replace emp=1 if work==1
replace emp=2 if work==0 & q19==1
replace emp=0 if work==0 & q19==2

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*Work status
replace emp_wj = 1 if q32 == 1	
replace emp_se = 1 if inrange(q32,2,5)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Main Job																			/* Universe for hours in main job: Age 7 and above */

* Actual hours worked last week
egen mj=rowtotal(q56a_1 q56a_2 q56a_3 q56a_4 q56a_5 q56a_6 q56a_7), missing			/* Sum hours from Mon to Sun */					
replace ahrswk_mj=mj
replace ahrswk_mj=0 if mj==. & (emp==0 | emp==2)

*-----------------------------------------

* Sec Job																			/* Universe for hours in sec job: Age 12 and above */

* Actual hours worked last week
egen sj=rowtotal(q56b_1 q56b_2 q56b_3 q56b_4 q56b_5 q56b_6 q56b_7), missing
replace ahrswk_sj=sj
replace ahrswk_sj=0 if sj==. & (emp==0 | emp==2)


******************************************
* Non-market work
******************************************

/* Employment status (non-market work)												/* Universe for nm section: Age 7 to 17 only */
replace emp_nm=0 if ==0
replace emp_nm=1 if ==1

*-----------------------------------------

* Time spent on non-market work

* Actual hours worked in past 7 days
egen byte nmhrs=rowtotal(), missing
replace ahrswk_nm=nmhrs
replace ahrswk_nm=0 if emp_nm==0 & nmhrs==.
*/

******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn uc
local time ahrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if q32==1
replace mj_sa=1 if ((q32==2 | q32==3) & (q31>=100 & q32<=500)) | q32==5
replace mj_sn=1 if ((q32==2 | q32==3) & (q31>500 & q32<=9900)) | q32==4
replace mj_uc=1 if q32==6

replace sj_wj=1 if q43==1
replace sj_sa=1 if ((q43==2 | q43==3) & (q44>=100 & q44<=500)) | q43==5
replace sj_sn=1 if ((q43==2 | q43==3) & (q44>500 & q44<=9900)) | q43==4
replace sj_uc=1 if q43==6

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}


egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
replace ahrswk_wj_mj = ahrswk_mj if q32==1 													//Main job is employee
replace ahrswk_wj_aj = ahrswk_wj_mj if q41 == 2												//Person has only one (wage) job
replace ahrswk_wj_aj = hrs if q41 == 1 & q43==1												//Main and second job is employee

replace flag_set1 = 1 if q32==1 & q41 == 2													//Person has only one job (q41), which is wage
*Note: Some individuals seem to be giving mixed responses: They claim not to have a second job but give sj hours
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
replace flag_set1 = 0 if flag_set1 == 1 & diff1  < 0

replace flag_set2 = 1 if flag_set1 == 1 | (q32 == 1 & q41 == 1 & q43 == 1)					//Person has main wj and additional wage jobs
replace flag_set3 = 1 if flag_set2 == 1 | (q32 == 1 & q41 == 1 & (q43 >= 2 & q43 <= 5))		//Person has main wj and additional jobs, also se

sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1	

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=0																	/* Meal time is explicitly excluded */													
replace chrsx=2						

*-----------------------------------------

gen ind = .
replace ind = 1 if inrange(q8d,100,500)
replace ind = 2 if inrange(q8d,1010, 4510)
replace ind = 3 if inrange(q8d,4521, 9900)

*-----------------------------------------
*Income (employed)
*-----------------------------------------
replace inc_wj_aj_c_g = q72a_1 //monthly gross cash income, *We have income 99999 (is this upper limit?!)
	replace inc_wj_aj_c_g = . if inc_wj_aj_c_g== 99999
replace inc_wj_aj_ik_g = q72a_2 	

gen inc_ben = q72c	//Subsidized benefits, diff. periodicities
		//Note: q72d is 1 week, 2 month, 3 year
	replace inc_ben = inc_ben*52/12 if q72d == 1
	replace inc_ben = inc_ben/12 if q72d == 3 

egen incwj_tot = rowtotal(inc_wj_aj_c_g inc_wj_aj_ik_g inc_ben),m	//generate total wage job income
	*replace inc_wj_aj_tot_g = incwj_tot
	replace inc_wj_aj_tot_g = incwj_tot if q32 == 1					//Replace only if person has main job in wage


*bysort q32: sum q72a_1		//Majority is indeed working as employees, rest probably coming from people who hold employee as well
*bysort q43: sum q72a_1		//as a self employed job position in main/second job. But people here specifically asked to give wage.

*-----------------------------------------
*Income (self-employed)
*-----------------------------------------
gen inc_semp = q73c1		//Net income
	replace inc_semp = inc_semp * 52/12 if q73c2 == 1				//Weekly --> Monthly
	replace inc_semp = . if q73c2 == 0 | q73c2 == 3 | q73c2 == 5	//These codes for income periodicities do not exist in questionnaire
	
gen se_rev = q73a1			//Revenues
	replace se_rev = q73a1*52/12 if q73a2 == 1						//Weekly --> Monthly
	replace se_rev = . if q73a2 == 0 | q73a2 == 3 | q73a2 == 5		//These codes do not exist in questionnaire
	
gen se_exp = q73b1 			//Costs
	replace se_exp = q73b1 *52/12 if q73b2 == 1						//Weekly --> Monthly
	replace se_exp = . if q73b2 == 0 | q73b2 == 3 | q73b2 == 5		//These codes do not exist in questionnaire
	
gen se_profits = se_rev - se_exp

*Our standard variable
replace inc_se_aj_tot_g = se_profits			//DECISION (gross/net; q73c1 vs own comp. of rev-costs) TO BE MADE HERE, but I'd stick to this. q73c1 (net profits by interviewer full of mistakes)

*Total individual income
egen tot_wjse = rowtotal(incwj_tot inc_se_aj_tot_g),m
	replace ind_tot_wjse = tot_wjse

*Check results against each other
*bysort q32: sum inc_semp se_profits		//Majority now in self employed, rest is due to people having employee as well as
*bysort q43: sum inc_semp se_profits		//self employed jobs.
*gen diff = inc_semp - se_profits
*order hid pid se_rev q73a1 q73a2 se_exp q73b1 q73b2 diff se_profits inc_semp q73c1 q73c2  

*-----------------------------------------
*Household Income 
*-----------------------------------------
bysort hid: egen hh_wj = total(incwj_tot),m				//Use this measure, not inc_wj_aj_tot (there, we have only main job wage!)
bysort hid: egen hh_se = total(inc_se_aj_tot_g),m		//Note that we have a total of 38 observations where multiple individuals in HH mention 
														//to have exact same self employment income
/*
*Check hh income in self employment: 
keep if se_rev != .
order hid pid num se_rev q73a1 q73a2 se_exp q73b1 q73b2 diff se_profits inc_semp q73c1 q73c2
tab num
count if num == 2 & se_rev[_n] == se_rev[_n-1]		//Yields 38 individuals
*/

egen hh_tot = rowtotal(hh_wj hh_se),m 
	replace inc_hh = hh_tot

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
