use Data/Cleaned_data/repl_master_stats,clear

keep if coreDummy==1
	
* Variables
local vs hwp er hwe 
local g a // f m 
local a all // prime young old 

foreach v in `vs'{
	forvalues q=1/3{
		sum `v'_`g'_`a' if q_${z}==`q' // & (country=="TZA" | country=="USA")
		local `v'_`g'_`a'_`q'=r(mean)
	}
	local lra_`v'_`g'_`a'=ln(``v'_`g'_`a'_1'/``v'_`g'_`a'_3')
	local lrb_`v'_`g'_`a'=ln(``v'_`g'_`a'_1'/``v'_`g'_`a'_2')
	local lrc_`v'_`g'_`a'=ln(``v'_`g'_`a'_2'/``v'_`g'_`a'_3')
	
	local da_`v'_`g'_`a'=(``v'_`g'_`a'_1'-``v'_`g'_`a'_3')
	local db_`v'_`g'_`a'=(``v'_`g'_`a'_1'-``v'_`g'_`a'_2')
	local dc_`v'_`g'_`a'=(``v'_`g'_`a'_2'-``v'_`g'_`a'_3')					
}

* Decomposition 1: ln(x_low/x_high)/ln(hwp_low/hwp_high) for x=er, hwe
di "ER: "  round((`lra_er_`g'_`a'' /`lra_hwp_`g'_`a'')*100,.1)
di "HWE: " round((`lra_hwe_`g'_`a''/`lra_hwp_`g'_`a'')*100,.1)

* Decomposition 2: as in Table 3, bbf_note
di "ER: " round((`hwe_`g'_`a'_3'*`da_er_`g'_`a'' /`da_hwp_`g'_`a'')*100,.1)
di "HWE: " round((`er_`g'_`a'_1'*`da_hwe_`g'_`a''/`da_hwp_`g'_`a'')*100,.1)

* Decomposition 3: as in Table 3, bbf_note, but other way around
di "ER: " round((`hwe_`g'_`a'_1'*`da_er_`g'_`a'' /`da_hwp_`g'_`a'')*100,.1)
di "HWE: " round((`er_`g'_`a'_3'*`da_hwe_`g'_`a''/`da_hwp_`g'_`a'')*100,.1)

* Note in all decompositios, for individual countries things would add up to 100 but this is not the case for the averages of the country income groups.
