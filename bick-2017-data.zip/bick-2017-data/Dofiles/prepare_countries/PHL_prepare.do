************************************************************************************************
* Program: PHL_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for the Philippines
************************************************************************************************

use "Data\Philippines\LFS 2010\Data\Final data\PLFS_Final", clear 

* Initialize variables 
qui do Dofiles/initialize_variables

*-----------------------------------------

* Generate household and personal id
replace hid=hid1
replace pid=c101_lno
order hid pid
sort hid pid

*-----------------------------------------

* Age 	
gen age=c07_age
replace age=. if c07_age==99														/* Replace Not Reported (99) with missing */

* Gender
replace male=1 if c06_sex==1
replace male=0 if c06_sex==2

*-----------------------------------------

* Weight
replace wgt=fwgt

* Interview dates 
replace refdatex=1
replace refmonth=svymo
replace refyear=svyyr 

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if a02_csch==1
replace educ=0 if a02_csch==2
gen educlvl=.

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe: Age 5 and above */
replace emp=1 if c13_work==1 														/* Worked at least one hour during past week */
replace emp=2 if c13_work==2 & c14_job==1											/* Did not work in past week but has a job to return to */
replace emp=0 if c13_work==2 & c14_job==2											/* Did not work in past week and does not have a job to return to */

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*-----------------------------------------

* All jobs

* Actual hours worked during past week
replace ahrswk_aj=a04_thrs 
replace ahrswk_aj=0 if a04_thrs==. & (emp==0 | emp==2)								/* Replace missing hours with 0 if individual did not work past week */

*-----------------------------------------

* Main job

* Usual hours worked per day during past week
replace uhrsday_mj=c21_pwhr 
replace uhrsday_mj=0 if c21_pwhr==. & (emp==0 | emp==2)

* Actual hours worked during past week
replace ahrswk_mj=c22_phrs 
replace ahrswk_mj=0 if c22_phrs==. & (emp==0 | emp==2)	

*-----------------------------------------
		
* Hours worked by job nature 

* Generate indicator for each job nature
local nature wj sa sn
local time uhrsday ahrswk
foreach n in `nature'{ 
	gen mj_`n'=0
}

replace mj_wj=1 if c19pclas>=0 & c19pclas<=2
replace mj_sa=1 if (c19pclas>=3 & c19pclas<=6) & (c18_pkb>=1 & c18_pkb<=6)
replace mj_sn=1 if (c19pclas>=3 & c19pclas<=6) & (c18_pkb>=10 & c18_pkb<=99)		/* 99 is a valid industry category, it is not unknown */

* Generate hours worked by job nature 
foreach t in `time'{
	foreach n in `nature'{
	replace `t'_`n'= `t'_`n' + `t'_mj if `t'_`n'~=. & mj_`n'==1 & `t'_mj~=. 
	replace `t'_`n'= `t'_mj if `t'_`n'==. & mj_`n'==1 & `t'_mj~=. 	
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
