clear

use "Data\Rwanda\EICV (full data)\2010-11\EICV3_Stata\RWA_merged.dta", clear 
 
*Females above age 6, male children 6 to 17 only
***************************************************
* Standard Variables:
	*1) Age	
		rename  S1Q3Y age
	*2) Country
		gen country = "RWA"
	*3) Gender
		gen male=.
		replace male=1 if S1Q1==1
		replace male=0 if S1Q1==2	
	*4) Year
		gen year = 2011
	*5) Weights
		gen wgt = HH_WT
*________________________________________________________________________________________

*Data we need: Four categories, Questionnaire page 27/72


	*1) Cooking
gen p_cooking = S6GQ9
	recode p_cooking (2=0)
	
gen cooking = S6G10	
	replace cooking = 0 if p_cooking == 0 & cooking == .
	replace p_cooking = 1 if cooking >0 & cooking != . & p_cooking == .

*2) Shopping, going to market
gen p_goods_services = S6GQ7
	recode p_goods_services (2=0)
	
gen goods_services = S6GQ8
	replace goods_services = 0 if p_goods_services == 0 & goods_services == .
	replace p_goods_services = 1 if goods_services >0 & goods_services != . & p_goods_services == .

*3) cleaning
gen p_cleaning =  S6GQ11
	recode p_cleaning (2=0)
	
gen cleaning =  S6GQ12
	replace cleaning = 0 if p_cleaning == 0 & cleaning == .
	replace p_cleaning = 1 if cleaning >0 & cleaning != . & p_cleaning == .

*4)Childcare: Is included in the cleaning variable!
	gen childcare = .
	
*5) Fetching water and firewood
		gen p_wood = S6GQ1
		recode p_wood (2=0)
		gen wood =   S6GQ2
		replace wood = 0 if p_wood == 0 & wood == .
		
		gen p_water =  S6GQ5
		recode p_water (2=0)		
		gen water =  S6GQ6
		replace water = 0 if p_water == 0 & water == .
		
		*____________________________________________________________________________________*

		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)

		egen coll_wf = rowtotal(wood water)
		replace coll_wf = . if (wood ==. & water ==.)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
	
keep age country male year wgt cleaning p_cleaning coll_wf p_coll_wf goods_services p_goods_services cooking p_cooking childcare

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/RWA_timeuse.dta", replace

