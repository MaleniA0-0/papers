*To merge the quarterly LFS subfiles for South Africa

forvalues n = 1/4 {

use "Data\South Africa\QLFS 2008/qlfs-2008-0`n'.dta", clear
	gen quarter = `n'
	gen N = _N
	tostring quarter, generate(quarter_s)
	gen hhid = UQNO+""+quarter_s
save "Data\South Africa\QLFS 2008/qlfs-2008-0`n'_ind.dta", replace
}

forvalues n = 1/4 {
if `n' == 1 {
	use "Data\South Africa\QLFS 2008/qlfs-2008-0`n'_ind.dta", clear
	save "Data\South Africa\QLFS 2008/ZAF_08_merged.dta", replace

}
if `n' != 1 {
	append using "Data\South Africa\QLFS 2008/qlfs-2008-0`n'_ind.dta",
	save "Data\South Africa\QLFS 2008/ZAF_08_merged.dta", replace
}

} 

