******************************************************************************************
* Program: RWA_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Rwanda
******************************************************************************************

use "Data\Rwanda\EICV (full data)\2010-11\EICV3_Stata\RWA_merged.dta", clear 

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
destring hid, replace
replace hid=HHID
replace pid=PID
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if  S1Q2 == 1 //Reference Person
replace hh_link = 2 if  S1Q2 == 2 //Spouse/Husband
replace hh_link = 3 if  S1Q2 == 3  |  S1Q2 == 4 |  S1Q2 == 7 //child, grand child
replace hh_link = 4 if   S1Q2 == 5 | S1Q2 == 8 //Ascendant (parent, grand parent, parent in law)
replace hh_link = 98 if  S1Q2 == 11 | S1Q2 == 12 //Not related
replace hh_link = 99 if   S1Q2 == 6 | S1Q2 ==9 | S1Q2 == 10  //Others 

*-----------------------------------------

* Age 	
gen age=S1Q3Y

* Gender
replace male=1 if S1Q1==1
replace male=0 if S1Q1==2

*-----------------------------------------

* Weight 
replace wgt=HH_WT				//Household weight, is that correct?! See columbia
gen hh_wgt = HH_WT

* Interview date
replace refdatex=0
replace startdate=mdy(11,2,2010)	
replace enddate=mdy(10,24,2011)
format startdate enddate %td

*-----------------------------------------
*Schooling															/* schooling variable for being enrolled within last 12 months */
gen educ=.
replace educ=1 if S2AQ3==1
replace educ=0 if S2AQ3==2
/*
drop educ
gen educ=.
replace educ=1 if S2B1Q5==1 | S2B1Q13==1 | S2B2Q18==1 | S2B2Q21==1
replace educ=0 if S2B1Q5==2 & S2B1Q13==2 & S2B2Q18==2 & S2B2Q21==2
*/
gen educlvl=.
replace educlvl=1 if S2B2Q21==1
replace educlvl=0 if S2B1Q5==1 | S2B1Q13==1 | S2B2Q18==1

gen edu = .
replace edu =1 if S2CQ4==1 | S2CQ4==3
replace edu =2 if S2CQ4==3
replace edu =2 if inrange(S2CQ4,4,5)
replace edu =3 if inrange(S2CQ4,6,10)


******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe: Age 6 and above */
replace emp=0 if S6BQ1==2  
replace emp=1 if S6BQ1==1
replace emp=2 if S6BQ1==2 & (S6BQ2==1 | S6BQ2==2) 					/*Did not work because on holiday or temporary absence*/

* Reason for being economically inactive							/*Questionnaire largely does not match our reason coding*/

replace reason=0 if emp<=1											/* emp=0 or 1 (employed and working or unemployed)*/
replace reason=2 if S6BQ2==2										/* vacation or public holiday*/

*Work status
replace emp_wj = 1 if S6CQ7_firstjob == 1 |  S6CQ7_firstjob == 2 |  S6CQ7_firstjob == 8
replace emp_se = 1 if S6CQ7_firstjob == 4 | S6CQ7_firstjob == 5 | S6CQ7_firstjob == 6 | S6CQ7_firstjob == 7
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .										

*-----------------------------------------
* Actual hours worked in past 7 days, all jobs (first + sec + third + fourth + fifth)

egen hoursworked_1=rowtotal(S6CQ6A_firstjob S6CQ6B_firstjob S6CQ6C_firstjob S6CQ6D_firstjob S6CQ6E_firstjob S6CQ6F_firstjob S6CQ6G_firstjob) if EID_firstjob!=. ,m
egen hoursworked_2=rowtotal(S6CQ6A_secondjob S6CQ6B_secondjob S6CQ6C_secondjob S6CQ6D_secondjob S6CQ6E_secondjob S6CQ6F_secondjob S6CQ6G_secondjob) if EID_secondjob!=. ,m
egen hoursworked_3=rowtotal(S6CQ6A_thirdjob S6CQ6B_thirdjob S6CQ6C_thirdjob S6CQ6D_thirdjob S6CQ6E_thirdjob S6CQ6F_thirdjob S6CQ6G_thirdjob) if EID_thirdjob!=. ,m
egen hoursworked_4=rowtotal(S6CQ6A_fourthjob S6CQ6B_fourthjob S6CQ6C_fourthjob S6CQ6D_fourthjob S6CQ6E_fourthjob S6CQ6F_fourthjob S6CQ6G_fourthjob S6CQ7_fourthjob) if EID_fourthjob!=. ,m
egen hoursworked_5=rowtotal(S6CQ6A_fifthjob S6CQ6B_fifthjob S6CQ6C_fifthjob S6CQ6D_fifthjob S6CQ6E_fifthjob S6CQ6F_fifthjob S6CQ6G_fifthjob) if EID_fifthjob!=. ,m

egen hoursworked=rowtotal(hoursworked_1 hoursworked_2 hoursworked_3 hoursworked_4 hoursworked_5), missing

replace ahrswk_aj=hoursworked

*Following two lines added by Paul, 13.01.2015
replace ahrswk_aj = 0 if S6BQ1==2  & ahrswk_aj == .
replace ahrswk_aj = 0 if S6BQ1==2 & (S6BQ2==1 | S6BQ2==2) & ahrswk_aj == .

gen num_jobs = 0.
forvalues n = 1/5 {
	replace num_jobs = num_jobs+1 if hoursworked_`n' > 0 & hoursworked_`n' != .
}

*drop hoursworked_1 hoursworked_2 hoursworked_3 hoursworked_4 hoursworked_5

*-----------------------------------------
*Job nature
local n = 0
foreach v in first second third fourth fifth {
local n = `n' + 1

*Wage job:	All those where Question S6CQ7 equals 1 or 2, that is wage job farm or non farm respectively:
egen hoursworked_wj_`n'=rowtotal(S6CQ6A_`v'job S6CQ6B_`v'job S6CQ6C_`v'job S6CQ6D_`v'job S6CQ6E_`v'job S6CQ6F_`v'job S6CQ6G_`v'job) if (S6CQ7_`v'job==1 | S6CQ7_`v'job==2) & EID_`v'job!=. ,m


*Self employed agricultural All those where Question S6CQ7 equals 4 or 5
egen hoursworked_sa_`n' = rowtotal(S6CQ6A_`v'job S6CQ6B_`v'job S6CQ6C_`v'job S6CQ6D_`v'job S6CQ6E_`v'job S6CQ6F_`v'job S6CQ6G_`v'job) if (S6CQ7_`v'job==4 | S6CQ7_`v'job==5) & EID_`v'job!=. ,m


*Self employed non-agricultural All those where Question S6CQ7 equals 6 or 7
egen hoursworked_sn_`n' = rowtotal(S6CQ6A_`v'job S6CQ6B_`v'job S6CQ6C_`v'job S6CQ6D_`v'job S6CQ6E_`v'job S6CQ6F_`v'job S6CQ6G_`v'job) if (S6CQ7_`v'job==6 | S6CQ7_`v'job==7) & EID_`v'job!=. ,m

}
egen hoursworked_wj=rowtotal( hoursworked_wj_1 hoursworked_wj_2 hoursworked_wj_3 hoursworked_wj_4 hoursworked_wj_5), missing
replace ahrswk_wj=hoursworked_wj

egen hoursworked_sa=rowtotal( hoursworked_sa_1 hoursworked_sa_2 hoursworked_sa_3 hoursworked_sa_4 hoursworked_sa_5), missing
replace ahrswk_sa=hoursworked_sa

egen hoursworked_sn=rowtotal( hoursworked_sn_1 hoursworked_sn_2 hoursworked_sn_3 hoursworked_sn_4 hoursworked_sn_5), missing
replace ahrswk_sn=hoursworked_sn

foreach v in wj sn sa {
	replace ahrswk_`v' = 112 if ahrswk_`v' > 112 & ahrswk_`v' != 112		//Some have 600 hours in categories!!
}


*----------------------------------------------------------------------------------
*We have total wage job income (for each job separately) and hours for each wage job
replace ahrswk_wj_mj = hoursworked_wj_1											
replace ahrswk_wj_aj = ahrswk_wj_mj if num_jobs == 1										//These guys have only one (main) job
replace ahrswk_wj_aj = ahrswk_wj if num_jobs > 1 & 	(ahrswk_wj_mj> 0 & ahrswk_wj_mj!= .)	//These guys have multiple jobs. This is total wage job hours

replace flag_set1 = 1 if (S6CQ7_firstjob==1 | S6CQ7_firstjob==2) & num_jobs == 1			//These guys have only one main (wage) job

gen indic_se = 0
forvalues n = 1/5 {
	replace indic_se = indic_se+1 if (hoursworked_sa_`n' > 0 & hoursworked_sa_`n' != .) | (hoursworked_sn_`n' > 0 & hoursworked_sn_`n' != .)
}

replace flag_set2 = 1 if flag_set1 == 1 | (num_jobs > 1 & indic_se == 0 & (S6CQ7_firstjob==1 | S6CQ7_firstjob==2))				//These guys have multiple, but no se jobs
*Some 23 individuals land in set2 eventhough they shouldn't: They have VUP hours for which we however do not have income (see below).
gen diff1 = ahrswk_wj_mj - ahrswk_aj
gen diff2 = ahrswk_wj_aj - ahrswk_aj

replace flag_set2 = 0 if diff2 != 0 & flag_set2 == 1 

replace flag_set3 = 1 if flag_set2 == 1 | indic_se > 0

sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1


******************************************
* Non-Market work
******************************************

egen work_nm=rowtotal(S6GQ2 S6GQ4 S6GQ6 S6GQ8 S6G10 S6GQ12), missing
replace ahrswk_nm=work_nm

*-----------------------------------------

* Commuting and meal hours															/* Not stated */
replace mealhrsx=2
replace chrsx=1																		/*explicitely included*/
replace chrsday = S6EQ11/60*2 if emp == 1 | emp == 2								//VUP activities only
replace commuting = S6EQ11/60*2*7	if emp == 1 | emp == 2											//VUP activities only
replace chrsday = 0 if emp == 0
replace commuting = 0 if emp == 0

*-----------------------------------------

gen ind = .
replace ind = 1 if inrange( S6DQ3_firstjob, 11,14)
replace ind = 2 if inrange( S6DQ3_firstjob,21,38)
replace ind = 3 if inrange( S6DQ3_firstjob,41,93)
replace ind = 1 if ind == . & ( S6AQ2==1 | S6AQ3==1 )

*-----------------------------------------
*Income for Waged/salaried employment (section 6D
*-----------------------------------------
local jobs first second third fourth fifth
local cash_vars 
local inkind_vars
*Need to take seasonality into account for wage jobs
foreach j in `jobs' {
				
replace S6CQ5A_`j' = . if S6CQ5A_`j' > 12						//Some months_worked per year have 99 or higher than 12, not possible in one year!
replace S6CQ5D_`j' = . if S6CQ5D_`j' > 12

replace S6CQ5B_`j' = . if S6CQ5B_`j' > 31						//Some days_worked per month larger than 31, not possible.
replace S6CQ5E_`j' = . if S6CQ5E_`j' > 31

gen inc_wj_cash_`j' =  S6DQ8A_`j'job							//Main category variable
	gen inc_wj_cash_`j'per =  S6DQ8B_`j'job						//periodicity variable

gen inc_wj_inkind_`j' = S6DQ10A_`j'job 
	gen inc_wj_inkind_`j'per = S6DQ10B_`j'job 

gen inc_wj_subs_housing_`j' =  S6DQ12A_`j'job  
	gen inc_wj_subs_housing_`j'per =  S6DQ12B_`j'job  

gen inc_wj_other_`j' =  S6DQ14A_`j'job  
	gen inc_wj_other_`j'per =  S6DQ14B_`j'job  


local variables inc_wj_cash_ inc_wj_inkind_ inc_wj_subs_housing_ inc_wj_other_
	foreach var in `variables' {

		replace `var'`j' = . if `var'`j' >= 9999999		//Some observations have 9999999999, have to be missings
		replace `var'`j' = . if `var'`j'per == 9		//Code does not exist in Questionnaire
	
		*1) With seasonality: Need to add up the two seasons
			*1.1) Daily to monthly
			gen `var'`j'_h = `var'`j'*S6CQ5B_`j'*S6CQ5A_`j'/12 if `var'`j'per == 1 & S6CQ4_`j' == 1	//Days --> month, high season
			gen `var'`j'_l = `var'`j'*S6CQ5E_`j'*S6CQ5D_`j'/12 if `var'`j'per == 1 & S6CQ4_`j' == 1	//Days-->Month, low season
			
			*1.2) Weekly to monthly
			replace `var'`j'_h = `var'`j'*52/12*S6CQ5A_`j'/12 if `var'`j'per == 2 & S6CQ4_`j' == 1	//week --> month, high season
			replace `var'`j'_l = `var'`j'*52/12*S6CQ5D_`j'/12 if `var'`j'per == 2 & S6CQ4_`j' == 1	//week-->Month, low season
			
			*1.3) Monthly: Needs to be multiplied by share of months worked in that job
			replace `var'`j'_h = `var'`j'*S6CQ5A_`j'/12 if `var'`j'per == 3 & S6CQ4_`j' == 1	//Monthly to share of monthly
			replace `var'`j'_l = `var'`j'*S6CQ5D_`j'/12 if `var'`j'per == 3 & S6CQ4_`j' == 1
			
			*1.4) Yearly: Divide by 12 (assuming that individuals have incoroporated # of months worked in job already)
			replace `var'`j'_h = `var'`j'/12 if `var'`j'per == 4 & S6CQ4_`j' == 1
			replace `var'`j'_l = `var'`j'/12 if `var'`j'per == 4 & S6CQ4_`j' == 1

		egen `var'`j'_tot = rowtotal(`var'`j'_h `var'`j'_l),m		//gen total sum of both seasons
			replace `var'`j' = `var'`j'_tot if S6CQ4_`j' == 1
			
		*2) Without seasonality (variuable S6CQ4 == 2)
			*2.1) Replace variable values*Days per month*Months per year divided by 12 for daily --> monthly
			replace `var'`j' = `var'`j'*S6CQ5E_`j'*S6CQ5D_`j'/12 if `var'`j'per == 1 & S6CQ4_`j' == 2		//Day to month
			
			*2.2) Weekly to monthly: Variable * 52/12 weeks*share of months per year
			replace `var'`j' = `var'`j'*52/12*S6CQ5D_`j'/12 if `var'`j'per == 2 & S6CQ4_`j' == 2				//week to month
			
			*2.3) Monthly
			replace `var'`j' = `var'`j'*S6CQ5D_`j'/12 if `var'`j'per == 3 & S6CQ4_`j' == 2					//month
			
			*2.4) Yearly down to monthly: Divide by 12 (assuming that individuals have incoroporated # of months worked in job already)
			replace `var'`j' = `var'`j'/12 if `var'`j'per == 4 & S6CQ4_`j' == 2
	}
	*Replace income variable in case the job is not employee/wage/apprentice (these ind. should not be asked income anyways!
	foreach incvar in inc_wj_cash_`j' inc_wj_subs_housing_`j' inc_wj_other_`j' inc_wj_inkind_`j' {
		replace `incvar' = . if  inrange(S6CQ7_`j',3,7) 
	}
	
local cash_vars `cash_vars' inc_wj_cash_`j' inc_wj_subs_housing_`j' inc_wj_other_`j'
local inkind_vars `inkind_vars' inc_wj_inkind_`j' 

}	
display "`cash_vars'"

*Our standard variables
	*1. Main job
	egen wjmj_cn = rowtotal(inc_wj_cash_first inc_wj_subs_housing_first inc_wj_other_first),m
		replace inc_wj_mj_c_n = wjmj_cn
	replace inc_wj_mj_ik_n = inc_wj_inkind_first
	
	egen wjmj_tot = rowtotal(inc_wj_mj_c_n inc_wj_mj_ik_n),m
		replace inc_wj_mj_tot_n = wjmj_tot if  S6CQ7_firstjob == 1 |  S6CQ7_firstjob == 2 |  S6CQ7_firstjob == 8
		*Replace only if individual was wage farm/wage non-farm/wage or apprentice in main job
	
	*2. All wage jobs
	egen wjaj_c = rowtotal(`cash_vars'),m		//Note that cash_vars local contains only those jobs that are employee/wage! Non employee jobs are set to missing!
		replace inc_wj_aj_c_n = wjaj_c
	egen wjaj_ik = rowtotal(`inkind_vars'),m	//Same as above holds: Only employees
		replace inc_wj_aj_ik_n = wjaj_ik
	egen wjaj_tot = rowtotal(inc_wj_aj_c_n inc_wj_aj_ik_n),m
		replace inc_wj_aj_tot_n = wjaj_tot if  S6CQ7_firstjob == 1 |  S6CQ7_firstjob == 2 |  S6CQ7_firstjob == 8	//Only consider those who are also employees in main job!
		

/*
*Check whether really only employed
local jobs first second third fourth fifth
foreach j in `jobs' {
	*bysort S6CQ7_`j': sum S6DQ8A_`j'job S6DQ10A_`j'job S6DQ12A_`j'job S6DQ14A_`j'job 
	*--> There's only wage job incomes in here!
	bysort S6CQ7_`j': sum inc_wj_mj_tot_n inc_wj_aj_tot_n
}
*/
	
*2) VUP activities
*gen inc_vup = S6EQ8A	//Cannot standardize (unclear whether hour, day or week salary)

*3) Non-Farm Self Employed: According to mail: Household Enterprise activities only answered by hh-head, no one else!
local profits_se

	forvalues num = 1/11 {
	
	replace S7BQ4_`num' = . if S7BQ4_`num' > 12			//Q4: Months business has been operating
	replace S7AQ8B_`num' = . if S7AQ8B_`num' == 0		//0 is a non-existent code in questionnaire (unit of time for business income)
	replace S7AQ6B_`num' = . if S7AQ6B_`num' == 0		//Unit of time for labour expenditure (0 is nonexistent in quest.)
	replace S7AQ7B_`num' =. if S7AQ7B_`num' == 0		//Unit of time, non-labour expenditure
	
	*Revenues
	gen rev_se_na_`num' = S7AQ8A_`num' 	//revenues self-employed non-agricultural
		replace rev_se_na_`num' = . if rev_se_na_`num' >= 9999999										//MIssings/ N/A are just 999999999
		replace rev_se_na_`num' = . if S7AQ8B_`num' == 1 //rev_se_na_`num'*24*S7BQ4_`num'/12 if S7AQ8B_`num' == 1		//Daily revenues, do not have days worked per month, so set to missing
		replace rev_se_na_`num' = rev_se_na_`num'*52/12*S7BQ4_`num'/12 if S7AQ8B_`num' == 2				//Weekly revenues, multiplied by share of months worked
		replace rev_se_na_`num' = rev_se_na_`num'/12 if S7AQ8B_`num' == 4								//Yearly revenues
	*Labour expenses
	gen expl_se_na_`num' = S7AQ6A_`num'
		replace expl_se_na_`num' = . if expl_se_na_`num' >= 9999999
		replace expl_se_na_`num' = . if S7AQ6B_`num' == 1 //expl_se_na_`num'*24*S7BQ4_`num'/12 if S7AQ6B_`num' == 1	//Daily expenses, no days worked
		replace expl_se_na_`num' = expl_se_na_`num'*52/12*S7BQ4_`num'/12 if S7AQ6B_`num' == 2				//Weekly expenses
		replace expl_se_na_`num' = expl_se_na_`num'/12 if S7AQ6B_`num' == 4								//Yearly
	*Non-Labour expenses
	gen expnl_se_na_`num' = S7AQ7A_`num'
		replace expnl_se_na_`num' = . if expnl_se_na_`num' >= 9999999
		replace expnl_se_na_`num' = . if S7AQ7B_`num' == 1 //expnl_se_na_`num'*24*S7BQ4_`num'/12 if S7AQ7B_`num' == 1	//Daily expenses, no days worked
		replace expnl_se_na_`num' = expnl_se_na_`num'*52/12*S7BQ4_`num'/12 if S7AQ7B_`num' == 2				//Weekly
		replace expnl_se_na_`num' = expnl_se_na_`num'/12 if S7AQ7B_`num' == 4	

	*Profits
	gen profits_`num' = rev_se_na_`num' - expl_se_na_`num' - expnl_se_na_`num'
	
	*Check if profits belong to Household in entirety. If not: Multiply with share of profits
	replace profits_`num' = profits_`num' *( S7BQ6_`num'/100) if S7BQ5_`num' == 2
	
	local profits_se `profits_se' profits_`num'
}	

order hid pid hh_link S7AQ8A_* S7AQ6A_* S7AQ7A_*

egen incse_totg = rowtotal(`profits_se'),m 	


*4) Farm production: ON Household level for all individuals directly!

	replace S8FQ4A = S8FQ4A * 12 	//Other agric incomes, monthly
	replace S8A3Q6 = S8A3Q6 * 12	//Income from sale of ...., is avg monthly (was made to avg in merge-aggregates
	replace S8A4Q6 = S8A4Q6 * 12	//Avg monthly expenditure variable has too many missings. Use last month expenditure

	local variables S8A1Q8  S8A1Q16  S8A3Q6  S8B1Q8  S8B1Q12  S8B1Q14  S8B2Q9  S8B2Q11  S8DQ13  S8EQ11  S8FQ4A S8A1Q11  S8A2Q8  S8A4Q6  S8B1Q4  S8CQ7  S8GQ3
foreach v in `variables' {
	replace `v' = . if `v' >= 9999999		//These have to be missings! Kick out, otherwise they distort everything
}	

egen rev =  rowtotal( S8A1Q8  S8A1Q16  S8A3Q6      S8B1Q14    S8B2Q11  S8DQ13  S8EQ11  S8FQ4A ) ,m 	//S8B1Q8,S8B1Q12 (sale, rent of land), S8B2Q9 (rent of equip.)
egen cost = rowtotal( S8A1Q11  S8A2Q8  S8A4Q6    S8CQ7  S8GQ3 ), m		//Before was S8A4Q6, but that was only last 4 weeks; S8B1Q4 (cost to buy land)
gen hh_sa = (rev - cost)/12

*Still have to aggregate everything! Personal vs Household income...
bysort hid: egen hh_wj = total(wjaj_tot ),m		//Not inc_wj_aj_tot_n, because that only includes individuals who are only wage jobs!
bysort hid: egen hh_sn = total(incse_totg),m	//from household head to all hh members

egen hhinc = rowtotal(hh_wj hh_sn hh_sa),m
	replace inc_hh = hhinc
	
*--> We have QUINTILES! 


* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt QUINTILE `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 



