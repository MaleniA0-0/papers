clear all

use Data/External_data/pwt90, clear

di "${z}"



if "${z}"=="e9ry"{
	local g="rgdpe"
}
else if "${z}"=="e9cy"{
	local g =cgdpe
}
else if "${z}"=="o9ry"{
	local g =rgdpo
}
else if "${z}"=="o9cy"{
	local g =cgdpo
}

keep if year==2005
keep country* `g' pop

replace `g'=`g'/pop

sort `g'

gen p=_n/_N
gen q=1
replace q=2 if p>1/3
replace q=3 if p>2/3

forvalues q=1/3{
	sum `g' if q==`q'
	local g_pwt`q'=r(mean)
	local n_pwt`q'=r(N)
}

*********************

use Data/Cleaned_data/repl_master_stats, clear

keep if coreDummy!=.
keep q_${z} coreDummy gdppc_${z}

forvalues q=1/3{
	sum gdppc_${z} if q==`q' & coreDummy==1
	local g_core`q'=r(mean)
	local n_core`q'=r(N)	
	sum gdppc_${z} if q==`q' 
	local g_all`q'=r(mean)
	local n_all`q'=r(N)	
}


local ds pwt core all

local tpwt  Penn World Tables 9.0 (2005)
local tall Core + All non-core Countries
local tcore Core Countries
quiet{
*#################################################################
* Tex Table Generation
*#################################################################

********************************
* Settings
********************************

global name="tab_tercile_thresholds_${z}"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
global fonttype /* ="\textit" */
global digit 2

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{lcccc}") _n
$write ("\tabularnewline\hline\hline") _n
$write ("Sample \;\;\;  & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("& \;\;\; Low \;\;\; & \;\;\; Middle \;\;\;  & \;\;\; High \;\;\; \\\hline") _n

foreach d in `ds'{
	$write ("`t`d''")
	forvalues q=1/3{
		$write ("&")
		global var `g_`d'`q''
		$write ("\numprint{")
		$write (round(${var},1))
		$write ("}")
	}
	$write ("\\[-.15cm]") _n
	forvalues q=1/3{
		$write ("&\footnotesize(")
		$write (`n_`d'`q'')
		$write (")")
	}
	$write ("\\") _n	
}
$write ("\hline") _n
*#################################################################
${lastl}
${close}
*#################################################################	
} // quiet
