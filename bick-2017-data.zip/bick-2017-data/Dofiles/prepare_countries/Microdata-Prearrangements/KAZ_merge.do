* Merge demographics and employment subfiles for Kazakhstan LSMS 1996

*Set path
*cd ""

use "Data\Kazakhstan\LSMS 1996\Data\KZ96GEN", clear
keep rn respond a_001_ a_002_
rename a_001_ sex
gen age = 1996 - year(a_002_)
drop a_002_

merge 1:1 rn respond using "Data\Kazakhstan\LSMS 1996\Data\KZ96OCC"
drop _merge

merge 1:1 rn respond using "Data\Kazakhstan\LSMS 1996\Data\KZ96TMB"
drop _merge

save "Data\Kazakhstan\LSMS 1996\Data\KAZ_Merged", replace

merge 1:1 respond using "Data\Kazakhstan\LSMS 1996\Data\KZ96EDU.dta"

save "Data\Kazakhstan\LSMS 1996\Data\KAZ_Merged_educ", replace
