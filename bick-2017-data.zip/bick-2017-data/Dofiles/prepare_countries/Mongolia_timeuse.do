clear

use "Data\Mongolia\Data\LFS 2006-2007.dta"
 

***************************************************
* Standard Variables:
	*1) Age	
	gen age=I5
	
	*2) Country
	gen country = "MNG"
		
	*3) Gender
	gen male=.
	replace male=1 if I3==1
	replace male=0 if I3==2

	*4) Year
	gen year = 2006

	*5) Weight
	gen wgt = Weight
*________Questionnaire page 6/15________________________________________________________________________________
*Questions asked to all members of household. Many missings, but zeroes exist, too. Did some people choose not to answer questions?

*Data we need: Four categories


	*1) Cooking (av6)
		gen cooking = II37 			/* cooking*/
		
	*2) Cleaning/Housework (av7)
		egen cleaning = rowtotal(II38 II39), missing					/*laundry and cleaning the house*/
		
	*3) Childcare (Av11)
		gen childcare = II46
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = II41						/*going to market*/
		
	*5) Fetching water and fuel
		egen coll_wf = rowtotal(II43 II44), missing
	
	*5) Sum of four variables
		gen others=.
		gen hrs_hw = II49

keep age wgt country male year others cooking-hrs_hw

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}

save "Data/Cleaned_data/MNG_timeuse.dta", replace

