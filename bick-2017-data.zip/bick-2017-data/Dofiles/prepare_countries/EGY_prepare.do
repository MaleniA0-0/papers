******************************************************************************************
* Program: EGY_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Egypt
******************************************************************************************

use "Data\Egypt\LMPS 2006\Data\elmps06_Inddtav3_merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=hhid06
replace pid=person
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=de0104

* Gender
replace male=1 if de0101==1
replace male=0 if de0101==2

*-----------------------------------------

* Weights
replace wgt=expan

* Interview date  																	/* Date when the questionnaire is fully completed (out of the 3 visits) */
replace refdatex=1
replace refdate=mdy( cv06a2, cv06a1, cv06a3) if cv06a8==1							/* First visit */
replace refdate=mdy( cv06b2, cv06b1, cv06b3) if cv06b8==1							/* Second visit */
replace refdate=mdy( cv06c2, cv06c1, cv06c3) if cv06c8==1							/* Third visit */
format refdate %td

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate) 

*-----------------------------------------

gen educ=.
replace educ=1 if q2001==3
replace educ=0 if q2001==2 | q2001==1
gen educlvl=.
replace educlvl=1 if q2038st==8 | q2038st==9
replace educlvl=0 if q2038st<8


******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for market section: Everyone >= age 6 */
egen byte work = anymatch(q4101-q4102_13), values(1)								/* Considered employed if indiv worked in last 7 days or participated in any activity for family business */
egen byte rowtotal = rowtotal(q4101-q4102_13), missing
replace work=. if rowtotal==.

replace emp=1 if work==1															/* Implicitly emp=. if work==. */
replace emp=0 if work==0	
*replace emp=2 if work==0 & (q5114a>=1 & q5114b>=1)			

/* Last line added by Paul, question from Section 5: Applied to all those who had jobs in the past three months!)*/											
*They have a question, how much time people spent on their main job/ second job in past three months (Q5112 ff)

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* Hours worked in all jobs															/* Universe for market hours: Everyone >= age 6 and employed */
																					/* Hours for those NIU, or emp=. are kept as missing */
* Actual days worked in past 7 days 
replace adayswk_aj=q4105															/* No adjustments for DK or RF as these options were never used */
replace adayswk_aj=0 if q4105==. & emp==0											/* Set day to zero if day is missing and person is not employed */

* Usual hours worked per day in past 7 days
replace uhrsday_aj=q4106d
replace uhrsday_aj=0 if q4106d==. & emp==0											/* Set hours to zero if hours is missing and person is not employed */					

* Usual hours worked per week in past 7 days
replace uhrswk_aj=q4106wk
replace uhrswk_aj=0 if q4106wk==. & emp==0											/* Set hours to zero if hours is missing and person is not employed */										


******************************************
* Non-market work
******************************************

* Employment status (non-market work)												/* Universe for nm section: male children age 6 to 17, and females age 6 and above */
egen byte work_nm = anymatch(q4301 q4303 q4305 q4315 q4317), values(1)				/* nm work: agri work, raised poultry/livestock, produced ghee/butter/cheese for HH use, collect water, firewood in last 7 days*/
egen byte rowtotal_nm = rowtotal(q4301 q4303 q4305 q4315 q4317), missing
replace work_nm=. if rowtotal_nm==.

replace emp_nm=0 if work_nm==0
replace emp_nm=1 if work_nm==1														/* Implicitly emp_nm=. if work_nm==. */

egen a_hrs_home_prod = rowtotal( q4302 q4304 q4306), missing						/*Page 27/72: Agriculture, Poultry, produce of home products*/
*Since egypt has actual nonmarket but usual market hours, we do not add up both categories

*-----------------------------------------

* Time spent on non-market work

* Actual hours worked in past 7 days
egen byte nmhrs=rowtotal(q4302 q4304 q4306 q4316 q4318), missing
replace ahrswk_nm=nmhrs
replace ahrswk_nm=0 if emp_nm==0 & nmhrs==.

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=0																	/* Explicitly excluded from work hours*/
replace chrsx=0

replace chrsday=q5134h*2 if q5134h>0 & q5134h<.										/* Convert from hours and minutes for one way trip to hours only for round trip. Kept as missing if time=-9 */
replace chrsday=(q5134h+(q5134m/60))*2 if q5134h>0 & q5134h<. & q5134m>0 & q5134m<.
replace chrsday=(q5134m/60)*2 if q5134m>0 & q5134m<. & q5134h==.
replace chrsday=0 if chrsday==. & emp==0											/* Set hour to zero if hour is missing and self reported as not employed */

*-----------------------------------------
*Timeuse
*1) Cooking  (av6)
		gen p_cook = q4307
		recode p_cook (2=0)
		gen cook = q4308
		replace cook = 0 if p_cook == 0 & cook == .
		
		gen p_dish = q4309
		recode p_dish (2=0)
		gen dish = q4310
		replace dish = 0 if p_dish == 0 & dish == .
	
	*____________________________________________________________________________________*
	
		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
		
		egen cooking = rowtotal(cook dish)						/* cooking*/
		replace cooking = . if (cook ==. & dish ==.)
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_iron = q4311
		recode p_iron (2=0)
		gen iron = q4312
		replace iron = 0 if p_iron == 0 & iron == .
		
		gen p_clean = q4313
		recode p_clean (2=0)
		gen clean = q4314
		replace clean = 0 if p_clean == 0 & clean == .
		
		*____________________________________________________________________________________*
		
		gen p_cleaning = 1 if (p_clean + p_iron >=1) & (p_clean + p_iron != .)
		replace p_cleaning = 0 if (p_clean + p_iron == 0)
		
		egen cleaning =  rowtotal(iron clean)
		replace cleaning = . if (iron ==.  & clean ==.)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .		
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = q4325
		recode p_kid1 (2=0)
 		gen kid1 = q4326
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = q4327
		recode p_kid2 (2=0)
		gen kid2 = q4328
		replace kid2 = 0 if p_kid2 == 0 & kid2 == .

		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)
		
		egen childcare =  rowtotal(kid1 kid2)
		replace childcare = . if (kid1==. & kid2==.)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = q4319
		recode p_goods_services (2=0)
		
		gen goods_services = q4320										/*shopping for clothes and food*/
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .

	
	*5) Collecting water & Firewood
		gen p_water = q4315
		recode p_water (2=0)
		gen water = q4316
		replace water = 0 if p_water == 0 & water == .
		
		gen p_wood = q4317
		recode p_wood (2=0)
		gen wood = q4318
		replace wood = 0 if p_wood == 0 & wood == .

		*____________________________________________________________________________________*
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(water wood)
		replace coll_wf = . if (water ==. & wood ==.)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
		
* Keep standardized variables 
keep hid pid ahrsday_aj-age educ educlvl a_hrs_home_prod cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
