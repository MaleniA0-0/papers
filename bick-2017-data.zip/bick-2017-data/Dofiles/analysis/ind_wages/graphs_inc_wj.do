
use data/simplified_wj_world_data, clear

rename hr_wage_dec cd
sort country cd

foreach x in wl_n hm_n{
	by country cd: egen m`x'=mean(`x')
}
by country cd: keep if _n==1

*------------
sort cd q country
by cd: gen cidentifier=_n
sort q country cd
list countr cidentifier q if cd==1
*------------

sort country cd


gen w=ln(mwl)
gen h=ln(mhm)

save data/aux, replace
keep country cd q mwl mhm 


use data/aux, clear

sort cd y
gen xyz=_n

forvalues q=1/3{
	sum xyz if q==`q' & cd==1
	local min`q'=r(min)
	local max`q'=r(max)
}


local options1=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local options2  ytitle(Hours per Week) xlabel(-6(1)4)

sort y
tab y, gen(zid)

local c1 black
local c2 gs9
local c3 gs12

sum xyz if cd==1
local N=r(N)

local t1=8.40286
local t2=9.717068 
local lc gs8
local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local xl 7(.5)11

sort w
local vs mhm w
local z hl
 

*local vs h w
*local z hln

forvalues c=`min1'/`max1'{
	local gr`c' "(connect `vs' if zid`c'==1, msym(x) lcolor(`c1') mcol(`c1') mlabcol(`c1')) (scatter `vs' if zid`c'==1 & cd==1, mlabel(country) msym(x) mcol(`c1') mlabcol(`c1')) "
}

forvalues c=`min2'/`max2'{
	local gr`c' "(connect `vs' if zid`c'==1, msym(x) lcolor(`c2') mcol(`c2') mlabcol(`c2')) (scatter `vs' if zid`c'==1 & cd==1, mlabel(country) msym(x) mcol(`c2') mlabcol(`c2')) "
}

forvalues c=`min3'/`max3'{
	local gr`c' "(connect `vs' if zid`c'==1, msym(x) lcolor(`c3') mcol(`c3') mlabcol(`c3')) (scatter `vs' if zid`c'==1 & cd==10, mlabel(country) msym(x) mcol(`c3') mlabcol(`c3')) "
}

local l1 1
local l2 69
local l3 25

twoway `gr1' `gr2' `gr3' `gr4' `gr5' `gr6' `gr7' `gr8' `gr9' `gr10' ///
`gr24' `g25' `gr26' `gr27' `gr28' `gr29' `gr30' ///
`gr31' `gr32' `gr33' `gr34' `gr35' `gr36' `gr37' `gr38' `gr39' `gr40' `gr41' `gr42' `gr43' `gr44' `gr23' `gr24' ///
`gr11' `gr12' `gr13' `gr14' `gr15' `gr16' `gr17' `gr18' `gr19' `gr20' `gr21' `gr22' `gr23'  ///
,  `options1' `options2' ylabel(0(10)90, gmin gmax) xtitle(ln(Hourly Wage)) legend(label (`l1' Low-Income) label(`l2' Middle-Income) label(`l3' High-Income) rows(1) order(`l1' `l2' `l3'))

graph export texinput/incall_`z'.pdf, replace



