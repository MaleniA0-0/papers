*******************************************************************************************
* Program: PRY_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Paraguay
*******************************************************************************************

use "Data\Paraguay\EPH 2011\Data\r02_eph11", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs upm nvivi nhoga
foreach v in `vs'{
	gen `v's=string(`v')	
}

replace hid=upms+"-"+nvivis+"-"+nhogas

foreach v in `vs'{
	drop `v's
}

replace pid=l02
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=p02

* Gender
replace male=1 if p06==1
replace male=0 if p06==6

*-----------------------------------------

* Weight
replace wgt=fex

* Interview date																	/* Data collection period */
replace refdatex=0
replace startdate=mdy(10, 1, 2011)
replace enddate=mdy(12, 31, 2011)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if ed08<=19
replace educ=0 if ed08==20
gen educlvl=.
replace educlvl=1 if ed08==17 | ed08==19
replace educlvl=0 if ed08<=16 | ed08==18

******************************************
* Market work, Questionnaire page 14																		/* Universe: Age 10 and above */
******************************************

* Employment status (market work) in the last 14 days
replace emp=1 if a02==1 | a03==1
replace emp=0 if a02==6 & a03==6
replace emp=2 if a02==6 & a03==6 & a04==1

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1
replace reason=1 if emp==2

*-----------------------------------------

* Main job

* Actual hours worked in last 7 days
local as b03lu b03ma b03mi b03ju b03vi b03sa b03do
foreach a in `as'{
	gen `a's=`a'
	replace `a's=. if `a'>99 & `a'<.
} 

egen mjtot=rowtotal(b03lus b03mas b03mis b03jus b03vis b03sas b03dos), missing
replace ahrswk_mj=mjtot
replace ahrswk_mj=0 if (emp==0 | emp==2) & mjtot==.

* Usual hours worked per week	
replace uhrswk_mj=b06
replace uhrswk_mj = mjtot if uhrswk_mj == . & b04 == 1
replace uhrswk_mj=. if b06==999
replace uhrswk_mj=0 if (emp==0 | emp==2) & uhrswk_mj==.

*-----------------------------------------

* Sec job

* Actual hours worked in last 7 days
replace ahrswk_sj=c03
replace ahrswk_sj=. if c03==999
replace ahrswk_sj=0 if (emp==0 | emp==2) & ahrswk_sj==.

* Added by Paul: 02.02.2015
* Usual hours worked per week	
replace uhrswk_sj = c05
replace uhrswk_sj = c03 if uhrswk_sj == . & c04 == 1
replace uhrswk_sj = . if c05 == 999
replace uhrswk_sj = 0 if (emp==0 | emp==2) & uhrswk_sj==.

******************************************
* Hours worked by job characteristics
******************************************

*Generate indicators for main and sec job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if b14==1 | b14==2 | b14==6
replace mj_sa=1 if (b14>=3 & b14<=5) & b02rec==1
replace mj_sn=1 if (b14>=3 & b14<=5) & (b02rec>=2 & b02rec<=8)
replace mj_sx=1 if (b14>=3 & b14<=5) & (b02rec==99 | b02rec==.)
replace mj_uc=1 if b14==9

replace sj_wj=1 if c09==1 | c09==2 | c09==6
replace sj_sa=1 if (c09>=3 & c09<=5) & c02rec==1
replace sj_sn=1 if (c09>=3 & c09<=5) & (c02rec>=2 & c02rec<=8)
replace sj_sx=1 if (c09>=3 & c09<=5) & (c02rec==99 | c02rec==.)
replace sj_uc=1 if c09==9

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
