*Purpose: To merge Rwanda subfiles

clear all

use "EICV3_Stata\S01_hhmembers_S02_education_S03_health_S04_migration.dta"

* 1) merge with Labour data
merge 1:1 HHID PID using "EICV3_Stata\S06AB_occupation", nogen

save "EICV3_Stata\RWA_merged part1.dta", replace

*What happens now is that each job worked in during the last 12 months is listed, I will only keep 
*those where people did indeed work in during last week.
foreach num of numlist 1/5 {

use "EICV3_Stata\S06CDEF_jobs"



*select only actual jobs (leave out those where worked in last 12 months, but not last week)
egen worked=anymatch(S6CQ6A S6CQ6B S6CQ6C S6CQ6D S6CQ6E S6CQ6F S6CQ6G), values(1/24)
keep if worked==1 //21912 kicked

sort PID EID
by PID: gen jobnum=_n

keep if jobnum==`num'

if `num'==1{
renvars EID S6CQ3 S6CQ4 S6CQ5A S6CQ5B S6CQ5C S6CQ5D S6CQ5E S6CQ5F S6CQ6A S6CQ6B S6CQ6C S6CQ6D S6CQ6E S6CQ6F S6CQ6G S6CQ7 S6DQ3, postfix(_firstjob)
}
if `num'==2 {
renvars EID S6CQ3 S6CQ4 S6CQ5A S6CQ5B S6CQ5C S6CQ5D S6CQ5E S6CQ5F S6CQ6A S6CQ6B S6CQ6C S6CQ6D S6CQ6E S6CQ6F S6CQ6G S6CQ7 S6DQ3, postfix(_secondjob)
}
if `num'==3 {
renvars EID S6CQ3 S6CQ4 S6CQ5A S6CQ5B S6CQ5C S6CQ5D S6CQ5E S6CQ5F S6CQ6A S6CQ6B S6CQ6C S6CQ6D S6CQ6E S6CQ6F S6CQ6G S6CQ7 S6DQ3, postfix(_thirdjob)
}
if `num'==4 {
renvars EID S6CQ3 S6CQ4 S6CQ5A S6CQ5B S6CQ5C S6CQ5D S6CQ5E S6CQ5F S6CQ6A S6CQ6B S6CQ6C S6CQ6D S6CQ6E S6CQ6F S6CQ6G S6CQ7 S6DQ3, postfix(_fourthjob)
}
if `num'==5 {
renvars EID S6CQ3 S6CQ4 S6CQ5A S6CQ5B S6CQ5C S6CQ5D S6CQ5E S6CQ5F S6CQ6A S6CQ6B S6CQ6C S6CQ6D S6CQ6E S6CQ6F S6CQ6G S6CQ7 S6DQ3, postfix(_fifthjob)
}

drop jobnum

save "EICV3_Stata\S06DEF_job_`num'.dta", replace

clear

}

use "EICV3_Stata\RWA_merged part1.dta"
foreach num of numlist 1/5 {
merge 1:1 HHID PID using "EICV3_Stata\S06DEF_job_`num'.dta", nogen
}

merge 1:1 HHID PID using "EICV3_Stata\S06G_timeuse.dta"
save "EICV3_Stata\RWA_merged.dta", replace

qui do "EICV3_Stata\merge_aggregates_paul"
save "EICV3_Stata\RWA_merged.dta", replace


foreach num of numlist 1/11 {
use "EICV3_Stata\S07_enterprise", clear

sort PID EID
by PID: gen jobnum=_n

keep if jobnum==`num'

renvars S7AQ3 - S7BQ17, postfix(_`num')

save "EICV3_Stata\S07_enterprise_`num'.dta", replace

}

use "EICV3_Stata\RWA_merged.dta", clear
foreach num of numlist 1/11 {
	merge 1:1 HHID PID using "EICV3_Stata\S07_enterprise_`num'.dta", nogen
}

save "EICV3_Stata\RWA_merged.dta", replace

