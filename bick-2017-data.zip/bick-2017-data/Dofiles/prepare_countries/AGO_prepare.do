******************************************************************************************
* Program: AGO_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constrcts harmonized individual employment and hours worked data for Angola
******************************************************************************************
clear 

use "Data\Angola\2008 - 2009 Inquerito Integrado sobre o Bem Estar da Popula��o (IBEP)\Data\Ficheiro dos Individuos.dta", clear

* Initialize variables 
qui do Dofiles/initialize_variables

*-----------------------------------------

* Generate household and personal id
drop hid
gen hid=NIDF
bysort NIDF: gen num=_n
replace pid=num
order hid pid
sort hid pid

*-----------------------------------------

* Age 	
gen age=S01V03

* Gender
replace male=1 if S01V02==1
replace male=0 if S01V02==2

*-----------------------------------------

* Weight
replace wgt=.

* Interview dates 
replace refdatex=1
drop startdate
gen startdate="May 2008"
drop enddate
gen enddate="July 2009"

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if S03V12==1
replace educ=0 if S03V12==2
gen educlvl=.							//No info on education level attended


******************************************
* Market work
******************************************

* Employment status (market work): 								/* Universe: Age 14 and above */

replace emp=1 if S13V01==1  									/*worked or did not work but was employed; not included: Helped family without payment*/ 
replace emp=0 if S13V01>=4 & S13V01!=.							/*unemployed and looking/not looking for work, retired, studied, domestic, military service, disabled*/ 
replace emp=2 if S13V01==2										/*was employed but did not work*/
replace emp=1 if S13V07>=1 & S13V01==3 & S13V07!=.				/*if usual hours larger than zero and person said he helped family without payment, this is considered as working!*/

replace reason=. if emp==1 | emp==0 | emp==2					/*Reason not given in questionnaire*/	

*-----------------------------------------

* Main Job

* Usual hours per day
replace uhrsday_mj=S13V07
* Usual days per week
replace udayswk_mj=S13V08

*-----------------------------------------

* Second Job
* Usual hours per day
replace uhrsday_sj=S13V15
* Usual days per week
replace udayswk_sj=S13V16

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl startdate enddate
order hid pid male age wgt startdate enddate refday-refdatex emp reason emp_nm mealhrsx chrsx 





































