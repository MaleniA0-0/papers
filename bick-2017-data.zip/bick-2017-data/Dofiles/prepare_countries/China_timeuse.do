clear

use "Data\China\CHNS Cross-sectional\CHNS 2006\Data\c06adult.dta" 

*Questions asked only to adults
*Hours are determined using "how many times*(how many hours + how many minutes each time)

***************************************************
* Standard Variables:
	*1) Age	
		gen age=a3a 
	*2) Country
		gen country = "CHN"
	*3) Gender
		gen male=.
		replace male=1 if aa2a==1
		replace male=0 if aa2a==2	
	*4) Year
		gen year = 2006
	*5) Weights
		gen wgt = .
*_____________________Questionnaire �age 12/40___________________________________________________________________

*Data we need: Four categories
local variables  k3 k5 k7 k7c
foreach v in `variables' {
replace `v'=. if `v'==-99
replace `v'=. if `v'==-88
gen `v'_hrs=`v'/60
} 

	*Documentation page 12/40
	*1) Cooking  (av6)
		gen p_cooking = k4
		replace p_cooking = . if k4==9											/*There are nines in participation status, undefined in questionnaire*/
		gen cooking = k5_hrs*7													/* cooking*/
		replace cooking = 0 if p_cooking == 0 & cookin == .
		replace cooking = . if cooking == -99
		replace p_cooking = 1 if cooking > 0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
		
	*2) Cleaning/Housework (av7)
		gen p_wash = k6
		replace p_wash = . if k6 == 9											/*There are nines in participation status, undefined in questionnaire*/															
		gen wash = k7_hrs*7
		replace wash = 0 if p_wash == 0 & wash == .
		replace wash = . if wash == -99
		replace p_wash = 1 if wash > 0 & wash != .
		
		gen p_clean = k7b
		replace p_clean = . if k7b == 9											/*There are nines in participation status, undefined in questionnaire*/
		gen clean = k7c_hrs*7
		replace clean = 0 if p_clean == 0 & clean == .
		replace clean = . if clean == -99
		replace p_clean = 1 if clean > 0 & clean != .

		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_clean + p_wash >=1) & (p_clean + p_wash != .)
		replace p_cleaning = 0 if (p_clean + p_wash == 0)
		
		egen cleaning = rowtotal(wash clean)								/*laundry and cleaning the house*/
		replace cleaning = . if (clean == . & wash == .)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = k12
		replace p_kid1 = . if k12 == 9											/*There are nines in participation status, undefined in questionnaire*/
		gen kid1 = k13
		replace kid1 = . if kid1 == -99
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		replace p_kid1 = 1 if kid1 > 0 & kid1 != . 
		
		gen p_kid2 = k13b
		replace p_kid2 = . if k13b == 9											/*There are nines in participation status, undefined in questionnaire*/
		gen kid2 = k13c
		replace kid2 = . if kid2==-99
		replace kid2 = 0 if p_kid2 == 0
		replace p_kid2 = 1 if kid2 > 0 & kid2 != .
		
		*____________________________________________________________________________________*
		
		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)

		egen childcare = rowtotal(kid1 kid2)
		replace childcare = . if (kid1 == . & kid2==.)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = k2
		replace p_goods_services = . if k2 == 9									/*There are nines in participation status, undefined in questionnaire*/
		gen goods_services = k3_hrs*7	 										/*going to market*/
		
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace goods_services = . if goods_services == -99
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Fetching water and firewood
		gen coll_wf = .
		gen p_coll_wf = .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/CHN_timeuse.dta", replace


