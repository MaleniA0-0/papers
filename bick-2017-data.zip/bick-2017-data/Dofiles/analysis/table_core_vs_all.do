clear all

local z ${z}


use "Data/Cleaned_Data/repl_master_stats", clear

local Q=3
local groups Core Intermediate All

sort q_${z} gdppc_${z}

forvalues q=1/`Q' {

	*Group 1: Only the coreDummy countries
	display "core"
	sum hwp_a_all if coreDummy==1 & q_${z}==`q'
	local Core_mean_`q'=r(mean)
	local Core_sd_`q'=r(N)

	*Group 2: All countries with actual hours, irrespective of timeframe
	display "core + partial year"
	sum hwp_a_all if robustDummy==2 & q_${z}==`q'
	local Intermediate_mean_`q'=r(mean)
	local Intermediate_sd_`q'=r(N)

	*All countries (Group 3)
	display "all"
	sum hwp_a_all if (coreDummy==1 | coreDummy==0) & q_${z}==`q'
	local All_mean_`q'=r(mean)
	local All_sd_`q'=r(N)
}

	*Save number of countries for all three groups
	sum hwp_a_all if coreDummy==1
	local Core_num=r(N)
	sum hwp_a_all if robustDummy==2
	local Intermediate_num=r(N)
	sum hwp_a_all if (coreDummy==1 | coreDummy==0)
	local All_num=r(N)	
	
local lm0 5 
local lm1 25

local s0 
local s1 _p

local tq1 Low
local tq2 Middle
local tq3 High 

forvalues t=0/0{
	
********************************
* Settings
********************************

* Assing file name
global name="Robustness_Check`s`t''_${z}"				
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"

global digit 1

file open ${name} using "texinput/${name}.tex", write replace		
	
***************************************************************
* Start table
***************************************************************

local ands
forvalues q=1/`Q'{
	local ands `ands' &
} 

local ia 2 // Digits before decimal points
local ib 1 // Digits after deicmal point


$write ("\begin{tabular}{l c c c c}") _n 
$write ("\tabularnewline\hline\hline\\[-.`lm`t''cm] ") _n
$write ("& \multicolumn{3}{c}{Country Income Group} \\")
*----------------

forvalues q=1/`Q'{
	$write (" & \;\;\; `tq`q'' \;\;\; ")
}
$write ("& \# Countries ") _n
if `t'==0{
	$write ("\\[-.`lm`t''cm]\\\hline") _n
}
else{
	$write ("\\\hline") _n
}

*----------------

foreach g in `groups'{
	* Row title
	if "`g'"=="Core" | "`g'"=="All" { 
	$write ("`g' Countries")
	}
	if "`g'"=="Intermediate" {
	$write ("Core + Partial-Year")
	}
	
	* Means
	forvalues q=1/`Q'{
		$write ("&")
		
		* Assign to var the local number you want to be printed
		global var ``g'_mean_`q''
		`do1'
	}	
	
	if `t'==0{
		$write ("\\[-0.05cm]")
		forvalues q=1/`Q'{
			$write ("&")
			$write ("\footnotesize(``g'_sd_`q'')")
		}
		$write ("& \footnotesize (``g'_num')") _n
	}
	else{
		$write ("& ``g'_num'") _n
	}
	$write ("\\") _n

}

$write ("\hline") _n

*----------------
${lastl} _n
${close}

}
