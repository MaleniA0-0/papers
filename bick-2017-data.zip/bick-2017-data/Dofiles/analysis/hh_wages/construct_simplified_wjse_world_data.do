use Data/Cleaned_data/wjse_world_dataset,clear

drop pid hid

aorder
order country

gen hm_n=hrs																	//Hrs = total hours: Baseline		
gen wl_n=hr_wage_wjse															
replace hm_n=hh_hrs_pe  if flag_set_hhse==1										//Hrs = HH hrs for countries with HH lvl se income
replace wl_n=hr_wage_hh if flag_set_hhse==1										
gen w_dec= hr_wage_wjse_dec														//Baseline: We use wjse income to gen deciles									
replace w_dec= hr_wage_hh_dec if flag_set_hhse==1

*Paul (23.02.2017): 
*Need to use main job hours for IDN and MUS. Wage used is correct
 replace hm_n=hrs_a_mj  if flag_set_nosj==1									
*Paul: What about USA, TUR & PAK? These guys do not have self employment, recode using wage and hrs in wage job
 replace hm_n = hrs_wj if flag_set_nose == 1
 replace wl_n = hr_wage if flag_set_nose == 1
 replace w_dec = hr_wage_dec if flag_set_nose == 1


foreach v in hm_n wl_n{
	replace `v'=. if hr_wage_wjse_pctl==1 | hr_wage_wjse_pct==100
	replace `v'=. if (hr_wage_hh_pctl==1 | hr_wage_hh_pct==100) & flag_set_hhse==1
	
	replace `v'=. if (hr_wage_pctl==1 | hr_wage_pct==100) & flag_set_nose == 1	
	//Do we need more conditions here? Should be kicking out PAK & TUR flag_set3? USA?

}

gen age2=age^2

local x n
gen w_`x'=ln(wl_`x')
gen lhm_`x'=ln(hm_`x')

merge m:1 country using data/gdpph

tab _merge
keep if _merge==3
drop _merge

rename q_ q

gen p=ln(gdpph)
rename gdpph pl

gen y=ln(gdppc)
rename gdppc yl

drop g*

aorder 
order country

drop pop* 

tab edu, gen(edu)

save data/simplified_wjse_world_data, replace
