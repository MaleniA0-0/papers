* To merge HH roster and employment subfiles for Bosnia LSMS 2001

use "Data\Bosnia\LSMS 2001\Data\sub_abhcfind.dta", clear
sort muncode gnd numist hid apno

duplicates tag muncode gnd numist hid apno, generate(duple)
browse if duple>=1

drop if duple>=1

rename weight weight_HHRoster

merge 1:1 muncode gnd numist hid apno using "C:\Users\Xing Yi\Dropbox\Hours\Data\Bosnia\LSMS 2001\Data\sub_abhiind"
rename weight weight_labor

drop _merge duple

save "Data\Bosnia\LSMS 2001\Data\BIH_merged.dta", replace
