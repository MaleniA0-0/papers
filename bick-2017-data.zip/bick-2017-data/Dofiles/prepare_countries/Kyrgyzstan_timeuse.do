clear

use "Data\Kyrgyzstan\LSMS 1998\Data\KGZ_merged.dta"

***************************************************
* Standard Variables:
	*1) Age	
	gen age=a0105a if a0105b==. 
	replace age=a0105a + a0105b/12 if a0105b~=.
	
	*2) Country
	gen country = "KGZ"
		
	*3) Gender
	gen male=.
	replace male=1 if a0102==1
	replace male=0 if a0102==2
	
	*4) Year
	gen year = 1998
	
	*5) Weight
	gen wgt=expfact

*______________Questionnaire Page 37/87__________________________________________________________________________

*Data we need: Four categories


	*1) Cooking & Cleaning, Housework  (av6)
		gen others = h0503*7  					/* cooking*/
		gen cooking=.
		
	*2) Cleaning/Housework (av7)
		gen cleaning = . 					/*laundry and cleaning the house*/
		
	*3) Childcare (Av11)
		gen childcare =  h0501*7
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .			/*going to market*/
		
	*5) Fetching water and fuel
		gen coll_wf = h0504*7
	
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(others cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age wgt country male year others cooking-hrs_hw

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/KGZ_timeuse.dta", replace

