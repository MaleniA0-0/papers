*******************************************************************************************
* Program: KAZ_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Kazakhstan
*******************************************************************************************

use "Data\Kazakhstan\LSMS 1996\Data\KAZ_Merged_educ", clear
rename age agex

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
gen hids=string(rn,"%6.0g")
replace hid=hids
replace pid=respond
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=agex
replace age=0 if agex==-3

* Gender
replace male=1 if sex==1
replace male=0 if sex==2

*-----------------------------------------

* No survey weight

* Interview date
replace refdatex=0
replace refmonth=7
replace refyear=1996

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if bw005_==1 | bd011_==1
replace educ=0 if bw005_==2
gen educlvl=.
replace educlvl=1 if bw006_==6 | bw006_==5 & educ==1
replace educlvl=0 if bw006_<=4 | bw006_>=7 & bw006_!=. & educ==1

******************************************
* Market and non-market work, Questionnaire hhq02 page 8/45
******************************************

* Employment status: Universe: Age 16 and above
/* 	Paul: Data Dictionary Page 118/184, page 141/184. Issue: There is a total of three sections which ask for working for money last week/ currently being employed/ work for enterprise last week.
	All of these sections have many missings, so I combine them in the effort to take as many missings out as possible. I think the way I do it is still straightforward*/

replace emp = .
replace emp = 1 if k_001 == 1 | k_003_ == 1 | k_004_ == 1											/*Work for money/prof. business d. last 7 days? */
replace emp = 1 if d_001_ == 1 & emp == .															/*Is respondent currently employed*/
replace emp = 1 if hw001_ == 1 | (hw001_==1 |  h_004_==1 | hd007_h==1 | hd008_==1) & emp == . 		/*Do not include workin in dacha/garden, h_004_?!*/

replace emp = 0 if (k_001 == 2 & k_003_ == 2 & k_004 == 2) & emp == . 
replace emp = 0 if d_001_ == 2 & emp == .
replace emp = 0 if hw001_ == 2 &  h_004_==2 & hd007_h==2 & hd008_==2 & emp == .

replace emp = 2 if k_002_ == 1 & emp == 0
replace emp = 2 if d_001_ == 3 & emp == .


/*
_______________________________________________________________________________
Old version by Xing															
replace emp=0
replace emp=1 if hw001_==1 |  h_004_==1 | hd007_h==1 | hd008_==1 
replace emp=. if hw001_==. &  h_004_==. & hd007_h==. & hd008_==.
replace emp=2 if emp==0 & k_002_==1 												
/*Last line added by Paul! k_002_ asks: if you did not work, do you have a job or your own business that you were temporarily not engaged in*/

*Question d_001_: Is respondent currently employed? 1 yes 2 no 3 paid leave for child care
*d_023_ how many hours last 30 days?
________________________________________________________________________________
*/
* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* All jobs

* Actual hours worked in last 7 days
local as hw002 hw003 h_005 hd007 hd009
foreach a in `as'{ 
	gen `a'hr=`a'_m/60																/* Convert minutes to hours */
	egen `a'_tot=rowtotal(`a'hr `a'_h), missing
}

egen total=rowtotal(hw002_tot h_005_tot hd007_tot hd009_tot), missing				/* Work in an enterprise, organization, including additional work, work at home, business and farm activities, work in dacha, garden (except farms), work in family farm, other work for payment */
replace ahrswk_aj=total

*Paul: Replace hours = 0 if emp == 0 & hrs are missing, replace emp = 1 if emp is missing but hours > 0
replace ahrswk_aj = 0 if emp == 0 & ahrswk_aj == .
replace emp = 1 if ahrswk_aj > 0 & ahrswk_aj != . & emp == .


*-----------------------------------------

* Commuting and meal hours															/* Both are excluded from hours worked */
replace mealhrsx=0
replace chrsx=0

replace chrsday=hw003_tot

*-----------------------------------------
*Timeuse

local variables h_015_m hw017_m hw019_m h_021_m h_023_m h_025_m h_027_m h_029_m h_031_m
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Data we need: Four categories
	*1) Cooking  (av6)
		gen p_cooking = h_020_
		recode p_cooking (2=0)
		egen cooking = rowtotal ( h_021_h h_021_m_hrs), missing			/* (cooking + washing dishes)*/
		replace cooking = 0  if p_cooking == 0 & cooking == .
		replace p_cooking = 1 if cooking > 0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		gen p_clean = h_022_
		recode p_clean (2=0)
		egen clean = rowtotal( h_023_h h_023_m_hrs), missing
		replace clean = 0  if p_clean == 0 & clean == .
		
		gen p_wash = h_024_
		recode p_wash (2=0)
		egen wash = rowtotal(h_025_h h_025_m_hrs), missing
		replace wash = 0 if p_wash == 0 & wash == .

		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_wash+p_clean >=1 ) & (p_wash + p_clean != .)
		replace p_cleaning = 0 if (p_wash + p_clean == 0)
		
		egen cleaning = rowtotal(clean wash), missing 	/*cleaning + cleaning clothes  */
		replace cleaning = . if (clean ==. & wash ==.)			/*Replace cleaning = missing if both partial hours are missing*/
		replace p_cleaning = 1 if cleaning >0 & cleaning != .	/*Set participation to 1 if hours larger than zero*/		
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = h_026_
		recode p_kid1 (2=0)
		egen kid1 = rowtotal(h_027_h h_027_m_hrs), missing
		replace kid1 = 0 if  p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = h_028_
		recode p_kid2 (2=0)
		egen kid2 = rowtotal(h_029_h h_029_m_hrs), missing
		replace kid2 = 0 if  p_kid2 == 0 & kid2 == .
		 
		gen p_kid3 = h_030_
		recode p_kid3 (2=0)
		egen kid3 = rowtotal(h_031_h h_031_m_hrs), missing
		replace kid3 = 0 if  p_kid3 == 0 & kid3 == .
	
		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 + p_kid3 >=1 1) & (p_kid1 + p_kid2 + p_kid3 != .)
		replace p_childcare = 0 if (p_kid1 + p_kid2 + p_kid3 == 0)
		
		egen childcare = rowtotal( kid1 kid2 kid3)
		replace childcare = . if (kid1 == . & kid2 == . & kid3 == .)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_food = h_014_
		recode p_food (2=0)
		egen food = rowtotal(h_015_h h_015_m_hrs), missing
		replace food = 0 if p_food == 0 & food == .
		
		gen p_nonfood = hw016_
		recode p_nonfood (2=0)
		egen nonfood = rowtotal(hw017_h hw017_m_hrs), missing
		replace nonfood = 0 if p_nonfood == 0 & nonfood == .
		
		gen p_services = hw018_
		recode p_services (2=0)
		egen services = rowtotal(hw019_h hw019_m_hrs), missing
		replace services = 0 if p_services == 0 & services == .

		*____________________________________________________________________________________*
		gen p_goods_services = 1 if (p_food + p_nonfood + p_services >= 1) | (p_food + p_nonfood + p_services !=.)
		replace p_goods_services = 0 if (p_food + p_nonfood + p_services == 0)
		
		egen goods_services = rowtotal( food nonfood services)
		replace goods_services = . if (food == . & nonfood == . & services == .)
		*egen goods_services = rowtotal( h_015_h hw017_h hw019_h h_015_m_hrs hw017_m_hrs hw019_m_hrs), missing	/*Shopping food and non food goods, services*/
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .	
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Water and firewood
		gen coll_wf = .
		gen p_coll_wf = .
		
	*6) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .

		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf
drop hids
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
