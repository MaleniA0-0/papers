******************************************************************************************
* Program: TUN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Tunisia
******************************************************************************************

use "Data\Tunisia\LFS 2010\Data\Individus", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs Num_Men V_10
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid= Num_Mens+"-"+V_10s

local ps V_201 V_205 V_210
foreach p in `ps'{
	gen `p'x=`p'
	replace `p'x=0 if `p'x==.
}

replace pid= V_201x*1000 + V_205x*100 + V_210x
order hid pid
sort hid pid

drop Num_Mens V_10s V_201x V_205x V_210x

*-----------------------------------------

* Age 
gen age=V_210

* Gender
replace male=1 if V_205==1
replace male=0 if V_205==2

*-----------------------------------------

* Weight 
replace wgt= V_200

* Interview date
replace refdatex=0
replace startdate=mdy(4,8,2010)
replace enddate=mdy(6,30,2010)
format startdate enddate %td

*-----------------------------------------
*schooling
gen educ=.
replace educ=1 if V_230==1
replace educ=0 if V_230==2
gen educlvl=.
replace educlvl=1 if V_231==6 | V_231==7
replace educlvl=0 if V_231==4 | V_231==5 | V_231>=8 & V_231!=.


******************************************
* Market & non-market work
******************************************

* Employment status																	/* Universe: Age 15 and above */
replace emp=0 if V_281==2
replace emp=1 if V_281==1
replace emp=2 if V_281==2 & (V_284==1 | V_284==3)									/*Added by Paul to account for temporary absence*/ 

*-----------------------------------------

* All Jobs																			/* Includes helping family in agri & non-agri work */

* Actual hours worked last week
replace ahrswk_aj=V_282
replace ahrswk_aj=0 if V_282==. & emp==0

* Actual days worked last week
replace adayswk_aj=V_283
replace adayswk_aj=0 if V_283==. & emp==0


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs aj
local nature wj sa sn sx uc
local time ahrswk adayswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace aj_wj=1 if V_321==3 | V_321==4
replace aj_sa=1 if (V_321==1 | V_321==2 | V_321==5) & V_337==0						/* V_321==5 (Helping family) */
replace aj_sn=1 if (V_321==1 | V_321==2 | V_321==5) & (V_337>=10 &  V_337<=98)
replace aj_sx=1 if (V_321==1 | V_321==2 | V_321==5) & V_337==.
replace aj_uc=1 if V_321==6

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------
* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
duplicates tag hid pid, generate(duple)
drop if duple>=1
drop duple
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
