****************************************************************************************
* Program: ARM_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Armenia
****************************************************************************************

use "Data\Armenia\LFS 2008\Data\LFS 2008 Microdata", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
gen hh_nums=string(hh_num)
replace hid=hh_nums
replace pid=mem
order hid pid
sort hid pid
drop hh_nums

*-----------------------------------------

* Age 
gen age= b11

* Gender
replace male=1 if b10==1
replace male=0 if b10==2

*-----------------------------------------

* Weight 
replace wgt=ww

* Interview dates
replace refdatex=0
replace startdate=mdy(7,1,2008)
replace enddate=mdy(7,31,2008)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.


******************************************
* Market work
******************************************

* Employment status in last 7 days													/* Universe: Ages 15 to 75 */
replace emp=1 if Employed==1
replace emp=0 if Employed==0

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* Main job

* Usual hours worked per week		
replace uhrswk_mj=e55_1
replace uhrswk_mj=0 if e55_1==. & (emp==0 | emp==2)	

* Actual hours worked in surveyed week											/* Both mj and sj: Include overtime work, even if unpaid , and excluding unworked hours, even if paid */	
replace ahrswk_mj=e56_1
replace ahrswk_mj=0 if e56_1==. & (emp==0 | emp==2)

*-----------------------------------------

* Sec job

* Usual hours worked per week		
replace uhrswk_sj=e55_2
replace uhrswk_sj=0 if e55_2==. & (emp==0 | emp==2)	

* Actual hours worked in surveyed week		
replace ahrswk_sj=e56_2
replace ahrswk_sj=0 if e56_2==. & (emp==0 | emp==2)

******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx
local time ahrswk uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if d15==1 | d15==2
replace mj_sa=1 if (d15>=3 & d15<=7) & (d9_Gr==1 | d9_Gr==2)
replace mj_sn=1 if (d15>=3 & d15<=7) & (d9_Gr>=3 & d9_Gr<=17)
replace mj_sx=1 if (d15>=3 & d15<=7) & d9_Gr==.

replace sj_wj=1 if e42==1 | e42==2
replace sj_sa=1 if (e42>=3 & e42<=7) & (e37_Gr==1 | e37_Gr==2)
replace sj_sn=1 if (e42>=3 & e42<=7) & (e37_Gr>=3 & e37_Gr<=17)
replace sj_sx=1 if (e42>=3 & e42<=7) & e37_Gr==.


* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
