******************************************************************************************
* Program: EU-SILC_prepapre.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: 	Constructs harmonized individual employment and hours worked data for the EU-SILC
* 			Data used in the hrs-wage analysis
******************************************************************************************

**** Choose data from EU-SILC csv-files, label them and transform them into dta-file****
 *Set up dataset with all countries in stata format
insheet using "Data\EU-SILC\2005/UDB_c05P_ver 2005-5 from 01-08-09.csv", comma
gen c_id = lower(pb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id",  nogen
saveold "Data\EU-SILC\2005/EUSILC_raw_p.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2005/UDB_c05R_ver 2005-5 from 01-08-09.csv", comma
gen c_id = lower(rb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
saveold "Data\EU-SILC\2005/EUSILC_raw_r.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2005/UDB_c05D_ver 2005-5 from 01-08-09.csv", comma
gen c_id = lower(db020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename db030 hid
rename db090 hh_wgt
saveold "Data\EU-SILC\2005/EUSILC_All_d.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2005/UDB_c05H_ver 2005-5 from 01-08-09.csv", comma
gen c_id = lower(hb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename hb030 hid
rename hy010 hh_income_g
	label variable hh_income_g "Total HH Gross Income"
rename hy022 hh_income
	label variable hh_income "Total disposable HH Income before social transfers (incl. old age and benefits)"
saveold "Data\EU-SILC\2005/EUSILC_All_h.dta", replace version(12)

use "Data\EU-SILC\2005/combine_all", clear
rename country c_id
merge m:1 c_id using  "Data\EU-SILC\2005/c_id", nogen
save "Data\EU-SILC\2005/combine_all", replace

*******************************2006***********************************
clear
insheet using "Data\EU-SILC\2006/UDB_c06P_ver 2006-4 from 01-03-10.csv", comma
gen c_id = lower(pb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id",  nogen
saveold "Data\EU-SILC\2006/EUSILC_raw_p.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2006/UDB_c06R_ver 2006-4 from 01-03-10.csv", comma
gen c_id = lower(rb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
saveold "Data\EU-SILC\2006/EUSILC_raw_r.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2006/UDB_c06D_ver 2006-4 from 01-03-10.csv", comma
gen c_id = lower(db020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename db030 hid
rename db090 hh_wgt
saveold "Data\EU-SILC\2006/EUSILC_All_d.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2006/UDB_c06H_ver 2006-4 from 01-03-10.csv", comma
gen c_id = lower(hb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename hb030 hid
rename hy010 hh_income_g
	label variable hh_income_g "Total HH Gross Income"
rename hy022 hh_income
	label variable hh_income "Total disposable HH Income before social transfers (incl. old age and benefits)"
saveold "Data\EU-SILC\2006/EUSILC_All_h.dta", replace version(12)

use "Data\EU-SILC\2005/combine_all", clear
save "Data\EU-SILC\2006/combine_all", replace


*******************************2007***********************************
clear
insheet using "Data\EU-SILC\2007/UDB_c07P_ver 2007-6 from 01-08-11.csv", comma
gen c_id = lower(pb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id",  nogen
saveold "Data\EU-SILC\2007/EUSILC_raw_p.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2007/UDB_c07R_ver 2007-6 from 01-08-11.csv", comma
gen c_id = lower(rb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
saveold "Data\EU-SILC\2007/EUSILC_raw_r.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2007/UDB_c07D_ver 2007-6 from 01-08-11.csv", comma
gen c_id = lower(db020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename db030 hid
rename db090 hh_wgt
saveold "Data\EU-SILC\2007/EUSILC_All_d.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2007/UDB_c07H_ver 2007-6 from 01-08-11.csv", comma
gen c_id = lower(hb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename hb030 hid
rename hy010 hh_income_g
	label variable hh_income_g "Total HH Gross Income"
rename hy022 hh_income
	label variable hh_income "Total disposable HH Income before social transfers (incl. old age and benefits)"
saveold "Data\EU-SILC\2007/EUSILC_All_h.dta", replace version(12)

use "Data\EU-SILC\2005/combine_all", clear
save "Data\EU-SILC\2007/combine_all", replace

*******************************2008***********************************
clear
insheet using "Data\EU-SILC\2008/UDB_c08P_ver 2008-7 from 01-03-15.csv", comma
gen c_id = lower(pb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id",  nogen
saveold "Data\EU-SILC\2008/EUSILC_raw_p.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2008/UDB_c08R_ver 2008-7 from 01-03-15.csv", comma
gen c_id = lower(rb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
saveold "Data\EU-SILC\2008/EUSILC_raw_r.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2008/UDB_c08D_ver 2008-7 from 01-03-15.csv", comma
gen c_id = lower(db020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename db030 hid
rename db090 hh_wgt
saveold "Data\EU-SILC\2008/EUSILC_All_d.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2008/UDB_c08H_ver 2008-7 from 01-03-15.csv", comma
gen c_id = lower(hb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename hb030 hid
rename hy010 hh_income_g
	label variable hh_income_g "Total HH Gross Income"
rename hy022 hh_income
	label variable hh_income "Total disposable HH Income before social transfers (incl. old age and benefits)"
saveold "Data\EU-SILC\2008/EUSILC_All_h.dta", replace version(12)

use "Data\EU-SILC\2005/combine_all", clear
save "Data\EU-SILC\2008/combine_all", replace

*******************************2009***********************************
clear
insheet using "Data\EU-SILC\2009/UDB_c09P_ver 2009-7 from 01-03-15.csv", comma
gen c_id = lower(pb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id",  nogen
saveold "Data\EU-SILC\2009/EUSILC_raw_p.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2009/UDB_c09R_ver 2009-7 from 01-03-15.csv", comma
gen c_id = lower(rb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
saveold "Data\EU-SILC\2009/EUSILC_raw_r.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2009/UDB_c09D_ver 2009-7 from 01-03-15.csv", comma
gen c_id = lower(db020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename db030 hid
rename db090 hh_wgt
saveold "Data\EU-SILC\2009/EUSILC_All_d.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2009/UDB_c09H_ver 2009-7 from 01-03-15.csv", comma
gen c_id = lower(hb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename hb030 hid
rename hy010 hh_income_g
	label variable hh_income_g "Total HH Gross Income"
rename hy022 hh_income
	label variable hh_income "Total disposable HH Income before social transfers (incl. old age and benefits)"
saveold "Data\EU-SILC\2009/EUSILC_All_h.dta", replace version(12)

use "Data\EU-SILC\2005/combine_all", clear
save "Data\EU-SILC\2009/combine_all", replace

*******************************2010***********************************
clear
insheet using "Data\EU-SILC\2010/UDB_c10P_ver 2010-6 from 01-03-15.csv", comma
gen c_id = lower(pb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id",  nogen
saveold "Data\EU-SILC\2010/EUSILC_raw_p.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2010/UDB_c10R_ver 2010-6 from 01-03-15.csv", comma
gen c_id = lower(rb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
saveold "Data\EU-SILC\2010/EUSILC_raw_r.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2010/UDB_c10D_ver 2010-6 from 01-03-15.csv", comma
gen c_id = lower(db020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename db030 hid
rename db090 hh_wgt
saveold "Data\EU-SILC\2010/EUSILC_All_d.dta", replace version(12)
clear
insheet using "Data\EU-SILC\2010/UDB_c10H_ver 2010-6 from 01-03-15.csv", comma
gen c_id = lower(hb020)
merge m:1 c_id using "Data\EU-SILC\2005/c_id", nogen
rename hb030 hid
rename hy010 hh_income_g
	label variable hh_income_g "Total HH Gross Income"
rename hy022 hh_income
	label variable hh_income "Total disposable HH Income before social transfers (incl. old age and benefits)"
saveold "Data\EU-SILC\2010/EUSILC_All_h.dta", replace version(12)

use "Data\EU-SILC\2005/combine_all", clear
save "Data\EU-SILC\2010/combine_all", replace


***********************************************************************************
*							Prepare the raw datasets							  *
***********************************************************************************
local countries AUT BEL BGR CHE MLT ROM  CYP CZE DEU DNK ESP EST FIN FRA GBR GRC HUN IRL ITA LTU LVA NLD POL PRT ROM SVK SVN SWE CHE LUX MLT NOR

local cAT at
local cBE be
local cCZ cz
local cDE de
local cDK dk
local cES es
local cFI fi
local cFR fr
local cGR gr
local cHU hu
local cIE ie
local cIT it
local cNL nl
local cNO no
local cPL pl
local cPT pt
local cSE se
local cUK uk

local ymin=2004
local ymax=2008


foreach y in 2005 2006 2007 2008 2009 2010  {	//

	use "Data\EU-SILC/`y'/EUSILC_raw_p.dta", clear
	
	di "Year: `y'"
	
*quiet{
	rename pb150 sex
	label var sex "Sex"
	
	rename pb010 refyear
	label var refyear "Reference Year"
		
	rename px020 age
	label var age "Age"
	
	rename px030 hid
	label var hid "Household ID"
	
	rename pb030 pid
	label var pid "Personal ID"
	
	rename pb040 wgt 
	label var wgt "Personal cross-sectional weight"
	
	rename py010g ann_wj_earnings_g
	label var ann_wj_earnings_g "Total (mj + sj) employee cash or near cash income (gross, annual)"
	
	rename py010n ann_wj_earnings_n
	label var ann_wj_earnings_n "Total (mj + sj) employee cash or near cash income (net, annual)"
	
	rename py010g_f ann_earnings_g_flag
	label var ann_earnings_g_flag "Flag: Employee cash or near cash income (gross, annual)"
		label def ann_earnings_g_flag 0	"no income", replace
		label def ann_earnings_g_flag 1	"net of tax on income at source and social contributions", add
		label def ann_earnings_g_flag 2	"net of tax on income at source", add
		label def ann_earnings_g_flag 3	"net of tax on social contributions", add
		label def ann_earnings_g_flag 4	"gross", add
		label def ann_earnings_g_flag 5	"unknown", add		
		label def ann_earnings_g_flag -1 "missing (As missing values are imputed this code is only acceptable if not imputation is possible)", add
		label def ann_earnings_g_flag -5 "not filled: variable of net series is filled", add
	label values ann_earnings_g_flag ann_earnings_g_flag
	
	rename py200g monthly_wj_earnings_g
	label var monthly_wj_earnings_g "Gross monthly earnings for employees"

	rename py200g_f monthly_earnings_g_flag
	label var monthly_earnings_g_flag "Flag: Gross monthly earnings for employees"
		label def monthly_earnings_g_flag 0	"no income", replace
		label def monthly_earnings_g_flag 1	"net of tax on income at source and social contributions", add
		label def monthly_earnings_g_flag 2	"net of tax on income at source", add
		label def monthly_earnings_g_flag 3	"net of tax on social contributions", add
		label def monthly_earnings_g_flag 4	"gross", add
		label def monthly_earnings_g_flag 5	"unknown", add
			
		label def monthly_earnings_g_flag -1 "missing (As missing values are imputed this code is only acceptable if not imputation is possible)", add
		label def monthly_earnings_g_flag -2 "na (PL040 not = 3 or MS has other source to calculate gender pay gap or for analyse it)", add
	label values monthly_earnings_g_flag monthly_earnings_g_flag
	
	rename py050g ann_se_earnings_g
		label var ann_se_earnings_g "Gross cash benefits or losses from self-employment"

	rename py050n ann_se_earnings_n
		label var ann_se_earnings_n "Net (tax deducted) cash benefits or losses from self-employment"	
	
	rename py070g ann_se_earnings_ikg 
	rename py070n ann_se_earnings_ikn 
	
	rename pe040 edu
	label var edu "Highest attained level of education"
		label def edu	0 "pre-primary education", replace
		label def edu	1 "primary education", add
		label def edu	2 "lower secondary education", add 
		label def edu	3 "(upper) secondary education", add
		label def edu	4 "post-secondary non tertiary education", add
		label def edu	5 "first stage of tertiary education and second stage of tertiary education", add
	label values edu edu
	
	rename pl060 uhrswk_mj
	label var uhrswk_mj "Hours usually worked in a week in main job"
		replace uhrswk_mj = . if uhrswk_mj < 0
		
	rename pl100 uhrswk_sj
	label var uhrswk_sj "Hours usually worked in a week in second and third job"
		replace uhrswk_sj = . if uhrswk_sj < 0
	
	rename pl040 emp_type
	label var emp_type "Status in employment"
		label def emp_type 1 "self-employed with employees", replace
		label def emp_type 2 "self-employed without employees", add
		label def emp_type 3 "employee", add
		label def emp_type 4 "family worker", add
	label values emp_type emp_type
	
	rename pl035 working
	label var working "Worked at least 1 hour during the previous week"
		label def working 1 "Yes", replace
		label def working 2 "No", add
	label values working working
	
	rename pl030 emp_status
	label var emp_status "Self-defined current economic status"
		label def emp_status 1  "Working full time", replace
		label def emp_status 2 	"Working part-time", add
		label def emp_status 3 	"Unemployed", add
		label def emp_status 4 	"Pupil, student, further training, unpaid work experience", add
		label def emp_status 5 	"In retirement or in early retirement or has given up business", add
		label def emp_status 6 	"Permanently disabled or/and unfit to work", add
		label def emp_status 7 	"In compulsory military community or service", add
		label def emp_status 8 	"Fulfilling domestic tasks and care responsibilities", add
		label def emp_status 9	"Other inactive person", add
	label values emp_status emp_status
	
	rename px010 exchange_rate
		label var exchange_rate "Conversion factor: euro / national currency"
	
	rename pl110 industry
	
	keep refyear country age wgt pid hid sex ann_earnings* ann_wj_earnings* ann_se_earnings* monthly_earnings* monthly_wj_earnings* uhrswk_mj uhrswk_sj edu emp_type emp_status working exchange_rate ann_se_earnings_n ann_se_earnings_g ann_se_earnings_ikg ann_se_earnings_ikn industry
	
	save "Data\EU-SILC/`y'/EUSILC_All_p.dta", replace
	
	use "Data\EU-SILC/`y'/EUSILC_raw_r.dta", clear
	 
	rename rx030 hid
	label var hid "Household ID"
	
	rename rb030 pid
	label var pid "Personal ID"
	
	rename rb090 sex
	label var sex "Sex"
	
	rename rx010 age
	label var age "Age"

	keep if country != ""
	
	joinby country hid pid using "Data\EU-SILC/`y'/EUSILC_All_p.dta", unmatched(both)
	drop _merge
		
	keep if country != ""

	merge m:m country hid using "Data\EU-SILC/`y'/EUSILC_All_d.dta", keepusing(hh_wgt)
	drop if _merge == 1
	drop _merge	
	keep if country != ""
	
	merge m:m country hid using "Data\EU-SILC/`y'/EUSILC_All_h.dta", keepusing(hh_income hh_income_g)
	drop if _merge == 1	
	drop _merge	
	keep if country != ""
	
	keep refyear country age wgt hh_wgt pid hid sex ann_earnings* ann_wj_earnings* ann_se_earnings* monthly_earnings* monthly_wj_earnings* uhrswk_mj uhrswk_sj edu emp_type emp_status working exchange_rate hh_income hh_income_g ann_se_earnings_n ann_se_earnings_g ann_se_earnings_ikg ann_se_earnings_ikn industry
	order country hid pid wgt hh_wgt 
	saveold "Data\EU-SILC/`y'/EUSILC_All.dta", replace version(12)
	foreach c in `countries'{	
			use "Data\EU-SILC/`y'/EUSILC_All.dta", clear
			keep if country=="`c'"
			saveold "Data\EU-SILC/`y'\Countries/silc_`c'", replace version(12)
	}

*} /*quiet*/
}
