*****************************************************************************************
* Program: LAO_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Lao PDR
*****************************************************************************************

use "Data\Laos\LECS 2007-08\Data\LAO_Merged_hhlabor2", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=hhid
destring pcode, gen(pcodes)
replace pid=pcodes
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if p1q2 == 1 //Reference Person
replace hh_link = 2 if p1q2 == 2 //Spouse/Husband
replace hh_link = 3 if p1q2 == 4 | p1q2 == 5 //child, grand child
replace hh_link = 4 if  p1q2 == 3 //Ascendant (parent, grand parent)
replace hh_link = 98 if p1q2 == 9 //Not related
replace hh_link = 99 if  p1q2 == 6 | p1q2 == 7 | p1q2 == 8 //Others 

*-----------------------------------------

* Age 
gen age=p1q5
replace age=. if p1q5==999

* Gender
replace male=1 if p1q3==1
replace male=0 if p1q3==2

*-----------------------------------------

* Weight
replace wgt=hhweight
gen hh_wgt = .
 
* Interview date
replace refdatex=0
replace startdate=mdy(4,1,2007)
replace enddate=mdy(3,31,2008)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if p3q6==1 | p3q6==2
replace educ=0 if p3q6==3
gen educlvl=.
replace educlvl=1 if p3q7a==5 & educ==1
replace educlvl=0 if p3q7a<=4 & educ==1

gen edu = .
replace edu = 1 if inrange(p3q11a,0,1)
replace edu = 2 if inrange(p3q11a,2,3)
replace edu = 3 if inrange(p3q11a,4,5)
replace edu = 1 if edu == . & p3q3 == 2

******************************************
* Market and non-market work
******************************************

* Employment status																	/* Universe: Age 10 and above */
replace emp=1 if p4s1q4=="1"
replace emp=0 if p4s1q4=="2" & p4s1q5=="2"
replace emp=2 if p4s1q4=="2" & p4s1q5=="1"

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*-----------------------------------------

* All jobs
replace ahrswk_ajx = 0 if (p4s1q4=="2" & p4s1q5=="2") & ahrswk_ajx == .		/*Added by Paul: Replace hours to zero for those who are unemployed*/
replace ahrswk_ajx = 0 if (p4s1q4=="2" & p4s1q5=="1") & ahrswk_ajx == .		/*Added by Paul: Replace hours to zero for those who are employed but did not work*/
* Actual hours worked in last 7 days	
replace ahrswk_aj = ahrswk_ajx

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------

gen ind = .
destring p4s2q1,replace
replace ind = 1 if inrange( p4s2q1, 0,322)
replace ind = 2 if inrange( p4s2q1, 510,3900)
replace ind = 3 if inrange( p4s2q1, 4100,9900)

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
