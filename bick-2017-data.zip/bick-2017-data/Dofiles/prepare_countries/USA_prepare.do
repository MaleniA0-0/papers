******************************************************************************************
* Program: USA_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for the US
******************************************************************************************

use "Data\USA\CPS 2005\Data\us2005y", clear
										
rename age ageUS											

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
destring hhid, replace ignore(" ")
format hhid %20.0g
sort hhid hrhhid2 intmonth minsamp state county  cbsafips lineno
by hhid hrhhid2 intmonth minsamp state county  cbsafips: gen id1=1 if _n==1
gen hhidunique=sum(id1)

tostring hhidunique, replace

replace hid=hhidunique
replace pid=lineno
drop hhidunique id1

order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if  relref95 == 1 //Reference Person
replace hh_link = 2 if  relref95 == 3 //Spouse/Husband
replace hh_link = 3 if  relref95 == 4  |  relref95 == 5 //child, grand child
replace hh_link = 4 if   relref95 == 6 //Ascendant (parent, grand parent, parent in law)
replace hh_link = 98 if relref95 ==2 | relref95 == 9 | relref95 ==12 | relref95 ==14 | relref95 ==16 | relref95 ==18 //Not related
replace hh_link = 99 if   relref95 == 7 | relref95 ==8 | relref95 == 10 | relref95 == 13 | relref95 ==15 | relref95 ==17 //Others 

*-----------------------------------------

* Age 	
gen age=ageUS

* Gender
replace male=1 if sex==1
replace male=0 if sex==2

*-----------------------------------------

* Weight 
replace wgt=earnwt
gen hh_wgt = .

* Interview date 													/* Full interview date is not available. Refweek is one week prior to interview week*/
replace refdatex=1
replace refmonth=intmonth
replace refyear=2005

*-----------------------------------------
*schooling
gen educ=.
replace educ=1 if schenr==1
replace educ=0 if schenr==2
gen educlvl=.
replace educlvl=1 if schlvl==2
replace educlvl=0 if schlvl==1

gen edu = .
replace edu =1 if inrange(grade92, 31,34)
replace edu =2 if inrange(grade92, 35,39)
replace edu =3 if inrange(grade92, 40,46)

******************************************
* Market work
******************************************

* Employment status													/* Universe for market section: Everyone >= age 16 */

replace emp=1 if lfsr94==1											/*employed and working in reference week*/
replace emp=2 if lfsr94==2											/*employed but not working in refweek*/
replace emp=0 if lfsr94>2 & lfsr94!=.								/*not employed*/
replace emp=. if lfsr94==.											/*missing*/


replace emp_wj = 1 if inrange(class94, 1,5)	
replace emp_se = 1 if inrange(class94,6,7)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Reason for being economically inactive

replace reason=0 if emp<=1											/* emp=0 or 1 (employed and working or unemployed)*/
replace reason=2 if absent94==4										/* vacation or public holiday*/
replace reason=3 if	absent94==5										/* sickness */		
replace reason=4 if absent94==9										/* labour dispute */
replace reason=5 if absent94==8										/* maternity leave */
replace reason=6 if absent94==6										/* childcare leave */
replace reason=7 if absent94<=3|absent94==7|(absent94>=10&absent94!=.)/* other reasons */

*-----------------------------------------
* Main job

* Usual hours worked per week in main job							/*Universe: non-self-employed workers for pay */
replace uhrswk_mj=uhourse if uhourse<=99							/*We only have observations for usual hours worked for non-self employed workers*/				
replace uhrswk_mj=0 if uhourse==. & emp==0							/*Set hours to 0 if hours are missing because people are not employed*/

* All jobs
* Actual hours worked during refweek in all jobs
replace ahrswk_aj=hourslw if hourslw<=99							/* No missing values */
replace ahrswk_aj=0 if hourslw==. & emp==0
 
* Paid and unpaid overtime hours in the refweek - no extra variable

*-----------------------------------------

* Second job
* no separate information available

*-----------------------------------------

* Hours worked by job nature

* Generate indicator for each job nature
local jobs aj mj 
local nature wj sa sn sx uc
local time uhrswk ahrswk 

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if class94>=1 & class94<=5
replace mj_sa=1 if (class94>=6 & class94<=8) & agri==1 			/*class94=8 is "work not for pay" and is maybe comparable to family workers in the ELFS; agri is an agricultural industry flag*/
replace mj_sn=1 if (class94>=6 & class94<=8) & agri==0 
replace mj_sx=1 if (class94>=6 & class94<=8) & agri==.
replace mj_uc=1 if class94==.

replace aj_wj=1 if class94>=1 & class94<=5						/* classified according to job where the respondent worked the most hours */
replace aj_sa=1 if (class94>=6 & class94<=8) & agri==1 			/*class94=8 is "work not for pay" and is maybe comparable to family workers in the ELFS; agri is an agricultural industry flag*/
replace aj_sn=1 if (class94>=6 & class94<=8) & agri==0 
replace aj_sx=1 if (class94>=6 & class94<=8) & agri==.
replace aj_uc=1 if class94==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*Calculate actual/uhrs factor:
sum ahrswk_aj if class94>=1 & class94<=5
local  a_hrs_ww = r(mean) 
sum uhours if class94>=1 & class94<=5
local u_hrs_ww = r(mean)

local c_fac = `a_hrs_ww'/`u_hrs_ww'
display "`c_fac'"

*We cannot separate main from all jobs! But we can infer usual hours worked in main wage job: TO BE DECIDED! 14.02.2017
replace ahrswk_wj_mj = uhours*`c_fac' if class94>=1 & class94<=5

*Since we cannot identify whether an individual has multiple jobs, we cannot code anyone to set1. Since we do not know additional
*incomes, no one is coded to sets 2 or 3.

*And: We know the hourly wage rate! See below.

*-----------------------------------------

*Commuting and meal hours
replace mealhrsx=0													/*Both are explicitly excluded fr hours worked*/						
replace chrsx=0

*-----------------------------------------
gen ind = .
replace ind =1 if inrange(ind02,170,290)
replace ind =2 if inrange(ind02,370,3990)
replace ind =3 if inrange(ind02,4070,9890)

*-----------------------------------------
*Income Wage job: Main only
*-----------------------------------------
replace inc_wj_mj_c_g = earnwke*52/12

replace rep_hr_wage = earnhre/100

bysort hid: egen hh_wj = total(inc_wj_mj_c_g),m
	replace inc_hh = hh_wj

	/*
gen income_wj = inc_wj_mj_c_g 

gen inc_wj_hr = income_wj/ahrswk_aj
gen hr_wage = income_wj/ahrswk_wj_mj		
	*/	
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
