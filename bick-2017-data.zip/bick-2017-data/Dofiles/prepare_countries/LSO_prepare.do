******************************************************************************************
* Program: LSO_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Lesotho
******************************************************************************************

use "Data\Lesotho\ILFS 2008\Data\lfs_2008", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs  ea_num hh_no quest_no
foreach v in `vs'{
	gen `v's=string(`v')	
}

replace hid= ea_nums+"-"+hh_nos+"-"+quest_nos
replace pid=b*1000 + b3*10 + b2
order hid pid
sort hid pid

foreach v in `vs'{
	drop `v's
}

*-----------------------------------------

* Age 
gen age=b3

* Gender
replace male=1 if b2==1
replace male=0 if b2==2

*-----------------------------------------

* Weight 
replace wgt=weights

* Interview dates																	/* Data collection was conducted in the month of May 2008 only */
replace refdatex=0
replace startdate=mdy(5,1,2008)	
replace enddate=mdy(5,31,2008)	
format startdate enddate %td

*-----------------------------------------
*schooling
rename educ broad_educ
gen educ=.
replace educ=1 if b7==1
replace educ=0 if b7==2
gen educlvl=.
*no information on attending education level

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe: Age 6 and above */
egen byte work=anymatch(c1 c2 c3 c4 c5 c6), values(1)								/* Includes subsistence farming (c3) here because hours is asked for all jobs */
replace work=. if  c1==. & c2==. & c3==. & c4==. & c5==. & c6==.
replace emp=1 if work==1
replace emp=2 if work==0 & c7==1
replace emp=0 if work==0 & c7==2

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=3 if emp==2 & c8==1
replace reason=2 if emp==2 & c8==2
replace reason=5 if emp==2 & c8==4
replace reason=7 if emp==2 & (c8==3 | (c8>=5 & c8<=11))

*-----------------------------------------

* All Jobs

* Actual hours worked last week
egen aj=rowtotal(d23a d23b d23c d23d d23e d23f d23g), missing						/* Sum hours from Mon to Sun */					
replace ahrswk_aj=aj
replace ahrswk_aj=0 if aj==. & (emp==0 | emp==2)									/* Replace missing hours with 0 if person did not work last week */


******************************************
* Non-market work
******************************************

* Employment status (non-market work)												/* Universe for nm section: Every HH member regardless of age */
egen work_nm= anymatch(g1a g2a g4a g5a), values(1)									/* nm work: Fetch water (sa), firewood (sa), hunting & gathering for HH consumption (sa), produce any other goods for HH use either through weaving, sewing etc (sn) last week */
replace work_nm=. if g1a==. & g2a==. & g4a==. & g5a==.
replace emp_nm=0 if work_nm==0
replace emp_nm=1 if work_nm==1

*-----------------------------------------

* Actual hours worked in non-market work last week
local as g1b g2b g4b g5b
foreach a in `as'{ 
	gen `a'hr=`a'/60																/* Convert minutes to hours */
	replace `a'hr=0 if `a'hr==. & emp_nm==0 
}

egen ahrswk_nmsa=rowtotal(g1bhr g2bhr g4bhr), missing
gen ahrswk_nmsn=g5bhr
egen nm=rowtotal(ahrswk_nmsa ahrswk_nmsn), missing
replace ahrswk_nm=nm


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs aj nmsa nmsn
local nature wj sa sn sx
local time ahrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace aj_wj=1 if (d1==2 |d1==.) & d12==3											/* Employees */
replace aj_sa=1 if d1==1															/* Subsistence farming */
replace aj_sx=1 if (d1==2 |d1==.) & (d12==1 | d12==2 | d12==4 | d12==5)				/* Is not subsistence farming, is self-employed but economic sector is unknown */

replace nmsa_sa=1 if ahrswk_nmsa>0 & ahrswk_nmsa<.
replace nmsn_sn=1 if ahrswk_nmsn>0 & ahrswk_nmsn<.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=0																	/* Meal time is explicitly excluded */													
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
duplicates tag hid pid, generate(duple)
drop if duple>=1
drop duple
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
