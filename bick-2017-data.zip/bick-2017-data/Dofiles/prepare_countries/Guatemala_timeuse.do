clear

use "Data\Guatemala\ENCOVI 2000\Data\ECV10P09"


***************************************************
* Standard Variables:
	*1) Age
		rename edad age
	*2) Country
		gen country = "GTM"
	*3) Gender
		gen male=.
		replace male=1 if sexo==1
		replace male=0 if sexo==2
	*4) Year
		gen year = 2000
	*5) Weight
		gen wgt = factor
	
*_______________Questionaire Page 33/47_________________________________________________________________________

*Convert minutes to hours for selected timeuse  variables
local variables p09c02c p09c03c p09c01c p09c04c p09c05c p09c08c p09d01c p09c06c p09c07c
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Data we need: Four categories
	
	recode p09c02b p09c03b p09c01b p09c04b p09c05b p09c08b p09d01b p09c02c p09c03c p09c01c p09c04c p09c05c p09c08c p09d01c(99=.)

	*1) Cooking  (av6)
		*Generate hours of single variables
		gen p_cook = p09c02a
		recode p_cook (2=0)
		egen cook = rowtotal(p09c02b p09c02c_hrs), missing
		replace cook = 0 if p_cook == 0 & cook == .
		replace p_cook = 1 if cook > 0 & cook != . 

		gen p_dish = p09c03a
		recode p_dish (2=0)
		egen dish = rowtotal (p09c03b p09c03c_hrs), missing
		replace dish = 0 if p_dish == 0 & dish == .
		replace p_dish = 1 if dish > 0 & dish != .
		
		*____________________________________________________________________________________*

		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
		
		*Sum up hours of selected variables
		egen cooking_day = rowtotal (cook dish)
		replace cooking_day=. if (cook==. & dish ==.)
		gen cooking = cooking_day*7
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		*Generate hours of single variables
		gen p_clean = p09c01a
		recode p_clean (2=0)
		egen clean = rowtotal(p09c01b p09c01c_hrs), missing
		replace clean = 0 if p_clean == 0 & clean == .
		replace p_clean = 1 if clean >0 & clean != .
		
		gen p_iron = p09c04a
		recode p_iron (2=0)
		egen iron = rowtotal(p09c04b p09c04c_hrs), missing
		replace iron = 0 if p_iron == 0 & iron == .
		replace p_iron = 1 if iron >0 & iron != .
	
		gen p_garb = p09c05a
		recode p_garb (2=0)
		egen garb = rowtotal(p09c05b p09c05c_hrs), missing
		replace garb = 0 if p_garb == 0 & garb == .
		replace p_garb = 1 if garb >0 & garb != .
	
		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_clean + p_iron + p_garb >=1) & (p_clean + p_iron + p_garb!=.)
		replace p_cleaning = 0 if (p_clean + p_iron + p_garb == 0)
		
		*Sum up hours of selected variables
		egen cleaning_day = rowtotal(clean iron garb)
		replace cleaning_day = . if (clean ==. & iron ==. & garb ==.)
		gen cleaning = cleaning_day*7
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_childcare = p09c08a
		recode p_childcare (2=0)
		
		egen childcare_day = rowtotal(p09c08c_hrs p09c08b), missing
		replace childcare_day = 0 if p_childcare == 0 & childcare_day == .
		gen childcare = childcare_day*7
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = p09d01a
		recode p_goods_services (2=0)
		
		egen goods_services_day = rowtotal(p09d01b p09d01c_hrs), missing	/*Shopping*/
		replace goods_services_day = 0 if p_goods_services == 0 & goods_services_day == .
		gen goods_services = goods_services_day*7
		replace p_goods_services = 1 if  goods_services > 0 & goods_services!=.
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
	
	*5) Collecting water/Firewood
		*Generate single hours for water and firewood
		gen p_water = p09c06a
		recode p_water (2=0)	
		egen water = rowtotal(p09c06b p09c06c_hrs), missing
		replace water = 0 if p_water == 0 & water == .
		replace p_water = 1 if water > 0 & water != .
		
		gen p_wood = p09c07a
		recode p_wood (2=0)
		egen wood = rowtotal(p09c07b p09c07c_hrs), missing
		replace wood = 0 if p_wood == 0 & wood == .
		replace wood = 1 if wood > 0 & wood != .

		*____________________________________________________________________________________*
		
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf_day = rowtotal(water wood)
		replace coll_wf_day = . if (water ==. & wood ==.)
		gen coll_wf = coll_wf_day*7
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
 		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .

		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/GTM_timeuse.dta", replace

