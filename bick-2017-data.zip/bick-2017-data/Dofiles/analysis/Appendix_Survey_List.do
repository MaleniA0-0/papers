 **********************************************************************************************************
* Program: Appendix Survey List
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi, Paul Reimers
* Purpose:  Generate a table that lists the surveys used in the project
*			This program draws on a dataset compiled by us and containing the survey sources, # of obs. etc. 
*			(see Data/Cleaned_data/data_sources.dta)
***********************************************************************************************************

clear all


use "Data/Cleaned_data/data_sources.dta", clear

*** Arrangements for Table ***
local variables Country Source Year Tercile Core  
local save_in texinput

foreach s in `save_in' {

global name="Data_Appendix"
global write "file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"
local do1="do dofiles/Alex/dcol"
global digit 1
global fonttype

		if "`s'"=="Slides" | "`s'"=="Manuscript" {
		file open ${name} using "`s'/${name}.tex", write replace		//David's File for presentations
		}
		if "`s'"=="texinput" {
		file open ${name} using "`s'/${name}.tex", write replace	
		}
		
***********************************************
********** Start Table *************
***********************************************

local ands
foreach v in `variables' {
	local ands `ands' &
} 

local ia 4 // Digits before decimal points
local ib 0 // Digits after deicmal point

$write "\begin{longtable}{m{2.0cm} m{6.5cm} c c c c} \caplb " _n
$write "\\\midrule \midrule" _n

foreach v in `variables' {
if "`v'" != "Country" {
	$write (" & ") 
}
	$write (" \multicolumn{1}{l}{\bf `v' } ") _n 
}
	$write (" & \multicolumn{1}{l}{\bf Sample Size } ") _n 

$write "\\\midrule" _n
$write ("\endhead") _n

count 								// tells you how many observations you have
local N=r(N) 						// stores the number of observations

*mkmat refyear 						// in general all numeric values have to go in here

forvalues n=1/`N' {
	$write ("")
	foreach value in countryname {
	local x=`value'[`n']
	$write (" \textbf{`x'} ") 			//could let country be bold using command \textbf{}
		}
		
	foreach value in source {				//Adds the survey name
	local x=`value'[`n']
	$write (" & `x' ") 			
		}
		
	foreach value in refyear {				//Adds the year we used
	local x=`value'[`n']
	$write (" & `x' ") 			
		}
		
	foreach value in q {					//Adds the quartile (here q, as q_3 was renamed to q before)
	local x=`value'[`n']
	$write (" & `x' ") 	
		}
		
	foreach value in coreDummy {			//Adds the coreDummy
	local x=`value'[`n']
	if `x'==1 {
	$write (" & Yes ") 			
			}
	if `x'==0 {
	$write (" & No ")
			}
	}
	
	foreach value in N_adults {					//Adds the sample size 
	local x=`value'[`n']
	$write (" & \numprint{`x'} ") 	
		}
	
	*Input some lines to design the table
	$write "\\" _n
	if inlist(`n', 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75 ) {
	$write "\midrule" _n
	}
	else {
		if `n'!=`N'{
		$write "\cmidrule{2-6}" _n
		}
	}
	if `n'==`N' {
	$write "\midrule"
	}
}

$write "\end{longtable}" _n
$write ("") _n


global close="file close ${name}"
${close}

}


