clear

use "Data\Uganda\NPS LSMS 2009\Data\GSEC8_11_merged"  

***************************************************
* Standard Variables:
	*1) Age	
	gen age=h2q8
	
	*2) Country
	gen country = "UGA"
		
	*3) Gender
	gen male=.
	replace male=1 if h2q3==1
	replace male=0 if h2q3==2


	*4) Year
	gen year = 2010

	*5 Weight
	gen wgt = wgt09
*___________________Questionnaire page 9 / 27_____________________________________________________________________

*Data we need: Four categories


	*1) Cooking  (av6)
		gen cooking = h8q63 						/* cooking*/
		
	*2) Cleaning/Housework (av7)
		gen cleaning = . 							/*laundry and cleaning the house*/
		
	*3) Childcare (Av11)
		gen childcare = .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		egen goods_services = rowtotal(h8q64 h8q66),m						/*going to market*/
		
	*5) Fetching water and fuel
		egen coll_wf = rowtotal(h8q59 h8q60), missing
	
	*5) Sum of four variables
		gen others=.
		*egen hrs_hw = rowtotal(others cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age wgt country male year others cooking-hrs_hw

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/UGA_timeuse.dta", replace

