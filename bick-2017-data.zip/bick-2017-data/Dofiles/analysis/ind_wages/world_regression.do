clear all

quiet{

local gid=1

local k1 keep if flag_set5==1
local k2 keep if flag_set1==1
local k3 keep if flag_set5==1 & hr_wage_dec!=1 & hr_wage_dec!=10

forvalues o=0/3{

if `o'==0{
	use data/simplified_wjse_world_data, clear
}
else{
	use data/simplified_wj_world_data, clear	
	`k`o''
}

gen weight=1

gen xyz=y
replace xyz=10000000000 if country=="USA"
sort xyz
tab xyz, gen(zid)
by xyz:	gen n=_n

count if n==1
local nda=r(N)-1		
local ndb=`nda'+1

forvalues n=1/`ndb'{
	gen wc`n'=0
	replace wc`n'=w_n if zid`n'==1
}

local x n

local da
local dm if male==1
local df if male==0

local is a m f

foreach i in `is'{

*---------------------
reg lhm_`x' p age age2 `d`i'' [aweight=weight], vce(cluster country)
mat x =e(b)
local r 1
local by`r'`i'=_b[p] 
local sy`r'`i'=_se[p]
local ty`r'`i'=abs(`by`r'`i''/`sy`r'`i'')
local bi`r'`i'=. 
local si`r'`i'=.
local ti`r'`i'=.
local r2`r'`i'=e(r2_a)
local N`r'`i'=e(N)
*---------------------
reg lhm_`x' w_`x' age age2 `d`i'' [aweight=weight], vce(cluster country)
mat x =e(b)
local r 2
local by`r'`i'=.
local sy`r'`i'=.
local ty`r'`i'=.
local bi`r'`i'=_b[w_`x'] 
local si`r'`i'=_se[w_`x']
local ti`r'`i'=abs(`bi`r'`i''/`si`r'`i'')
local r2`r'`i'=e(r2_a)
local N`r'`i'=e(N)
*---------------------
reg lhm_`x' p w_`x' age age2 `d`i'' [aweight=weight], vce(cluster country)
mat x =e(b)
local r 3
local by`r'`i'=_b[p] 
local sy`r'`i'=_se[p]
local ty`r'`i'=abs(`by`r'`i''/`sy`r'`i'')
local bi`r'`i'=_b[w_`x'] 
local si`r'`i'=_se[w_`x']
local ti`r'`i'=abs(`bi`r'`i''/`si`r'`i'')
local bi`r'`i'=x[1,2]
local r2`r'`i'=e(r2_a)
local N`r'`i'=e(N)
*---------------------

reg lhm_`x' zid1-zid`nda' w_`x' age age2 `d`i'' [aweight=weight], vce(cluster country)
mat x =e(b)
local r 4
local by`r'`i'=.
local sy`r'`i'=.
local ty`r'`i'=.
local bi`r'`i'=_b[w_`x'] 
local si`r'`i'=_se[w_`x']
local ti`r'`i'=abs(`bi`r'`i''/`si`r'`i'')
local r2`r'`i'=e(r2_a)
local N`r'`i'=e(N)

gen fe_world=.
forvalues c=1/`nda'{
	replace fe_world=x[1,`c'] if zid`c'==1 & n==1
}


*---------------------

*******************************************

local yworld  -1(.25)0.5

if `gid'==1 & `o'==1{
foreach w in world{
replace fe_`w'=0 if country=="USA" & n==1

local t1=8.40286
local t2=9.717068 
local lc gs8
local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'
local xl 7(.5)11

twoway (scatter fe_`w' y if n==1, msize(vsmall) mlab(country) mcolor(black) mlabpos(3)) (lfit fe_`w' y if n==1) ///	
	, `options' xtitle(ln(GDP per Capita)) ytitle(Country Dummy) ylabel(`y`w'', grid gmin gmax)  ///
	legend(off) yline(0,lcolor(black) lpattern(solid) lwidth(medthick))  xlabel(`xl')

graph export texinput/reg_world_fe_`w'_`o'_`i'.pdf, replace

}
}

drop fe*

*******************************************

*#################################################################
* Tex Table Generation
*#################################################################


********************************
* Settings
********************************

global name="tab_reg_world`o'_`i'"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"

global fonttype /* ="\textit" */
global digit 3

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{l ") 
forvalues c=1/4{
	$write ("D{.}{.}{1,${digit}}")	
}
$write ("c }") _n
$write ("\tabularnewline\hline\hline") _n
forvalues c=1/4{
$write (" & \multicolumn{1}{c}{ln Hours} ") 
}
$write (" \\\hline") _n


local t1 ln (GDP per Hour)
local t2 ln (Hourly Wage)
local t3 Country Fixed Effects 
local t4="$ R^2 $"
local t5 Obs.\ 

local r1 by
local r2 bi
local r3 fe
local r4 r2
local r5 N

local fe1 No 
local fe2 No
local fe3 No
local fe4 Yes

local s1 sy
local s2 si

forvalues h=1/5{
	$write ("`t`h'' ")
	
	forvalues r=1/4{
		$write (" & ")
		if `h'==1 | `h'==2 | `h'==4 {
			global var ``r`h''`r'`i''
			`do1'
		}
		else if `h'==3{
			$write ("\multicolumn{1}{c}{``r`h''`r''}")
		}		
		else if `h'==5{
			$write ("\multicolumn{1}{c}{\numprint{``r`h''`r'`i''}}")
			/*
			local n=``r`h''`r'`i''
			local n1=floor(`n'/1000)
			local n2=`n'-`n1'*1000
		
			$write ("\multicolumn{1}{c}{`n1',`n2'}")
			*/
		}		
		
	}
	if `h'==1 | `h'==2{
		$write("\\[-.2cm] ")
		forvalues r=1/4{
			$write (" & ")			
			global var ``s`h''`r'`i''	
			`do2'			
		}	
	}
	
	$write("\\ ")
	if `h'==2 $write("\hline ")
}

$write ("\hline") _n			
		*#################################################################
${lastl}
${close}		
*#################################################################	

} // i=gender
} // robustness settings
} // quiet


