******************************************************************************************
* Program: COL_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Colombia
******************************************************************************************

use "Data\Colombia\2008\Data\Merged\R+C_GEN_TRA_OCU_Final", clear 
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=hhid
replace pid=orden
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if p6050 == 1 //Reference Person
replace hh_link = 2 if p6050 == 2 //Spouse
replace hh_link = 3 if p6050 == 3 //Child in law, step child, grand child
*replace hh_link = 4 if  p03 == 6 | p03 == 7 // No Ascendants (parent, grand parent)
replace hh_link = 98 if  p6050 == 9 | p6050 == 6 | p6050 == 7 | p6050 == 8 //Not related
replace hh_link = 99 if  p6050 == 5 | p6050 == 4 //Others, newphew/niece



*-----------------------------------------

* Age
gen age=p6040

* Gender
replace male=1 if p6020==1
replace male=0 if p6020==2

*-----------------------------------------
 
* Weight
replace wgt=fex_c_20	//no personal weight?!
gen hh_wgt = fex_c_20 

* Interview dates								
replace refdatex=0
replace refmonth=svymth	
replace refyear=2008
*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if p6170==1
replace educ=0 if p6170==2
gen educlvl=.

gen edu = .
replace edu = 1 if inrange(p6210,1,4)
replace edu = 2 if p6210==5
replace edu = 3 if p6210==6

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for market section: Age 10 and above */
replace emp=0 if p6240==5 | (p6250==2 & p6260==2 & p6270==2)						/* Permanently incapacitated for work or (not only was the main activity last week not work, he also did not do paid work for at least 1hr, did not have a work or business that receives income, and was not working unpaid */
replace emp=1 if p6240==1 | p6250==1 | p6270==1 							/* Main activity last week was work or (although main job last week was not working, he did paid work for at least 1hr or have a work or business that receives income or did unpaid work for at least 1hr) */
replace emp=2 if emp==0 & p6260==1											/*PAUL: This line is new: Adds the fact that person has a job that receives income, but he did not go to work last week!*/


* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*Work status
replace emp_wj = 1 if p6430 == 1 | p6430 == 2 | p6430 == 3 | p6430 == 8
replace emp_se = 1 if inrange(p6430,4,7)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Main job

* Months worked in the last 12 months
replace mthsyr_mj=p6790
replace mthsyr_mj=0 if p6790==. & emp==0

* Usual hours in a working week
replace uhrswk_mj=p6800  
replace uhrswk_mj=0 if p6800==. & emp==0

* Actual hours worked last week 
replace ahrswk_mj=p6850
replace ahrswk_mj=0 if p6850==. & emp==0

*-----------------------------------------

* Sec job

* Actual hours worked last week
replace ahrswk_sj=p7045		
replace ahrswk_sj=0 if p7045==. & emp==0


******************************************
* Non-market work
******************************************
									
* Employment status (non-market work)												/* Universe for non-market section: Age 10 and above */
replace emp_nm=1 if p7480s1==1 | p7480s3==1 | p7480s7==1 							/* Raised animals or did farm work (sa), made crafts at home (sn1), create clothes for HH members (sn2) last week */
replace emp_nm=0 if p7480s1==2 & p7480s3==2 & p7480s7==2							/* Implicitly emp_nm=. if all three activities are 2 */

*-----------------------------------------

* Actual hours worked last week in non-market work 
gen sa_hrs=p7480s1a
egen sn_hrs=rowtotal(p7480s3a p7480s7a), missing
egen nm=rowtotal(sa_hrs sn_hrs), missing
replace ahrswk_nm=nm
replace ahrswk_nm=0 if nm==. & emp_nm==0

*-----------------------------------------

* Hours worked by job nature 
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk uhrswk mthsyr

* Generate indicator for each job nature
foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

destring rama2d, replace
replace mj_wj=1 if p6430>=1 & p6430<=3 | p6430==8
replace mj_sa=1 if (p6430>=4 & p6430<=7) & (rama2d>=1 & rama2d<=5)
replace mj_sn=1 if (p6430>=4 & p6430<=7) & (rama2d>=10 & rama2d<=99)
replace mj_sx=1 if (p6430>=4 & p6430<=7) & rama2d==.
replace mj_uc=1 if p6430==9

replace sj_wj=1 if p7050>=1 & p7050<=3 | p7050==8 
replace sj_sx=1 if p7050>=4 & p7050<=7
replace sj_uc=1 if p7050==9

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen totalsa= rowtotal(ahrswk_sa sa_hrs), missing
replace ahrswk_sa=totalsa

egen totalsn= rowtotal(ahrswk_sn sn_hrs), missing
replace ahrswk_sn=totalsn

*Disentangling wage job hours
replace ahrswk_wj_mj = ahrswk_mj if mj_wj == 1
replace ahrswk_wj_aj = ahrswk_wj_mj if p7040 == 2 								//No additional work
replace ahrswk_wj_aj = ahrswk_wj if mj_wj == 1 & p7040 == 1						//Additional wage job hours coded if mj is wage

replace flag_set1 = 1 if mj_wj == 1 & p7040 == 2								//Only one main wage job
replace flag_set2 = 1 if flag_set1 == 1 | (mj_wj == 1 & p7040 == 1 & (p7050>=1 & p7050<=3 | p7050==8 ))	//Additional job is wage job
replace flag_set3 = 1 if flag_set2 == 1 | (mj_wj == 1 & p7040 == 1 & (p7050>=4 & p7050<=7) | p7050 == 9)

egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1
*Looks good.

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

*-----------------------------------------

*destring rama2d,replace
gen ind = .
replace ind = 1 if inrange( rama2d,01,05)
replace ind = 2 if inrange( rama2d,10,45)
replace ind = 3 if inrange( rama2d,50,99)

*-----------------------------------------
*Income employed
*-----------------------------------------
*1) Wage job (main) - Standard variables generated further down.
gen wj_c_mj = p6500		//gross monthly income from employment or business, main activity!
	replace wj_c_mj = . if wj_c_mj == 98 
	replace wj_c_mj = . if wj_c_mj == 99
	

	*Under here: Additional payments. Correct sorting? Yes
	replace p6510s1 =  . if p6510s1 == 99 | p6510s1 == 98	/* Extra hours payment*/
		replace p6510s1 = . if p6510s2 == 1			//Note: question tells whether add. is included
	replace p6630s1a = .  if p6630s1a ==98 | p6630s1a ==99		//Service bonus
		replace p6630s1a = p6630s1a/12
	replace p6630s2a = .  if p6630s2a == 98	| p6630s2a == 99	//Christmas bonus
		replace p6630s2a = p6630s2a/12
	replace p6630s3a = .  if p6630s3a ==98	| p6630s3a ==99		//Holiday bonus
		replace p6630s3a = p6630s3a/12
	replace p6630s4a = .  if p6630s4a ==98	| p6630s4a ==99		//Permanent annual payments?
		replace p6630s4a = p6630s4a/12	

	*The below code was checked again by paul and found correct, except for educational subsidy.
	*replace p6585s_c = . if p6585s1a == 1 | p6585s_c == 98 | p6585s_c == 99	//Auxilio os subsidio de alimentacion, is in inkind
	replace p6585s2a = .  if p6585s_b == 1 | p6585s2a == 98 | p6585s2a == 99	//Auxilio o subsidio de transporte
	replace p6585s3a = .  if p6585s_a == 1 | p6585s3a == 98 | p6585s3a == 99	//Subsidio familiar
	*replace p6585s4a = .  if p6585s_d == 1 | p6585s4a == 98 | p6585s4a == 99	//Subsidio educativo: Cannot be sure that p6585s_d is var belonging to educ.
	replace p6580s1= .  if p6580s2 == 1 | p6580s1==98	//Monthly bonus
	
local payments p6510s1 p6630s1a p6630s2a p6630s3a p6630s4a p6585s2a p6585s3a p6580s1 		//p6585s_c

*Inkind payments main job		
local ikvariables p6590s1 p6600s1  p6620s1		
	/* This is Aliments, Vivienda, other inkind; (Transporte: p6610s1 but already in cash category, thus excluded here) */
foreach v in `ikvariables' {
	
	replace `v' = . if `v' == 98 
	replace `v' = . if `v' == 99
	
}	

*2. Second wage job
gen inc_wj_sj = .
	replace inc_wj_sj = p7070 if p7050 == 1 | p7050 == 2 | p7050 == 3 | p7050 == 8		//Only replace if ind. is employee in 2nd job

*Our standard variables
egen mj_cg = rowtotal(wj_c_mj `payments'),m												//Cash, gross, main job
	replace inc_wj_mj_c_g = mj_cg
egen mj_ikg = rowtotal(`ikvariables'), m												//Inkind ""
	replace inc_wj_mj_ik_g = mj_ikg
egen mj_totg = rowtotal(inc_wj_mj_c_g inc_wj_mj_ik_g),m	
	replace inc_wj_mj_tot_g = mj_totg if p6430 == 1 | p6430 == 2 | p6430 == 3 | p6430 == 8	//Only replace if ind. is employee in 1st job
	
egen wj_ajtot = rowtotal(inc_wj_mj_tot_g inc_wj_sj),m		
	replace inc_wj_aj_tot_g = wj_ajtot if p6430 == 1 | p6430 == 2 | p6430 == 3 | p6430 == 8	//Note: Second job is only coded to wage if person is employed in 2nd!
	
*-----------------------------------------
*income independents 
*-----------------------------------------
*1) Main job self employed
gen inc_se_mj1 = p6750 //explicitely asks for monthly net income!
	replace inc_se_mj1 = . if inc_se_mj1 == 98 | inc_se_mj1 == 99
	
	*Apparently, some people still name income for more than one months!
	replace p6760 = . if p6760 == 98 | p6760 == 99
	replace inc_se_mj1 = inc_se_mj1/p6760											//to how many months does p6750 refer to?
	
	*Use this section only for subsection of individuals with missings in p6750
	*income independents, rural areas
	gen inc_semp_rural = p550 if p6750 == .
		replace inc_semp_rural = . if inc_semp_rural == 98 | inc_semp_rural == 99
		replace inc_semp_rural = inc_semp_rural/12									//Question is for last 12 months income

replace inc_se_mj_tot_n = inc_se_mj1												//*Standard variable: Self employed main job	
replace inc_se_mj_tot_n = inc_semp_rural if inc_se_mj1==.							//If std variable is missing
	
*2) Income from second job self employed:
gen inc_se_sj = .
	replace inc_se_sj = . if inc_se_sj == 98 | inc_se_sj == 99
	replace inc_se_sj = p7070 if p7050 == 4 | p7050 == 5 | p7050 == 6 | p7050 == 7

egen se_ajn = rowtotal(inc_se_mj_tot_n inc_se_sj),m			//*Our standard variable: self employed all jobs
	replace inc_se_aj_tot_n = se_ajn

	
	
*Total individual Income
egen tot_wjse = rowtotal(wj_ajtot inc_se_aj_tot_n),m	
	replace ind_tot_wjse = tot_wjse
	
/* *Checking: Is self empoyment incomepersonal or household? 
order hid pid inc_wj_mj_tot_g inc_wj_aj_tot_g inc_se_mj_tot_n inc_se_aj_tot_n	 
keep if inc_se_aj_tot_n != .	
bysort hid: gen num = _n
tab num
order hid pid num inc_wj_mj_tot_g inc_wj_aj_tot_g inc_se_mj_tot_n inc_se_aj_tot_n	 
*Looks very much like personal level to me
*/

*---------------------------------------------
*Generate household income
*---------------------------------------------
bysort hid: egen hh_wj = total(wj_ajtot),m			//Household wage jobs
bysort hid: egen hh_se = total(inc_se_aj_tot_n),m 			//Household self employment incomes

egen inc = rowtotal(hh_wj hh_se),m
	replace inc_hh = inc
	
*order hid pid inc_wj_mj_tot_g inc_wj_aj_tot_g inc_se_mj_tot_n inc_se_aj_tot_n hh_wj hh_se inc_hh	 
*sum hid pid inc_wj_mj_tot_g inc_wj_aj_tot_g inc_se_mj_tot_n inc_se_aj_tot_n hh_wj hh_se inc_hh	 
/*	
gen income_wj = inc_wj_aj_tot_g
replace income_wj = inc_wj_mj_tot_g if income_wj == .

gen inc_wj_hr = income_wj/hrs
gen hr_wage = income_wj/ahrswk_wj_aj	
*/	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
