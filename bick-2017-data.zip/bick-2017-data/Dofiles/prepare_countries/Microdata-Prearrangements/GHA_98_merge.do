
* Merge files for Ghana LSS 1998

*Set path
*cd ""


* Keep interview date for 3rd visit, which is the date when the employment section was asked
use "SEC0C", clear
drop if visitcd<3
save "SEC0C_edited", replace

* Use demographics master file
use "SEC1", clear
*keep clust nh pid s1q23 sex rel agey mar
sort clust nh pid

* Merge hours
merge 1:1 clust nh pid using  "SEC4G", keepusing ( s4gq1 s4gq2 s4gq3a s4gq3b s4gq3c s4gq3d s4gq3e s4gq18)
rename _merge _merge1

* Merge characteristics of main job
merge 1:1 clust nh pid using "SEC4A", 
rename _merge _merge9
merge 1:1 clust nh pid using "SEC4B", keepusing ( s4bq1 s4bq2 s4bq6a s4bq6b s4bq4 s4bq7a s4bq7b s4bq8 s4bq9  s4bq5 s4bq6a s4bq6b s4bq7a s4bq7b s4bq10 s4bq11 s4bq12a s4bq12b s4bq13 s4bq14 s4bq15a s4bq15b s4bq16 s4bq17a s4bq17b s4bq18 s4bq19a s4bq19b s4bq20 s4bq21a s4bq21b)
rename _merge _merge2

* Merge characteristics of sec job
merge 1:1 clust nh pid using "SEC4C", keepusing ( s4cq1 s4cq3 s4cq4 s4cq12  s4cq9 s4cq10a s4cq10b s4cq13 s4cq14 s4cq15a s4cq15b s4cq16 s4cq17a s4cq17b)
rename _merge _merge3

* Merge interview dates
merge m:1 clust nh using  "SEC0C_edited", keepusing( visitcd s0vday s0vmonth s0vyear)
rename _merge _merge4

* Merge weights
merge m:1 clust nh using  "POV_GH", keepusing(weight income incomec totemp  agri1c nfsey2 imprt remitinc otherinc decile quintile)
rename _merge _merge5

* Merge characteristics of third job
merge 1:1 clust nh pid using "SEC4D", keepusing (s4dq1 s4dq11  s4dq8 s4dq9a s4dq9b s4dq13 s4dq14a s4dq14b)
rename _merge _merge6

* Merge characteristics of fourth job
merge 1:1 clust nh pid using "SEC4E", keepusing (s4eq1 s4eq11  s4eq8 s4eq9a s4eq9b s4eq13 s4eq14a s4eq14b)
rename _merge _merge7

* Merge with Education section
merge 1:1 nh pid s1q23 clust using "SEC2A.DTA", keepusing(s2aq4 s2aq2 s2aq1) nogen

* Merge with unemployment section
merge 1:1 nh pid s1q23 clust using "SEC4F.dta", nogen

* Merge with screening employment section
merge 1:1 nh pid s1q23 clust using "SEC4A.dta", nogen

*Merge with personal income sections
merge 1:1 nh pid clust using "SEC4J.DTA", nogen

merge 1:1 nh pid clust using "INC2", nogen

merge 1:1 nh pid clust using "INC3", nogen

merge 1:1 nh pid clust using "INC4", nogen

merge 1:1 nh pid clust using "INC5", nogen

save "GHA_98_Merged.dta", replace













