********************************************************************************
*This program generates a set of variables that may be missing (especially for
*non-core countries variables for incomes, education etc.), in order to be able 
*to run masterData properly.
********************************************************************************




quiet {
capture noisily gen edu = .
	capture noisily gen ind = . 
	capture noisily gen hh_link = .	
	capture noisily gen QUINTILE = .
	capture noisily gen hh_wgt = .
	capture noisily gen decile = .

*---------------------------------*
***Income variables***
*---------------------------------*
local jobform wj se
	local wj wage job
	local se Self-employment job
local jobs mj aj
	local mj main 
	local aj all 
local tax g n o
	local g gross
	local n net
	local o other tax,
local payment c ik tot
	local c cash
	local ik inkind
	local tot inkind+cash/unspecified 

local income_vars inc_hh
foreach jf in `jobform' {
	foreach j in `jobs' {
		foreach p in `payment' {
			foreach t in `tax' {
			capture noisily	gen inc_`jf'_`j'_`p'_`t' = .
				label variable inc_`jf'_`j'_`p'_`t' "``t'' ``j'' ``jf'' , ``p''"
				
				local income_vars `income_vars' inc_`jf'_`j'_`p'_`t'
			}
		}
	}
}
capture noisily gen inc_hh = .
	label variable inc_hh "HH income: Total of individual employed & self-employed income"

capture noisily	gen emp_wj = .
capture noisily	gen emp_se = .

capture noisily gen rep_hr_wage = .
capture noisily gen flag_set1 = 0
capture noisily gen flag_set2 = 0
capture noisily gen flag_set3 = 0

capture noisily gen ahrswk_wj_aj = .
capture noisily gen ahrswk_wj_mj = .

capture noisily gen ind_tot_wjse = .
}
