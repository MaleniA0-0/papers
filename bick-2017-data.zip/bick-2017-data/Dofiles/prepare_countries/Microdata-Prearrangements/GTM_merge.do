*Set path
* cd ""


* Merge demographics and employment subfiles for Guatemala ENCOVI (LSMS) 2000
use "Data\Guatemala\ENCOVI 2000\Data\ECV09P05", clear

merge 1:1 hogar caso using "Data\Guatemala\ENCOVI 2000\Data\ECV10P09.DTA"
drop _merge

merge 1:1 hogar caso using "Data\Guatemala\ENCOVI 2000\Data\ECV11P10"
drop _merge

save "Data\Guatemala\ENCOVI 2000\Data\GTM_Merged", replace

*Add education. 
use "Data\Guatemala\ENCOVI 2000\Data\GTM_Merged.dta" , clear
merge 1:1 hogar thogar caso sexo edad area using "Data\Guatemala\ENCOVI 2000\Data\ECV10P09.DTA" ,nogen

save "Data\Guatemala\ENCOVI 2000\Data\GTM_Merged.dta" , replace

