
cd "C:\Users\s6961780\AppData\Local\Dropbox\Dropbox (ERC Transitions)\Hours"

* To merge files for Lao PDR ECS 2007-08
**********************************************************************************

* 1) Prepare job data in labor2 module

use "Data\Laos\LECS 2007-08\Data\iv. hhlabor2.dta", clear
sort hhid pcode
destring p4s2q1, replace
gen p4s2q1_c = .
bysort hhid pcode: replace p4s2q1_c = p4s2q1 if _n ==1

collapse (sum) ahrswk_ajx=p4s2q3 p4s2q1=p4s2q1_c, by (hhid pcode)

save "Data\Laos\LECS 2007-08\Data\labor1", replace

* 2) Merge demographics with labor subfiles
use "Data\Laos\LECS 2007-08\Data\i. hhcomposition.dta", clear

merge 1:1 hhid pcode using "Data\Laos\LECS 2007-08\Data\iv. hhlabor1.dta"

drop _merge

merge 1:1 hhid pcode using "Data\Laos\LECS 2007-08\Data\labor1"

drop _merge

save "Data\Laos\LECS 2007-08\Data\LAO_merged", replace

merge 1:1 hhid pcode using "Data\Laos\LECS 2007-08\Data\iii. hheducation.dta" 

*merge 1:m hhid pcode using "Data\Laos\LECS 2007-08\Data\iv. hhlabor2.dta", nogen

*save "C:\Users\Paul\Dropbox (ERC Transitions)\Hours\Data\Laos\LECS 2007-08\Data\LAO_merged.dta" , replace

save "Data\Laos\LECS 2007-08\Data\LAO_merged_hhlabor2.dta" , replace
