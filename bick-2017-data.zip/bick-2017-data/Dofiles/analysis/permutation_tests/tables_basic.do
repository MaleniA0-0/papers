clear all

use Data/ptest_basic, clear 

gen cs=ql*10+qh

local cs 13 12 23

*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Margins table
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
local vs hwp er hwe
local g a
local a all // young prime old

foreach c in `cs'{	
foreach v in `vs'{
	di `c' "   `v' "
	sum d if cs==`c' & v=="`v'" & g=="`g'" & a=="`a'"
	local d`c'`v'=r(mean)
	qui sum p if cs==`c' & v=="`v'" & g=="`g'" & a=="`a'"
	local p`c'`v'=r(mean) 
}
}

local rhwp Hours per Adult
local rer Employment Rate
local rhwe Hours per Employed

*#################################################################
* Tex Table Generation
*#################################################################

********************************
* Settings
********************************

global name="tab_permut_vs_${z}"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
local do2="do Dofiles/analysis/dcol_sd"	
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{l D{.}{.}{2,2} D{.}{.}{2,2} D{.}{.}{2,2}}") _n
$write ("\tabularnewline\hline\hline") _n
$write ("  & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("&  \multicolumn{1}{c}{ Low-High } & \multicolumn{1}{c}{ Low-Middle } & \multicolumn{1}{c}{  Middle-High } \\\hline") _n


foreach v in `vs'{
	$write ("`r`v''")
	global digit 1
	foreach c in `cs'{
		$write ("& ")
		global var `d`c'`v''		
		`do1'
	}
	$write ("\\[-.2cm]") _n
	global digit 2
	foreach c in `cs'{
		$write ("& ")
		global var `p`c'`v''
		`do2'
	}	

	$write ("\\") _n
	if "`v'"=="hwp" $write ("\hline") _n
}
$write ("\hline") _n


*#################################################################
${lastl}
${close}
*#################################################################




