***************************************************************************************************
* This program creates a graphical depiction for survey timeframes for the Core Group & the non-Core Countries
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi, Paul Reimers 
* Purpose: Create a graphical overiew of survey timeframes (in weeks)
**************************************************************************************************
clear

**********************************************************************************************************************
*Generate Core Group Graph
**********************************************************************************************************************
use "Data/Cleaned_data\reshaped combined timeframes"

merge m:1 country using "Data\Cleaned_data\repl_master_stats.dta", nogen keepusing(coreDummy)

*Keep only core group countries
keep if coreDummy==1
drop if week == 53

egen cid_graph=group(country) //generate a new country variable for graphical depiction
sum cid_graph				//Save maximum to be used later in graph options
local max=r(max)
labmask cid_graph, values(country) lblname(yl)
labmask cid_graph, values(country) lblname(yl)

graph twoway rbar week_min week_max cid_graph if wk_code==1, horizontal color(gs12) graphregion(fcolor(white) lcolor(white) lstyle(black)) ///
			xtitle(Week of the Year, size(small)) ytitle("") ///
			legend(lab(1 "Weekly") size(vsmall) cols(4) margin(zero) height(5) width(100) title(Categorization of observations, size(vsmall)) symxsize(*0.5)) ///
			ysize(20) xsize(20)ysc(rev) ylabel(`yl' 1(1)`max', labs(1.3) angle(0) val) xtick(0(1)53, grid tp(c)) ytick(1(1)`max', grid tp(c)) barw(1) ///
			|| rbar week_min week_max cid_graph if wk_code==3, horizontal color(gs9) legend(lab(2 "Monthly")) ///
			|| rbar week_min week_max cid_graph if wk_code==5, horizontal color(gs4) legend(lab(3 "Quarterly")) ///
			|| rbar week_min week_max cid_graph if wk_code>=7, hor color(gs1) legend(lab(4 "> Quarter"))


		graph export "texinput\Core_timeframes.pdf", replace		
			
clear

************************************************************************************************************
***Generate Non-Core Graph***
************************************************************************************************************
use "Data/Cleaned_data\reshaped combined timeframes"

merge m:1 country using "Data\Cleaned_data\repl_master_stats.dta", nogen keepusing(coreDummy)

*Keep only non_core countries
keep if coreDummy==0
drop if week == 53
egen cid_graph=group(country) //generate a new country variable for graphical depiction
sum cid_graph
local max=r(max)
labmask cid_graph, values(country) lblname(yl)
labmask cid_graph, values(country) lblname(yl)
recode wk_code (2=3)(6=7)

graph twoway rbar week_min week_max cid_graph if wk_code==1, graphregion(fcolor(white) lcolor(white) lstyle(black)) horizontal color(gs12) ///
			xtitle(Week of the Year, size(small)) ytitle("")  ///
			legend(lab(1 "Weekly") size(vsmall) cols(5) margin(zero) height(7) width(100) title(Categorization of observations, size(vsmall)) symxsize(*0.4)) ///
			ysize(20) xsize(20)ysc(rev) ylabel(`yl' 1(1)`max', labs(1.3) angle(0) val) xtick(0(1)53, grid tp(c)) ytick(1(1)`max', grid tp(c)) barw(1) ///
			|| rbar week_min week_max cid_graph if wk_code==3, horizontal color(gs9) legend(lab(2 "Monthly")) ///
			|| rbar week_min week_max cid_graph if wk_code==4, horizontal color(gs7) legend(lab(3 "<Quarter")) ///
			|| rbar week_min week_max cid_graph if wk_code==5, horizontal color(gs4) legend(lab(4 "Quarterly")) ///
			|| rbar week_min week_max cid_graph if wk_code>=7, hor color(gs1) legend(lab(5 ">Quarter"))
			
			*|| rbar week_min week_max cid_graph if wk_code==6, horizontal color(gs3) legend(lab(4 "< Half year")) ///


		graph export "texinput\NonCore_timeframes.pdf", replace		
		

**********************************************************************
***Program End***
**********************************************************************
















