******************************************************************************************
* Program: MNG_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Mongolia
******************************************************************************************

use "Data\Mongolia\Data\LFS 2006-2007", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs  STRATUM SUBSAMPLE SEGNUM HHNUM
foreach v in `vs'{
	gen `v's=string(`v')
}


replace hid=STRATUMs+"-"+SUBSAMPLEs+"-"+SEGNUMs+"-"+HHNUMs

bysort hid: gen ppid=_n
replace pid=ppid

order hid pid

gen hh_link = .
replace hh_link = 1 if I2 == 1 //Reference Person
replace hh_link = 2 if I2 == 2 //Spouse/Husband
replace hh_link = 3 if I2 == 3  | I2 == 5 | I2 == 7 | I2 == 9 //child, grand child
replace hh_link = 4 if  I2 == 4 | I2 == 6 | I2 == 8 //Ascendant (parent, grand parent)
replace hh_link = 98 if  I2 == 11 //Not related
replace hh_link = 99 if  I2 ==5 | I2 ==10  //Others 

*-----------------------------------------

* Age
gen age=I5

* Gender
replace male=1 if I3==1
replace male=0 if I3==2

*-----------------------------------------

* Weight
replace wgt=Weight			//Looks like Household weight
gen hh_wgt = Weight

* Interview Date
replace refdatex=1
replace refdate=mdy(StartMonth, StartDay, StartYear)
format refdate %td

replace refweek=week(refdate)
replace refday=dow(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if I16==1
replace educ=0 if I16==2 | I16==3
replace educ=1 if VII2==1
replace educ=0 if VII2==2
gen educlvl=.
*We only have current level for those aged 5-17 years, not above (so probably do not include tertiary education)

gen edu = .
replace edu=1 if inrange(I17,1,3)
replace edu=2 if inrange(I17,4,5)
replace edu=3 if inrange(I17,6,8)

******************************************
* Market work
******************************************

* Employment status (primary)
replace emp=1 if II50>=1 & II50!=.		//II50 variable is the sum of hours in wage job and self-employed
replace emp=2 if II51==1 				//II51 asks, if hours are zero, is person employed?
replace emp=0 if II51==2 & II50==0		//did not work & does not have a job

* Reason for being economically inactive
replace reason=0 if emp<=1
replace reason=2 if III78==6 | III79==2
replace reason=3 if III78==5
replace reason=5 if III78==7 
replace reason=7 if III78==8 | III78==2 | III78==3 | III78==4 
replace reason=7 if III79<=6 & III79!=2

*Work status
replace emp_wj = 1 if V98 == 1 | V98 == 2 
replace emp_se = 1 if inrange(V98,3,6)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

*Market work

* Actual hours last week main job (divided into wage job vs. self employed classification)
*1) Total hours
	replace ahrswk_aj=II36
*2) Hours from wage job
	replace ahrswk_wj=II21
*3) Hours from self-employment
	*replace ahrswk_sx=II35
	egen var1 = rowtotal(II24 II25 II35),m
		replace ahrswk_sa = var1
	egen var2 = rowtotal(II23 II26 II27 II28 II29 II30 II31 II32 II33 II34), m
		replace ahrswk_sn=var2
	drop var1 var2
	
* Usual hours per week main job
	replace uhrswk_mj=II52

* Actual hours last week second job
	replace ahrswk_sj=II65		//These should already be included in II36 (total hours)


gen indic_se = 0								//indicator for ind having second job or not
replace indic_se = 1 if II62 == 1
replace indic_se = 1 if II62 == 2 & II63 == 1	
replace ahrswk_wj_mj = ahrswk_wj if indic_se == 0 & (II57 == 1 | II57 == 2)										//Recode only main (wage) jobs 
replace ahrswk_wj_aj = ahrswk_wj_mj if indic_se == 0 & (II57 == 1 | II57 == 2)									//Again, these guys have only one main wage job
replace ahrswk_wj_aj = ahrswk_wj if indic_se == 1 & (II57 == 1 | II57 == 2) & (II68 == 1 | II68 == 2)			//These guys have multiple wage jobs
	
replace flag_set1 = 1 if indic_se == 0 & (II57 == 1 | II57 == 2)												//These guys have only main (wage) job
replace flag_set2 = 1 if flag_set1 == 1 | (indic_se == 1 & (II57 == 1 | II57 == 2) & (II68 == 1 | II68 == 2)) 	//These guys additionally have second job wage
replace flag_set3 = 1 if flag_set2 == 1 | (indic_se == 1 & (II57 == 1 | II57 == 2) & (II68 >= 3 & II68 <= 6)) 	//These guys have main wage job and second se job
	
*We have 19 observations of people who report no second job, but actually have main wage job and hours in self employment. These guys are coded to
*set 3, but not 1,2
replace flag_set1 = 0 if flag_set1 == 1 & (ahrswk_sn > 0 & ahrswk_sn != .) | (ahrswk_sa > 0 & ahrswk_sa != .)
replace flag_set2 = 0 if flag_set2 == 1 & (ahrswk_sn > 0 & ahrswk_sn != .) | (ahrswk_sa > 0 & ahrswk_sa != .)

egen hrs = rowtotal(ahrswk_wj ahrswk_sa ahrswk_sn),m
gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1

******************************************
* Non-market work
******************************************

egen byte work_nm = anymatch(II37 II38 II39 II40 II41 II42 II43 II44 II45 II46 II47 II48), values(1) 
egen byte rowtotal_nm = rowtotal(II37 II38 II39 II40 II41 II42 II43 II44 II45 II46 II47 II48), missing
replace work_nm=. if rowtotal_nm==.

replace emp_nm=0 if work_nm==0
replace emp_nm=1 if work_nm==1

*-----------------------------------------

* Time spent on non-market work
	
*Non-Market work
replace ahrswk_nm=II49	
	
*-----------------------------------------

*Commuting and meal hours
replace mealhrsx=2					// Both not explicitly included or excluded from work hours */
replace chrsx=2

*-----------------------------------------

gen ind = .
destring II56, replace
replace ind = 1 if inrange(II56, 0,322)
replace ind = 2 if inrange(II56, 510,3900)
replace ind = 3 if inrange(II56, 4100,9900)

*-----------------------------------------
*Income wage/self employment jobs: Use usually active population module, also asks for income!
*-----------------------------------------
	*1) Main Job: 
		gen inc_mj_tot_g =  V101A
			replace inc_wj_mj_tot_g = inc_mj_tot_g if V98 == 1 | V98 == 2 	//cash, weekly --> monthly, main wage job only
			replace inc_se_mj_tot_g = inc_mj_tot_g if inrange(V98,3,6) 		//cash, weekly --> monthly, main wage job only
			
	*2) All Jobs:
		gen inc_aj_tot_g = V108A 
			replace inc_wj_aj_tot_g = inc_aj_tot_g if (V98 == 1 | V98 == 2) & (V105 == 1 | V105 == 2)	//All wage jobs only
			replace inc_wj_aj_tot_g = inc_wj_mj_tot_g if inc_wj_aj_tot_g == . 							//These individuals only have one main wage job! Coding this way yields more observations and higher wage income means.
			
			replace inc_se_aj_tot_g = inc_aj_tot_g if (V98 == 3 | V98 == 4 | V98 == 5 | V98 == 6) & (V105 == 3 | V105 == 4 | V105 == 5 | V105 == 6)
			replace inc_se_aj_tot_g = inc_se_mj_tot_g if inc_se_aj_tot_g == . & V105 == .
		
		*These are only the people who have either only wage or only self employment jobs. We are missing the ones who have mixed jobs!
	
	*Total individual income
	replace ind_tot_wjse = V108A
	
*-----------------------------------------
*Household income
*-----------------------------------------
replace V108A = V101A if V108A == .
bysort hid: egen inc = total(V108A)		
		replace inc_hh = inc

*Everything is measured in thousand tugrik! So need to multiply by this to get our true values
foreach v in inc_wj_aj_c_g inc_wj_aj_ik_g inc_wj_mj_tot_g inc_wj_aj_tot_g inc_hh ind_tot_wjse {
replace `v' = `v' * 1000
}
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 


/* Old income code
*Active in last 7 days: Only asked to employees
	*1) Main Job: How much did () earn in this primary occupation in the last 7 days?
		gen inc_mj_c_g =  II74A*52/12 
			replace inc_wj_mj_c_g = inc_mj_c_g if II57 == 1 | II57 == 2 	//cash, weekly --> monthly, main wage job only
		gen inc_mj_ik_g = II74B*52/12 
			replace inc_wj_mj_ik_g = inc_mj_ik_g if II57 == 1 | II57 == 2	//inkind (cash value) , main wage job only	
		*here we really have only employees.
		
	*2) Second Job)
		gen inc_sj_c_g = II75A*52/12 
			gen inc_wj_sj_c_g = inc_sj_c_g if II68 == 1 | II68 == 2		//Second job wage, only
		gen inc_sj_ik_g = II75B*52/12 if II68 == 1 | II68 == 2
			gen inc_wj_sj_ik_g = inc_sj_ik_g if II68 == 1 | II68 == 2

	egen wj_c = rowtotal(inc_wj_mj_c_g inc_wj_sj_c_g),m						//cash income, all wage jobs)
		replace inc_wj_aj_c_g = wj_c 
	egen wj_ik = rowtotal(inc_wj_mj_ik_g inc_wj_sj_ik_g),m					//inkind income, all wage jobs
		replace inc_wj_aj_ik_g = wj_ik 

		
	egen wj_mjtot = rowtotal(inc_wj_mj_c_g inc_wj_mj_ik_g),m				//inkind + cash income, main wage job
		replace inc_wj_mj_tot_g = wj_mjtot 
		//(II21 >= 0 & II21 != .) & (II22 == 0 | II22 == . )				//Replace only if wage job worked only
	
	egen wj_ajtot = rowtotal(inc_wj_aj_c_g inc_wj_aj_ik_g),m				//inkind + cash income, all wage jobs
		replace inc_wj_aj_tot_g = wj_ajtot 
		//(II21 >= 0 & II21 != .) & (II22 == 0 | II22 == . )				//Replace only if wage job!
*/
