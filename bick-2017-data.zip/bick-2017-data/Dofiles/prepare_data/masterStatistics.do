 **********************************************************************************************************
* Program: masterStats.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos
*---------------------------------------------------------------------------------------------------------*
* Purpose: 	Loops over the harmonized country Datafiles to compute master_stats, which contains statistics 
*			on employment rates/hours worked by age, education, occupation etc. for all countries.
*			For the detailed structure, see lines 58-76.
***********************************************************************************************************

clear all

set more off 

***This part generates a file containing the countrynames.***
*Later, all statistics are inputted into this file! If this part is run, all current entries are overwritten!!!*** 

local countries AGO ALB ARG ARM AUS AUT BEL	BEN	BGR	BIH BOL BRA	BWA	CAN	CHE	CHL	CHN COL CYP CZE DEU DNK	ECU	EGY	ESP	EST	FIN FRA	GBR	GHA GRC GTM HUN IDN IRL IRQ ISL ITA JAM JOR KAZ KEN KGZ KHM KOR LAO LCA LSO LTU LUX LVA MEX MLI MLT MNG MUS MWI MYS NAM NIC NLD NOR PAK PAN PER PHL POL PRT PRY ROM RUS RWA SLV SRB SVK SVN SWE TAI TJK TLS TUN TUR TZA UGA USA VEN VNM ZAF
foreach c in `countries' {
	if "`c'" == "AGO" {
		set obs 1	
		gen country = "AGO"
		local n = _N+1
	}
	if "`c'" != "AGO" {
		set obs `n'
		replace country = "`c'" if country == ""
		local n = _N+1
	}
}

****************************************************

merge 1:1 country using "Data/external_data/pwt_v2.dta", nogen				//Yields dataset with all our included countries, classified into income groups
capture noisily: drop _merge
 
saveold "Data\Cleaned_data\repl_master_stats.dta", replace version(12)


**************************************************
*** COMPUTE COUNTRY AVERAGE Statistics ***********
**************************************************

local countries AGO ALB ARG ARM AUS AUT BEL	BEN	BGR	BIH BOL BRA	BWA	CAN	CHE	CHL	CHN COL CYP CZE DEU DNK	ECU	EGY	ESP	EST	FIN FRA	GBR	GHA GRC GTM HUN IDN IRL IRQ ISL ITA JAM JOR KAZ KEN KGZ KHM KOR LAO LCA LSO LTU LUX LVA MEX MLI MLT MNG MUS MWI MYS NAM NIC NLD NOR PAK PAN PER PHL POL PRT PRY ROM RUS RWA SLV SRB SVK SVN SWE TAI TJK TLS TUN TUR TZA UGA USA VEN VNM ZAF
	
local ages all young prime old non_prime non_young non_old old_56_64 old_65_99 15_64 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 25_34 35_44 45_54 55_64 65_74 75_84 85plus 		/*Add age category also to line 361 363*/
local ages_2 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 85plus	/*Add age category also to line 361 363*/
local ages_3 25_34 35_44 45_54 55_64 65_74 75_84 85plus
local main_ages all young prime old non_prime non_young 

local genders a m f

local statistics 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 50

*s=1:  Hours worked per Employed, HWE
*s=2:  employment rates, ER
*s=3:  Hours worked per Capita, HWP
*s=4:  Population numbers
*s=5:  US Weighted Statistics
*s=6:  Robustness Check for monthly/quarterly average hours
*s=7:  Industry shares
*s=8:  Education shares
*s=9:  HWE by industry
*s=10: HWE by education	//stat 8 needs to run, too
*s=11: Employment Rates, by education //stat 8 needs to run, too
*s=12: Hours worked per Capita, by education: ER*HWE=HWP //stat 8 needs to run, too
*s=13: US Weighted Statistics for ER, HWE and HWP
*s=14: Household Hours (by Education of Household Head)
*s=15: Hours worked per Employed, Employment Rates, Hours per Capita by income quintile. DO NOT USE: THIS IS OLD STAT I COMPUTED IN MARCH 
*s=16: US Age x Education Composition
*s=17: Share of people in wages/self employment, share of people with wage incomes - all over total # of employed
*.....
*s=50: Timeuse Statistics: Need to do it last, since it is built on MTUS datasets, too!


foreach country in `countries' {
	display "`country'"
	use "Data\Cleaned_data/`country'_all_std.dta", clear
	gen country="`country'" 

	global master_stats country coreDummy robustDummy
	
foreach s in `statistics' {	

***********************************************************
*Statistic 1: HWE statistic
***********************************************************
if `s' == 1 {		
	foreach a in `ages' {

	//calculation of Hours worked per employed													
		sum hrs if employed==1 & hrs!=. & age_`a' == 1 [aweight=wgt]
		gen hwe_a_`a' = r(mean)
	
	
	* Average hours per employed, by sex							
		sum hrs if employed==1 & hrs!=. & age_`a' == 1 & male == 0	[aweight=wgt]  
		gen hwe_f_`a' = r(mean)
		sum hrs if employed==1 & hrs!=. & age_`a' == 1 & male == 1	[aweight=wgt]  
		gen hwe_m_`a' = r(mean)
	
	global master_stats $master_stats hwe_a_`a' hwe_m_`a' hwe_f_`a'
	
	}	//Ages
}	//Statistic 1: HWE

***********************************************************
*Statistic 2: Employment Rates
***********************************************************
if `s' == 2 {		
	foreach a in `ages' {
	
		sum employed if employed!=. & age_`a' == 1 [aweight=wgt] 	
		gen er_a_`a' = r(mean)
	
	
	*Employment Rates, by gender
		sum employed if employed!=. & age_`a' == 1 & male == 0 [aweight=wgt] 	
		gen er_f_`a' = r(mean)
		sum employed if employed!=. & age_`a' == 1 & male == 1 [aweight=wgt] 	
		gen er_m_`a' = r(mean)
		
	global master_stats $master_stats er_a_`a' er_m_`a' er_f_`a' 
	
	} //Ages
}	//Statistic 2: ER


***********************************************************
*Statistic 3: Hours worked per Capita: ER*HWE=HWP
***********************************************************
if `s' == 3 {		
	foreach a in `ages' {
		foreach g in `genders' {
			
			gen hwp_`g'_`a'=er_`g'_`a'*hwe_`g'_`a'
			replace hwp_`g'_`a' = 0 if er_`g'_`a' == 0
		} 	//Genders
		
	global master_stats $master_stats hwp_a_`a' hwp_m_`a' hwp_f_`a' 

	}	//Ages
} 	//Statistic 3: HWP


***********************************************************
*Statistic 4: Population fractions
***********************************************************
if `s' == 4 {
	
	count if age_all == 1
	gen N_adults = r(N)
	
	foreach a in `ages' {
		//Sum the weights in spec. age group and dep. on gender
		egen popwgt_a_`a' = sum(wgt) if age_`a' == 1
		egen popwgt_m_`a' = sum(wgt) if male==1 & age_`a' == 1
		egen popwgt_f_`a' = sum(wgt) if male==0 & age_`a' == 1
		
		foreach g in `genders' {
			//Make sure the observation is written into the first cell
			sum popwgt_`g'_`a'
			replace popwgt_`g'_`a' = r(mean)
			//Generate fraction age_group of total population
			gen popshare_`g'_`a' = popwgt_`g'_`a'/tot_wgt
		}
		
	global master_stats $master_stats N_adults popshare_a_`a' popshare_m_`a' popshare_f_`a' popwgt_a_`a' popwgt_m_`a' popwgt_f_`a' tot_wgt
	
	} //Ages
	
} //Statistic 4: Population #

***********************************************************
*Statistics 5: US Weighted Statistics for ER, HWE and HWP
***********************************************************
if `s' == 5 {	
	merge 1:1 _n using "Data\Cleaned_data\USA_weights_merged.dta", nogen
	global er_USweights 
	global hwe_USweights
	
	foreach a in `ages_2' {
		foreach g in `genders' {
		if "`g'" != "a" {
		
		egen USemployee_`g'_`a' = min(ageshare_hwe_`g'_`a')
		replace ageshare_hwe_`g'_`a' = USemployee_`g'_`a'

		egen USsurvey_`g'_`a' = min(ageshare_er_`g'_`a')
		replace ageshare_er_`g'_`a' = USsurvey_`g'_`a'
		
		drop USsurvey_`g'_`a' USemployee_`g'_`a'
		
		gen er_USweights_`g'_`a' = er_`g'_`a' * ageshare_er_`g'_`a'
		gen hwe_USweights_`g'_`a' = hwe_`g'_`a' * ageshare_hwe_`g'_`a'

		global er_USweights $er_USweights er_USweights_`g'_`a'
		global hwe_USweights $hwe_USweights hwe_USweights_`g'_`a'

		*display `er_USweights'
		} //gender if loop
		}	//Gender loop
	} 	//ages loop

*** Generating new weighted er, hwe, hwp ***

** Use US age/gender shares for calculation new er
egen er_a_all_USweights = rowtotal($er_USweights), missing
*er_USweights_m_20_24 er_USweights_f_20_24 er_f_15_19*ageshare_er_f_15_19 + er_m_15_19*ageshare_er_m_15_19 + er_f_20_24*ageshare_er_f_20_24 + er_m_20_24*ageshare_er_m_20_24 + er_f_25_29*ageshare_er_f_25_29 + er_m_25_29*ageshare_er_m_25_29 + er_f_30_34*ageshare_er_f_30_34 + er_m_30_34*ageshare_er_m_30_34 + er_f_35_39*ageshare_er_f_35_39 + er_m_35_39*ageshare_er_m_35_39 + er_f_40_44*ageshare_er_f_40_44 + er_m_40_44*ageshare_er_m_40_44 + er_f_45_49*ageshare_er_f_45_49 + er_m_45_49*ageshare_er_m_45_49 + er_f_50_54*ageshare_er_f_50_54 + er_m_50_54*ageshare_er_m_50_54 + er_f_55_59*ageshare_er_f_55_59 + er_m_55_59*ageshare_er_m_55_59 + er_f_60_64*ageshare_er_f_60_64 + er_m_60_64*ageshare_er_m_60_64 + er_f_65_69*ageshare_er_f_65_69 + er_m_65_69*ageshare_er_m_65_69 + er_f_70_74*ageshare_er_f_70_74 + er_m_70_74*ageshare_er_m_70_74 + er_f_75_79*ageshare_er_f_75_79 + er_m_75_79*ageshare_er_m_75_79 + er_f_80_84*ageshare_er_f_80_84 + er_m_80_84*ageshare_er_m_80_84 + er_f_85plus*ageshare_er_f_85plus + er_m_85plus*ageshare_er_m_85plus

** Use US age/gender shares for calculation of hwe
egen hwe_a_all_USweights = rowtotal($hwe_USweights), missing
*hwe_f_15_19*ageshare_hwe_f_15_19 + hwe_m_15_19*ageshare_hwe_m_15_19 + hwe_f_20_24*ageshare_hwe_f_20_24 + hwe_m_20_24*ageshare_hwe_m_20_24 + hwe_f_25_29*ageshare_hwe_f_25_29 + hwe_m_25_29*ageshare_hwe_m_25_29 + hwe_f_30_34*ageshare_hwe_f_30_34 + hwe_m_30_34*ageshare_hwe_m_30_34 + hwe_f_35_39*ageshare_hwe_f_35_39 + hwe_m_35_39*ageshare_hwe_m_35_39 + hwe_f_40_44*ageshare_hwe_f_40_44 + hwe_m_40_44*ageshare_hwe_m_40_44 + hwe_f_45_49*ageshare_hwe_f_45_49 + hwe_m_45_49*ageshare_hwe_m_45_49 + hwe_f_50_54*ageshare_hwe_f_50_54 + hwe_m_50_54*ageshare_hwe_m_50_54 + hwe_f_55_59*ageshare_hwe_f_55_59 + hwe_m_55_59*ageshare_hwe_m_55_59 + hwe_f_60_64*ageshare_hwe_f_60_64 + hwe_m_60_64*ageshare_hwe_m_60_64 + hwe_f_65_69*ageshare_hwe_f_65_69 + hwe_m_65_69*ageshare_hwe_m_65_69 + hwe_f_70_74*ageshare_hwe_f_70_74 + hwe_m_70_74*ageshare_hwe_m_70_74 + hwe_f_75_79*ageshare_hwe_f_75_79 + hwe_m_75_79*ageshare_hwe_m_75_79 + hwe_f_80_84*ageshare_hwe_f_80_84 + hwe_m_80_84*ageshare_hwe_m_80_84 + hwe_f_85plus*ageshare_hwe_f_85plus + hwe_m_85plus*ageshare_hwe_m_85plus

** Resulting hwp
gen hwp_a_all_USweights = er_a_all_USweights*hwe_a_all_USweights

global master_stats $master_stats er_a_all_USweights hwp_a_all_USweights  hwe_a_all_USweights 
	
} //Statistic 5: US weighted

****************************
***Save labour Statistics***

***********************************************************
*Statistics 6: Robustness Check for monthly/quarterly average hours
***********************************************************
if `s' == 6 {		
	*if coreDummy == 1 {
	global master_stats $master_stats
	
	*EULFS countries
	if "`country'" == "AUT" | "`country'" == "BEL" | "`country'" == "BGR" | "`country'" == "CHE" | "`country'" == "CYP" | "`country'" == "CZE" | "`country'" == "DEU" | "`country'" == "DNK" | "`country'" == "ESP" | "`country'" == "EST" | "`country'" == "FIN" | "`country'" == "FRA" | "`country'" == "GBR" | "`country'" == "GRC" | "`country'" == "HUN" |  "`country'" == "ISL" | "`country'" == "ITA" | "`country'" == "LTU" | "`country'" == "LUX" | "`country'" == "LVA" | "`country'" == "MLT" | "`country'" == "NLD" | "`country'" == "POL" | "`country'" == "PRT" | "`country'" == "ROM" | "`country'" == "SVK" | "`country'" == "SVN" | "`country'" == "SWE"  {
	
	gen month_d = .
	
	replace month_d = 1 if refweek == 1 | refweek == 2 | refweek == 3 | refweek == 4 | refweek == 5 
	replace month_d = 2 if refweek == 6 | refweek == 7| refweek == 8 | refweek ==9  
	replace month_d = 3 if refweek ==10 | refweek ==11 | refweek == 12 | refweek == 13 | refweek ==14 
	replace month_d = 4 if refweek ==15 | refweek ==16 | refweek == 17 | refweek == 18 
	replace month_d = 5 if refweek ==19 | refweek ==20 | refweek == 21 | refweek == 22 
	replace month_d = 6 if refweek ==23 | refweek ==24 | refweek == 25 | refweek == 26 | refweek ==27
	replace month_d = 7 if refweek ==28 | refweek ==29 | refweek == 30 | refweek == 31 
	replace month_d = 8 if refweek ==32 | refweek ==33 | refweek == 34 | refweek == 35 | refweek ==36
	replace month_d = 9 if refweek ==37 | refweek ==38 | refweek == 39 | refweek == 40 
	replace month_d = 10 if refweek ==41 | refweek ==42 | refweek == 43 | refweek == 44 
	replace month_d = 11 if refweek ==45 | refweek ==46 | refweek == 47 | refweek == 48 | refweek ==49
	replace month_d = 12 if refweek ==50 | refweek ==51 | refweek == 52 | refweek == 53 

	global hwe 
	global er
	global hwp
	
	forvalues n = 1/12 {
		sum hrs if employed==1 & hrs!=. & age_all == 1 & month_d == `n' [aweight=wgt]
		gen hwe_a_all_`n' = r(mean)
		global hwe $hwe hwe_a_all_`n' 
		
		sum employed if employed!=. & age_all == 1 & month_d == `n'  [aweight=wgt] 	
		gen er_a_all_`n' = r(mean)
		global er $er er_a_all_`n'
		
		gen hwp_a_all_`n' = er_a_all_`n'*hwe_a_all_`n'
		global hwp $hwp hwp_a_all_`n'
		
	}

	local variables er hwe hwp
	foreach v in `variables' {
		egen `v'_a_all_mthavg = rowtotal(`v'_a_all_1 `v'_a_all_2 `v'_a_all_3 `v'_a_all_4 `v'_a_all_5 `v'_a_all_6 `v'_a_all_7 `v'_a_all_8 `v'_a_all_9 `v'_a_all_10 `v'_a_all_11 `v'_a_all_12), missing
		replace `v'_a_all_mthavg = `v'_a_all_mthavg/12
	}
	
	global master_stats $master_stats er_a_all_mthavg hwe_a_all_mthavg hwp_a_all_mthavg 
	} //Countries EULFS
	
	if "`country'" == "COL" | "`country'" == "GHA" | "`country'" == "MUS" | "`country'" == "TZA" | "`country'" == "USA" | "`country'" == "VNM" | "`country'" == "MNG" {
	gen month_d = refmonth	
	
	global hwe 
	global er
	global hwp
	
	forvalues n = 1/12 {
		sum hrs if employed==1 & hrs!=. & age_all == 1 & month_d == `n' [aweight=wgt]
		gen hwe_a_all_`n' = r(mean)
		global hwe $hwe hwe_a_all_`n' 
		
		sum employed if employed!=. & age_all == 1 & month_d == `n'  [aweight=wgt] 	
		gen er_a_all_`n' = r(mean)
		global er $er er_a_all_`n'
		
		gen hwp_a_all_`n' = er_a_all_`n'*hwe_a_all_`n'
		global hwp $hwp hwp_a_all_`n'
		
	}

	local variables er hwe hwp
	foreach v in `variables' {
		egen `v'_a_all_mthavg = rowtotal(`v'_a_all_1 `v'_a_all_2 `v'_a_all_3 `v'_a_all_4 `v'_a_all_5 `v'_a_all_6 `v'_a_all_7 `v'_a_all_8 `v'_a_all_9 `v'_a_all_10 `v'_a_all_11 `v'_a_all_12), missing
		replace `v'_a_all_mthavg = `v'_a_all_mthavg/12
	}
	
	global master_stats $master_stats er_a_all_mthavg hwe_a_all_mthavg hwp_a_all_mthavg 
	}	//COL and other monthly avail. countries
	
	if "`country'" == "PAK" {
	*global hwe 
	*global er
	*global hwp
	
	gen quarter_d = quarter(startdate)
		
	forvalues q = 1/4 {

		sum hrs if employed==1 & hrs!=. & age_all == 1 & quarter_d == `q' [aweight=wgt]
		gen hwe_a_all_`q' = r(mean)
		*global hwe $hwe hwe_a_all_`q' 
		
		sum employed if employed!=. & age_all == 1 & quarter_d == `q'  [aweight=wgt] 	
		gen er_a_all_`q' = r(mean)
		*global er $er er_a_all_`q'
		
		gen hwp_a_all_`q' = er_a_all_`q'*hwe_a_all_`q'
		*global hwp $hwp hwp_a_all_`q'
		
	}

	local variables er hwe hwp
	foreach v in `variables' {
		egen `v'_a_all_mthavg = rowtotal(`v'_a_all_1 `v'_a_all_2 `v'_a_all_3 `v'_a_all_4 ), missing
		replace `v'_a_all_mthavg = `v'_a_all_mthavg/4
	}

	global master_stats $master_stats er_a_all_mthavg hwe_a_all_mthavg hwp_a_all_mthavg 
	} //Pak
	
	*} //Core
}	//Statistic 6

***********************************************************
*Statistics 7: Industry shares
***********************************************************
if `s' == 7 {

    sum wgt
    if r(N)==0 replace wgt=1 
   
	foreach age in all { // `main_ages'{
		
		egen z=sum(wgt) if employed==1 & hrs != . & age_`age' == 1 & ind==.
		sum z
		if r(N)==0{
			local z=0
		}
		else{	
			local z=r(mean)
		}
		egen n=sum(wgt) if employed==1 & hrs != . & age_`age' == 1 
		sum n
		local n=r(mean)
		drop z n
		gen h_ind_`age'_miss=`z'/`n'
		sum h_ind_`age'_miss
		global master_stats $master_stats h_ind_`age'_miss
	}
	
}

***********************************************************
*Statistics 8: Education
***********************************************************
if `s' == 8 {
	
    local ife if employed!=.
    local ifh if employed==1 & hrs!=.

    sum wgt
    if r(N)==0 replace wgt=1 
   
	foreach age in `main_ages'{
	foreach v in e h{
		egen z=sum(wgt) `if`v'' & age_`age' == 1 & edu==.
		sum z
		if r(N)==0{
			local z=0
		}
		else{	
			local z=r(mean)
		}
		egen n=sum(wgt) `if`v'' & age_`age' == 1 
		sum n
		local n=r(mean)
		drop z n
		gen `v'_edu_`age'_miss=`z'/`n'
		sum `v'_edu_`age'_miss
		global master_stats $master_stats `v'_edu_`age'_miss
	}
	}
	
} 	// s== 8

***********************************************************
*Statistics 9: Hours Worked per Employed, by industry
***********************************************************
if `s' == 9 {

replace ind = 4 if ind == .
gen ind_nm = 1 if ind != 4 //Industry is non-missing

foreach a in `main_ages' {
	forvalues num = 1/4 {
														
		capture noisily	sum hrs if employed==1 & hrs!=. & age_`a' == 1 &  ind == `num' [aweight=wgt]
			gen hwe_a_`a'_ind`num' = r(mean)

		replace hwe_a_`a'_ind`num' = . if   h_ind_all_miss == 1	
		replace hwe_a_`a'_ind`num' = . if hwe_a_`a'_ind`num' == 0
		
		global master_stats $master_stats hwe_a_`a'_ind`num'
	
	}	// industries loop	
	
	*Averages for age groups if industry is non-missing
		capture noisily	sum hrs if employed==1 & hrs!=. & age_`a' == 1 &  ind_nm == 1 [aweight=wgt]
			gen hwe_a_`a'_ind5 = r(mean)
			
			global master_stats $master_stats hwe_a_`a'_ind5

}	//ages 

} 	//s == 9

***********************************************************
*Statistics 10: Hours Worked per Employed, by education
***********************************************************
if `s' == 10 {

replace edu = 4 if edu == .
gen edu_nm = 1 if edu != 4 //Education is non-missing

foreach a in `ages' {			//`main_ages'
	forvalues num = 1/4 {		//education loop															
		capture noisily	sum hrs if employed==1 & hrs!=. & age_`a' == 1 &  edu == `num' [aweight=wgt]
			gen hwe_a_`a'_edu`num' = r(mean)
		
		capture noisily sum hrs if employed==1 & hrs!=. & age_`a' == 1 & male == 0 &  edu == `num' [aweight=wgt]
			gen hwe_f_`a'_edu`num' = r(mean)
		capture noisily sum hrs if employed==1 & hrs!=. & age_`a' == 1 & male == 1 &  edu == `num' [aweight=wgt]
			gen hwe_m_`a'_edu`num' = r(mean)			
		
		foreach g in `genders' {
		replace hwe_`g'_`a'_edu`num' = . if h_edu_all_miss == 1	
		replace hwe_`g'_`a'_edu`num' = . if hwe_`g'_`a'_edu`num' == 0
		}
		
		global master_stats $master_stats hwe_a_`a'_edu`num' hwe_f_`a'_edu`num' hwe_m_`a'_edu`num'
			
	} // education loop	

	*Average HWE for age groups if education is non-missing														
		capture noisily	sum hrs if employed==1 & hrs!=. & age_`a' == 1 &  edu_nm == 1 [aweight=wgt]
			gen hwe_a_`a'_edu5 = r(mean)
		
		capture noisily	sum hrs if employed==1 & hrs!=. & age_`a' == 1  & male == 0 &  edu_nm == 1 [aweight=wgt]
			gen hwe_f_`a'_edu5 = r(mean)
		capture noisily	sum hrs if employed==1 & hrs!=. & age_`a' == 1  & male == 1 &  edu_nm == 1 [aweight=wgt]
			gen hwe_m_`a'_edu5 = r(mean)			
			
		global master_stats $master_stats hwe_a_`a'_edu5 hwe_f_`a'_edu5 hwe_m_`a'_edu5

} //Ages	

	
*global master_stats $master_stats hwe_a_all_edu1 hwe_a_all_edu2 hwe_a_all_edu3

} 	//s == 10

***********************************************************
*Statistic 11: Employment Rates, by education
***********************************************************
if `s' == 11 {	

foreach a in `ages' {			//`main_ages'	
	forvalues num = 1/4 {
	capture noisily	sum employed if employed!=. & age_`a' == 1 & edu==`num'	 [aweight=wgt] 	
		gen er_a_`a'_edu`num' = r(mean)
	
	capture noisily	sum employed if employed!=. & age_`a' == 1 & male == 0  & edu==`num'	 [aweight=wgt] 	
		gen er_f_`a'_edu`num' = r(mean)
	capture noisily	sum employed if employed!=. & age_`a' == 1 & male == 1  & edu==`num'	 [aweight=wgt] 	
		gen er_m_`a'_edu`num' = r(mean)
		
		foreach g in `genders' {
		replace er_m_`a'_edu`num' = . if h_edu_all_miss == 1	
		replace er_f_`a'_edu`num' = . if er_`g'_`a'_edu`num' == 0
		}
		
		global master_stats $master_stats er_a_`a'_edu`num' er_f_`a'_edu`num' er_m_`a'_edu`num'

	}	//num 1 2 3 
	
	*Average ER for age groups if education is non-missing	
	capture noisily	sum employed if employed!=. & age_`a' == 1 & edu_nm==1	 [aweight=wgt] 	
		gen er_a_`a'_edu5 = r(mean)
	
	capture noisily	sum employed if employed!=. & age_`a' == 1 & male == 0 & edu_nm==1	 [aweight=wgt] 	
		gen er_f_`a'_edu5 = r(mean)
	capture noisily	sum employed if employed!=. & age_`a' == 1 & male == 1 & edu_nm==1	 [aweight=wgt] 	
		gen er_m_`a'_edu5 = r(mean)
		
		global master_stats $master_stats er_a_`a'_edu5 er_f_`a'_edu5 er_m_`a'_edu5

}
	

}	//Statistic 11

***********************************************************
*Statistic 12: Hours worked per Capita, by education: ER*HWE=HWP
***********************************************************
if `s' == 12 {		

foreach a in `main_ages' {			//`main_ages'		
	forvalues num = 1/5 {
	foreach g in `genders' {	
		gen hwp_`g'_`a'_edu`num' = er_`g'_`a'_edu`num'*hwe_`g'_`a'_edu`num'
		
	global master_stats $master_stats hwp_`g'_`a'_edu`num'
	
	}	//genders
	}	//Education
}	//Ages


} 	//Statistic 12: HWP

***********************************************************
*Statistics 13: US Weighted Statistics for ER, HWE and HWP
***********************************************************
if `s' == 13 {	
	merge 1:1 _n using "Data\Cleaned_data\USA_weights_merged.dta", nogen
	global er_USweights 
	global hwe_USweights
	global er_USweights_ny
	global hwe_USweights_ny
	
	local vars edu ind
foreach v in `vars'	{

global er_USweights
global hwe_USweights

global er_USweights_ny
global hwe_USweights_ny
	

	forvalues a =1/3 {
		
		egen USemployee_a_`a' = min(`v'share_hwe_a_`a')
		egen USemployee_a_`a'_non_young = min(`v'share_hwe_a_`a'_non_young)

		replace `v'share_hwe_a_`a' = USemployee_a_`a'
		replace `v'share_hwe_a_`a'_non_young = USemployee_a_`a'_non_young


		if "`v'" == "edu" {
			egen USsurvey_a_`a' = min(`v'share_er_a_`a')
			replace `v'share_er_a_`a' = USsurvey_a_`a'
			
			egen USsurvey_a_`a'_non_young = min(`v'share_er_a_`a'_non_young)
			replace `v'share_er_a_`a'_non_young = USsurvey_a_`a'_non_young
			
			drop USsurvey_a_`a' USsurvey_a_`a'_non_young
		}
		
		drop USemployee_a_`a' USemployee_a_`a'_non_young
		
		*Gen statistics for all-ages group
		if "`v'" == "edu" {		
			gen er_US_`v'wgt_a_`a' = er_a_all_`v'`a' * `v'share_er_a_`a'

			gen er_US_`v'wgt_a_`a'_non_young = er_a_non_young_`v'`a' * `v'share_er_a_`a'_non_young
		}
		
		gen hwe_US_`v'wgt_a_`a' = hwe_a_all_`v'`a' * `v'share_hwe_a_`a'
		gen hwe_US_`v'wgt_a_`a'_non_young = hwe_a_non_young_`v'`a' * `v'share_hwe_a_`a'_non_young


		if "`v'" == "edu" {		
			global er_USweights $er_USweights er_US_`v'wgt_a_`a' 
			
			global er_USweights_ny $er_USweights_ny er_US_`v'wgt_a_`a'_non_young
		}
		global hwe_USweights $hwe_USweights hwe_US_`v'wgt_a_`a' 
		
		global hwe_USweights_ny $hwe_USweights_ny hwe_US_`v'wgt_a_`a'_non_young

	} 	//ages loop

*** Generating new weighted er, hwe, hwp ***

** Use US age/gender shares for calculation new er
if "`v'" == "edu" {		
	egen er_a_all_US_`v'wgt = rowtotal($er_USweights), missing

	egen er_a_non_young_US_`v'wgt = rowtotal($er_USweights_ny), missing

}	
*er_USweights_m_20_24 er_USweights_f_20_24 er_f_15_19*ageshare_er_f_15_19 + er_m_15_19*ageshare_er_m_15_19 + er_f_20_24*ageshare_er_f_20_24 + er_m_20_24*ageshare_er_m_20_24 + er_f_25_29*ageshare_er_f_25_29 + er_m_25_29*ageshare_er_m_25_29 + er_f_30_34*ageshare_er_f_30_34 + er_m_30_34*ageshare_er_m_30_34 + er_f_35_39*ageshare_er_f_35_39 + er_m_35_39*ageshare_er_m_35_39 + er_f_40_44*ageshare_er_f_40_44 + er_m_40_44*ageshare_er_m_40_44 + er_f_45_49*ageshare_er_f_45_49 + er_m_45_49*ageshare_er_m_45_49 + er_f_50_54*ageshare_er_f_50_54 + er_m_50_54*ageshare_er_m_50_54 + er_f_55_59*ageshare_er_f_55_59 + er_m_55_59*ageshare_er_m_55_59 + er_f_60_64*ageshare_er_f_60_64 + er_m_60_64*ageshare_er_m_60_64 + er_f_65_69*ageshare_er_f_65_69 + er_m_65_69*ageshare_er_m_65_69 + er_f_70_74*ageshare_er_f_70_74 + er_m_70_74*ageshare_er_m_70_74 + er_f_75_79*ageshare_er_f_75_79 + er_m_75_79*ageshare_er_m_75_79 + er_f_80_84*ageshare_er_f_80_84 + er_m_80_84*ageshare_er_m_80_84 + er_f_85plus*ageshare_er_f_85plus + er_m_85plus*ageshare_er_m_85plus

** Use US age/gender shares for calculation of hwe
egen hwe_a_all_US_`v'wgt = rowtotal($hwe_USweights), missing

egen hwe_a_non_young_US_`v'wgt = rowtotal($hwe_USweights_ny), missing

*hwe_f_15_19*ageshare_hwe_f_15_19 + hwe_m_15_19*ageshare_hwe_m_15_19 + hwe_f_20_24*ageshare_hwe_f_20_24 + hwe_m_20_24*ageshare_hwe_m_20_24 + hwe_f_25_29*ageshare_hwe_f_25_29 + hwe_m_25_29*ageshare_hwe_m_25_29 + hwe_f_30_34*ageshare_hwe_f_30_34 + hwe_m_30_34*ageshare_hwe_m_30_34 + hwe_f_35_39*ageshare_hwe_f_35_39 + hwe_m_35_39*ageshare_hwe_m_35_39 + hwe_f_40_44*ageshare_hwe_f_40_44 + hwe_m_40_44*ageshare_hwe_m_40_44 + hwe_f_45_49*ageshare_hwe_f_45_49 + hwe_m_45_49*ageshare_hwe_m_45_49 + hwe_f_50_54*ageshare_hwe_f_50_54 + hwe_m_50_54*ageshare_hwe_m_50_54 + hwe_f_55_59*ageshare_hwe_f_55_59 + hwe_m_55_59*ageshare_hwe_m_55_59 + hwe_f_60_64*ageshare_hwe_f_60_64 + hwe_m_60_64*ageshare_hwe_m_60_64 + hwe_f_65_69*ageshare_hwe_f_65_69 + hwe_m_65_69*ageshare_hwe_m_65_69 + hwe_f_70_74*ageshare_hwe_f_70_74 + hwe_m_70_74*ageshare_hwe_m_70_74 + hwe_f_75_79*ageshare_hwe_f_75_79 + hwe_m_75_79*ageshare_hwe_m_75_79 + hwe_f_80_84*ageshare_hwe_f_80_84 + hwe_m_80_84*ageshare_hwe_m_80_84 + hwe_f_85plus*ageshare_hwe_f_85plus + hwe_m_85plus*ageshare_hwe_m_85plus

** Resulting hwp
if "`v'" == "edu" {		
	gen hwp_a_all_US_`v'wgt = er_a_all_US_`v'wgt*hwe_a_all_US_`v'wgt

	gen hwp_a_non_young_US_`v'wgt = er_a_non_young_US_`v'wgt*hwe_a_non_young_US_`v'wgt

}
if "`v'" == "edu" {		
	global master_stats $master_stats er_a_all_US_`v'wgt hwp_a_all_US_`v'wgt  hwe_a_all_US_`v'wgt er_a_non_young_US_`v'wgt hwp_a_non_young_US_`v'wgt  hwe_a_non_young_US_`v'wgt 
}
	}	//Vars
	global master_stats $master_stats hwe_a_all_US_indwgt hwe_a_non_young_US_indwgt
} //Statistic 13: US Educ/Industry weighted statistics





***********************************************************
*Statistic 14: Hours worked per Household, by education: ER*HWE=HWP
***********************************************************
if `s' == 14 {		

bysort hid: egen hh_hrs = total(hrs) if employed==1 & hrs!=.
sum hh_wgt
	if r(mean) == 1 & r(sd) == 0 {
		replace hh_wgt = hhtot15plus_wgt					//Replace household weights with sum of weights 15 plus if they were missing		
	} 
	
bysort hid: replace hh_hrs = . if _n != 1					//We will be running analysis only for one observation in each household
*bysort hid: replace hh_wgt = . if _n != 1

*Generate the # of adults & # of working adults within each household
gen num_hh_1 = .
	bysort hid: replace num_hh_1 = 1 if hrs!=. & age >= 15 & age != . 
	bysort hid: replace num_hh_1 = sum(num_hh)
	bysort hid: egen num_hh = max(num_hh)
		
gen num_working_hh_1 = .
	bysort hid: replace num_working_hh_1 = 1 if employed==1 & hrs!=. & age >= 15 & age != .
	bysort hid: replace num_working_hh_1 = sum(num_working_hh_1)
	bysort hid: egen num_working_hh = max(num_working_hh_1)
	

*HH hours per adult
gen hh_hrs_adult = hh_hrs/num_hh

*HH hours per working adult
gen hh_hrs_workadult = hh_hrs/num_working_hh

*Statistics	All
sum hh_hrs [aweight=hh_wgt] if hh_head_edu != .					//This & following commands is now running mean only for _n == 1 by hid! All others have missing weights!
gen hh_hrs_all = r(mean)

sum hh_hrs_adult [aweight=hh_wgt] if hh_head_edu != .
gen hh_hrs_all_adult = r(mean)

sum hh_hrs_workadult [aweight=hh_wgt] if hh_head_edu != .
gen hh_hrs_all_workadult = r(mean)

sum num_hh [aweight=hh_wgt] if hh_head_edu != .
gen num_hh_all = r(mean)

sum num_working_hh [aweight=hh_wgt] if hh_head_edu != .
gen num_working_hh_all = r(mean)

*Statistics for the three education groups
forvalues num = 1/3 {

sum hh_hrs [aweight=hh_wgt] if hh_head_edu == `num'
	gen hh_hrs_edu_`num' = r(mean)	

sum hh_hrs_adult [aweight=hh_wgt] if hh_head_edu == `num'
	gen hh_hrs_edu_`num'_adult = r(mean)	

sum hh_hrs_workadult [aweight=hh_wgt] if hh_head_edu == `num'
	gen hh_hrs_edu_`num'_workadult = r(mean)	

sum num_hh [aweight=hh_wgt] if hh_head_edu == `num'
	gen num_hh_edu_`num' = r(mean)	

sum num_working_hh [aweight=hh_wgt] if hh_head_edu == `num'
	gen num_working_hh_edu_`num' = r(mean)	
}

*Countries without HH identifiers
if "`country'" == "IDN" | "`country'" == "TAI" | "`country'" == "CAN" | "`country'" == "SWE" | "`country'" == "CHE" | "`country'" == "DNK" | "`country'" == "NOR" {
	replace hh_hrs_all = .
	replace hh_hrs_all_adult = .
	replace hh_hrs_all_workadult = .
	replace num_working_hh_all = .
	replace num_hh_all = .
	
	forvalues num = 1/3 {
		
		replace hh_hrs_edu_`num' =.
		replace hh_hrs_edu_`num'_adult=.
		replace hh_hrs_edu_`num'_workadult=.
		replace num_hh_edu_`num'  = .
		replace num_working_hh_edu_`num' = .

	}
}

label variable hh_hrs_edu_1 "Less than Highschool (HH head)"
label variable hh_hrs_edu_2 "Highschool (HH head)"
label variable hh_hrs_edu_3 "More than Highschool (HH head)"

global master_stats $master_stats num_hh_all num_working_hh_all num_working_hh_edu_1 num_working_hh_edu_2 num_working_hh_edu_3 num_hh_edu_1 num_hh_edu_2 num_hh_edu_3  hh_hrs_all_adult hh_hrs_edu_1_adult hh_hrs_edu_2_adult hh_hrs_edu_3_adult  hh_hrs_all_workadult hh_hrs_edu_1_workadult hh_hrs_edu_2_workadult hh_hrs_edu_3_workadult hh_hrs_all hh_hrs_edu_1 hh_hrs_edu_2 hh_hrs_edu_3 

} 	//Statistic 14: HWP

***********************************************************
*Statistic 15: Hours worked per Employed, Employment Rates, Hours per Capita by income quintile
***********************************************************
if `s' == 15 {	
	
	global income_stats
	
	forvalues n = 1/5 {
		sum hrs if employed==1 & hrs!=. & quintile== `n' [aweight=wgt]
		gen hwe_a_q`n' = r(mean)
	
		sum employed if employed!=. & quintile== `n' [aweight=wgt] 	
		gen er_a_q`n' = r(mean)
		
		gen hwp_a_q`n'=er_a_q`n'*hwe_a_q`n'
		
	global income_stats $income_stats hwp_a_q`n' er_a_q`n' hwe_a_q`n' 
	
	}
	
global master_stats $master_stats $income_stats

}	//Statistic 15

***********************************************************
*Statistics 16: US Weighted Statistics for ER, HWE and HWP
***********************************************************
if `s' == 16 {	
merge 1:1 _n using "Data\Cleaned_data\USA_weights_merged.dta", nogen
global er_USweights 
global hwe_USweights
	
foreach a in `ages_3' {
forvalues n = 1/3 {		
		*make sure the share values are avail. in all rows
		egen USemployee_a_`a'_edu`n' = min(ageshare_hwe_a_`a'_edu`n')
		replace ageshare_hwe_a_`a'_edu`n' = USemployee_a_`a'_edu`n'
		egen USsurvey_a_`a'_edu`n' = min(ageshare_er_a_`a'_edu`n')
		replace ageshare_er_a_`a'_edu`n' = USsurvey_a_`a'_edu`n'
		
		drop USsurvey_a_`a' USemployee_a_`a'
		
		gen er_USweights_a_`a'_edu`n' = er_a_`a'_edu`n' * ageshare_er_a_`a'_edu`n'
		gen hwe_USweights_a_`a'_edu`n' = hwe_a_`a'_edu`n' * ageshare_hwe_a_`a'_edu`n'

		global er_USweights $er_USweights er_USweights_a_`a'_edu`n'
		global hwe_USweights $hwe_USweights hwe_USweights_a_`a'_edu`n'

		*display `er_USweights'
		}	//Edu loop
	} 	//ages loop

*** Generating new weighted er, hwe, hwp ***

** Use US age/gender shares for calculation new er
egen er_a_non_young_USage_edu = rowtotal($er_USweights), missing

** Use US age/gender shares for calculation of hwe
egen hwe_a_non_young_USage_edu = rowtotal($hwe_USweights), missing

** Resulting hwp
gen hwp_a_non_young_USage_edu = er_a_non_young_USage_edu*hwe_a_non_young_USage_edu

global master_stats $master_stats er_a_non_young_USage_edu hwp_a_non_young_USage_edu hwe_a_non_young_USage_edu 
	
} //Statistic 16: US Educ/Industry weighted statistics


***********************************************************
*Statistic 17: Share of people in wage/self em ployed, 
***********************************************************
if `s' == 17 {		

if  "`country'"=="AUT" | "`country'"=="BEL" | "`country'"=="BGR" | "`country'"=="CHE" | "`country'"=="CYP" | "`country'"=="CZE" | "`country'"=="DEU" | "`country'"=="DNK" | "`country'"=="EST" | "`country'"=="ESP" | "`country'"=="FIN" | "`country'"=="FRA" | "`country'"=="GRC" | "`country'"=="HUN" | "`country'"=="IRL" | "`country'"=="ITA" | "`country'"=="LTU" | "`country'"=="LUX" | "`country'"=="LVA" | "`country'"=="NLD"  | "`country'"=="POL" | "`country'"=="PRT" | "`country'"=="ROM"  | "`country'"=="SVN" | "`country'"=="SVK" | "`country'"=="GBR" | "`country'"=="ALB" | "`country'"=="BWA" | "`country'"=="GHA" | "`country'"=="ECU" | "`country'"=="IDN" | "`country'"=="MUS" | "`country'"=="MWI" | "`country'"=="NAM"  | "`country'"=="UGA" | "`country'"=="PAK" | "`country'"=="KHM" | "`country'"=="COL" | "`country'"=="IRQ" | "`country'"=="RWA" | "`country'"=="KEN" | "`country'"=="VNM" | "`country'"=="TLS" | "`country'"=="TUR" | "`country'"=="TZA" | "`country'"=="MNG" | "`country'"=="PER" | "`country'"=="USA" { 		//| "`country'"=="NOR" | "`country'"=="SWE"	
	
	gen sh_wj_ws = wgt_wj/wgt_ws 				//Captures fraction of employees in total working population
		label variable sh_wj_ws "Share of work status ''Employee'' (from tot. avail. work status)"
	gen sh_se_ws = wgt_se/wgt_ws 				//Captures fraction of self employed in total population
		label variable sh_se_ws "Share of work status ''Self Employed'' (from tot. avail. work status)"		

	gen indic = wgt if (emp_wj == . | emp_se == .) & employed == 1
	egen wgtsum = total(indic),m
	gen sh_na_emp = wgtsum/wgt_emp
		label variable sh_na_emp "Share of work status not available (from all employed)"
		sum sh_na_emp 
		if r(N) == 0 {
			replace sh_na_emp = 0			//Replace to zero if there are no missings
		}
	
	gen sh_wj_emp = wgt_wj/wgt_emp
		label variable sh_wj_emp "Share of work status employee (from all employed)"
	
	gen sh_se_emp = wgt_se/wgt_emp
		label variable sh_se_emp "Share of work status self employed (from all employed)"
	
	local edu_sh sh_wj_emp sh_se_emp sh_wj_ws sh_se_ws sh_na_emp
	
	*Share of employed/self-employed in education group, (from avail. work status)
	forvalues n = 1/5 {
	if `n' == 4 {
		replace edu = 4 if edu == .
	}
	if `n' == 5 {
		replace edu = 5 if inrange(edu,1,3)
	}
	
		foreach v in wj se {
		gen `v' = wgt if emp_`v' == 1 & edu == `n'
			egen `v'_wgt = total(`v'),m
		
		gen i = wgt if (emp_wj == 1 | emp_se == 1) & edu == `n'
			egen edu_wgt = total(i),m
			
		gen sh_`v'_ws_edu`n' = `v'_wgt/edu_wgt
			label variable sh_`v'_ws_edu`n' "Share work status = `v' in educ == `n', from tot. avail. work status"
			
		drop `v' `v'_wgt i edu_wgt
		local edu_sh `edu_sh' sh_`v'_ws_edu`n'
		
		}	
	}
	
	/*
	if "`country'" == "TLS"  {
		foreach j in wj se {
			foreach s in ws emp {
			replace sh_`j'_`s' = .			//We only have work status for employees, not self employed
			}
		}
		
	} */
	
	global master_stats $master_stats `edu_sh' 
}

} 	//Statistic 17: Share of employment etc

} //Statistics Loop

	keep if _n == 1
	capture noisily keep $master_stats
	
	merge 1:1 country using "Data\Cleaned_data\repl_master_stats.dta" , nogen
	save "Data\Cleaned_data\repl_master_stats.dta", replace
	
	*qui do
	
****************************	
} //Countries loop


****Timeuse Statistics****
foreach country in `countries' {

foreach s in `statistics' {	
if `s' == 50 {		//Timeuse Hours

if "`country'" == "BEN"  | "`country'" == "EGY" | "`country'" == "EGY"| "`country'" == "GHA"| "`country'" == "GTM" |"`country'" == "IRQ" | "`country'" == "LSO" | "`country'" == "MLI" | "`country'" == "RWA"  | "`country'" == "PAK" | "`country'" == "RUS"  | "`country'" == "FRA" | "`country'" == "DEU" | "`country'" == "NLD" | "`country'" == "ESP" | "`country'" == "GBR" | "`country'" == "USA" | "`country'" == "ITA" | "`country'" == "ZAF" | "`country'" == "AUT" | "`country'" == "MNG" | "`country'" == "KGZ" | "`country'" == "CHN" | "`country'" == "KAZ" | "`country'" == "TLS" {
display "`country'"
use "Data\Cleaned_data/`country'_timeuse.dta", clear

local variables cooking cleaning childcare shopping collwf 
local ages_1 all prime non_prime young old 

global timeuse_stats country

	capture noisily rename coll_wf collwf

	
*For MTUS countries, generate participation variable	
if  "`country'" == "AUS" | "`country'" == "FRA" | "`country'" == "DEU" | "`country'" == "NLD" | "`country'" == "ESP" | "`country'" == "GBR" | "`country'" == "USA" | "`country'" == "ITA" | "`country'" == "ZAF" | "`country'" == "AUT"  {
	gen p_collwf = 1
}	

capture noisily rename goods_services shopping
*capture noisily gen collwf = .

sum wgt
if r(N) == 0 {
	replace wgt = 1
}

foreach v in `variables' { 	//Induce participation rates for those countries where not asked, by looking at positive vs. zero hours
	capture noisily	gen p_`v' = .
	
		replace p_`v' = 1 if (`v' > 0 & `v' != .) & p_`v' == .
		replace p_`v' = 0 if (`v' == 0) & p_`v' == .

	
	foreach a in `ages_1' {
		sum `v' if age_`a' == 1 & p_`v'==1 & year >= 1990 [aweight=wgt]
		gen `v'_a_`a'_m = r(mean)
	
		sum p_`v' if age_`a' == 1 & year >= 1990 [aweight=wgt]
		gen p_`v'_a_`a'_m = r(mean)
		
	*By Genders
		sum `v' if age_`a' == 1 & p_`v'==1 & male==1 & year >= 1990 [aweight=wgt]
		gen `v'_m_`a'_m = r(mean)
		sum p_`v' if age_`a' == 1 & male==1 & year >= 1990 [aweight=wgt]
		gen p_`v'_m_`a'_m = r(mean)
				
		sum `v' if age_`a' == 1 & p_`v'==1 & male==0 & year >= 1990 [aweight=wgt]
		gen `v'_f_`a'_m = r(mean)
		sum p_`v' if age_`a' == 1 & male==0 & year >= 1990 [aweight=wgt]
		gen p_`v'_f_`a'_m = r(mean)
		
	
		*Generate unconditional hours
		foreach g in `genders' {
			gen `v'_`g'_`a'_uc = `v'_`g'_`a'_m * p_`v'_`g'_`a'_m 
		}	//Genders
	
	} 	//ages_1
}	//variables local
		
	foreach g in `genders' {
		foreach a in `ages_1' {
			egen total_hrs_`g'_`a' = rowtotal(cooking_`g'_`a'_m cleaning_`g'_`a'_m childcare_`g'_`a'_m shopping_`g'_`a'_m collwf_`g'_`a'_m ), missing
			egen total_hrs_`g'_`a'_uc = rowtotal(cooking_`g'_`a'_uc cleaning_`g'_`a'_uc childcare_`g'_`a'_uc shopping_`g'_`a'_uc collwf_`g'_`a'_uc ), missing			
		} //ages_1
	}	//genders
	
	
	global timeuse_stats $timeuse_stats cooking_a_all_m-total_hrs_f_old_uc

	keep if _n == 1
	keep $timeuse_stats
	
	merge 1:1 country using "Data\Cleaned_data\repl_master_stats.dta" , nogen
	save "Data\Cleaned_data\repl_master_stats.dta", replace
	
	}	//Countries for timeuse
  }	//Statistic 50
} //Statistics loop

} //Countries loop

	
***************************************************
use "Data\Cleaned_data\repl_master_stats.dta", clear

*Labeling all variables
local variables hwe er hwp //pop
local genders a m f
local ages all young prime old non_prime old_56_64 old_65_99 15_64 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 85plus		/*Add age category also to line 361 363*/

local all_min = 15
local all_max = 99
local young_min = 15
local young_max = 24
local prime_min = 25
local prime_max = 55
local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			
local old_min = 56
local old_max = 99
local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64


local a All
local m Males
local f Females
local hwp Hours Worked per Capita
local hwe Hours Worked per Employed
local er Employment Rates
local pop Number of Obs. aged 

foreach v in `variables' {
	foreach age in `ages' {
		foreach g in `genders' {
		
			if "`age'" == "all" | "`age'" == "young" | "`age'" == "prime" | "`age'" == "old" | "`age'" == "non_prime" {
				label variable `v'_`g'_`age' "``v'', ``g'' ``age'_min'-``age'_max'" 
			}
			if "`age'" != "all" & "`age'"!="young" & "`age'"!="prime" & "`age'"!="old" & "`age'"!="non_prime" {
				label variable `v'_`g'_`age' "``v'', ``g'' `age'" 
			}	
			
		}
	}
}
local main_ages all young prime old non_prime non_young
local ages all young prime old non_prime non_young old_56_64 old_65_99 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 85plus 15_64		/*Add age category also to line 361 363*/

local variables hwe er hwp //pop


foreach v in `variables' {
	foreach age in `main_ages' {
		forvalues n = 1/5 {
			if `n' == 1 {
			label variable `v'_a_`age'_edu`n' "Less than Highschool, `v' `age'"
			}
			if `n' == 2 {
			label variable `v'_a_`age'_edu`n' "Highschool, `v' `age'"
			}
			if `n' == 3 {
			label variable `v'_a_`age'_edu`n' "More than Highschool, `v' `age'"
			}
			if `n' == 4 {
			label variable `v'_a_`age'_edu`n' "Missing Education, `v' `age'"
			}
			if `n' == 5 {
			label variable `v'_a_`age'_edu`n' "Non-Missing Education, `v' `age'"			
			}
		}
	}
}


foreach age in `main_ages' {
	forvalues n = 1/3 {
		if `n' == 1 {
		label variable hwe_a_`age'_ind`n' "Agriculture, HWE `age'"
		}
		if `n' == 2 {
		label variable hwe_a_`age'_ind`n' "Manufacturing, HWE `age'"
		}
		if `n' == 3 {
		label variable hwe_a_`age'_ind`n' "Services, HWE `age'"
		}
	}
}
	 
 **********************************************************************************
 *** Generate our Core Group Variable ***
 **********************************************************************************
	
* 1)Countries belonging to Core Group depending on survey timeframes
	merge 1:1 country using "Data\Cleaned_data\list4", nogen update
	keep if coreDummy!=. 		//kicks out all countries merged with timeframes that are NOT in Masterhours programming

	forvalues n=1/4 {
	replace list`n'=0 if list`n'==.
	}

	label variable list1 "All countries except those for which we for sure do not cover the entire year"
	label variable list2 "Countries for which we for sure cover the entire year"
	label variable list3 "All countries where we for sure do not cover the entire year "
	label variable list4 "CodeDummy for all countries available"
 
 	*We replace coreDummy to zero, if hours are actual, but survey timeframe does not suffice for coregroup classification
	replace coreDummy=0 if list1==0 & coreDummy==1
 
	*We include in group 2 of robustness check all countries where we have actual hours, irrespective of survey timeframe
	*replace robustDummy=2 if coreDummy==1
	
* 2)Countries with less than 1 Mio. inhabitants & country surveys with less than 5K observations (though lowest amount we have is 7224 & 7288 for KAZ & ARM)
	drop if pop<1000				//countries dropped: ISL, LCA, LUX, MLT
  
 order country countryname region coreDummy gdppc ln_gdppc er* hwe* hwp*
  drop if country == "ARG" | country == "NOR"  | country == "KOR" | country == "ISL" | country == "LCA" | country == "LUX" | country == "MLT" |  country == "CHN"

saveold "Data\Cleaned_data\repl_master_stats", replace version(12)





