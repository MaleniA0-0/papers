******************************************************************************************
* Program: KHM_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Cambodia
******************************************************************************************

use "Data\Cambodia\CSES 2011\Data\KHM_Merged", clear 

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=hhid
replace pid=q01ac01
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if q01ac06 == 1 //Reference Person
replace hh_link = 2 if q01ac06 == 2 //Spouse
replace hh_link = 3 if q01ac06 == 3 | q01ac06 == 4 | q01ac06 == 5 | q01ac06 == 10 | q01ac06 == 8 //child, Child in law, step child, grand child
replace hh_link = 4 if  q01ac06 == 6 | q01ac06 == 12 //Ascendant (parent, grand parent)
replace hh_link = 98 if  q01ac06 == 14 | q01ac06 == 15 //Not related
replace hh_link = 99 if  q01ac06 == 7 | q01ac06 == 9 | q01ac06 == 11 | q01ac06 == 13 //Others (brother/sister, newphew/niece)


*-----------------------------------------

* Age 	
gen age=q01ac05

* Gender
replace male=1 if q01ac03==1
replace male=0 if q01ac03==2

*-----------------------------------------

* Weight 
replace wgt=pw11a
gen hh_wgt = hw11a

* Interview date
replace refdatex=0
replace startdate=mdy(1,1,2011)	
replace enddate=mdy(12,29,2011)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if Q02C07==1
replace educ=0 if Q02C07==2
gen educlvl=.
replace educlvl=1 if Q02C08==15 | Q02C08==16
replace educlvl=0 if Q02C08<=14

*drop if q01ac05 < 15 | q01ac05 > 60		//This is why weight was 1!
gen edu = .
replace edu = 1 if inrange( Q02C06, 0,8)
replace edu = 2 if inrange( Q02C06, 9,13)
replace edu = 3 if inrange( Q02C06, 14,20)

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe: Age 5 and above */
replace emp=0 if q15_c03==2 & q15_c04==2
replace emp=1 if q15_c03==1 | q15_c04==1
replace emp=2 if q15_c03==2 & q15_c04==1

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*Work status
replace emp_wj = 1 if q15_c08 == 1
replace emp_se = 1 if inrange(q15_c08,2,4)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* All jobs (main + sec + additional jobs)

* Actual hours worked in past 7 days
replace ahrswk_aj=q15_c19
replace ahrswk_aj=0 if q15_c19==. & (emp==0 | emp==2)

*-----------------------------------------

* Main job

* Actual hours worked in past 7 days
replace ahrswk_mj=q15_c09
replace ahrswk_mj=0 if q15_c09==. & (emp==0 | emp==2)

* Actual days worked in past month
replace adaysmth_mj=q15_c10a
replace adaysmth_mj=0 if q15_c10a==. & (emp==0 | emp==2)

*-----------------------------------------

* Second and additional job

* Actual hours worked in past 7 days in second and additional jobs 
egen sjhrs=rowtotal(q15_c16 q15_c18a), missing
replace ahrswk_sj=sjhrs
replace ahrswk_sj=0 if sjhrs==. & (emp==0 | emp==2)

* Actual days worked in past month in sec job only
replace adaysmth_sj=q15_c17a
replace adaysmth_sj=0 if q15_c17a==. & (emp==0 | emp==2)


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk adaysmth

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

destring q15_c06b, replace
replace mj_wj=1 if q15_c08==1
replace mj_sa=1 if (q15_c08>=2 & q15_c08<=4) & (q15_c06b>=111 & q15_c06b<1000 )
replace mj_sn=1 if (q15_c08>=2 & q15_c08<=4) & (q15_c06b>=1000 & q15_c06b<=9600)
replace mj_sx=1 if (q15_c08>=2 & q15_c08<=4) & q15_c06b>9600
replace mj_uc=1 if q15_c08==5

destring q15_c13b, replace
replace sj_wj=1 if q15_c15==1
replace sj_sa=1 if (q15_c15>=2 & q15_c15<=4) & (q15_c13b>=111 & q15_c13b<1000)
replace sj_sn=1 if (q15_c15>=2 & q15_c15<=4) & (q15_c13b>=1000 & q15_c13b<=9600)
replace sj_sx=1 if (q15_c15>=2 & q15_c15<=4) & q15_c13b>9600
replace sj_uc=1 if q15_c15==5

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*Incomes: We have first and second, not additional wage job hours, but total wage job income!
replace ahrswk_wj_mj = ahrswk_mj if q15_c08==1												//Main job is wage
replace ahrswk_wj_aj = ahrswk_mj if q15_c08==1 & q15_c11 == 0								//Main wage job is only job
replace ahrswk_wj_aj = ahrswk_wj if (q15_c11 == 1 & q15_c15==1)				 				//Main plus one additional wage job				

replace flag_set1 = 1 if q15_c08==1 & q15_c11 == 0											//Only one job that is wage
replace flag_set2 = 1 if flag_set1 == 1 | (q15_c08==1 & q15_c11 == 1 & q15_c15==1 )			//Only two jobs, both wage. 3 wage jobs? Not possible! Don't know total wage job hours.
*We cannot code anyone to set three since we do not knwo for sure total wage hours (no ws for third/fourth job)
replace flag_set3 = 1 if flag_set2 == 1 | (q15_c08==1 & q15_c11 == 1 & (q15_c15==2 | q15_c15 == 3 | q15_c15 == 4 | q15_c15 == 5))
*Since secondary occupation is se, we must already have total hours in wj

egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m
gen diff1 = ahrswk_wj_mj - hrs
sum diff1 if flag_set1 == 1
gen diff2 = ahrswk_wj_aj - hrs
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1

*-----------------------------------------

* Commuting and meal hours															/* Not stated */
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------

gen ind = .
destring q15_c06b, replace
replace ind = 1 if inrange( q15_c06b, 0111,0322)
replace ind = 2 if inrange( q15_c06b, 0510,3900)
replace ind = 3 if inrange( q15_c06b, 4100,9900)

*-----------------------------------------
*Income: Wage job
*-----------------------------------------
replace inc_wj_aj_tot_o = q15_c20 if (q15_c08 == 1 & q15_c15 ==  .) | (q15_c08 == 1 & q15_c15 == 1)	//Only for employees,  monthly earnings in salaries/wages from main plus seocnd wage economic activities

*-----------------------------------------
*Income: Self employed (HH level)
*-----------------------------------------
*1) Generate profits on Household non-agricultural income activities	
	*--> The below variables are collapsed(sum) summing over all accounting positions for hh enterprises (see merge dofile)
forvalues n = 3/7 {		//Loop over the non-agricultural activities Q05H3C03-Q05H3C07
	gen profits_`n' =   Q05H3C0`n' - Q05H2C0`n'
}

egen var1 = rowtotal(profits_3 profits_4 profits_5 profits_6 profits_7), m
	gen inc_se_na = var1/12								//HH enterprises is on 12 month basis

*2) HH Farmincome (LEO) 
egen revenues = rowtotal(croprevenue livestockrevenue fishrevenue forestryrevenue),m
egen costs = rowtotal(cropcosts livestockpurchases livestockcosts fishcosts forestrycosts),m
gen inc_se_a = (revenues - costs)/12					//HH farming enterprises is on 12 month/Past dry & wet season basis

*-----------------------------------------
*Household income
*-----------------------------------------
bysort hid: egen hh_wj = total(q15_c20),m			//Bring wage income to hh_level
	
egen var2 = rowtotal(hh_wj inc_se_na inc_se_a ),m	
	replace inc_hh = var2
	
*order hid pid inc_wj_o hh_wj inc_se_na inc_se_a inc_hh	//hh_enterprises is on hh level.
sum inc_wj_aj_tot_o inc_se_a inc_se_na inc_hh

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx   ahrsday_aj-hh_wgt 
