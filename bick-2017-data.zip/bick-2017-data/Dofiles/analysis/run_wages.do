do Dofiles/analysis/construct_gdpph

global path="do Dofiles/analysis/ind_wages"

* Construct data
${path}/construct_simplified_wj_world_data

* Basic world regression table (incl. self-employment & some robustness checks)
${path}/world_regression

* Country betas
${path}/country_regressions

* Robustness check for countries with actual and usual hours
${path}/country_regressions_robust_usual_hours

* Decile figure
${path}/graphs_inc_wj

* Overview Table
${path}/overview_table

*********************************
global path="do Dofiles/analysis/hh_wages"

quiet{
* Construct data
${path}/construct_simplified_wjse_world_data

* Country betas
${path}/country_regressions_wjse

* Decile figure
${path}/graphs_inc_wjse

* Overview Table
${path}/overview_table_wjse
}

*********************************

* Constructs decile_hours_wages, which is made publicly available
do Dofiles/analysis/construct_decile_hours_wages_dataset

* Constructs country-specific ratio of income per worker (based on wages in paid employment and self-employment) to compute ratios of income per worker over GDP per worker.
do Dofiles/analysis/checking_income
