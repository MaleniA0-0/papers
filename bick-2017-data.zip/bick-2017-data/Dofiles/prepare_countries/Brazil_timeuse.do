clear

use "Data\Brazil\PNAD 2009\Data\PNAD_PES2009.dta" 
 

***************************************************
* Standard Variables:
	*1) Age	
		rename V8005 age
	*2) Country
		gen country = "BRA"
	*3) Gender
		gen male=.
		replace male=1 if V0302==2
		replace male=0 if V0302==4
	*4) Year
		gen year = 2009
	*5) Weight
		gen wgt = V4729
	
*________________________________________________________________________________________

*Data we need: Four categories
	
	*1) Cooking  (av6)
		gen cooking = .
		
	*2) Cleaning/Housework (av7)
		gen cleaning = .					
		
	*3) Childcare (Av11)
		gen childcare = .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .		
	
	*5) Sum of four variables
		gen hrs_hw = V9921
		
keep age country male year cooking-hrs_hw

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}

save "Data/Cleaned_data/BRA_timeuse.dta", replace


