*To merge Peru Subfiles

use "Data\Peru\ENAHO 2004 & 2010\2010\279-Modulo05\enaho01a-2010-500.dta" , clear

merge 1:1 conglome vivienda hogar codperso using "Data\Peru\ENAHO 2004 & 2010\2010\279-Modulo03\enaho01a-2010-300.dta" 

save "Data\Peru\ENAHO 2004 & 2010\2010\PER_merged.dta", replace
