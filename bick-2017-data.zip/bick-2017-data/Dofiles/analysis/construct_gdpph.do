use Data/Cleaned_data/repl_master_stats, clear

keep if coreDummy==1
keep country refyear gdppc_${z} q_${z} ///
hwp_a_all hwe_a_all er_a_all ///
N_adult* sh_wj_emp sh_mwj_ws_hr_all sh_na_emp sh_wj_ws sh_mwjse_ws_hr_all

rename refyear year
replace country="TMP" if country=="TLS"
merge 1:1 country year using Data/External_data/wdi_pop_share_15plus
replace country="TLS" if country=="TMP"
drop if _merge==2

gen gdppa=gdppc_${z}/pop_share_15plus
gen gdppe=gdppa/er_a_all
gen gdpph=gdppa/hwp_a_all/52

keep country gdp* pop_share_15plus year q_${z} ///
hwp_a_all hwe_a_all er_a_all ///
N_adult* sh_wj_emp sh_mwj_ws_hr_all sh_na_emp sh_wj_ws sh_mwjse_ws_hr_all

rename country countrycode
replace country="ROU" if country=="ROM"
merge 1:1 country year using Data/External_data/pwt90, keepusing(pop)
tab _merge
drop if _merge==2
drop _merge
replace country="ROM" if country=="ROU"
rename countrycode  country

* Use PWT 7.1 values for Timor Leste
replace pop=1.086174 if country=="TLS" 
gen weight_pop=1

save Data/gdpph, replace

