*******************************************************************************************
* Program: KGZ_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Kyrgyzstan
*******************************************************************************************
use "Data\Kyrgyzstan\LSMS 1998\Data\KGZ_merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hid=string(fprimary)
replace pid=pidb
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=a0105a if a0105b==. 
replace age=a0105a + a0105b/12 if a0105b~=.

* Gender
replace male=1 if a0102==1
replace male=0 if a0102==2

*-----------------------------------------

* Weight
replace wgt=expfact

* Interview date																	/* Data collection period */
replace refdatex=0
replace startdate=mdy(10, 1, 1998)
replace enddate=mdy(11, 30, 1998)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.
*Problem here is only children living elsewhere are asked wether they are still in school; Variable classification unclear

******************************************
* Market work																		/* Universe: Age 7 and above */
******************************************

* Employment status (market work) in the last 7 days
replace emp=2 if a0502==2 & a0503==1
replace emp=1 if a0502==1 | a0504==1 | a0505==1
replace emp=0 if a0502==2 & a0504==2 & a0505==2
replace emp=0 if emp==. & (a0502==2 | a0504==2 | a0505==2)							/* To adjust those respondents who only gave answers to some of the questions */

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1 
replace reason=1 if emp==2

*-----------------------------------------

* Main job

* Actual hours worked in last 7 days
replace ahrswk_mj=c0503
replace ahrswk_mj=0 if (emp==0 | emp==2) & c0503==.

* Actual days worked in last 7 days	
replace adayswk_mj=c0502
replace adayswk_mj=0 if (emp==0 | emp==2) & c0502==.

* Actual months worked in last 12 months
replace mthsyr_mj=c0505
replace mthsyr_mj=0 if (emp==0 | emp==2) & c0505==.

* Usual hours worked per week in last 12 months
replace uhrswk_mj=c0506
replace uhrswk_mj=0 if (emp==0 | emp==2) & c0506==.

*-----------------------------------------

* Sec job

* Actual hours worked in last 7 days
replace ahrswk_sj=d0503
replace ahrswk_sj=0 if (emp==0 | emp==2) & d0503==.

* Actual days worked in last 7 days	
replace adayswk_sj=d0502
replace adayswk_sj=0 if (emp==0 | emp==2) & d0502==.

* Actual months worked in last 12 months
replace mthsyr_sj=d0504
replace mthsyr_sj=0 if (emp==0 | emp==2) & d0504==.

* Usual hours worked per week in last 12 months
replace uhrswk_sj=d0505
replace uhrswk_sj=0 if (emp==0 | emp==2) & d0505==.


******************************************
* Non-market work
******************************************

* Actual hours worked in non-market work yesterday 									/* Gathering water and fuel for HH use */
replace ahrsday_nm=h0504

******************************************
* Hours worked by job characteristics
******************************************

* Generate indicators for main and sec job nature
local jobs mj sj
local nature wj sa sn sx uc
local time ahrswk adayswk mthsyr uhrswk

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if c0512==1 | c0512==2 | c0512==6
replace mj_sa=1 if (c0512>=3 & c0512<=5) & c0501==1
replace mj_sn=1 if (c0512>=3 & c0512<=5) & (c0501>=2 & c0501<=9)
replace mj_sx=1 if (c0512>=3 & c0512<=5) & c0501==.
replace mj_uc=1 if c0512==.

replace sj_wj=1 if d0509==1 | d0509==2 | d0509==6
replace sj_sa=1 if (d0509>=3 & d0509<=5) & d0501==1
replace sj_sn=1 if (d0509>=3 & d0509<=5) & (d0501>=2 & d0501<=9)
replace sj_sx=1 if (d0509>=3 & d0509<=5) & d0501==.
replace sj_uc=1 if d0509==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

replace ahrsday_sa=ahrsday_nm

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2																	/* Not stated */
replace chrsx=2

replace c0537a=. if c0537a==99
replace c0537b=. if c0537b==99
gen c0537bx= c0537b/60
egen ctot=rowtotal(c0537a c0537bx), missing
replace chrsday=ctot*2

*-----------------------------------------
*Timeuse

	*1) Cooking & Cleaning, Housework  (av6)
		gen others = h0503*7  					/* cooking*/
		gen cooking=.
		
	*2) Cleaning/Housework (av7)
		gen cleaning = . 					/*laundry and cleaning the house*/
		
	*3) Childcare (Av11)
		gen childcare =  h0501*7
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services = .			/*going to market*/
		
	*5) Fetching water and fuel
		gen coll_wf = h0504*7
	
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(others cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl others cooking-hrs_hw
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
