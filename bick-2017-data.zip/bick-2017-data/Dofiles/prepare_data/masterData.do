**********************************************************************************************************
* Program: masterData.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos
*---------------------------------------------------------------------------------------------------------*
* Purpose: 	Loops over the raw country Datafiles to compute a final dataset containing harmonized employment/
*			hours/occupation/age groups/country income groups etc. These files are later used to generate 
*			our statistics. Prepare weights for counterfactual analyses.
* Structure: 
*			1) 	Harmonize the core & non-core Datasets (incl. EULFS data): Lines 22-615
*					a) 	Code actuals hours worked last week, dep. on the provided hours measure (aj: total 
*						hours, mj + sj: main + second job hours; actual vs usual); 
*					b)	Code usual hours if available, (for robustness checks lateron; 
*					c)	Harmonize employment status, include individuals employed but not working last week
*					d.1)Income: Code incomes from paid employment, generate consistent wage rates according
*						to avail. earnings variables (all vs. main vs main + additional paid employment 
*						earnings.
*						Add ppp conversion factors & other PWT GDp variables
*					d.2)Income: Code income and wage rates on HH level, and from paid + self employment 
*						activities
*					e)	Classify individuals into age groups for main analysis by age agroups
*			2) 	Harmonize the EUSILC data used for hours-wage analysis: Lines 620-1130
*					Structure follows (1)
*			3) 	Prepare data set with US age/educ/industry/age*educ weights 1131 ff., see 
*				Data/Cleaned_data/USA_weights_merged
*				
***********************************************************************************************************


clear 
set more off

*Set command directory to folder containing "replication_files"
*cd ""

* To facilitate the working process, countries have been saved in locals that 
* already distinguish between a country belonging to the core set or not.
local nc_countries 	AGO ALB ARG ARM AUS BEN	BIH BOL BRA	CAN	CHL	CHN	EGY GTM IDN ISL JAM JOR KAZ KGZ KOR LAO LCA LSO LUX MEX MLI MLT MYS NIC PAN PHL PRY RUS SLV SRB TAI TJK_07 TUN VEN ZAF 
local c_countries 	ALB_12 BWA COL ECU_05 GHA_98  IRQ KEN_05 KHM LAO MNG MUS MWI_04 NAM_09 PAK PER RWA TLS_07 TUR TZA UGA USA VNM_02 ZAF_08 AUT BEL BGR  ROM CHE CYP CZE DEU DNK ESP EST FIN FRA GBR GRC HUN IRL ITA LTU LVA NLD POL PRT SVK SVN SWE NOR
local countrysets c_countries nc_countries

quiet{

foreach set in `countrysets' {
  foreach country in ``set'' {

	display "`country' `v'"
	use "Data\Cleaned_data/`country'_raw.dta" ,replace
	
	qui do "Dofiles/missing_vars"								//Need to generate selected variables (income, edu) that are N/A for non-core & some core countries
	
	keep hid pid wgt male age hhsize numkids startdate enddate refday refweek refmonth refyear refdate emp ahrsday_aj-chrsday edu*  ind hh_link hh_wgt decile QUINTILE  inc_wj_mj_c_g-inc_hh emp_wj emp_se flag_set1-flag_set3 rep_hr_wage ahrswk_wj_aj ahrswk_wj_mj ind_tot_wjse
	order hid pid wgt male age hhsize numkids refday refweek refmonth refyear refdate emp ahrsday_aj-chrsday hh_link

	*Replace weights if missing
	if "`country'"=="CHN" | "`country'"=="KAZ" | "`country'"=="MUS" | "`country'"=="AGO" {		//no weight use for those where unavailable
		sum wgt
		if r(N) == 0 {
		replace wgt = 1
		}
	}

		sum hh_wgt
		if r(N) == 0 {
			replace hh_wgt = 1 				
		}
	
	gen tot_wgt = sum(wgt)														//Sum of all weights, has to be taken before we kick out < 15 years old!
	sum tot_wgt 
		replace tot_wgt = r(max)	
	
	bysort hid: egen hhtot_wgt = total(wgt),m
	
	drop if age < 15
	drop if age > 98
	
	bysort hid: egen hhtot15plus_wgt = total(wgt),m								//Household weight: Sum of weights for all ind. aged 15plus.

	gen coreDummy=0																//Set up the CoreDummy Variable
	gen robustDummy=0															//Set up Variable for robustness checks (Table 1 in Paper)
	
	*Core Group 1 
	if "`country'"=="ALB_12" | "`country'"=="ARM" | "`country'"=="AUT"  |"`country'"=="BEL" | "`country'"=="BEN" | "`country'"=="BIH" |"`country'"=="BGR" | "`country'"=="BWA" | "`country'"=="CHE" | "`country'"=="CHN" | "`country'"=="COL" | "`country'"=="CYP" | "`country'"=="CZE" | "`country'"=="DEU" | "`country'"=="DNK" | "`country'"=="ECU_05" | "`country'"=="ESP" | "`country'"=="EST" | "`country'"=="FIN" |  "`country'"=="FRA" | "`country'"=="GRC" | "`country'"=="GBR" |"`country'"=="GTM" | "`country'"=="HUN" | "`country'"=="IDN" | "`country'"=="IRL" |"`country'"=="ISL" | "`country'"=="ITA" |"`country'"=="KGZ" | "`country'"=="KHM" | "`country'"=="LTU" | "`country'"=="LUX" | "`country'"=="LVA" | "`country'"=="MLT" | "`country'"=="MUS" | "`country'"=="NAM" | "`country'"=="NLD" | "`country'"=="NOR" | "`country'"=="PAK" | "`country'"=="PAN" | "`country'"=="PER" | "`country'"=="POL" | "`country'"=="PRT" | "`country'"=="PRY" | "`country'"=="ROM" | "`country'"=="SRB" |"`country'"=="SVK" | "`country'"=="SVN" | "`country'"=="SWE" | "`country'"=="TAI" | "`country'"=="TJK_07" | "`country'"=="TUR" | "`country'"=="UGA" | "`country'"=="ZAF_08"  {
		egen hrs = rowtotal(ahrswk_mj ahrswk_sj), missing						//Standard Hours variable
		egen a_hrs_a = rowtotal(ahrswk_mj ahrswk_sj), missing					//ACTUAL hours ALL jobs
		gen a_hrs_m = ahrswk_mj
		
		replace coreDummy=1														//all actual hours (aj, mj+sj) surveys are core countries
		replace robustDummy=2													//all actual hours surveys are included in group 2 of robustness check
	}
	
	*Core Group 2
	if "`country'"=="CAN"  |  "`country'"=="GHA_98" | "`country'"=="IRQ" | "`country'"=="JAM" | "`country'"=="JOR" | "`country'"=="KAZ" | "`country'"=="KEN" | "`country'"=="LAO" |"`country'"=="LSO" | "`country'"=="LCA" | "`country'"=="MEX" | "`country'"=="MYS" | "`country'"=="NAM_09" | "`country'"=="NGA" | "`country'"=="NIC" | "`country'"=="PHL" | "`country'"=="RWA" | "`country'"=="SLV" | "`country'"=="TLS_07"  | "`country'"=="TUN" | "`country'"=="USA"| "`country'"=="VEN" | "`country'"=="ZAF" | "`country'"=="UGA_05" | "`country'"=="VNM_02" | "`country'"=="ZAF" {
		gen a_hrs_a = ahrswk_aj													//ACTUAL hours ALL jobs
		gen hrs = ahrswk_aj														//Our standard hours variable

		replace coreDummy=1														//all actual hours (aj, mj+sj) surveys are core countries
		replace robustDummy=2													//all actual hours surveys are included in group 2 of robustness check
	}
	
	*Core Group 3
	if    "`country'"=="MWI" | "`country'"=="MWI_04" | "`country'"=="TZA" | "`country'"=="KEN_05" | "`country'"=="MNG" {
		egen hrs = rowtotal(ahrswk_wj ahrswk_sn ahrswk_sa), missing				//Sum of different hours categories also make it into core
		replace coreDummy=1
		replace robustDummy=2
	}
	
	*Full 1
	if "`country'"=="CHL"| "`country'"=="NPL" | {
		gen a_hrs_m = ahrswk_mj													//ACTUAL hours MAIN job
		gen hrs = ahrswk_mj														// Since only main job, does not qualify for core
		replace robustDummy=2
	}
	

	*Calculation of Hours based on usual hours: Do not qualify as core because use usual hours
	*Full 2
	if "`country'"=="EGY" | "`country'"=="MLI" {
		gen hrs = uhrswk_aj														//Our standard hours variable
		gen u_hrs_a = uhrswk_aj													//USUAL hours ALL jobs
	}
	
	if "`country'"=="AUS" | "`country'"=="KOR" {
		gen hrs = uhrsyr_aj/52													//Our standard hours variable
		gen u_hrs_a = uhrsyr_aj/52												//USUAL hours ALL jobs
	}
	
	if "`country'"=="BRA" | "`country'"=="RUS" | "`country'"=="TUL"  {
		egen hrs = rowtotal(uhrswk_mj uhrswk_sj), missing 						//Our standard hours variable		
		egen u_hrs_a = rowtotal(uhrswk_mj uhrswk_sj), missing 					//USUAL hours ALL jobs
	}	
		
	if "`country'"=="AGO" {
		gen hrs_mj = uhrsday_mj*udayswk_mj
		gen hrs_sj = uhrsday_sj*udayswk_sj
		egen hrs = rowtotal(hrs_mj hrs_sj), missing								//Our standard hours variable		
		egen u_hrs_a = rowtotal(hrs_mj hrs_sj), missing							//USUAL hours ALL jobs
		drop hrs_mj hrs_sj
	}
	
	if "`country'"=="BOL"  {
		gen hrs_mj = uhrsday_mj*adayswk_mj
		gen hrs_sj = uhrsday_sj*adayswk_sj
		egen hrs = rowtotal(hrs_mj hrs_sj), missing								//Our standard hours variable
		egen u_hrs_a = rowtotal(hrs_mj hrs_sj), missing							//USUAL hours ALL jobs
		drop hrs_mj hrs_sj
	}	
		if "`country'"=="MWI"  {
		egen u_hrs_a = rowtotal(uhrswk_mj uhrswk_sj), missing					//Our standard hours variable for usual hours
	}
	
***Countries where we have actual hours already: Add Usual hours measures***
	if "`country'" == "ALB" | "`country'" == "BIH" | "`country'" == "MNG" | "`country'" == "TUR" | 	"`country'"=="ALB" | "`country'"=="USA" | "`country'"=="AUT_2011" | "`country'"=="BEL_2011" | "`country'"=="BGR_2011" | "`country'"=="CHE_2011" | "`country'"=="CYP_2011" | "`country'"=="CZE_2011" | "`country'"=="DEU_2011" | "`country'"=="DNK_2011" | "`country'"=="EST_2011" | "`country'"=="ESP_2011" | "`country'"=="FIN_2011" | "`country'"=="FRA_2011" | "`country'"=="GRC_2011" | "`country'"=="HUN_2011" | "`country'"=="IRL_2011" | "`country'"=="ITA_2011" | "`country'"=="LTU_2011" | "`country'"=="LUX_2011" | "`country'"=="LVA_2011" | "`country'"=="NLD_2011" | "`country'"=="NOR_2011" | "`country'"=="POL_2011" | "`country'"=="PRT_2011" | "`country'"=="ROM_2011" | "`country'"=="SWE_2011" | "`country'"=="SVN_2011" | "`country'"=="SVK_2011" | "`country'"=="GBR_2011" {
		gen u_hrs_m = uhrswk_mj													//USUAL hours MAIN job
		gen u_hrs_a=.
	}

	if "`country'" == "ARM" | "`country'" == "ZAF_08" | "`country'" == "ALB_12" | "`country'" == "KGZ" | "`country'" == "NAM" | "`country'" == "PRY" | "`country'" == "TLS" | "`country'" == "UGA" {
		gen u_hrs_m = uhrswk_mj													//USUAL hours MAIN job
		egen u_hrs_a = rowtotal(uhrswk_mj uhrswk_sj), missing					//USUAL hours ALL job	
		*gen u_hrs_s = uhrswk_sj												//USUAL hours SECOND job	
	}
	
	if "`country'" == "CHN" {
		gen u_hrs_m = uhrsday_mj*udayswk_mj										//USUAL hours MAIN job
		gen u_hrs_s = uhrsday_sj*udayswk_sj										//USUAL hours SECOND job
		egen u_hrs_a = rowtotal(u_hrs_m u_hrs_s), missing			
		drop u_hrs_s
	}

	if "`country'" == "PER" {
		gen u_hrs_a = uhrswk_aj													//USUAL hours ALL jobs
		gen u_hrs_m = .															//USUAL hours MAIN job
	}

	if "`country'" == "AUT" | "`country'" == "BEL" | "`country'" == "BGR" | "`country'" == "ROM" | "`country'" == "CHE" | "`country'" == "CYP" | "`country'" == "CZE" | "`country'" == "DEU" | "`country'" == "DNK" | "`country'" == "ESP" | "`country'" == "EST" | "`country'" == "FIN" | "`country'" == "FRA" | "`country'" == "GBR" | "`country'" == "GRC" | "`country'" == "HUN" | "`country'" == "ITA" | "`country'" == "LTU" | "`country'" == "LVA" | "`country'" == "NLD" | "`country'" == "POL" | "`country'" == "PRT" | "`country'" == "SVK" | "`country'" == "SVN" | "`country'" == "SWE" |  "`country'"=="IRL" |"`country'"=="ISL" | "`country'"=="LUX" | "`country'"=="NOR" {
		egen u_hrs_a = rowtotal(uhrswk_mj uhrswk_sj),m
		gen u_hrs_m = uhrswk_mj
	}


*For those countries where the narrower hours categories are missing
	capture noisily gen a_hrs_a = .												//ACTUAL hours ALL jobs
	capture noisily gen a_hrs_m = .												//ACTUAL hours MAIN job
	capture noisily gen u_hrs_a = .												//USUAL hours ALL jobs
	capture noisily gen u_hrs_m = .												//USUAL hours MAIN job

	drop if male == .
	
	local hours u_hrs_a u_hrs_m a_hrs_a a_hrs_m hrs
	foreach hrs in `hours' {
		replace `hrs' = 112 if `hrs' > 112 & `hrs' != . 						//Upper threshold for hours
	}
		
	gen employed = emp															// Generate employed variable
	replace employed = 0 if emp==0												// Unemployed
	replace employed = 1 if emp==1 												// Employed & Working
	replace employed = 1 if emp==2												// Employed but not workin in reference week
	
	* Replace missing employment status=1 for all those, where actual hours worked avail, but employment is missing
	local actualhrs ahrswk_mj ahrswk_sj ahrswk_aj
	foreach a in `actualhrs' {
		replace employed=1 if employed==. & `a'>0 & `a'!=.
	}
	replace employed=1 if employed==. &	(ahrsday_mj>0 & ahrsday_mj!=.) & (adayswk_mj>0 & adayswk_mj!=.)
	replace employed=1 if employed==. &	(ahrsday_sj>0 & ahrsday_sj!=.) & (adayswk_sj>0 & adayswk_sj!=.)
	
	if "`country'"=="MWI" | "`country'"=="MWI_04"{
	replace employed=1 if employed==. & hrs>0 & hrs!=.
	}
	
	*Weights for share of individuals in Paid/Self employment
	gen wgt_test = wgt if employed == 1
	egen wgt_emp = total(wgt_test),m
		label variable wgt_emp "Sum of weights for all emp == 1"
	drop wgt_test
	
	gen wgt_test = wgt if emp_wj == 1 & employed == 1
	egen wgt_wj = total(wgt_test),m
		label variable wgt_wj "Sum of weights for all employed with working status ''Employee'' "
	drop wgt_test
	
	gen wgt_test = wgt if emp_se == 1 & employed == 1
	egen wgt_se = total(wgt_test),m
		label variable wgt_se "Sum of weights for all employed with working status ''Self Employed'' "
	drop wgt_test
	
	egen wgt_ws = rowtotal(wgt_se wgt_wj),m
		label variable wgt_ws "Sum of weights for employed & non-missing work status"
		
*------------------------------------------------------------------------------------*
*Income:
local incvars
local hh_hours
	
	*Wage job income classifications
	gen inc_wj_aj = . 
		label variable inc_wj_aj "Income from all wage jobs"
	gen inc_wj_mj = .
		label variable inc_wj_mj "Income from main wage job"
	
	*1) All wage jobs: Captures total income from paid employment, irrespective of gross/net/unclear
	if  "`country'"=="VNM_02" | "`country'"=="KHM" | "`country'"=="GHA_98" | "`country'"=="TLS_07" | "`country'"=="MWI_04" {
		replace inc_wj_aj = inc_wj_aj_tot_o									//Other tax: not specified whether net or gross
	}
	if "`country'"=="RWA" | "`country'"=="IRQ" {
		replace inc_wj_aj = inc_wj_aj_tot_n									//net wage income
	}
	if  "`country'"=="COL"  |  "`country'"=="BWA" | "`country'"=="MNG" | "`country'"=="PER" | "`country'"=="UGA" | "`country'"=="ECU_05" {
		replace inc_wj_aj = inc_wj_aj_tot_g									//gross wage income
	}
	
	*2) Main wage job: Captures income from main paid employment, irrespective of gross/net/unclear
	if  "`country'"=="VNM_02" | "`country'"=="GHA_98" | "`country'"=="TZA" | "`country'"=="KEN_05" | "`country'"=="TLS_07" {
		replace inc_wj_mj = inc_wj_mj_tot_o 
		gen indic_sjwj = 0
		replace indic_sjwj = 1 if  inc_wj_aj> inc_wj_mj
	}
	if  "`country'" == "ALB_12" | "`country'"=="TUR" | "`country'"=="IDN" |  "`country'"=="PAK" |  "`country'"=="RWA" {
		replace inc_wj_mj = inc_wj_mj_tot_n				
	}
	if  "`country'"=="MUS" | "`country'"=="COL"   | "`country'"=="MNG" | "`country'"=="PER" | "`country'"=="USA" | "`country'"=="UGA" | "`country'"=="ECU_05"  {
		replace inc_wj_mj = inc_wj_mj_tot_g 
	}
	if "`country'"=="USA" {
		replace inc_wj_mj = inc_wj_mj_c_g
	}

	gen hrs_wj = .
		label variable hrs_wj "Hours spent in wage job, used for hr_wage computation"
	gen hr_wage = .
		label variable hr_wage "Hourly wage: Wage earnings/wage hours"
	gen hr_wage_wjse = .
		label variable hr_wage_wjse "Wage rate based on total individual income/total ind. hours"
	gen hr_wage_hh = .
		label variable hr_wage_hh "Wage rate based on total HH income/total HH hours"
	gen flag_set_nosj = 0
		label variable flag_set_nosj "Country-lvl flag: Only mj incomes are available" 
	gen flag_set_nose = 0
		label variable flag_set_nose "Country-lvl flag: No se incomes available"
	gen flag_set_hhse = 0
		label variable flag_set_hhse "Country-lvl: HH level self-employment income"


	*Merge with Penn World Table dataset containing ppp conversion rates in each country's respective survey year (variable refyear)
	gen country = "`country'" 	
	if "`country'" == "ALB_12" | "`country'" == "ZAF_08" |"`country'" == "VNM_02" | "`country'" == "GHA_98" | "`country'" == "TJK_07"| "`country'" == "KEN_05" | "`country'" == "ECU_05" | "`country'" == "NAM_09" | "`country'" == "TLS_07" | "`country'" == "MWI_04" {
		replace country = substr(country,1,3)
	}
	
	drop refyear
	merge m:1 country using "Data\external_data/PWT/pwt_v2.dta", keepusing(refyear pop_9y ngdp_e9y ngdp_o9y rgdp_e9y rgdp_o9y gdppc_e9ry gdppc_e9cy gdppc_o9ry gdppc_o9cy gdppc_e9r gdppc_o9r gdppc_e9c gdppc_o9c gdppc_e9ny gdppc_o9ny gdppe_e9ny gdppe_o9ny gdppe_e9ry gdppe_o9ry xr_9y ppp_r ppp_c)
	keep if _merge == 3
	drop country _merge

	*Generate share of employed based on Micro-data (to compare to PWT)
	gen wgt_empind = wgt if employed == 1
	egen tot_wgtemp = total(wgt_empind),m
	
	gen sh_emp = tot_wgtemp/tot_wgt
		label variable sh_emp "Share of population employed"
	gen tot_emp_9y = pop_9y*(tot_wgtemp/tot_wgt)
		label variable tot_emp_9y "Total # of persons engaged (based on Micro-Data)"
	
	*Generate GDP per employed based on share of employmed in microdata (to compare to PWT)
	foreach eo in e o {
	gen gdppe_`eo'9ny_md = ngdp_`eo'9y/tot_emp_9y
		label variable gdppe_`eo'9ny "GDP per employed, based on share of ind. employed (Micro-Data)"
	gen ln_gdppe_`eo'9ny_md = ln(gdppe_`eo'9ny_md)
	
	local incvars `incvars' gdppc_`eo'9ry gdppc_`eo'9cy gdppc_`eo'9ny gdppe_`eo'9ny gdppe_`eo'9ny_md gdppe_e9ry gdppe_o9ry
	}
	
if "`set'" == "c_countries" {													//Only use core countries
	local incvars inc_hh_pe inc_hh_pa inc_hh_hr

	*--------------------------------*
	*Household income & hour measures
	*--------------------------------*
	*Household income per working adult: Need to know how many employees in household
	gen indic = 1 if employed == 1
	bysort hid: egen hh_numemp = total(indic),m
	gen inc_hh_pe = .
	replace inc_hh_pe = inc_hh/hh_numemp if employed == 1						//Replace HH income per working adult only for workers
	
	*Household income per adult
	bysort hid: gen hhsize_adults = _N
		label variable hhsize_adults "# of adults in Household"
	
	gen inc_hh_pa = .
	replace inc_hh_pa = inc_hh/hhsize_adults
	
	*Household wage rate
	bysort hid: egen hh_hrs = total(hrs),m
	gen inc_hh_hr = inc_hh/(hh_hrs*52/12)										//Household wage rate: Monthly income/hours worked in hh per month!
	
	*Household hours
	gen hh_hrs_pe = hh_hrs/hh_numemp
		label variable hh_hrs_pe "HH hours per employed"
	gen hh_hrs_pa = hh_hrs/hhsize_adults
		label variable hh_hrs_pa "HH hours per adult"
	gen hh_emp = hh_numemp/hhsize_adults
		label variable hh_emp "Share of employed adults in HH"
	
	local `hh_hours' hh_hours hh_hrs_pe hh_hrs_pa hh_emp

	*-----------------------------------------------------------------------------------------------------*
	*Setting up a standard income variable for individual wage job income
	*Note: 	Individuals with positive earnings but emp == 2 (employed, but not 
	*		working past week) have missing wage rates!

	*-----------------------------------------------------------------------------------------------------*
	local incvar inc_wj	
	gen `incvar' = `incvar'_aj
		replace `incvar' = `incvar'_mj if `incvar'==.							//Use all wage job income if available, main job only if all N/A
		rename `incvar' `incvar'_mth											//Income is standardized to monthly in all country prepare dofiles
		label variable `incvar'_mth "Monthly income rate, based on `incvar'"
	
	gen `incvar'_hr = .
		label variable `incvar'_hr "Hourly wage rate, based on `incvar'"
	replace `incvar'_hr = `incvar'_mth/(hrs*52/12)								//Wage rate: Monthly earnings (mj, aj)/(total weekly hours*4.33). 
	
	gen hrs_u = .	
		label variable hrs_u "Usual hours worked"
	gen hrs_u_mj = u_hrs_m 
	gen hrs_u_aj = u_hrs_a 
	
	* Generate consistent wage rates:
	*	1. Only main paid employment earnings avsail.: Use main wage job hours
	*	2. All earnings from paid employment avail.: Use all wage job hours
	
	*Case 1: We have only main wage job income. We filter main wage job hours to generate consistent wage rate for those who have only one (i.e. the main) job (wage)
	gen flag_set4 = flag_set3

	if "`country'" == "ALB_12" | "`country'" == "KEN_05" |  "`country'" == "PAK" |  "`country'" == "IDN" |  "`country'" == "TUR" |  "`country'" == "MUS"  |  "`country'" == "USA" {
		replace hrs_wj = ahrswk_wj_mj 
		replace hrs_wj = 112 if hrs_wj > 112 & hrs_wj != .
		replace hr_wage = inc_wj_mj/(hrs_wj*52/12)								//Wage rate: Main paid employment earnings/main wage job hours
		replace flag_set4 = 1 if flag_set3 == 0
		
		replace hrs_u = hrs_u_mj												//For robustness check: Prioritize main job usual hours
		replace hrs_u = hrs_u_aj if hrs_u == .									//If mj_usual hours N/A, use total usual hours
	}
	
	*Case 2: We have all wage job income & all wage job hours
	if "`country'" == "TLS_07" | "`country'" == "IRQ" | "`country'" == "GHA_98" | "`country'" == "BWA" | "`country'" == "ECU_05" | "`country'" == "KHM" | "`country'" == "RWA" | "`country'" == "PER" | "`country'" == "UGA" | "`country'" == "COL" | "`country'" == "MNG" | "`country'" == "VNM_02" {
		replace hrs_wj = ahrswk_wj_aj
		replace hrs_wj = 112 if hrs_wj > 112 & hrs_wj != .
		replace hr_wage = inc_wj_aj/(hrs_wj*52/12)								//Wage rate: All paid employment earnings/all hours in paid employment
		
		replace hrs_u = hrs_u_aj												//For robustness check: For countries where we have total income, prioritize total usual hours
		replace hrs_u = hrs_u_mj if hrs_u == .									//if total N/A, then use main usual hours
	}
	
	*Add a new wage rate equal to wage rate in main (wage) job, now for all countries where avail.: 
	gen hr_wage_mj = .
	replace ahrswk_wj_mj = 112 if ahrswk_wj_mj > 112 & ahrswk_wj_mj != .	
	replace hr_wage_mj = inc_wj_mj/(ahrswk_wj_mj*52/12) if flag_set2 == 1 | flag_set3 == 1	//Main wage job income/main wage hours
	
	*-----------------------------------------------------------------------------------------------------*
	*Adding self employed earnings & wage earnings:
	*-----------------------------------------------------------------------------------------------------*
	*Case 1) Total self employed earnings avail., i.e. wage rate = total earnings/total hours 
	if "`country'" == "GHA_98" | "`country'" == "BWA" | "`country'" == "MNG" | "`country'" == "ECU_05" | "`country'" == "COL" | "`country'" == "PER"  {
		replace hr_wage_wjse = (ind_tot_wjse)/(hrs*52/12)
	
	}
	*Case 2): We know incomes are wj and se, but mj only. Use mj hours if possible
	if "`country'" == "ALB_12" | "`country'" == "MUS"  {
		replace hr_wage_wjse = (ind_tot_wjse)/(ahrswk_mj*52/12)
		sum ahrswk_mj
		if r(N) == 0 {
			replace hr_wage_wjse = (ind_tot_wjse)/(hrs*52/12)					//In case main job hours are N/A, use total hours
		}
		
		replace flag_set_nosj = 1
	}	
	*Case 3) No self employment incomes available
	if "`country'" == "PAK" | "`country'" == "TUR" | "`country'" == "USA" {
		replace flag_set_nose = 1 
		
	}
	*Case 4) Self employment income is HH based
	if "`country'" == "KHM" | "`country'" == "TLS_07" | "`country'" == "RWA" | "`country'" == "VNM_02" | "`country'" == "TZA" | "`country'" == "IRQ" | "`country'" == "UGA" | "`country'" == "MWI_04" | "`country'" == "KEN_05" {
		replace flag_set_hhse = 1
	}
	
	*HH wage rate and HH hours
	replace hr_wage_hh = inc_hh/(hh_hrs*52/12)									//Total avail. monthly household income/(total weekly hh hours * 4.33)

	
	local incvars `incvars' `incvar'_hr  `incvar'_mth hr_wage hr_wage_mj hrs_wj	hrs_u hrs_u_mj hrs_u_aj			//`incvar'_hr_c

	*Get incomes in same currency/ppp
	local incomes inc_wj_mj inc_wj_aj inc_hh inc_hh_pe inc_hh_pa inc_hh_hr inc_wj_mth inc_wj_hr hr_wage rep_hr_wage hr_wage_mj hr_wage_wjse	hr_wage_hh //inc_wj_hr_c
	foreach i in `incomes' {
		gen `i'_pppr = `i' * ppp_r												//PPP conversion based on real GDP conv. factor
		gen `i'_pppc = `i' * ppp_c												//PPP conversion based on current GDP conv. factor
		gen `i'_usd = `i'/xr_9y													//Conversion from national currency to USD
		
		rename `i' `i'_nom
		gen `i' = `i'_pppr														//Our standard variable
		
		local incvars `incvars' `i'_nom `i'_pppr `i'_pppc `i'_usd `i'
	}
	
*make sure every person in household has data for hh level variables! 
	foreach v in hh_hrs_pa hh_hrs_pe hh_emp {
		by hid: egen `v'_1 = max(`v')
		replace `v' = `v'_1
	}
}

capture noisily: gen flag_set4 = .												//For non-core countries

*-----------------------------------------------------------------------*

	
*Generate Age-group dummies
local all_min = 15
local all_max = 99

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56														/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56														/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98

local non_young_min = 25
local non_young_max = 98

local non_old_min = 15
local non_old_max = 55

*5 & 10 yr. Age-Groups
local 15_19_min = 15
local 15_19_max = 19

local 20_24_min = 20
local 20_24_max = 24

local 25_29_min = 25
local 25_29_max = 29

local 30_34_min = 30
local 30_34_max = 34

local 25_34_min = 25
local 25_34_max = 34

local 35_39_min = 35
local 35_39_max = 39

local 40_44_min = 40
local 40_44_max = 44

local 35_44_min = 35
local 35_44_max = 44

local 45_49_min = 45
local 45_49_max = 49

local 50_54_min = 50
local 50_54_max = 54

local 45_54_min = 45
local 45_54_max = 54

local 55_59_min = 55
local 55_59_max = 59

local 60_64_min = 60
local 60_64_max = 64

local 55_64_min = 55
local 55_64_max = 64

local 65_69_min = 65
local 65_69_max = 69

local 70_74_min = 70
local 70_74_max = 74

local 65_74_min = 65
local 65_74_max = 74

local 75_79_min = 75
local 75_79_max = 79

local 80_84_min = 80
local 80_84_max = 84

local 75_84_min = 75
local 75_84_max = 84

local 85plus_min = 85
local 85plus_max = 98

local 15_64_min = 15
local 15_64_max = 64
 

local ages all young prime old non_prime non_young non_old old_56_64 old_65_99 15_64 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 25_34 35_44 45_54 55_64 65_74 75_84 85plus		/*Add age category also to line 361 363*/
	
foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


    * Gen hh_head_education
	bysort hid: gen hh_head_edu = edu if hh_link == 1
	capture noisily: gen hh_head_edu = .



*Keep relevant data and save the harmonized datasets
local covars hid pid male age hhsize numkids startdate enddate refday refweek refmonth refyear refdate age_all-age_85plus edu* ind hh_head_edu hh_link 
local employ emp employed emp_wj emp_se wgt_emp wgt_ws wgt_wj wgt_se	//emp_ws
local wgts wgt hh_wgt tot_wgt hhtot_wgt hhtot15plus_wgt 
local pwt_vars xr_9y ppp_r ppp_c sh_emp tot_emp_9y
local flags robustDummy coreDummy flag_set1 flag_set2 flag_set3 flag_set4 flag_set_hhse flag_set_nose flag_set_nosj 
local hours `hours' hrs hrs_wj ahrswk_wj ahrswk_wj_mj ahrswk_wj_aj ahrswk_sn ahrswk_sa 

keep `covars' `employ' `wgts' `pwt_vars' `flags'  `hours' `hh_hours' `incvars' `gdpvars' inc_wj_mj_c_g- inc_se_aj_tot_o  

	
*Save datasets
*For those where we have different years available, save the relevant ones WITHOUT the year added
	if "`country'"=="TJK_07" {
		saveold "Data\Cleaned_data/TJK_all_std.dta",replace version(12)
	}
	if "`country'"=="GHA_98" {
		saveold "Data\Cleaned_data/GHA_all_std.dta",replace version(12)
	}
	if "`country'"=="VNM_02" {
		saveold "Data\Cleaned_data/VNM_all_std.dta",replace version(12)
	}
	if "`country'"=="KEN_05" {
		saveold "Data\Cleaned_data/KEN_all_std.dta",replace version(12)
	}
	if "`country'"=="TLS_07" {
		saveold "Data\Cleaned_data/TLS_all_std.dta",replace version(12)
	}
	if "`country'"=="NAM_09" {
		saveold "Data\Cleaned_data/NAM_all_std.dta",replace version(12)
	}
	if "`country'"=="ECU_05" {
		saveold "Data\Cleaned_data/ECU_all_std.dta",replace version(12)
	}
	if "`country'"=="MWI_04" {
		saveold "Data\Cleaned_data/MWI_all_std.dta",replace version(12)
	}
	if "`country'" == "ALB_12" {
		saveold "Data\Cleaned_data/ALB_all_std.dta",replace version(12)	
	}
	if "`country'" == "ZAF_08" {
		saveold "Data\Cleaned_data/ZAF_all_std.dta",replace version(12)	
	}	
	
	*** save standardized version of data
	if "`country'"!="TJK_07" & "`country'"!="GHA_98" & "`country'"!="VNM_02" & "`country'"!="KEN_05" & "`country'"!="TLS_07"  & "`country'"!="NAM_09"  & "`country'"!="ECU_05" & "`country'"!="MWI_04" & "`country'"!="ALB_12" & "`country'"!="ZAF_08" {
		saveold "Data\Cleaned_data/`country'_all_std.dta",replace version(12)
	}
	
	*}	//Age group loop

  }	//Countries loop
}	//country set loop
} 	//quiet




 
 

 ***********************************************************************************************************
* Harmonize EUSILC Data
***********************************************************************************************************

local countries  AUT BEL BGR  CHE CYP CZE DEU DNK ESP EST FIN FRA GBR GRC IRL HUN ITA LTU LVA NLD POL PRT ROM SVK SVN SWE // NOR
quiet {

foreach c in `countries'{

display "Country `c'"

quiet {
local y 2005

if "`c'" == "HUN" {
	local y 2006
}
if "`c'" == "ROM" | "`c'" == "LVA" {
	local y 2007
}
if "`c'" == "BGR"  | "`c'" == "GBR" {
	local y 2008
}
if  "`c'" == "IRL" {
	local y 2009
}
if "`c'" == "CHE" {
	local y 2010
}
use "Data\EU-SILC/`y'\Countries/silc_`c'", clear

	gen coreDummy=1						//all actual hours (aj, mj+sj) surveys are core countries
	gen robustDummy=2					//all actual hours surveys are included in group 2 of robustness check

	sum hh_wgt
		if r(N) == 0 {
			replace hh_wgt = 1 				
		}
	
	gen tot_wgt = sum(wgt)						//Sum of all weights, has to be taken before we kick out < 15 years old!
	sum tot_wgt 
	replace tot_wgt = r(max)	
	*Better: egen tot_wgt = total(wgt),m
	
	bysort hid: egen hhtot_wgt = total(wgt),m
	
	drop if age < 15
	drop if age > 98
	
	bysort hid: egen hhtot15plus_wgt = total(wgt),m

* Gender
gen male = .
replace male=1 if sex==1
replace male=0 if sex==2

*Employment
gen employed=.
replace employed = 0 if working == 2 
replace employed = 0 if working == . & (emp_status >= 3 & emp_status!= .) 
replace employed=1 if working==1 
replace employed = 1 if working == . & emp_status<=2
	label def employed 1 "Employed", replace
	label def employed 0 "Not Employed", add
	label values employed employed	

*Work Status
gen emp_wj = .
replace emp_wj = 1 if emp_type == 3 
gen emp_se = .
replace emp_se = 1 if emp_type == 1 | emp_type == 2 | emp_type == 4
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*Education in line with ELFS
	replace edu=1 if edu >= 0 & edu<2
	replace edu=2 if edu>=2 & edu<=4
	replace edu=3 if edu==5

*Usual hours in all jobs
	replace uhrswk_mj=0 if uhrswk_mj==.
	replace uhrswk_sj=0 if uhrswk_sj==.
	egen uhrswk_aj=rowtotal(uhrswk_mj uhrswk_sj), m
	
*Cap at 112 hours *
	replace uhrswk_aj=min(uhrswk_aj,112)
	
*Usual months in job per year?	
	
*Keep only if hours and work status are consistent; or positive usual hours but no earnings
	drop if uhrswk_aj==0 & employed==1
	replace ann_wj_earnings_g=. if uhrswk_aj>0 & ann_wj_earnings_g==0


*Join by external data on public holidays and vacation days to generate weeks to multiply with weekly hours	
	gen year = refyear	
	joinby year country using "Data\EU-SILC\2005/combine_all", unmatched(master)
	drop _merge
	drop emp_cb emp_oecd pop_* hwe* hwp* er_*
	gen weeks_m2=52-(dpubhol+daleave)/5
	drop year
	
	drop dpubhol* daleave* dill*

	
*New correction form: By correction factor EULFS a_hrs/EUSilc u_hrs
	merge m:1 country using "Notes\Paul\Checking for consistency\EU_SILC/LFS_vs_Silc.dta", keepusing(c_fac)
	keep if _merge == 3
	drop _merge
	
*Generate usual hours and corrected hours measure
	gen hrs = uhrswk_aj
	replace hrs = hrs*c_fac
	gen hrs_u_aj = uhrswk_aj
	gen hrs_u_mj = uhrswk_mj
	gen hrs_u = hrs_u_aj
	
*Employment/Self employment weights
	gen wgt_test = wgt if employed == 1
	egen wgt_emp = total(wgt_test),m
		label variable wgt_emp "Sum of weights for all emp == 1"
	drop wgt_test
	
	gen wgt_test = wgt if emp_wj == 1
	egen wgt_wj = total(wgt_test),m
		label variable wgt_wj "Sum of weights for all with working status ''Employee'' "
	drop wgt_test
	
	gen wgt_test = wgt if emp_se == 1
	egen wgt_se = total(wgt_test),m
		label variable wgt_se "Sum of weights for all with working status ''Self Employed'' "
	drop wgt_test
	
	egen wgt_ws = rowtotal(wgt_se wgt_wj),m
		label variable wgt_ws "Sum of weights for non-missing work status"
	
	
	
*Keep only people between ages 15 and 99 *
	keep if age>=15 & age<=99
	keep if wgt != .


*Set up individual earnings 
replace monthly_wj_earnings_g=monthly_wj_earnings_g*12							//This is employee income from main job
rename monthly_wj_earnings_g m_wj_y												//Monthly employee (main wj only)
	label variable m_wj_y "Monthly --> Annual main wage job earnings, py200g"

local mth_wj_avail
sum m_wj_y
local Num = r(N) 
local m = r(mean)
}
if `Num' > 0 & `m' > 0 {
	local mth_wj_avail yes
	display "Monthly Wage job income Available? `mth_wj_avail'"
}
if `Num' == 0 | ( `Num' > 0 & (`m' == 0 | `m' == .)) {
	local mth_wj_avail no
	display "Monthly Wage job income Available? `mth_wj_avail'"
	display "We use Aggregate Yearly Income"
}
quiet {
sum ann_wj_earnings_g								
local N = r(N)																	//py010g We exclude non-cash employee income!
	if  `N' == 0 {
		rename ann_wj_earnings_n a_wj_y											//Gross N/A, use net!
	}
	if  `N' > 0 {
		rename ann_wj_earnings_g a_wj_y											//Gross is avail. use it!
	}

label variable a_wj_y "Total wage earnings, py010g/py010n (total wj)"

	
sum ann_se_earnings_g
local N = r(N)
	if `N' > 0 {
		egen tot_se = rowtotal(ann_se_earnings_g ann_se_earnings_ikg),m
		gen a_se_y = tot_se
	}
	if `N' == 0 {
		egen tot_se = rowtotal(ann_se_earnings_n ann_se_earnings_ikn),m
		gen a_se_y = tot_se
	}
	label variable a_se_y "Annual self employment earnings, total py050g/n plus py070g/n (if avail.)"

foreach incvar in a_wj_y m_wj_y	a_se_y {
	//These countries are in € here and in € in PWT! 
	if "`c'" != "SVK" & "`c'" != "SVN" & "`c'" != "LVA" & "`c'" != "CYP" & "`c'" != "EST" & "`c'" != "LTU"  {		
		replace `incvar' = `incvar' * exchange_rate		//Conversion to national currency
	}
}

*Express everything in real US dollar 
	*merge m:1 country year using ExternalData/data/PPP, update keepusing(xrat ppp) keep(match master)
	merge m:1 country refyear using "Data\external_data/PWT/FebPWT9_multiple years", keepusing( refyear rgdpe_9 rgdpo_9 pop_9 cgdpe_9 cgdpo_9 xr_9 ngdpo_9 ngdpe_9 ppp_r ppp_c emp_9)
		keep if _merge == 3
	drop _merge 
	
*Rename variables so that we know: This is PWT for refyear 2011
	rename cgdpe_9 cgdp_e9y
	rename cgdpo_9 cgdp_o9y

	rename pop_9 pop_9y
	rename ngdpo_9 ngdp_o9y
	rename ngdpe_9 ngdp_e9y
	rename rgdpe_9 rgdp_e9y
	rename rgdpo_9 rgdp_o9y

	rename xr_9 xr_9y
	rename emp_9 emp_9y

	*generate share of employed
	gen wgt_empind = wgt if employed == 1
	egen tot_wgtemp = total(wgt_empind),
	
	gen sh_emp = tot_wgtemp/tot_wgt
		label variable sh_emp "Share of population employed"
	gen tot_emp_9y = pop_9y*(tot_wgtemp/tot_wgt)
		label variable tot_emp_9y "Total # of persons engaged (based on Micro-Data)"
		
	local incvars inc_hh_pe inc_hh_pa inc_hh_hr rgdp_e9y rgdp_o9y pop_9y cgdp_e9y cgdp_o9y xr_9y ngdp_o9y ngdp_e9y ppp_r ppp_c 
	
*gen per capita variables for reference year 2011
foreach eo in e o {
	*1) Real GDP, reference year
	gen gdppc_`eo'9ry = rgdp_`eo'9y/pop_9y
	gen ln_gdppc_`eo'9ry = ln(gdppc_`eo'9ry)
			
	*2) Current GDP, reference year
	gen gdppc_`eo'9cy = cgdp_`eo'9y/pop_9y
	gen ln_gdppc_`eo'9cy = ln(gdppc_`eo'9cy)
	
	*3) Nominal GDP, reference year
	gen gdppc_`eo'9ny = ngdp_`eo'9y/pop_9y
	gen ln_gdppc_`eo'9ny = ln(gdppc_`eo'9ny)

	*4) Nominal GDP per Employed, reference year
	gen gdppe_`eo'9ny = ngdp_`eo'9y/emp_9y
		label variable gdppe_`eo'9ny "GDP per employed, based on # ind. employed in PWT (emp)"
	gen ln_gdppe_`eo'9ny = ln(gdppe_`eo'9ny)
	
	gen gdppe_`eo'9ny_md = ngdp_`eo'9y/tot_emp_9y
		label variable gdppe_`eo'9ny "GDP per employed, based on share of ind. employed (Micro-Data)"
	gen ln_gdppe_`eo'9ny_md = ln(gdppe_`eo'9ny_md)
	
	gen gdppe_`eo'9ry = rgdp_`eo'9y/emp_9y
		label variable gdppe_`eo'9ry "GDP per employed, based on # ind. employed in PWT (emp)"
	gen ln_gdppe_`eo'9ry = ln(gdppe_`eo'9ry)
	
	local incvars `incvars' gdppc_`eo'9ry gdppc_`eo'9cy gdppc_`eo'9ny gdppe_`eo'9ny gdppe_`eo'9ny_md gdppe_`eo'9ry 
}

*Generate a standard variable: This is in national currency, year 2005 value. 
	//Preferably use income based on monthly (main wj) gross, but if N/A use annual gross, if N/A annual net.

	if 	"`mth_wj_avail'" == "yes" {
		gen inc_wj_yr = m_wj_y							//Use monthly main wage job if available
	}
	if 	"`mth_wj_avail'" == "no" {
		gen inc_wj_yr = a_wj_y							//All countries have either gross or net yearly wj income
	}
	
	gen inc_wj_mth = inc_wj_yr/12
	gen inc_se_mth = a_se_y/12

*Generate household income
	sum a_se_y
	bysort hid: egen inc_se_hh = total(a_se_y),m
	bysort hid: egen inc_wj_hh = total(inc_wj_yr),m

	sum inc_se_hh
	if r(N) == 0 {
		gen inc_hh_yr = hh_income			//This is total disposable HH income before social transfers and benefits
	}
	else {
		egen inc_hh_yr = rowtotal(inc_se_hh inc_wj_hh),m
	}
	gen inc_hh_mth = inc_hh_yr/12
	gen inc_wj_mj_mth = m_wj_y/12
	
*Household income per working adult: Need to know how many employees in household!
	gen indic = 1 if employed == 1
	bysort hid: egen hh_numemp = total(indic),m			//Replace HH income per working adult only for workers

	gen inc_hh_pe = .
	replace inc_hh_pe = inc_hh_mth/hh_numemp if employed == 1
	
*Household income per adult
	bysort hid: gen hhsize_adults = _N
		label variable hhsize_adults "# of adults in Household"
	
	gen inc_hh_pa = .
	replace inc_hh_pa = inc_hh_mth/hhsize_adults
		
*Household hours
	bysort hid: egen hh_hrs = total(hrs),m

	gen hh_hrs_pe = hh_hrs/hh_numemp
		label variable hh_hrs_pe "HH hours per employed"
	gen hh_hrs_pa = hh_hrs/hhsize_adults
		label variable hh_hrs_pa "HH hours per adult"
	gen hh_emp = hh_numemp/hhsize_adults
		label variable hh_emp "Share of employed adults in HH"

*Generating hourly wage rates
	
	*Individual Wage rate
	gen inc_wj_hr = inc_wj_mth/(hrs*52/12)


gen flag_set1 = 0
gen flag_set2 = 0
gen flag_set3 = 0
gen flag_set4 = 0

gen ahrswk_wj_mj = uhrswk_mj*c_fac if emp_type == 3 										//These guys have main wage job
gen ahrswk_wj_aj = ahrswk_wj_mj if (uhrswk_sj == 0 | uhrswk_sj == .) 						//Same as above
*Cannot infer second job work status - thus we do not know what people work on. Yes we can!
replace ahrswk_wj_aj = hrs if (emp_type == 3 & (uhrswk_sj > 0 & uhrswk_sj != .) & (a_se_y == 0 | a_se_y == .)) 	//wk_aj has to be total hours if sj_hrs > 0 but total self-employment income is 0!

*For countries below, we have employee income from all wage jobs
 	//& : These guys have only one main wage job
if 	"`mth_wj_avail'" == "no" {
replace flag_set1 = 1 if  emp_type == 3 & (uhrswk_sj == 0 |  uhrswk_sj == .) & (a_se_y == 0 | a_se_y == .)		//Some guys have no second job hours, but two incomes - kick out of flagset1
replace flag_set2 = 1 if flag_set1 == 1  | (emp_type == 3 & (uhrswk_sj > 0 & uhrswk_sj != .) & (a_se_y == 0 | a_se_y == .)) 									//Cannot identify second job work status
replace flag_set3 = 1 if flag_set2 == 1  | (emp_type == 3 & (uhrswk_sj > 0 & uhrswk_sj != .) & (a_se_y != 0 & a_se_y != .)) | (emp_type == 3 & (uhrswk_sj == 0 |  uhrswk_sj == .) & (a_se_y != 0 & a_se_y != .))										//Since cannot identify second job ws, we don't know total wj hours
}
if 	"`mth_wj_avail'" == "yes" {
replace flag_set1 = 1 if  emp_type == 3 & (uhrswk_sj == 0 |  uhrswk_sj == .)	//These guys have only one job
replace flag_set2 = 1 if flag_set1 == 1  										//Cannot identify second job wage income (mj only)
replace flag_set3 = 1 if flag_set2 == 1  										// What if second job is wj? We don't know income! Thus, no additional ind. coded to set 3... | (emp_type == 3 & (uhrswk_sj > 0 & uhrswk_sj != .) & (a_se_y != 0 & a_se_y != .)) | (emp_type == 3 & (uhrswk_sj == 0 |  uhrswk_sj == .) & (a_se_y != 0 & a_se_y != .))										//Since cannot identify second job ws, we don't know total wj hours
}

*For those with flag_set 2,3 == 1: Generate main job wage rate
gen hr_wage_mj = .
replace hr_wage_mj = inc_wj_mj_mth/(ahrswk_wj_mj*52/12) if flag_set2 == 1 | flag_set3 == 1

gen hrs_wj = .
replace hrs_wj = ahrswk_wj_aj
replace hrs_wj = 112 if hrs_wj > 112 & hrs_wj != .

gen rep_hr_wage = .
	label variable rep_hr_wage "Reported Hourly Wage"
	
*Generate hourly wage rate: For avail. mthly income, divide by main wage job hours	
gen hr_wage = .
if 	"`mth_wj_avail'" == "no" {	
replace hr_wage = inc_wj_mth/(hrs_wj*52/12)
}
if 	"`mth_wj_avail'" == "yes" {	
replace hr_wage = inc_wj_mth/(ahrswk_wj_mj*52/12)
}

label variable hr_wage "Hourly wage: Wage earnings/wage hours"

*Total income & HH wage rates
	gen hr_wage_wjse = .
		label variable hr_wage_wjse "Wage rate based on total individual income/total ind. hours"
	gen hr_wage_hh = .
		label variable hr_wage_hh "Wage rate based on total HH income/total HH hours"
	gen flag_set_nosj = 0
		label variable flag_set_nosj "Country-lvl flag: Only mj incomes are available" 
	gen flag_set_nose = 0
		label variable flag_set_nose "Country-lvl flag: No se incomes available"
	gen flag_set_hhse = 0
		label variable flag_set_hhse "Country-lvl: HH level self-employment income"

*Total individual income for wjse dataset
gen ind_tot_wjse = .
if 	"`mth_wj_avail'" == "yes" {	
	egen tot_mjwj = rowtotal(inc_wj_mth) if flag_set1 == 1						//These guys only have one job, no second job hours
		replace ind_tot_wjse = tot_mjwj
}
if "`mth_wj_avail'" == "no" {
	egen tot_mjwj = rowtotal(a_wj_y) if flag_set1 == 1							//Like above, but we have to use annual wj income from all wj.
		replace ind_tot_wjse = tot_mjwj/12										//Caveat: Some individuals might be aggregating multiple wj incomes
																				//from last year - but we only have main wage job hours
}
*	All others: Sum of annual wj and se income
*	Caveat: We set up total income from wj and se last year, but may not have multiple job hours last week.
	egen tot_wjse = rowtotal(a_wj_y a_se_y)
		replace ind_tot_wjse = tot_wjse/12 if flag_set1 != 1					 

replace hr_wage_wjse = 	ind_tot_wjse/(hrs*52/12)								//hrs is mj_wj hrs for flagset1 == 1, total avail. hours for flagset1 != 1
	
*Household wage rate
gen inc_hh_hr = inc_hh_mth/(hh_hrs*52/12)										//Household wage rate: Monthly income/hours worked in hh per month!
replace hr_wage_hh = inc_hh_mth/(hh_hrs*52/12)
	
*Standardize to same currencies/ppp 
	local incomes  inc_hh_mth inc_hh_pe inc_hh_pa inc_hh_hr inc_wj_mth inc_wj_hr hr_wage rep_hr_wage hr_wage_mj hr_wage_wjse hr_wage_hh
	foreach i in `incomes' {
		gen `i'_pppr = `i' * ppp_r
		gen `i'_pppc = `i' * ppp_c
		gen `i'_usd = `i'/xr_9y
		
		rename `i' `i'_nom
		
		gen `i' = `i'_pppr
		
		local incvars `incvars' `i'_nom `i'_pppr `i'_pppc `i'_usd `i'
	}
	
gen ind = .
gen industry_2 = .
replace industry_2 = 1 if industry == "a+b"
replace industry_2 = 2 if industry == "c+d+e" | industry == "f" 
replace industry_2 = 3 if industry == "g" | industry == "h" | industry == "i" | industry == "j" | industry == "k" | industry == "l" | industry == "m" | industry == "n" | industry == "o+p+q"


replace ind = industry_2

*Generate Age-group dummies
local all_min = 15
local all_max = 99

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98

local non_young_min = 25
local non_young_max = 98

*Andres Age-Groups
local 15_19_min = 15
local 15_19_max = 19

local 20_24_min = 20
local 20_24_max = 24

local 25_29_min = 25
local 25_29_max = 29

local 30_34_min = 30
local 30_34_max = 34

local 35_39_min = 35
local 35_39_max = 39

local 40_44_min = 40
local 40_44_max = 44

local 45_49_min = 45
local 45_49_max = 49

local 50_54_min = 50
local 50_54_max = 54

local 55_59_min = 55
local 55_59_max = 59

local 60_64_min = 60
local 60_64_max = 64

local 65_69_min = 65
local 65_69_max = 69

local 70_74_min = 70
local 70_74_max = 74

local 75_79_min = 75
local 75_79_max = 79

local 80_84_min = 80
local 80_84_max = 84

local 85plus_min = 85
local 85plus_max = 98

local 15_64_min = 15
local 15_64_max = 64

local ages all young prime old non_prime non_young old_56_64 old_65_99 15_64 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 85plus 		/*Add age category also to line 361 363*/
	
foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}

keep hid pid wgt male age employed hrs robustDummy coreDummy age_all-age_85plus edu*  hh_wgt   tot_wgt hhtot_wgt hhtot15plus_wgt `incvars' refyear `gdpvars'  xr_9y ppp_r ppp_c sh_emp tot_emp_9y emp_wj emp_se wgt_emp wgt_ws wgt_wj wgt_se hh_hrs_pe hh_hrs_pa hh_emp c_fac flag_set1-flag_set3 flag_set4 hrs_wj ind hh_hrs hrs_u_aj hrs_u_mj hrs_u flag_set_hhse flag_set_nosj flag_set_nose	// gdppc_e9ry gdppc_e9cy gdppc_o9ry gdppc_o9cy gdppc_e9r gdppc_o9r gdppc_e9c gdppc_o9c gdppc_e9ny gdppc_o9ny gdppe_e9ny gdppe_o9ny//ahrsday_aj-chrsday 

	saveold "Data\Cleaned_data/`c'_silc_all_std.dta", replace version(12)
}

}
 
}	//quiet 
 
 
 *----------------------------------------------------------*
*Count. Exercise: Weights for US Age Composition Table 7 row 2
*----------------------------------------------------------*
use "Data\Cleaned_data/USA_all_std.dta"
local ages all young prime old non_prime old_56_64 old_65_99 15_64 15_19 20_24 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 85plus		/*Add age category also to line 361 363*/
local gender a m f

	foreach a in `ages' {

* Extract and calculate US age group/gender shares for employment rate 
	egen ageshare_er_a_`a' = sum(wgt) if age_`a' == 1
	egen ageshare_er_m_`a' = sum(wgt) if male==1 & age_`a' == 1
	egen ageshare_er_f_`a' = sum(wgt) if male==0 & age_`a' == 1
	
	sum  ageshare_er_a_`a', detail
		replace ageshare_er_a_`a' = r(max)
	sum ageshare_er_m_`a' , detail
		replace ageshare_er_m_`a' = r(max)
	sum ageshare_er_f_`a', detail
		replace ageshare_er_f_`a' = r(max)
		
* Extract and calculate US age group/gender shares for hours worked 
	gen dropped_`a' = 0 if hrs==. | employed!=1

	egen ageshare_hwe_a_`a' = sum(wgt) if age_`a' == 1 &  dropped_`a' != 0
	egen ageshare_hwe_m_`a' = sum(wgt) if male==1 & age_`a' == 1 & dropped_`a' != 0
	egen ageshare_hwe_f_`a' = sum(wgt) if male==0 & age_`a' == 1 & dropped_`a' != 0
	
	sum  ageshare_hwe_a_`a' if  dropped_`a' != 0, detail
		replace ageshare_hwe_a_`a' = r(max)
	sum ageshare_hwe_m_`a' if  dropped_`a' != 0, detail
		replace ageshare_hwe_m_`a' = r(max)
	sum ageshare_hwe_f_`a' if  dropped_`a' != 0, detail
		replace ageshare_hwe_f_`a' = r(max)

	*Generate fractions 	
	if "`a'" != "all" {
		replace ageshare_er_a_`a' = ageshare_er_a_`a'/ageshare_er_a_all
		replace ageshare_er_m_`a' = ageshare_er_m_`a'/ageshare_er_a_all
		replace ageshare_er_f_`a' = ageshare_er_f_`a'/ageshare_er_a_all

		replace ageshare_hwe_a_`a' = ageshare_hwe_a_`a'/ageshare_hwe_a_all
		replace ageshare_hwe_m_`a' = ageshare_hwe_m_`a'/ageshare_hwe_a_all
		replace ageshare_hwe_f_`a' = ageshare_hwe_f_`a'/ageshare_hwe_a_all	
	}
}

keep if _n == 1
keep ageshare_er_a_all-ageshare_hwe_f_85plus 
gen country = "USA"
drop dropped*

saveold "Data\Cleaned_data/USA_weights_merged.dta",replace version(12)

*-------------------------------------------------------------------------------------*
*Count. Exercise: Weights for US Education and industry compositions (Table 7, rows 4 & 7)
*-------------------------------------------------------------------------------------*
use "Data\Cleaned_data/USA_all_std.dta"
local variables edu ind

gen dropped = 0 if hrs==. | employed!=1 

drop if age < 15 | age == .

foreach v in `variables' {
	forvalues a = 1/3 {

	
* Extract and calculate US age group/gender shares for employment rate 
* Extract and calculate US age group/gender shares for hours worked 	
	egen `v'share_er_a_`a' = sum(wgt) if `v' == `a' 
	egen `v'share_hwe_a_`a' = sum(wgt) if `v' == `a' &  dropped != 0
	
	sum  `v'share_hwe_a_`a' if  dropped != 0, detail
		replace `v'share_hwe_a_`a' = r(max)
	sum  `v'share_er_a_`a', detail
		replace `v'share_er_a_`a' = r(max)		
				
}
}

foreach v in `variables' {
	*Generate fractions 	
	egen `v'share_er_a_total = rowtotal(`v'share_er_a_1 `v'share_er_a_2 `v'share_er_a_3), missing
	egen `v'share_hwe_a_total = rowtotal(`v'share_hwe_a_1 `v'share_hwe_a_2 `v'share_hwe_a_3), missing
	
	forvalues a = 1/3 {
		replace `v'share_er_a_`a' = `v'share_er_a_`a'/`v'share_er_a_total
		replace `v'share_hwe_a_`a' = `v'share_hwe_a_`a'/`v'share_hwe_a_total
		
	global variables `v'share_er_a_`a' `v'share_hwe_a_`a'
	}
}

keep if _n == 1
keep edushare_er_a_1-indshare_hwe_a_3
gen country = "USA"

merge 1:1 country using "Data\Cleaned_data/USA_weights_merged.dta" , nogen
saveold "Data\Cleaned_data/USA_weights_merged.dta",replace version(12)

*****************************************************************
***Nonyoung***
*****************************************************************
use "Data\Cleaned_data/USA_all_std.dta"
local variables edu ind

gen dropped = 0 if hrs==. | employed!=1 
*replace dropped = 0 if age<25 | age == .
drop if age < 25 | age == .

foreach v in `variables' {
	forvalues a = 1/3 {

	
* Extract and calculate US age group/gender shares for employment rate 
* Extract and calculate US age group/gender shares for hours worked 	
	egen `v'share_er_a_`a' = sum(wgt) if `v' == `a' 
	egen `v'share_hwe_a_`a' = sum(wgt) if `v' == `a' &  dropped != 0
	
	sum  `v'share_hwe_a_`a' if  dropped != 0, detail
		replace `v'share_hwe_a_`a' = r(max)
	sum  `v'share_er_a_`a' , detail
		replace `v'share_er_a_`a' = r(max)		
			
}
}

foreach v in `variables' {
	*Generate fractions 	
	egen `v'share_er_a_total = rowtotal(`v'share_er_a_1 `v'share_er_a_2 `v'share_er_a_3), missing
	egen `v'share_hwe_a_total = rowtotal(`v'share_hwe_a_1 `v'share_hwe_a_2 `v'share_hwe_a_3), missing
	
	forvalues a = 1/3 {
		replace `v'share_er_a_`a' = `v'share_er_a_`a'/`v'share_er_a_total
		replace `v'share_hwe_a_`a' = `v'share_hwe_a_`a'/`v'share_hwe_a_total
	
	gen `v'share_er_a_`a'_non_young = `v'share_er_a_`a' 
	gen `v'share_hwe_a_`a'_non_young = `v'share_hwe_a_`a'
	
	global variables `v'share_er_a_`a'_non_young `v'share_hwe_a_`a'_non_young
	}
}

keep if _n == 1
keep edushare_er_a_1_non_young-indshare_hwe_a_3_non_young
gen country = "USA"

merge 1:1 country using "Data\Cleaned_data/USA_weights_merged.dta" , nogen


saveold "Data\Cleaned_data/USA_weights_merged.dta",replace version(12)
 
*-------------------------------------------------------------------------------------*
*Count. Exercise: Weights for US Age*Education composition (Table 7, row 5)
*-------------------------------------------------------------------------------------*
 
use "Data\Cleaned_data/USA_all_std.dta", clear
local ages non_young 25_29 30_34 35_39 40_44 45_49 50_54 55_59 60_64 65_69 70_74 75_79 80_84 25_34 35_44 45_54 55_64 65_74 75_84 85plus	/*Add age category also to line 361 363*/
local gender a m f
gen dropped = 0 if hrs==. | employed!=1 
drop if age < 25 | age == .

foreach a in `ages' {
forvalues n = 1/3 {
quiet {
* Extract and calculate US age group/gender shares for employment rate 
	egen ageshare_er_a_`a'_edu`n' = sum(wgt) if age_`a' == 1 & edu == `n'
	sum  ageshare_er_a_`a'_edu`n', detail
		replace ageshare_er_a_`a'_edu`n' = r(max)

* Extract and calculate US age group/gender shares for hours worked 
	egen ageshare_hwe_a_`a'_edu`n' = sum(wgt) if age_`a' == 1 &  dropped != 0 & edu == `n'
	sum  ageshare_hwe_a_`a'_edu`n' if  dropped != 0, detail
		replace ageshare_hwe_a_`a'_edu`n' = r(max)

	*Generate fractions 	
	if "`a'" == "non_young" & `n' == 3 {
	egen ageshare_er_a_non_young = rowtotal(ageshare_er_a_`a'_edu1 ageshare_er_a_`a'_edu2 ageshare_er_a_`a'_edu3),m
	egen ageshare_hwe_a_non_young = rowtotal(ageshare_hwe_a_`a'_edu1 ageshare_hwe_a_`a'_edu2 ageshare_hwe_a_`a'_edu3),m
	}
	if "`a'" != "non_young" {
		replace ageshare_er_a_`a'_edu`n' = ageshare_er_a_`a'_edu`n'/ageshare_er_a_non_young
		replace ageshare_hwe_a_`a'_edu`n' = ageshare_hwe_a_`a'_edu`n'/ageshare_hwe_a_non_young
	}
}	//quiet	
}	//edu		
}	//age

keep if _n == 1
keep ageshare_er_a_non_young_edu1-ageshare_hwe_a_85plus_edu3 
gen country = "USA"
merge 1:1 country using "Data\Cleaned_data/USA_weights_merged.dta" , nogen

saveold "Data\Cleaned_data/USA_weights_merged.dta",replace version(12)
