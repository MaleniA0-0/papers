/* This file writes a number into a latex file or table 
with a pre-specified number of digits and the fonttype (italic, bold etc.) */

local x=10^(-${digit})

if "${var}" == "" {
	$write ("\multicolumn{1}{c}{--}")
}

else{
	$write ("${fonttype}{")

	/*
	$write round($var,`x')
	$write abs(round($var,`x'))
	$write ceil(abs($var))
	*/


	if (round(${var},`x')==int($var)) | ( abs(round($var,`x'))==ceil(abs($var)) ) {
		$write (round($var,`x'))
		$write ("}.${fonttype}{")
		forvalues i=1/$digit{
			$write ("0")
		}
		$write ("}")
	}
	else{
		* Add miuns in front if int(round(var)) is 0 and number is negative
		if int($var)==0 & round($var,`x')<0 $write ("-")
		
		* Integer
		$write (int($var))
		$write ("}.${fonttype}{")

		local z=abs((round(${var},`x')-int($var)))/`x'

		* Add 0 in front

		local imax=${digit}-1
		local icon=${digit}+1 /* Required to avoid numerical rounding errors */
		forvalues i=1/`imax'{
			if (int(`z'*10^(-`i')+10^(-`icon'))==0)  $write ("0")
		}


		* Rounded decimal partz
		$write (`z')
		$write ("}")
	}
}
