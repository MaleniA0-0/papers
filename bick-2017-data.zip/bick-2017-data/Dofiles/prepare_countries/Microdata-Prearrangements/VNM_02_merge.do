*To merge subfiles for Vietnam and generate earnings variables for HH level earnings activities

use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc1", clear

merge 1:1 tinh xa hoso matv using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc3"
rename _merge _merge1

merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\tongcong", keepusing(ngaydt)
rename _merge _merge2

merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\hhexpe02", keepusing(hhsize wt30 totw)
rename _merge _merge3
save "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged", replace

*Paul: Education
use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged.dta" , clear

merge 1:1 tinh xa hoso matv using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc2.dta" 
save "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged.dta", replace

*Leo:
use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc6b1.dta", clear	//Non-food expenditures
collapse(sum) m6b1c4 m6b1c5 , by(tinh xa hoso)
label var m6b1c4 "Daily non-food consumption: How much did you buy last 12 months"
label var m6b1c5 "Daily non-food consumption: How much did you self-make in these months"
merge 1:m tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged.dta" , nogen
save "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged_leo.dta", replace

use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc6a2.dta"		//Food expenditures
collapse(sum) m6a2c6 m6a2c10 , by(tinh xa hoso)
label var m6a2c6 "Daily food consumption: How much did you buy or barter last 12 months"
label var m6a2c10 "Daily food consumption: How much did you make yourself or receive as a gift last 12 months"
merge 1:m tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged_leo.dta" , nogen
save "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged_leo.dta", replace

use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc6a1.dta"		//Holiday food consumption
collapse(sum)  m6a1c3b m6a1c2b , by(tinh xa hoso)
label var m6a1c2b "Holiday food consumption: How much did you buy or barter"
label var m6a1c3b  "Holiday food consumption: How much did you make yourself or receive as a gift"
merge 1:m tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged_leo.dta" , nogen

//Annual expenditures on multitude of categories
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc6b2.dta", keepusing(m6b2cong) nogen 		
//Total income & expenses from agricultural production	
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b2ho.dta", keepusing(m5b24c17 m5b25c17e) nogen 	

//Total income from livestock (last 12 months)
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b31.dta", keepusing(m5b31cong) nogen	
//Total expenditure on livestock (last 12 months)	 
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b32.dta", keepusing(m5b32cong) nogen		
//Income from farm service (last 12 months)	//Added by Paul 
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b4.dta", keepusing( m5b41cong m5b42cong) nogen		
//Total income from aquaculture	(last 12 months)
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b61.dta", keepusing(m5b61cong) nogen	
//Total expenditures on planting and growing aquacultural products (last 12 months) 
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b62.dta", keepusing(m5b62cong) nogen		
//Total income from non-farm, non-forestry and non-aquaculture businesses (last 12 months) //Added by Paul
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5c1.dta", keepusing( m5c1cong) nogen		
//Total expenditures from non-farm, non-forestry and non-aquaculture businesses (last 12 months) //Added by Paul
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5c2.dta", keepusing( m5c2cong) nogen		
//Total income & expenditure on sylvieculture (last 12 months)
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b5.dta", keepusing(m5b51cong m5b52cong) nogen
//Cash & inkind from lending and/or using your land for rent, and Cash & inkind for paid for borrowing and/or using land from others. (last 12 months)	
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5b1.dta", keepusing(m5b1c8_8a m5b1c10) nogen	
																				

save "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged.dta", replace

*Merge with Income Section 
use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged.dta" , clear
drop _merge

*Merge with Section 5A: Income from Salary, wage (last 12 months)
merge 1:1 tinh xa hoso matv using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5a", 
drop if _merge == 2
drop _merge

*Merge with household other income sources (last 12 months)
merge m:1 tinh xa hoso using "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\muc5d.dta", nogen

save "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged.dta", replace







