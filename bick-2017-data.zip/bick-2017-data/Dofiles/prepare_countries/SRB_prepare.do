******************************************************************************************
* Program: SRB_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Serbia
******************************************************************************************

use "Data\Serbia\LSMS 2007\Data\individual", clear
drop if c1_1==3																		/* Drop if individual is in military service */ 

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid=opstina+"-"+popkrug+"-"+dom
replace pid=lice
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=starost

* Gender
replace male=1 if pol==1
replace male=0 if pol==2

*-----------------------------------------

* Weight 
replace wgt=hhweight																/* HH weight */

* Interview dates																	/* Not available */
replace refdatex=0
replace startdate=mdy(5,1,2007)
replace enddate=mdy(6,30,2007)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
/*We do not have usfficient information on schooling: Only up to secondary enrollment, but tertiary enrollment is not given
replace educ=1 if skolovanje_1=1 | skolovanje_2=2 | skolovanje_3=3
replace educ=0 if skolovanje_4=4
*/
gen educlvl=.

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe: Age 15 and above */
replace emp=1 if c1_1==1
replace emp=2 if c1_1==2
replace emp=0 if c1_1==4															/* Did not work in previous week and did not have a job which he is absent from */

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=2 if emp==2 & c1_2==1
replace reason=3 if emp==2 & c1_2==2
replace reason=5 if emp==2 & c1_2==3
replace reason=4 if emp==2 & c1_2==5
replace reason=7 if emp==2 & c1_2==4 | (c1_2>=6 & c1_2<=12)

*-----------------------------------------

* Main job

* Actual hours worked in previous week		
replace ahrswk_mj=c1_10
replace ahrswk_mj=0 if c1_10==. & (emp==0 | emp==2)									/* Replace missing hours with 0 if person did not work last week */

* Actual hours worked in previous month		
replace ahrsmth_mj=c1_11
replace ahrsmth_mj=. if c1_11==999													/* Replace unknown hours with missing */
replace ahrsmth_mj=0 if ahrsmth_mj==. & (emp==0 | emp==2)

*-----------------------------------------

* Sec job

* Actual hours worked in previous week		
replace ahrswk_sj=c1_28a
replace ahrswk_sj=0 if c1_28a==. & (emp==0 | emp==2)								/* Replace missing hours with 0 if person did not work last week */

* Actual hours worked in previous month		
replace ahrsmth_sj=c1_28b
replace ahrsmth_sj=. if c1_28b==999													/* Replace unknown hours with missing */
replace ahrsmth_sj=0 if ahrsmth_sj==. & (emp==0 | emp==2)


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn
local time ahrswk ahrsmth

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if c1_3==4
replace mj_sa=1 if (c1_3==1 |c1_3==2 |c1_3==3 |c1_3==5) & (c1_8_2>=11 &  c1_8_2<=30)
replace mj_sn=1 if (c1_3==1 |c1_3==2 |c1_3==3 |c1_3==5) & (c1_8_2>=50 &  c1_8_2<=990)

replace sj_wj=1 if c1_19==3
replace sj_sa=1 if (c1_19==1 |c1_19==2 |c1_19==4) & (c1_24_2>=11 &  c1_24_2<=30)
replace sj_sn=1 if (c1_19==1 |c1_19==2 |c1_19==4) & (c1_24_2>=50 &  c1_24_2<=990)

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2													
replace chrsx=2

*-----------------------------------------

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
