******************************************************************************************
* Program: IDN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Indonesia
******************************************************************************************
use "Data\Indonesia\Indonesia_Clean_drop\Raw_data\sak2010", clear 
 
* Initialize some variables 
qui do Dofiles/initialize_variables

* Household and personal id not available
*generate own pid
drop pid
gen pid = _n
*-----------------------------------------

* Age
gen age=umur

* Gender
replace male=1 if jk==1
replace male=0 if jk==2

gen hh_link = .
replace hh_link = 1 if hub == 1 //Reference Person
replace hh_link = 2 if hub == 2 //Spouse/Husband
replace hh_link = 3 if hub == 3  | hub == 4 | hub == 5 //child, grand child
replace hh_link = 4 if  hub == 6 //Ascendant (parent, grand parent)
replace hh_link = 98 if  hub == 8 | hub == 9 //Not related
replace hh_link = 99 if  hub ==7  //Others 

*-----------------------------------------

* Weight
replace wgt=weight		//Cluster weight
gen hh_wgt = . //weight

* Interview dates 
replace refdatex=0
replace startdate=mdy(1,1,2010)
replace enddate=mdy(12,31,2010)
format startdate enddate %td

*-----------------------------------------

gen educ=.
replace educ=1 if sek==2
replace educ=0 if sek==1 | sek==3
gen educlvl=.
*educlvl is unclear from questionnaire (cannot say wether mean actually enrolled program or last attained degree)

gen edu = .
replace edu = 1 if inrange(B5P1A,1,5)
replace edu = 2 if inrange(B5P1A,6,8)
replace edu = 3 if inrange(B5P1A,9,11)

******************************************
* Market work
******************************************

* Employment status (market work)													/* Universe for market section: Age 10 and above */
replace emp=0 if B5P2A1==2 & B5P3==2
replace emp=1 if B5P2A1==1
replace emp=2 if B5P2A1==2 & B5P3==1

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2


*Work status
replace emp_wj = 1 if B5P10A==4
replace emp_se = 1 if inrange(B5P10A,1,3)
	replace emp_se = 1 if inrange(B5P10A,5,7)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
*-----------------------------------------

* All jobs

* Actual days worked last week														/* Universe for hours questions: Age 10 and above, and employed */
replace adayswk_aj=B5P6A 
replace adayswk_aj=0 if B5P6A==. & emp==0											/* Replace missing hour with 0 if person is clearly not employed */

* Actual hours worked last week
replace ahrswk_aj=B5P6B
replace ahrswk_aj=0 if B5P6B==. & emp==0

*-----------------------------------------

* Main job

* Actual hours worked last week
replace ahrswk_mj=B5P9
replace ahrswk_mj=0 if B5P9==. & emp==0

*-----------------------------------------

* Hours worked by nature of job
replace ahrswk_wj=ahrswk_mj if B5P10A==4
replace ahrswk_sa=ahrswk_mj if ((B5P10A>=1 & B5P10A<=3) | B5P10A==7) & B5P7>=1111 & B5P7<=3263
replace ahrswk_sn=ahrswk_mj if ((B5P10A>=1 & B5P10A<=3) | B5P10A==7) & B5P7>=5000 & B5P7<=99000
replace ahrswk_sx=ahrswk_mj if ((B5P10A>=1 & B5P10A<=3) | B5P10A==7) & B5P7==99999

replace ahrswk_wj_mj = ahrswk_mj if B5P10A==4									//Primary work is employee
replace ahrswk_wj_aj = ahrswk_mj if B5P10A==4 & B5P16 == 2						//No additional employee jobs, primary work is only work								

*Code those individuals with only one job that is employee
replace flag_set1 = 1 if B5P10A==4 & B5P16 == 2 								//Only one (wage) job: Set 1

*Since we do not have total wage job income, cannot add individuals to set 2 or 3
replace flag_set2 = 1 if flag_set1 == 1
replace flag_set3 = 1 if flag_set2 == 1

*-----------------------------------------

*Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------
gen ind = .
replace ind = 1 if inrange(B5P7,1,05056)
replace ind = 2 if inrange(B5P7,10101,41003)
replace ind = 3 if inrange(B5P7,45100,99000)

*-----------------------------------------
*income  wage job(main job only)
*-----------------------------------------
replace inc_wj_mj_c_n = B5P12A	 //General net salary earned in main work, monthly
replace inc_wj_mj_ik_n = B5P12B	//General net in kind earned in main work, monthly

egen mjtot = rowtotal(inc_wj_mj_c_n inc_wj_mj_ik_n),m
	replace inc_wj_mj_tot_n = mjtot if B5P10A == 4		//Replace only if person has main wage job 
	
replace inc_se_mj_c_n = B5P11A if inrange(B5P10A,1,3)	 //--> For self-employed, freelance worked in agric, non-agric, monthly, net income
replace inc_se_mj_c_n = B5P11A if inrange(B5P10A,5,7)

egen tot_wjse = rowtotal(inc_wj_mj_tot_n inc_se_mj_c_n),m
replace ind_tot_wjse = tot_wjse													//ONLY MAIN JOBS!

/*
*Generate our standard variables for hh income: Not possible since we do not have HH identifiers
bysort hid: egen hh_wj_c = total(inc_wj_mj_net),m
bysort hid: egen hh_wj_ik = total(inc_wj_ik),m
bysort hid: egen hh_se = total(inc_se_mj_net),m

egen var1 = rowtotal(hh_wj_c hh_wj_ik hh_se),m
	replace inc_hh = var1
*/

*bysort B5P10A: sum inc_se_mj_net inc_wj_mj_net inc_wj_ik inc_hh
*order hid pid inc_se_mj_net inc_wj_mj_net inc_wj_ik //hh_wj_c hh_wj_ik hh_se inc_hh
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
