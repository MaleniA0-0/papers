clear all
* To merge subfiles for Tajikistan 2007

*1) Prepare employment subfiles
* Main job
use "Data\Tajikistan\LSMS 2007\Data\r1m5b", clear
replace m5bq7=2 if (hhid==4556 & memid==16 & m5bq5==40)
drop if m5bq7==2 | m5bq7==3	
rename m5bq2 sector_mjx
rename m5bq4 adayswk_mjx
rename m5bq5 ahrswk_mjx
rename m5bq6 wksyr_mjx
save "Data\Tajikistan\LSMS 2007\Data\TJK07_1", replace

* Merge third and sec jobs for 3 obs															/* There are 3 persons who reported a 3rd job. */
use "Data\Tajikistan\LSMS 2007\Data\r1m5b", clear
collapse (sum) ahrswk_3= m5bq5 if m5bq7>=2 & ((hhid==2738 & memid==1) | (hhid==2742 & memid==1) | (hhid==2840 & memid==3) | (hhid==4556 & memid==16)) , by (hhid memid)
save "Data\Tajikistan\LSMS 2007\Data\TJK07_3", replace

* Sec job
use "Data\Tajikistan\LSMS 2007\Data\r1m5b", clear
replace m5bq7=2 if (hhid==4556 & memid==16 & m5bq5==40)
drop if m5bq7==1 | m5bq7==3	
rename m5bq2 sector_sjx
rename m5bq4 adayswk_sjx
rename m5bq5 ahrswk_sjx
rename m5bq6 wksyr_sjx

merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\TJK07_3"
replace ahrswk_sjx=ahrswk_3 if ahrswk_3~=.
drop _merge ahrswk_3
save "Data\Tajikistan\LSMS 2007\Data\TJK07_2", replace

* Merge subfiles for main job and sec jobs
use "Data\Tajikistan\LSMS 2007\Data\TJK07_1", clear
merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\TJK07_2"
drop _merge
save "Data\Tajikistan\LSMS 2007\Data\TJK07_Emp", replace

*2) Drop 2 pairs of duplicates in Female Questionnaire (i.e. 4 obs)
use "Data\Tajikistan\LSMS 2007\Data\women_r1", clear
keep hhid memid fa63_1 fa64_1 fa65_1 fa66_1 fa67_1 fa68_1 fa69_1 fa70_1 fa71_1 fa72_1 fa73_1 fa63_2 fa64_2 fa65_2 fa66_2 fa67_2 fa68_2 fa69_2 fa70_2 fa71_2 fa72_2 fa73_2 fa63_3 fa64_3 fa65_3 fa66_3 fa67_3 fa68_3 fa69_3 fa70_3 fa71_3 fa72_3 fa73_3
duplicates tag hhid memid, generate(duple)
drop if duple>=1
save "Data\Tajikistan\LSMS 2007\Data\TJK07_Wmn", replace

*3) Merge with other files
use "Data\Tajikistan\LSMS 2007\Data\r1m1", clear
keep  hhid memid m1q2 m1q3 m1q5 m1q7
merge m:1 hhid using "Data\Tajikistan\LSMS 2007\Data\r1m0", keepusing (t_family dateday datemont)
drop _merge

merge m:1 hhid using "Data\Tajikistan\LSMS 2007\Data\weights", keepusing (weight popw)
drop _merge

merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\r1m5a", keepusing (m5aq1 m5aq2 m5aq3 m5aq4 m5aq5 m5aq6 m5aq7)
drop _merge

merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\TJK07_Emp"
drop _merge

merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\r1m5c", keepusing (m5cq5 m5cq37)
drop _merge

merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\TJK07_Wmn"
drop _merge

save "Data\Tajikistan\LSMS 2007\Data\TJK_07_merged", replace


* Education
use "Data\Tajikistan\LSMS 2007\Data\TJK_07_merged", clear 

merge 1:1 hhid memid using "Data\Tajikistan\LSMS 2007\Data\r1m3b.dta" 
save "Data\Tajikistan\LSMS 2007\Data\TJK07_merged.dta" , replace
