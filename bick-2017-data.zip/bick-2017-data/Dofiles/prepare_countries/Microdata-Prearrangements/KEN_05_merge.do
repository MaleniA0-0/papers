*Kenya: merge subfiles and code earnings from Household level activities

clear all

*Set path
*cd ""

*Notes: Each cluster (id_clust) contains 10 households (id_hh), then each household contains individuals (b_id)
use "Data\Kenya\KIHBS 2005\Data/Section B Household Member Information.dta", clear

merge m:1 id_clust id_hh using "Data\Kenya\KIHBS 2005\Data/Section A Identification.dta", nogen
			
bysort id_clust id_hh b_id: gen num = _n
tab num
drop if num == 2				//There are twelve individuals who have same pid code - must be mistake
drop num

merge 1:1 id_clust id_hh b_id using "Data\Kenya\KIHBS 2005\Data/Section C education.dta"
drop if _merge == 2
drop _merge

merge 1:1 id_clust id_hh b_id using "Data\Kenya\KIHBS 2005\Data/Section E Employment.dta",
drop if _merge == 2
drop _merge

save "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta", replace

*---------------------
*Agriculture holdings
*---------------------
use "Data\Kenya\KIHBS 2005\Data/Section N Agriculture Holding.dta", clear
gen ag_costrent = n14								//last 12 months
gen ag_costirrig = n18								//cost in last 12 months, irrigation
egen ag_costfert = rowtotal(n22 n25),m				//cost in/- & organic fertilizer last 12 months
egen ag_costinputs = rowtotal( n26_a n26_b n26_c n26_d n26_e n26_f n26_g n26_j n26_h n26_i ),m
egen ag_costother = rowtotal( n27_a n27_b n27_c),m

*Note that one HH might be owing and responding for various parcels!
collapse (sum) ag_costrent ag_costirrig ag_costfert ag_costinputs ag_costother, by(id_clust id_hh )
merge 1:m id_clust id_hh using "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta",nogen
save "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta", replace

*---------------------
*Agriculture output
*---------------------
use "Data\Kenya\KIHBS 2005\Data/Section O Agricultural Output.dta", clear
gen ag_costseeds = o11
gen ag_revoc = 014 * o17
	label variable ag_revoc "value of crop own cons.: units * avg price/unit"
gen ag_revsale = o16
gen ag_costlabour = o26

collapse (sum) ag_costseeds ag_revoc ag_revsale ag_costlabour, by(id_clust id_hh )
merge 1:m id_clust id_hh using "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta",nogen
save "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta", replace

*---------------------
*Livestock
*---------------------
use "Data\Kenya\KIHBS 2005\Data/Section P1 Livestock.dta", clear
gen ls_revsale = p06
gen ls_revoc = p04*p07
gen ls_costdie = p04*p08 
gen ls_costlost = p04 * p09
gen ls_costpurch = p14
gen ls_costlabour = p18
egen ls_costinputs = rowtotal(p19a p19b p19c p19d p19e p19f p19g p19h p19_a p19_b p19_c p19_d p19_e p19_f p19_g   p22a p22b),m
collapse (sum) ls_revsale ls_revoc ls_costdie ls_costlost ls_costpurch ls_costlabour ls_costinputs, by(id_clust id_hh )
merge 1:m id_clust id_hh using "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta",nogen
save "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta", replace


use "Data\Kenya\KIHBS 2005\Data/Section P2.dta", clear
gen ls_revprod = p24_v*12			//value of sold produce, last one month
collapse (sum) ls_revprod, by(id_clust id_hh )
merge 1:m id_clust id_hh using "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta",nogen
save "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta", replace

*---------------------
*Household Enterprise
*---------------------
use "Data\Kenya\KIHBS 2005\Data/Section Q Household Enterprises.dta", clear
gen rev_hhent = q16
egen cost_hhent = rowtotal(q17_1 q17_2 q17_4 q17_5 q17_6 q17_7 q17_8 q17_9),m		//Everything except taxes
collapse (sum) rev_hhent cost_hhent, by(id_clust id_hh )
merge 1:m id_clust id_hh using "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta",nogen

save "Data\Kenya\KIHBS 2005\Data/individuals_merged.dta", replace






