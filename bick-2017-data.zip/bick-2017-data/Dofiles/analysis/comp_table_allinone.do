clear all

use Data/Cleaned_data/repl_master_stats, clear
keep if coreDummy==1

***************
* Age Weights
***************

gen hbase_age=hwp_a_all 
local tbase_age Actual Hours per Adult

rename hwp_a_all_USweights hage
local tage Hypothetical Hours: U.S.\ Age Composition

***************
* Education Weights, 25+
***************

gen hbase_edu=hwp_a_non_young_edu5 
local tbase_edu Actual Hours per Adult (\textit{Ages 25+, Non-miss.\  Educ.})

rename hwp_a_non_young_US_eduwgt hedu
local tedu="Hypothetical Hours (\textit{Ages 25+}): U.S.\ Educ.\ Comp.\ "

gen heduage=hwp_a_non_young_USage_edu
local teduage="Hypothetical Hours (\textit{Ages 25+}): U.S.\ Age \& Educ.\ Comp.\ "

***************
* Sector Weights
***************

gen hbase_ind=hwe_a_all_ind5
local tbase_ind Actual Hours per Worker (\textit{Non-miss.\  Sec.})

rename hwe_a_all_US_indwgt hind
local tind="Hypothetical Hours: U.S.\ Sectoral Comp.\ "

***************
* Loops 
***************
local rs age edu ind 

foreach r in `rs'{

	local vs base_`r' `r'
	if "`r'"=="edu" local vs `vs' eduage
	
	foreach v in `vs'{
		forvalues q=1/3{
			sum h`v' if q_${z}==`q'
			local h`v'`q'=r(mean)
		}
	}
}
	
*#################################################################
* Tex Table Generation - LEVELS
*#################################################################

local ta=" Low "
local tb=" Middle "
local tc=" High "

********************************
* Settings
********************************

global name="tab_comp_${z}"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{lccc}") _n
$write ("\tabularnewline\hline\hline") _n	
$write ("   & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("&   Low  &  Middle    &  High  \\\hline") _n

foreach r in `rs'{

	local vs base_`r' `r'
	if "`r'"=="edu" local vs `vs' eduage
	foreach v in `vs'{
		$write ("`t`v''")
		forvalues q=1/3{
			$write ("&")
			global var `h`v'`q''
			`do1'				
		}
		$write ("\\") _n
		if "`v'"=="hwp" $write ("\hline") _n			
	}
	$write ("\hline") _n
}
*#################################################################
${lastl}
${close}
*#################################################################	
