local if0 
local if1 & coreDummy==1

local n0 all
local n1 core


forvalues i=1/1{

use Data/Cleaned_data/repl_master_stats, clear

keep country countryname year coreDummy gdppc_${z} q_${z} *_a_all

keep if coreDummy!=.

replace country="TMP" if country=="TLS"
*Populatioon share age 15+ from World Development Indicator
merge 1:1 country year using Data/External_data/wdi_pop_share_15plus

replace country="TLS" if country=="TMP"
drop if _merge==2
* For Taiwan we do not have population share data
tab country if _merge==1
replace pop_share_15plus=1-.158 if country=="TAI"
* Table 5, http://eng.stat.gov.tw/public/Data/7113143851PNHSNJPU.pdf

drop if _merge==1
drop _merge

sort gdppc

gen gdppa=gdppc/pop_share_15plus
gen gdppe=gdppa/er
gen gdpph=gdppa/hwp


foreach x in c e a h{
	forvalues q=1/3{
		sum gdpp`x' if q==`q' `if`i''
		local m`x'`q'=r(mean)
	}
	forvalues q=1/3{
		local m`x'`q'=`m`x'`q''/`m`x'3'*100
	}	
	local m`x'4=`m`x'3'/`m`x'1'	
}

*---------------------------------------

local tc Capita
local ta Adult
local te Worker
local th Hour Worked

local xs a e h

*#################################################################
* Development Accounting
*#################################################################


local xs e h

********************************
* Settings
********************************

global name="tab_devacc_`n`i''_${z}_brief"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"	
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{lcccc}") _n
$write ("\tabularnewline\hline\hline") _n
$write (" \;\;  & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("& \;\;  Low \;\; & \;\; Middle \;\;   & \;\; High \;\;  & \;\; High/Low \;\; \\\hline") _n

foreach x in `xs'{
	$write ("GDP per `t`x''")
	forvalues q=1/4{
		$write ("&")
		global var `m`x'`q''
		`do1'
	}
	$write ("\\") _n
}
$write ("\hline") _n
*#################################################################
${lastl}
${close}
*#################################################################	


}
