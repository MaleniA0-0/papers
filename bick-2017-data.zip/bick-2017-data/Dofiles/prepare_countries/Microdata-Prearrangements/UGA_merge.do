
*To merge subfiles and generate variables on earnings from HH level activities

use "Data\Uganda\NPS LSMS 2009\Data\GSEC8", clear
merge m:1 HHID using "Data\Uganda\NPS LSMS 2009\Data\GSEC1", 
tab _merge
drop if _merge==2								/* All these have missing PID (and missing hours) */
drop _merge

merge 1:1 HHID PID using "Data\Uganda\NPS LSMS 2009\Data\GSEC2", 
drop if h2q7==5 | h2q7==6 | h2q7==7	
rename _merge _merge_Xing 

merge 1:1 HHID PID using "Data\Uganda\NPS LSMS 2009\Data\GSEC4.dta" 
count
drop _merge
merge 1:1 HHID PID using "Data\Uganda\NPS LSMS 2009\Data\GSEC3.dta" 
count

save "Data\Uganda\NPS LSMS 2009\Data\GSEC8_merged_test", replace

*Adding section 11 for household income
use "Data\Uganda\NPS LSMS 2009\Data\GSEC11.dta" , clear

gen h11aq05_new = h11aq05
gen h11aq06_new = h11aq06
	replace h11aq05_new = . if (h11aq03 >= 21 & h11aq03 <= 45) 
	replace h11aq06_new = . if (h11aq03 >= 21 & h11aq03 <= 45) 

bysort HHID: egen hh_cash = total(h11aq05_new)
bysort HHID: egen hh_inkind = total(h11aq06_new)
	
	egen HH_income = rowtotal(hh_cash hh_inkind), m
bysort HHID: keep if _n == 1

save "Data\Uganda\NPS LSMS 2009\Data\GSEC11_filtered.dta" , replace


use "Data\Uganda\NPS LSMS 2009\Data\GSEC8_merged_test", clear
merge m:1 HHID using "Data\Uganda\NPS LSMS 2009\Data\GSEC11_filtered.dta" , nogen


save "Data\Uganda\NPS LSMS 2009\Data\GSEC8_11_merged", replace
