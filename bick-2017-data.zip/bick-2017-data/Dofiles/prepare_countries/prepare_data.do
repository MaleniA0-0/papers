************************************************************************************
* Program: prepare_data.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alexander Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Runs a loop over all the individual country prepare DoFiles in order 
* to create cleaned data for each country. 
************************************************************************************

clear all

*Set command directory to the folder containing "replication files"
*cd ""

set more off
set memory 1g

* To facilitate the working process, countries have been saved in locals that 
* already distinguish between a country belonging to the core set or not.
local core  ALB_12 BWA COL ECU_05 GHA_98 IDN IRQ KEN_05 KHM LAO MNG MUS MWI_04 NAM_09 PAK PER RWA TLS_07 TUR TZA UGA USA VNM_02 ZAF_08 AUT BEL BGR CHE CYP CZE DEU DNK ESP EST FIN FRA GBR GRC HUN IRL ITA LTU LVA NLD NOR POL PRT ROM SVK SVN SWE 		               
local non_core  AGO ALB ARG ARM AUS BEN BIH BOL BRA CAN CHL CHN EGY GTM ISL JAM JOR KAZ KGZ KOR LCA LSO LUX MEX MLI MLT MYS NGA NIC NPL PAN PHL PRY RUS SLV SRB TAI TJK_07 TJK_09 TUN URY VEN ZAF ZAF_93
local sets core non_core

foreach set in `sets' {
  foreach country in ``set'' {
	
	display "`country'"
	
	do Dofiles/`country'_prepare

	*********************
	* Generate Covariates
	*********************

	sort hid pid

	gen country="`country'"
	
	* Household Size
	by hid: gen hhsize=_N

	* Number of children aged 5 or younger
	gen ageid=1 if age>=0 & age<=5
	by hid: egen numkids=sum(ageid)
	drop ageid		

	* age=min(actual age, 99)]
	replace age=min(age,99)
	
	
	*********************
	* Done with Covariates
	*********************

	saveold Data/Cleaned_data/`country'_raw, replace version(12)
	
  }
}	

*********************************************************************************
*Run the EU_SILC prepare data DoFile:
do Dofiles/EU_SILC_prepapre
