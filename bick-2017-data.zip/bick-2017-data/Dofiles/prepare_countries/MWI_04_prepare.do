*******************************************************************************************************
* Program: MWI_04_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Malawi IHS (LSMS) 2004
*******************************************************************************************************

use "Data\Malawi\IHS LSMS 2004\Data\MWI_04_Merged", clear 
rename age agex
rename emp empx

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
replace hid= case_id
replace pid= memid
order hid pid
sort hid pid

*-----------------------------------------

* Age
gen age=agex

* Gender
replace male=1 if b03==1
replace male=0 if b03==2

*-----------------------------------------

* Weight
replace wgt=hhwght
gen hh_wgt = hhwght

gen hh_link = .
replace hh_link = 1 if b04 == 1 //Reference Person
replace hh_link = 2 if b04 == 2 //Spouse
replace hh_link = 3 if b04 == 3  | b04 == 4  | b04 == 8 //Child in law, step child, grand child
replace hh_link = 4 if  b04 == 6 | b04 == 10 | b04 == 11 //Ascendant (parent, grand parent)
replace hh_link = 98 if  b04 == 13 | b04 == 14 | b04 == 15 //Not related
replace hh_link = 99 if  b04 == 9 | b04 == 5 | b04 == 12 //Others (brother/sister, newphew/niece)


* Interview dates	
replace refdatex=1
replace refdate=idate
replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)
format refdate %td
*-----------------------------------------
*Schooling
gen educ=.
gen educlvl=.
*The education module (section c) is not available, only one question (c13)
gen edu = .
replace edu = 1 if inrange(c13,1,2)
replace edu = 2 if inrange(c13,3,5)
replace edu = 3 if inrange(c13,6,7)

******************************************
* Market work																		/* Universe: Age 5 and above */
******************************************

* Employment status (market work)
replace emp=1 if e13==1
replace emp=0 if e13==2
replace emp=2 if e13==2 & e14==1

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2 & e15==1
replace reason=3 if emp==2 & e15==2
replace reason=7 if emp==2 & (e15==3 | e15==4 |e15==5)

replace emp_wj = 1 if b21 == 2 
replace emp_se = 1 if inrange(b21, 3,5)
replace emp_wj = 1 if (e11 > 0 & e11 != .) | (e12 > 0 & e12 != .) & emp_wj == .
replace emp_se = 1 if (e08 > 0 & e08 != .) | (e09 > 0 & e09 != .) | (e10 > 0 & e10 != .) & emp_se == .
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .

*-----------------------------------------

* Hours worked by job nature														/* There isn't an unknown or refused to answer category */
local ns e08 e09 e10 e11 e12
foreach n in `ns'{
	gen `n'x=`n'
	replace `n'x=0 if `n'==. & (emp==0 | emp==2)
}

* Actual hours worked in wage jobs in last 7 days 									/* Casual, part-time or ganyu labour, work for a wage, salary, commission, or any payment in kind, excluding ganyu */
egen wj=rowtotal(e11x e12x), missing
replace ahrswk_wj=wj

* Actual hours worked in self-employed non-agri jobs in last 7 days 
egen sn=rowtotal(e09x e10x), missing
replace ahrswk_sn=sn

* Actual hours worked in self-employed agri jobs in last 7 days 	
replace ahrswk_sa=e08x

/*
sum e08x if e08x > 0
sum e09x if e09x > 0
sum e10x if e10x > 0
sum e11x if e11x > 0
sum e12x if e12x > 0
*/
*-----------------------------------------

* All jobs
* Actual hours worked in last 7 days
egen total=rowtotal(ahrswk_wj ahrswk_sn ahrswk_sa), missing
replace ahrswk_aj=total

*We cannot clearly identify those with only one (wage) job from those with multiple wage jobs - nobody in set 1.
*Also, since we only have main wage job income, we cannot classify individuals into sets 2 or 3.
*BUT: We are able to infer usual (monthly) main wage job hours: e23*e24, but still we cannot identify individuals belonging to set 1.


******************************************
* Non-market work																	/* Universe: Age 5 and above */
******************************************

* Actual hours spent on non-market activities yesterday								/* Non-market activities: Collecting water and firewood */
egen nm=rowtotal(e06a e07), missing													/* No explicit question about emp_nm */
replace ahrsday_nm=nm


*Industry
gen ind = .
replace ind = 1 if inrange(e20,111,220)
replace ind = 2 if inrange(e20,311,513)
replace ind = 3 if inrange(e20,611,972)
	
*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2		
replace chrsx=2

*-----------------------------------------
*Income
gen mths_worked = .
replace mths_worked = e22a if e22b == 5									//Monthly units
replace mths_worked = e22a/(52/12) if e22b == 4							//Weekly units 
gen days_mth = e23														//Days per month

*1) Wage income
gen wj_c = .
replace wj_c = e25*1/e26a*days_mth*mths_worked/12 if e26b == 3			//Days --> Daily --> Monthly --> Avg. monthly
replace wj_c = e25/e26a*e22a/12 if e26b == 4 & e22b == 4 				//weeks --> weekly --> yearly --> avg monthly
	replace wj_c = e25*1/e26a*52/12*mths_worked/12 if e26b == 4	& wj_c == .			//Weeks --> Weekly--> Monthly --> Avg. monthly
replace wj_c = e25*1/e26a*mths_worked/12 if e26b == 5					//Months --> Monthly --> Avg monthly

gen wj_ik = .
replace wj_ik = e27*1/e28a*days_mth*mths_worked/12 if e28b == 3
replace wj_ik = e27*1/e28a*52/12*mths_worked/12 if e28b == 4			//Weeks --> Weekly--> Monthly --> Avg. monthly
replace wj_c = e27*1/e28a*mths_worked/12 if e28b == 5					//Months --> Monthly --> Avg monthly

egen wjmj_cik = rowtotal(wj_c wj_ik),m
	replace inc_wj_mj_tot_o = wjmj_cik

*1.2: Ganyu wage income
gen wjganyu_c = e30*e31/12												//Days last 12 months * daily rate / 12 months

egen wj_tot = rowtotal(wj_c wj_ik wjganyu_c),m
	replace inc_wj_aj_tot_o = wj_tot if (wj_c > 0 & wj_c != .) | (wj_ik > 0 & wj_ik != .)						//I code this income only if main job is wage, and that's non-missing

	
*2 Self-employment incomes
*Profit variable is already on the household level - those calculations happen in the prepare dofile.
*For non agricultural enterprises, that's the variable profits

*Profits from agricultural enterprises	
egen agr_rev = rowtotal(p05 q21 s05 t09 u07),m
egen agr_cost = rowtotal(r_crop_c d_crop_c u13 u16 u19),m

gen agr_profits = agr_rev - agr_cost

bysort hid: egen hh_wj = total(wj_tot),m
egen hhinc = rowtotal(hh_wj profits agr_profits),m 
	replace inc_hh = hhinc

	
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ edu ind educlvl `income_vars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
