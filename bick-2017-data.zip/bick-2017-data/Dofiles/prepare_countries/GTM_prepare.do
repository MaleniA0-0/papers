*******************************************************************************************
* Program: GTM_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Guatemala
*******************************************************************************************

use "Data\Guatemala\ENCOVI 2000\Data\GTM_Merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
gen hids=string(hogar)
replace hid=hids
replace pid=caso
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=edad

* Gender
replace male=1 if sexo==1
replace male=0 if sexo==2

*-----------------------------------------

* Weight
replace wgt=factor

* Interview date																	/* Data collection period: Jul 2000 to Nov 30 2000 */
replace refdatex=0
replace startdate=mdy(7,1,2000)	
replace enddate=mdy(11,30,2000)
format startdate enddate %td

*-----------------------------------------
*Schooling
gen educ=.
replace educ=1 if p07b05==1
replace educ=0 if p07b05==2
gen educlvl=.
replace educlvl=1 if p07b06a==4 | p07b06a==5
replace educlvl=0 if p07b06a<=3


******************************************
* Market & non-market work
******************************************

* Employment status																	/* Universe: Age 5 and above */
replace emp=1 if p10a01==1 | p10a02==1
replace emp=2 if p10a01==2 & p10a02==2 & p10a03==1
replace emp=0 if p10a01==2 & p10a02==2 & p10a03==2

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0
replace reason=1 if emp==2

*-----------------------------------------

* Main Job

* Months worked in last 12 months
replace mthsyr_mj=p10b04
replace mthsyr_mj=. if p10b04==99
replace mthsyr_mj=0 if mthsyr_mj==. & (emp==0 | emp==2)

* Days per month worked
replace adaysmth_mj=p10b05
replace adaysmth_mj=. if p10b05==99
replace adaysmth_mj=0 if adaysmth_mj==. & (emp==0 | emp==2)

* Days per week worked
replace adayswk_mj=p10b06
replace adayswk_mj=. if p10b06==9
replace adayswk_mj=0 if adayswk_mj==. & (emp==0 | emp==2)

* Hours worked per week
replace ahrswk_mj=p10b07
replace ahrswk_mj=. if p10b07==999
replace ahrswk_mj=0 if ahrswk_mj==. & (emp==0 | emp==2)

* Hours worked per day
replace ahrsday_mj=p10b08
replace ahrsday_mj=. if p10b08==99
replace ahrsday_mj=0 if ahrsday_mj==. & (emp==0 | emp==2)

*-----------------------------------------

* Sec Job

* Months worked in last 12 months
replace mthsyr_sj=p10c05
replace mthsyr_sj=. if p10c05==99
replace mthsyr_sj=0 if mthsyr_sj==. & (emp==0 | emp==2)

* Days per month worked
replace adaysmth_sj=p10c06
replace adaysmth_sj=. if p10c06==99
replace adaysmth_sj=0 if adaysmth_sj==. & (emp==0 | emp==2)

* Days per week worked
replace adayswk_sj=p10c07
replace adayswk_sj=. if p10c07==9
replace adayswk_sj=0 if adayswk_sj==. & (emp==0 | emp==2)

* Hours worked per week
replace ahrswk_sj=p10c08
replace ahrswk_sj=. if p10c08==999
replace ahrswk_sj=0 if ahrswk_sj==. & (emp==0 | emp==2)

* Hours worked per day
replace ahrsday_sj=p10c09
replace ahrsday_sj=. if p10c09==99
replace ahrsday_sj=0 if ahrsday_sj==. & (emp==0 | emp==2)


******************************************
* Non-market work
******************************************

* Employment status (non-market work)												/* Universe for nm section: Age 7 and above */
egen byte work_nm=anymatch(p09c06a p09c07a), values(1)								/* nm work: Hauling water, collecting firewood yesterday */
replace work_nm=. if (p09c06a~=1 & p09c06a~=2) & (p09c07a~=1 & p09c07a~=2)			/* There are some invalid values e.g. 0 and 5. This code will treat p09c06a or p09c07a=0, 5, 9 and . as missing */
replace emp_nm=0 if work_nm==0
replace emp_nm=1 if work_nm==1

*-----------------------------------------

* Actual time spent on non-market work yesterday
foreach var in p09c06b p09c06c p09c07b p09c07c{ 
	gen `var'x=`var'
	replace `var'x=. if `var'==99
	}

gen p09c06cx_hr=p09c06cx/60															/* Convert from minutes to hours */
gen p09c07cx_hr=p09c07cx/60
egen nmhrs=rowtotal(p09c06bx p09c06cx_hr p09c07bx p09c07cx_hr), missing
replace ahrsday_nm=nmhrs
replace ahrsday_nm=0 if emp_nm==0 & nmhrs==.


******************************************
* Hours worked by job characteristics
******************************************

* Generate indicator for each job nature
local jobs mj sj
local nature wj sa sn sx
local time mthsyr adaysmth adayswk ahrswk ahrsday

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if p10b14>=1 & p10b14<=4											/* Wage job: Employee in government or pte co, day worker, domestic employee */
replace mj_sa=1 if (p10b14>=5 & p10b14<=8) & p10b02==1								/* Self-employed: Owner of company or your own farm, work for yourself or on your farm */
replace mj_sn=1 if (p10b14>=5 & p10b14<=8) & (p10b02>=2 & p10b02<=12)
replace mj_sx=1 if (p10b14>=5 & p10b14<=8) & p10b02>=99

replace sj_wj=1 if p10c12>=1 & p10c12<=4
replace sj_sa=1 if (p10c12>=5 & p10c12<=8) & p10c03==1
replace sj_sn=1 if (p10c12>=5 & p10c12<=8) & (p10c03>=2 & p10c03<=12)
replace sj_sx=1 if (p10c12>=5 & p10c12<=8) & p10c03>=99

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

egen totalsa=rowtotal(ahrsday_sa ahrsday_nm), missing
replace ahrsday_sa=totalsa

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

gen time=.
replace time=p10b33 if p10b33~=999														/* If response is 999, let time remain missing */
replace time=time/60

replace chrsday=time*p10b34*2															/* Total commuting time in a day = time per trip from dwelling to work place * no. of trips from dwelling to work place * 2 (assuming person returns to home in between work) */
replace chrsday=0 if p10b30==11 & time==.												/* Replace missing hours with 0 if person reported as working in his home */

*-----------------------------------------
*Timeuse
local variables p09c02c p09c03c p09c01c p09c04c p09c05c p09c08c p09d01c p09c06c p09c07c
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Data we need: Four categories
	
	recode p09c02b p09c03b p09c01b p09c04b p09c05b p09c08b p09d01b p09c02c p09c03c p09c01c p09c04c p09c05c p09c08c p09d01c(99=.)

	*1) Cooking  (av6)
		*Generate hours of single variables
		gen p_cook = p09c02a
		recode p_cook (2=0)
		egen cook = rowtotal(p09c02b p09c02c_hrs), missing
		replace cook = 0 if p_cook == 0 & cook == .
		replace p_cook = 1 if cook > 0 & cook != . 

		gen p_dish = p09c03a
		recode p_dish (2=0)
		egen dish = rowtotal (p09c03b p09c03c_hrs), missing
		replace dish = 0 if p_dish == 0 & dish == .
		replace p_dish = 1 if dish > 0 & dish != .
		
		*____________________________________________________________________________________*

		gen p_cooking = 1 if (p_cook+p_dish == 1) | (p_cook + p_dish == 2)
		replace p_cooking = 0 if (p_cook + p_dish == 0)
		
		*Sum up hours of selected variables
		egen cooking_day = rowtotal (cook dish)
		replace cooking_day=. if (cook==. & dish ==.)
		gen cooking = cooking_day*7
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (av7)
		*Generate hours of single variables
		gen p_clean = p09c01a
		recode p_clean (2=0)
		egen clean = rowtotal(p09c01b p09c01c_hrs), missing
		replace clean = 0 if p_clean == 0 & clean == .
		replace p_clean = 1 if clean >0 & clean != .
		
		gen p_iron = p09c04a
		recode p_iron (2=0)
		egen iron = rowtotal(p09c04b p09c04c_hrs), missing
		replace iron = 0 if p_iron == 0 & iron == .
		replace p_iron = 1 if iron >0 & iron != .
	
		gen p_garb = p09c05a
		recode p_garb (2=0)
		egen garb = rowtotal(p09c05b p09c05c_hrs), missing
		replace garb = 0 if p_garb == 0 & garb == .
		replace p_garb = 1 if garb >0 & garb != .
	
		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_clean + p_iron + p_garb >=1) & (p_clean + p_iron + p_garb!=.)
		replace p_cleaning = 0 if (p_clean + p_iron + p_garb == 0)
		
		*Sum up hours of selected variables
		egen cleaning_day = rowtotal(clean iron garb)
		replace cleaning_day = . if (clean ==. & iron ==. & garb ==.)
		gen cleaning = cleaning_day*7
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_childcare = p09c08a
		recode p_childcare (2=0)
		
		egen childcare_day = rowtotal(p09c08c_hrs p09c08b), missing
		replace childcare_day = 0 if p_childcare == 0 & childcare_day == .
		gen childcare = childcare_day*7
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = p09d01a
		recode p_goods_services (2=0)
		
		egen goods_services_day = rowtotal(p09d01b p09d01c_hrs), missing	/*Shopping*/
		replace goods_services_day = 0 if p_goods_services == 0 & goods_services_day == .
		gen goods_services = goods_services_day*7
		replace p_goods_services = 1 if  goods_services > 0 & goods_services!=.
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
	
	*5) Collecting water/Firewood
		*Generate single hours for water and firewood
		gen p_water = p09c06a
		recode p_water (2=0)	
		egen water = rowtotal(p09c06b p09c06c_hrs), missing
		replace water = 0 if p_water == 0 & water == .
		replace p_water = 1 if water > 0 & water != .
		
		gen p_wood = p09c07a
		recode p_wood (2=0)
		egen wood = rowtotal(p09c07b p09c07c_hrs), missing
		replace wood = 0 if p_wood == 0 & wood == .
		replace wood = 1 if wood > 0 & wood != .

		*____________________________________________________________________________________*
		
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf_day = rowtotal(water wood)
		replace coll_wf_day = . if (water ==. & wood ==.)
		gen coll_wf = coll_wf_day*7
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
 		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .

		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
		
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
