*Set path:
*cd ""

clear

use "Data/Ecuador\ECV LSMS 2005-2006\Data/e5r_per.dta"
rename factor_f weight
merge m:1 ciudad zona sector vivienda hogar using "Data/Ecuador\ECV LSMS 2005-2006\Data/e5r_viv.dta", keepusing(factor_f) nogen
merge m:1 ciudad zona sector vivienda hogar using "Data/Ecuador\ECV LSMS 2005-2006\Data/e5r_ubi.dta", keepusing(numpers) nogen

save "Data/Ecuador\ECV LSMS 2005-2006\Data/indiv_merged.dta", replace


