* Data from Ramey and Francis, 2009
insheet using Data/External_data/Century_Public_Data.csv, clear
rename v1 year

local gs m f a
local as 14_00 10_13 14_17 18_24 25_54 55_64 65_00

local i=2
foreach g in `gs'{
foreach a in `as'{
	rename v`i' `g'_`a'
	local i=`i'+1
}
}
rename a_14_00 hwp_a_all_r
rename a_25_54 hwp_prime_all_r

keep year hwp*

save Data/External_data/francis_ramey, replace

*****************

* Historical US GDP data
use Data/External_data/us_long_time_series, clear

keep if year<=2005 & year>=1875

keep year GDP
merge 1:1 year using Data/External_data/francis_ramey
drop _merge
gen coreDummy=1
gen us=1

append using "Data/Cleaned_data/repl_master_stats.dta"
keep if coreDummy==1 
replace us=0 if us==.
replace country="USA" if country==""

keep ln_gdppc_${z}  gdppc_${z}  hwp_a_all hwp_prime_all us q_${z} year  refyear country hwp*r GDP t1_${z} t2_${z}

sum gdppc_${z} if refyear==2005 & country=="USA"
local m1=r(mean)
sum GDP if year==2005 & country=="USA"
local m2=r(mean)

replace GDP=GDP*`m1'/`m2'

replace ln_gdppc_${z}=ln(GDP) if ln_gdppc_${z}==.

/* COSTA */

sum GDP ln_gdppc_${z} if year==1895
sum GDP ln_gdppc_${z} if year==1973
sum GDP ln_gdppc_${z} if year==1991

drop if year<1900

forvalues t=1/2{
	sum t`t'_${z}
	local t`t'=r(mean)
}

local v hwp

local rhwp 0(5)50
local thwp Hours per Week

local options=`"scheme(s2mono)  graphregion(color(white) fcolor(white)) legend(region(lcolor(white)))"'

local ms small
local lp dash


local lc gs8
local ms small
sort year
twoway (connect hwp_a_all_r ln_gdppc_${z}  if us==1, mcolor(gs10) msize(v`ms') lcolor(gs10)  xline(`t1', lpattern(dot) lcolor(`lc')) xline(`t2', lpattern(dot) lcolor(`lc')) ) ///
	   (scatter hwp_a_all ln_gdppc_${z}  if us==0, mcolor(black)  msize(`ms') mlab(country) mlabsize(tiny)) ///
	   (scatter hwp_a_all_r ln_gdppc_${z}  if us==1 & (year==1900 | year==1933 ), ///
	   msize(`ms') mcolor(gs10) mlab(year) mlabcolor(gs10) mlabposition(11)) ///
	   (scatter hwp_a_all_r ln_gdppc_${z}  if us==1 & (year==2005 | year==1944), ///
	   msize(`ms') mcolor(gs10) mlab(year) msym(square) mlabcolor(gs10)) ///	   
		, `options' xtitle(ln(GDP per Capita)) ytitle(`t`v'') ylabel(`r`v'', angle(0) grid gmin gmax) xlabel(7(.5)11) ///
	   	legend(label(2 Core Countries) label(1 "U.S. Time-Series (1900-2005)") order(2 1))	
	   	
graph export texinput/us_hwp_a_all_tsy_lab_${z}.pdf, replace 





