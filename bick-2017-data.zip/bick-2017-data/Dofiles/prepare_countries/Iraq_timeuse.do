clear

*cd "C:\Users\Paul\Dropbox (ERC Transitions)\Hours"
use "Data\Iraq\HSES LSMS 2007\Data\time use_2008.dta" 


***************************************************
* Standard Variables:
	*1) Age
		rename q0103 age
	*2) Country
		gen country = "IRQ"
	*3) Gender
		gen male=.
		replace male=1 if q0102==1
		replace male=0 if q0102==2
	*4) Year
		gen year = 2007
	*5) Weight
		gen wgt = weight

*About 1/3 of obs. has only missing variables
drop if age == .
		
*____________Questionnaire number 5, Timeuse____________________________________________________________________________
*Did everybody really see the questionnaire?!

local  variables mactiv6 mactiv5 mactiv7 mactiv16
foreach v in `variables' {
gen `v'_hrs=`v'/60
} 

*Data we need: Four categories
	*1) Cooking  (av6)
		gen cooking = mactiv5_hrs*7					/* (cooking)*/

	*2) Cleaning/Housework (av7)
		gen cleaning = mactiv6_hrs*7 				/*cleaning  */
	
	*3) Childcare (Av11)
		gen childcare = mactiv7_hrs*7
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen goods_services =  mactiv16_hrs*7			/*Shopping*/
	
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services), missing
		gen hrs_hw = .

		gen coll_wf = . 
keep age wgt country male year cooking-hrs_hw coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/IRQ_timeuse.dta", replace


