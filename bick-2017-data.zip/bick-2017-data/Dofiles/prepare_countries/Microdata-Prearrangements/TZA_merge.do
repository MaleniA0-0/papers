*To merge subfiles and set up earnings variables that arise from HH level activities
cd "C:\Users\s6961780\AppData\Local\Dropbox\Dropbox ERC\Dropbox (ERC Transitions)\Hours\Data\Tanzania"

*Merge demographics module to labor module
use "NPS LSMS 2009\Data\TZNPS1HHDTA_E\SEC_B_C_D_E1_F_G1_U", clear

merge m:1 hhid using "NPS LSMS 2009\Data\TZNPS1HHDTA_E\SEC_A_T", keepusing(hh_weight hh_weight_trimmed thhmem sa2q18y sa2q18m)

save "NPS LSMS 2009\Data\Merged\TZA_Merged", replace

********************************************************************************************
*Agriculture/Farmincome dataset (Household level)
use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_3A.dta", clear
collapse(sum) s3aq4 s3aq30 s3aq41 s3aq46 s3aq52 s3aq63_3 s3aq63_6 s3aq63_9 , by(hhid)
label var s3aq4 "plot rent revenues long rain season"
label var s3aq30 "plot rent expenditures long rain season"
label var s3aq41 "organic fertilizer expenditures long rain season"
label var s3aq46 "anorganic fertilitzer expenditures long rain season"
label var s3aq52 "pesticide expenditures long rain season"
label var s3aq63_3 "labor costs 1 long rain season"
label var s3aq63_6 "labor costs 2 long rain season"
label var s3aq63_9 "labor costs 3 long rain season"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_3Aaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_3B.dta", clear
collapse(sum) s3bq4 s3bq30 s3bq41 s3bq46 s3bq52 s3bq63_3 s3bq63_6 s3bq63_9 , by(hhid)
label var s3bq4 "plot rent revenues short rain season"
label var s3bq30 "plot rent expenditures short rain season"
label var s3bq41 "organic fertilizer expenditures short rain season"
label var s3bq46 "anorganic fertilitzer expenditures short rain season"
label var s3bq52 "pesticide expenditures short rain season"
label var s3bq63_3 "labor costs 1 short rain season"
label var s3bq63_6 "labor costs 2 short rain season"
label var s3bq63_9 "labor costs 3 short rain season"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_3Baux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_4A.dta", clear
collapse(sum) s4aq16 s4aq20 , by(hhid)
label var s4aq16 "value of harvested crops long rain season"		//Used for revenues
label var s4aq20 "seed expenditures long rain season"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_4Aaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_4B.dta", clear
collapse(sum) s4bq16 s4bq20 , by(hhid)								
label var s4bq16 "value of harvested crops short rain season"		//used for revenues
label var s4bq20 "seed expenditures short rain season"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_4Baux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_5A.dta", clear
collapse(sum) s5aq17 , by(hhid)
label var s5aq17  "value of lost crops long rain season"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_5Aaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_5B.dta", clear
collapse(sum) s5bq17 , by(hhid)								//Value of lost crop: Per unit or total lost value?!
label var s5bq17 "value of lost crops short rain season"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_5Baux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_7A.dta", clear
collapse(sum) s7aq4, by(hhid)
label var s7aq4 "value of sold fruit"							//Used for revenues
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_7Aaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_7B.dta", clear
collapse(sum) s7bq4 , by(hhid)
label var s7bq4 "value of permanent crops sold (non-fruit)"		//Used for revenues
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_7Baux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_9_ALL.dta", clear
collapse(sum) s9q8 s9q11, by(hhid)
label var s9q8 "total sales of processed agricultural products"	//Also used. Leo, isn't this counting some revenues double?!
label var s9q11 "by-product related expenses"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_9_ALLaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_10A.dta", clear
collapse(sum) s10aq9 s10aq14 s10aq16 s10aq18, by(hhid)
label var s10aq9 "value of alive livestock sales"
label var s10aq14 "value of slaughtered livestock sales"
label var s10aq16 "livestock related labor costs"
label var s10aq18 "fodder costs"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_10Aaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_10B.dta", clear
collapse(sum) s10bq6 , by(hhid)
label var s10bq6 "total sales of livestock byproducts"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_10Baux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_11_ALL.dta", clear
collapse(sum) s11q9 , by(hhid)
label var s11q9 "machine rent expenditures"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_11_ALLaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12A.dta", clear
collapse(sum) s12q9 s12q5 s12q7, by(hhid)
label var s12q5	"proceeds sale of fishing equipment" 
label var s12q7	"purchase costs fishing equipment"
label var s12q9 "repair costs fishing equipment"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12Aaux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12B.dta", clear
collapse(sum)  s12q12 s12q15, by(hhid)
label var s12q12 "days fished per week"
label var s12q15 "amount received per day for sale of fresh fish"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12Baux.dta", replace

use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12D.dta", clear
collapse(sum)    s12q24_q27 s12q25_q28, by(hhid)
label var s12q24_q27 "months with other fishing expenses"
label var s12q25_q28 "other fishing expenses per month"
gen othfishexpd = s12q25_q28 
label var othfishexpd "other fishing expenditures"
save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12Daux.dta", replace


use "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_3Aaux.dta", clear
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_3Baux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_4Aaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_4Baux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_5Aaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_5Baux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_7Aaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_7Baux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_9_ALLaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_10Aaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_10Baux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_11_ALLaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12Aaux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12Baux.dta", nogen
merge 1:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\SEC_12Daux.dta", nogen

egen plotrentrevenue = rowtotal(s3aq4 s3bq4),m
egen plotrentexpd = rowtotal(s3aq30 s3bq30),m
egen croprevenue = rowtotal(s4aq16 s4bq16 s7aq4 s7bq4 s9q8) ,m
egen cropcosts = rowtotal(s3aq41 s3aq46 s3aq52 s3bq41 s3bq46 s3bq52 s3aq63_3 s3aq63_6 s3aq63_9 s3bq63_3 s3bq63_6 s3bq63_9 s4aq20 s4bq20  s5aq17 s5bq17 s9q11),m
egen livestockrevenue = rowtotal(s10aq9 s10aq14 s10bq6),m
egen livestockcosts = rowtotal(s10aq16 s10aq18),m
gen machinecosts = s11q9
gen fishaux = s12q12*s12q15*52
egen fishingrevenue = rowtotal(s12q5 fishaux),m
egen fishingcosts =  rowtotal(s12q9 s12q7 othfishexpd),m

save "NPS LSMS 2009\Data\TZNPS1AGDTA_E\AgriIncome_Paul.dta", replace


use "NPS LSMS 2009\Data\Merged\TZA_Merged.dta", clear

*Consumption from data in year 2011, same households
merge m:1 hhid using "NPS LSMS 2011\TZY1.HH.Consumption.dta", keepusing(expm) nogen

capture noisily drop _merge
merge m:1 hhid using "NPS LSMS 2009\Data\TZNPS1AGDTA_E\AgriIncome.dta"
drop if _merge == 2		//Drop observations that we do not have in our master dataset (12 observations)
drop _merge

save "NPS LSMS 2009\Data\Merged/TZA_Merged", replace

*Section E2
use "NPS LSMS 2009\Data\TZNPS1HHDTA_E/SEC_E2.dta", clear
bysort hhid sememno: gen actnum = _n
keep if actnum == 2
renvars seq24o - seq44o, postfix(_act2)
save "NPS LSMS 2009\Data\TZNPS1HHDTA_E/SEC_E2_act2.dta", replace

use "NPS LSMS 2009\Data\TZNPS1HHDTA_E/SEC_E2.dta", clear
bysort hhid sememno: gen actnum = _n
keep if actnum == 1

merge 1:1 hhid sememno using "NPS LSMS 2009\Data\TZNPS1HHDTA_E/SEC_E2_act2.dta", nogen
save "NPS LSMS 2009\Data\TZNPS1HHDTA_E/SEC_E2_tomerge.dta", replace

use "NPS LSMS 2009\Data\Merged/TZA_Merged", clear
gen sememno = sbmemno	//Need member ID for merging
*drop _merge
merge 1:m hhid sememno using "NPS LSMS 2009\Data\TZNPS1HHDTA_E/SEC_E2_tomerge",  keepusing(seq35_1o seq35_2o seq36_1o seq36_2o seq27o  seq27o_act2 seq35_1o_act2 seq35_2o_act2 seq36_1o_act2 seq36_2o_act2)
drop if _merge == 2 //(Why do we now have 3 observations more than before?!

save "NPS LSMS 2009\Data\Merged/TZA_Merged", replace
