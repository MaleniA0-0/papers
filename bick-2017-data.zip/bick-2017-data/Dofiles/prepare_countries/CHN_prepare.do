******************************************************************************************
* Program: CHN_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for China
******************************************************************************************

use "Data\China\CHNS Cross-sectional\CHNS 2006\Data\c06_merged", clear 

* Initialize some variables 
quietly do Dofiles/initialize_variables

* Generate household and personal id
gen hhids=string(hhid06,"%11.0g")
replace hid=hhids
drop hhids

replace pid=line06
order hid pid
sort hid pid

*-----------------------------------------

* No weights

* Interview date
replace refdatex=1

gen year = int(t7_06/10000)			 									/* Convert from YMD to MDY */							
gen month = int((t7_06-(year*10000))/100)
gen day = int((t7_06-year*10000)-(month*100))
replace refdate = mdy(month,day,year)								
format refdate %td
drop year month day

replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------

* Age 
gen age=a3a 

* Gender
replace male=1 if aa2a==1
replace male=0 if aa2a==2

*-----------------------------------------
gen educ=.
replace educ=1 if a13==1
replace educ=0 if a13==0
*No info on current school level
gen educlvl=.

******************************************
* Market work
******************************************

* Employment status (market work)										/* Universe for market section: Adult>=18, child ages 0 to 17.99 who are not in school */
replace emp=0 if b2==0
replace emp=1 if b2==1

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*-----------------------------------------

* Main Job																/* Universe for hours questions: Those are are presently working */

* Usual hours worked per day 
replace uhrsday_mj=c6 
replace uhrsday_mj=. if c6==-9								 			/* Replace Unknown (-9) hours with missings */
replace uhrsday_mj=0 if c6==. & emp==0									/* Replace with 0 if hours are missing and person is not presently working */									

* Usual days worked per week 
replace udayswk_mj=c5 
replace udayswk_mj=. if c5==9											/* Unknown=9 */
replace udayswk_mj=0 if c5==. & emp==0

* Actual hours worked past week 
replace ahrswk_mj=c7 
replace ahrswk_mj=. if c7==-99 											/* Unknown=-99 */
replace ahrswk_mj=0 if c7==. & emp==0

* Months worked last year
replace mthsyr_mj=c3 
replace mthsyr_mj=. if c3==-9								 			/* Unknown=-9 */
replace mthsyr_mj=0 if c3==. & emp==0

*-----------------------------------------

* Second Job

* Usual hours worked per day 
replace uhrsday_sj=c6a 
replace uhrsday_sj=. if c6a==-9
replace uhrsday_sj=0 if c6a==. & emp==0

* Usual days worked per week 
replace udayswk_sj=c5a 
replace udayswk_sj=. if c5a==9 
replace udayswk_sj=0 if c5a==. & emp==0

* Actual hours worked past week 
replace ahrswk_sj=c7a
replace ahrswk_sj=. if c7a==-99
replace ahrswk_sj=0 if c7a==. & emp==0

* Months worked last year 
replace mthsyr_sj=c3a 
replace mthsyr_sj=. if c3a==-9
replace mthsyr_sj=0 if c3a==. & emp==0


******************************************
* Non-market work
******************************************

* Employment status (non-market work)									/* Universe for nm section: All adults, and children age>=6 */
egen byte work_nm = anymatch(d2a e2a f2a g2a), values(1)				/* Home gardening, HH/collective farming, raising livestock/poultry, fishing last year*/
egen byte rowtotal_nm = rowtotal(d2a e2a f2a g2a), missing
replace work_nm=. if rowtotal_nm==.

replace emp_nm=0 if work_nm==0
replace emp_nm=1 if work_nm==1											/* Implicitly emp_nm=. if work_nm==. */

*-----------------------------------------

* Time spent on non-market work

* Adjust unknown values
local as d3a d3b d3c e4a e4b e4c f4a f4b f4c g4a g4b g4c
foreach a in `as'{
	gen `a'1= `a'
	replace `a'1=. if `a'1==-9
}

* Usual hours worked per day
egen byte nm1=rowtotal(d3c1 e4c1 f4c1 g4c1), missing
replace uhrsday_nm=nm1
replace uhrsday_nm=0 if emp_nm==0 & uhrsday_nm==.

* Usual days worked per week 
egen byte nm2=rowtotal(d3b1 e4b1 f4b1 g4b1), missing
replace udayswk_nm=nm2
replace udayswk_nm=0 if emp_nm==0 & udayswk_nm==.

* Months worked last year 
egen byte nm3=rowtotal(d3a1 e4a1 f4a1 g4a1), missing
replace mthsyr_nm=nm3
replace mthsyr_nm=0 if emp_nm==0 & mthsyr_nm==.

*-----------------------------------------

* Hours worked by job nature  		

* Generate indicator for each job nature
local jobs mj sj
local nature wj sx uc
local time uhrsday udayswk ahrswk mthsyr

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if b5==3 | b5==5
replace mj_sx=1 if b5==1 | b5==2 | b5==4 | b5==6 | b5==7
replace mj_uc=1 if b5==8 | b5==9										/* 8=Other, 9=Unknown */	

replace sj_wj=1 if b10==3 | b10==5
replace sj_sx=1 if b10==1 | b10==2 | b10==4 | b10==6 | b10==7
replace sj_uc=1 if b10==8 | b10==9		

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

* Generate hours in other jobs by job nature
replace uhrsday_sa=uhrsday_nm
replace udayswk_sa=udayswk_nm
replace mthsyr_sa=mthsyr_nm

*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2														/* Both not explicitly included or excluded from work hours */
replace chrsx=2

if c06child==1 {
foreach trpt_ind of numlist 128 1 3 124 325{
	local trpt=`trpt_ind'+1
	replace chrsday= chrsday + u`trpt'_hr + (u`trpt'_mn/60) if chrsday~=. & u`trpt_ind'==1 & u`trpt'_hr>-9 & u`trpt'_hr<. & u`trpt'_mn<99
	replace chrsday= u`trpt'_hr + (u`trpt'_mn/60) if chrsday==. & u`trpt_ind'==1 & u`trpt'_hr>-9 & u`trpt'_hr<. & u`trpt'_mn<99
}
}
else {
foreach trpta_ind of numlist 128 126 124 325{
	local trpta=`trpta_ind'+1
	replace chrsday= chrsday + u`trpta'_hr + (u`trpta'_mn/60) if chrsday~=. & u`trpta_ind'==1 & u`trpta'_hr>-9 & u`trpta'_hr<. & u`trpta'_mn<99
	replace chrsday= u`trpta'_hr + (u`trpta'_mn/60) if chrsday==. & u`trpta_ind'==1 & u`trpta'_hr>-9 & u`trpta'_hr<. & u`trpta'_mn<99
}
}
replace chrsday=0 if chrsday>0 & chrsday<. & emp==0						/* Set hours to 0 for those who have positive commuting hours but are not employed. Helps to remove commuting hours to school, thereby leaving only commuting hours to work */

*-----------------------------------------
*Timeuse
local variables  k3 k5 k7 k7c
foreach v in `variables' {
replace `v'=. if `v'==-99
replace `v'=. if `v'==-88
gen `v'_hrs=`v'/60
} 

	*Documentation page 12/40
	*1) Cooking  (av6)
		gen p_cooking = k4
		replace p_cooking = . if k4==9											/*There are nines in participation status, undefined in questionnaire*/
		gen cooking = k5_hrs*7													/* cooking*/
		replace cooking = 0 if p_cooking == 0 & cookin == .
		replace cooking = . if cooking == -99
		replace p_cooking = 1 if cooking > 0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
		
	*2) Cleaning/Housework (av7)
		gen p_wash = k6
		replace p_wash = . if k6 == 9											/*There are nines in participation status, undefined in questionnaire*/															
		gen wash = k7_hrs*7
		replace wash = 0 if p_wash == 0 & wash == .
		replace wash = . if wash == -99
		replace p_wash = 1 if wash > 0 & wash != .
		
		gen p_clean = k7b
		replace p_clean = . if k7b == 9											/*There are nines in participation status, undefined in questionnaire*/
		gen clean = k7c_hrs*7
		replace clean = 0 if p_clean == 0 & clean == .
		replace clean = . if clean == -99
		replace p_clean = 1 if clean > 0 & clean != .

		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_clean + p_wash >=1) & (p_clean + p_wash != .)
		replace p_cleaning = 0 if (p_clean + p_wash == 0)
		
		egen cleaning = rowtotal(wash clean)								/*laundry and cleaning the house*/
		replace cleaning = . if (clean == . & wash == .)
		replace p_cleaning = 1 if cleaning >0 & cleaning != .
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = k12
		replace p_kid1 = . if k12 == 9											/*There are nines in participation status, undefined in questionnaire*/
		gen kid1 = k13
		replace kid1 = . if kid1 == -99
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		replace p_kid1 = 1 if kid1 > 0 & kid1 != . 
		
		gen p_kid2 = k13b
		replace p_kid2 = . if k13b == 9											/*There are nines in participation status, undefined in questionnaire*/
		gen kid2 = k13c
		replace kid2 = . if kid2==-99
		replace kid2 = 0 if p_kid2 == 0
		replace p_kid2 = 1 if kid2 > 0 & kid2 != .
		
		*____________________________________________________________________________________*
		
		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)

		egen childcare = rowtotal(kid1 kid2)
		replace childcare = . if (kid1 == . & kid2==.)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14)
		gen p_goods_services = k2
		replace p_goods_services = . if k2 == 9									/*There are nines in participation status, undefined in questionnaire*/
		gen goods_services = k3_hrs*7	 										/*going to market*/
		
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace goods_services = . if goods_services == -99
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
		
	*5) Fetching water and firewood
		gen coll_wf = .
		gen p_coll_wf = .
		
	*5) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .
		
		
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx 
