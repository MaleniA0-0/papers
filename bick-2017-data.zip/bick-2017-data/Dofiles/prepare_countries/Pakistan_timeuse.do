clear

use "Data\Pakistan\LFS 2010-11\Data\lfs2010-11.dta" 

***************************************************
* Standard Variables:
	*1) Age	
		rename  Sec4_4_6 age
	*2) Country
		gen country = "PAK"
	*3) Gender
		gen male=.
		replace male=1 if Sec4_4_5==1
		replace male=0 if Sec4_4_5==2
	*4) Year
		gen year = 2011
	*5) Weights
		gen wgt = weights
	
*_______________________________________Questionnaire Page 16/16___________________________________________________
*Questions are asked only to those who declare to do housekeeping, or other reason for not being able to work currently or in the future in Q. 9.14

*Data we need: Four categories
	*1) Cooking  (MTUS av6)
	
		gen p_cooking = Sec10_10_1_xiv_1					/*Generate Participation status*/
		recode p_cooking (2=0) 
		gen cooking = Sec10_10_1_xiv_2 						/* cooking*/
		
		replace cooking = 0 if p_cooking == 0 & cooking == .
		replace p_cooking = 1 if cooking >0 & cooking != .
		replace p_cooking = 0 if cooking == 0 & p_cooking == .
		
	*2) Cleaning/Housework (MTUS av7)
		
		gen p_clean = Sec10_10_1_xiii_1						/*Generate Participation status*/				
		recode p_clean (2=0)
		gen clean = Sec10_10_1_xiii_2
		replace clean = 0 if p_clean == 0 & clean == .
				
		gen p_wash = Sec10_10_1_x_1							/*Generate Participation status*/
		recode p_wash (2=0)
		gen wash = Sec10_10_1_x_2
		replace wash = 0 if p_wash == 0 & wash == .
		
		*____________________________________________________________________________________*

		gen p_cleaning = 1 if (p_wash+p_clean == 1) | (p_wash + p_clean == 2)
		replace p_cleaning = 0 if (p_wash + p_clean == 0)
		
		egen cleaning =  rowtotal(clean wash)  					/*Washing clothes and cleaning the house summed up*/
		replace cleaning = . if (clean ==. & wash ==.)			/*Replace cleaning = missing if both partial hours are missing*/
		replace p_cleaning = 1 if cleaning >0 & cleaning != .	/*Set participation to 1 if hours larger than zero*/		
		replace p_cleaning = 0 if cleaning == 0 & p_cleaning == .
		
	*3) Childcare (Av11)
		gen p_kid1 = Sec10_10_1_xi_1
		recode p_kid1 (2=0)
		gen kid1 = Sec10_10_1_xi_2
		replace kid1 = 0 if p_kid1 == 0 & kid1 == .
		
		gen p_kid2 = Sec10_10_1_xii_1
		recode p_kid2 (2=0)
		gen kid2 = Sec10_10_1_xii_2
		replace kid2 = 0 if p_kid2 == 0 & kid2 == .

		*____________________________________________________________________________________*

		gen p_childcare = 1 if (p_kid1 + p_kid2 == 1) | (p_kid1 + p_kid2 == 2)
		replace p_childcare = 0 if (p_kid1 + p_kid2 == 0)

 		egen childcare =  rowtotal(kid1 kid2)
		replace childcare = . if (kid1==. & kid2 ==.)
		replace p_childcare = 1 if childcare > 0 & childcare != .
		replace p_childcare = 0 if childcare == 0 & p_childcare == .
		
	*4) Purchasing Goods/Services (Av10 + AV14 in MTUS)
		gen p_goods_services = Sec10_10_1_ix_1
		recode p_goods_services (2=0)
	
		gen goods_services = Sec10_10_1_ix_2					/*Shopping food and non food goods, services*/
		replace goods_services = 0 if p_goods_services == 0 & goods_services == .
		replace p_goods_services = 1 if goods_services > 0 & goods_services != .
		replace p_goods_services = 0 if goods_services == 0 & p_goods_services == .
	
	*5) Fetching water and firewood
		gen p_water = Sec10_10_1_vii_1
		recode p_water (2=0)
		gen water = Sec10_10_1_vii_2
		replace water = 0 if p_water == 0 & water == .
		
		gen p_wood = Sec10_10_1_vi_1
		recode p_wood (2=0)
		gen wood = Sec10_10_1_vi_2
		replace wood = 0 if p_wood == 0 & wood == .
		
		*____________________________________________________________________________________*
		
		gen p_coll_wf = 1 if (p_water + p_wood == 1) | (p_water + p_wood == 2)
		replace p_coll_wf = 0 if (p_water + p_wood == 0)
		
		egen coll_wf = rowtotal(water wood)
		replace coll_wf = . if (water ==. & wood ==.)
		replace p_coll_wf = 1 if coll_wf > 0 & coll_wf != .
		replace p_coll_wf = 0 if coll_wf == 0 & p_coll_wf == .
	
	*6) Sum of four variables
		*egen hrs_hw = rowtotal(cooking cleaning childcare goods_services), missing
		*egen hrs_hw = rowtotal(cooking cleaning goods_services coll_wf), missing
		gen hrs_hw = .

keep age country male year wgt cooking cleaning childcare goods_services coll_wf hrs_hw p_cooking p_cleaning p_childcare p_goods_services p_coll_wf

local all_min = 15
local all_max = 98

local young_min = 15
local young_max = 24

local prime_min = 25
local prime_max = 55

local non_prime_min = 56			/*Reversed for the loop*/
local non_prime_max = 24			

local old_min = 56
local old_max = 98

local old_56_64_min = 56		/*Added ages for break down of old age group: Old_1 = 56-64, old_2 = 65+*/
local old_56_64_max = 64

local old_65_99_min = 65
local old_65_99_max = 98


local ages all young prime old non_prime 

foreach a in `ages' {
	gen age_`a'	= 0
	if "`a'" == "non_prime" {
		replace age_`a' = 1 if age >= 56 | age <= 24 
	}
	else {
		replace age_`a' = 1 if age >= ``a'_min' & age <= ``a'_max' 
	}
}


save "Data/Cleaned_data/PAK_timeuse.dta", replace

