clear all

local xcorec "keep if coreDummy==1"
local xallc

local np0 
local np1 _p

forvalues p=1/1{
foreach x in corec{
	
	use Data/Cleaned_data/repl_master_stats,replace

	* Core vs all countries
	`x`x''
	
	* Variables
	local vs hwp // er hwe 
	local gs a f m 
	local as all // young prime old non_old 15_64
	
	local thwp Average Hours
	local thwe `thwp'
	local ter  Employment Rates
		
	foreach v in `vs'{
	
		foreach g in `gs'{
			
			foreach a in `as'{
				if "`v'"=="er"{
					replace `v'_`g'_`a'=`v'_`g'_`a'*100
				}		
				forvalues q=1/3{
					sum `v'_`g'_`a' if q_${z}==`q'		
					local `v'_`g'_`a'_`q'=r(mean)
				}
			}
		}	
		
		
		*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		* Gender tables
		*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
		foreach a in `as'{
					
			local ra All
			local rf Women
			local rm Men
			
			*#################################################################
			* Tex Table Generation
			*#################################################################
		
			********************************
			* Settings
			********************************
		
			global name="tab_`v'_`a'_`x'`np`p''_${z}"
			global write="file write ${name}"
			global nextl=`"${write} ("\\") _n"'
			global lastl=`"${write} ("\end{tabular}")"'
			global close="file close ${name}"
		
			local do1="do Dofiles/analysis/dcol"	
			global fonttype /* ="\textit" */
			global digit 1
		
			file open ${name} using texinput/${name}.tex, write replace
		
			***************************************************************
			* Start table
			***************************************************************
		
			$write ("\begin{tabular}{lccc}") _n
			if `p'==0 $write ("\multicolumn{4}{c}{`t`v'' by Sex and Country Income}")
			$write ("\tabularnewline\hline\hline") _n		
			$write ("Sex \;\;\;  & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
			$write ("&  \;\;\; Low \;\;\; & \;\;\; Middle \;\;\; \;\;\;  & \;\;\; High \;\;\; \\\hline") _n
		
			foreach g in `gs'{
				$write ("`r`g''")
				forvalues q=1/3{
					$write ("&")
					global var ``v'_`g'_`a'_`q''
					`do1'
				}
				$write ("\\") _n
				if "`g'"=="a" $write ("\hline") _n			
			}
			$write ("\hline") _n
			*#################################################################
			${lastl}
			${close}
			*#################################################################		
		
		}
	}
} // core vs all countries
}
