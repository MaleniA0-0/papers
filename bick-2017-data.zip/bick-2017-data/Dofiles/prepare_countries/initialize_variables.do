* IDs
gen hid=""  										/* household id */
gen pid=.											/* person id */

* Hours worked by all, main and second job
local types a u										/* hours: actual, usual */
local refs  day wk mth yr							/* reference period: day, week, month, year */
local jobs  a m s									/* jobs: all, main, second */

foreach t in `types'{
foreach j in `jobs'{
	foreach r in `refs'{
		gen `t'hrs`r'_`j'j=.
	}
	gen `t'dayswk_`j'j=.
	gen `t'daysmth_`j'j=.
}
}


* Weeks worked per month, weeks/months worked in year and overtime hours per week by all, main and second job
foreach j in `jobs'{
	gen wksmth_`j'j=.
	gen wksyr_`j'j=.
	gen mthsyr_`j'j=.
	gen ohrswk_`j'j=.
}

gen ahrswk_wj_mj = .
gen ahrswk_wj_aj = .

* Flags for income analysis
gen flag_set1 = 0
	label variable flag_set1 "Individual has one job only"
gen flag_set2 = 0
	label variable flag_set2 "(1) + multiple wage jobs, no self-employment act."
gen flag_set3 = 0
	label variable flag_set3 "(2) + self-employment activities"
gen rep_hr_wage = .	
	label variable rep_hr_wage "Reported Hourly Wage"
	
* Hours worked in non-market work
gen ahrswk_nm=.
gen ahrsday_nm=.
gen uhrsday_nm=.
gen uhrsyr_nm=.
gen udayswk_nm=.
gen mthsyr_nm=.

* Hours worked by nature of job
local nature wj sn sa sx uc							/* nature of job: wage job, self-employed in non-agricultural work, self-employed in agricultural work, self-employed non-classified, unclassified */

foreach t in `types'{
foreach n in `nature'{
	foreach r in `refs'{
		gen `t'hrs`r'_`n'=.
	}
	gen `t'dayswk_`n'=.
	gen `t'daysmth_`n'=.
}
}

* Weeks/Months worked in year and overtime hours per week by nature of job
foreach n in `nature'{
	gen wksmth_`n'=.
	gen wksyr_`n'=.
	gen mthsyr_`n'=.
	gen ohrswk_`n'=.
}

* Commuting and meal hours
gen mealhrsx=. 										/* indicates whether meals hours and communting hours are explicitly included or excluded from the survey question */
gen chrsx=.

label def mealhrsx 0 excl 1 incl 2 "not stated"
label values mealhrsx mealhrsx
label def chrsx 0 excl 1 incl 2 "not stated"
label values chrsx chrsx

gen chrsday=.										/* commuting hours per day, do not differentiate by type of job */

* Employment status
gen emp=.
label def emp 0 "not employed" 1 "employed & working" 2 "employed & not working"
label values emp emp
label variable emp "employment status (market)"

gen emp_nm=.
label def emp_nm 0 "not employed" 1 employed
label values emp_nm emp_nm
label variable emp_nm "employment status (non-market)"

gen emp_wj = .
	label variable emp_wj "Work status in main job: Employee/Wage job earner"
gen emp_se = .
	label variable emp_se "Work status in main job: Self-Employed/Business Owner"

* Reason for being economically inactive
gen reason=.
label def reason 0 "N.A." 1 "don't know" 2 "vacation/public hol" 3 "sick" 4 "strike" 5 "maternity" 6 "childcare" 7 "Others"
label values reason reason
label variable reason "reason economically inactive"

* Interview date
gen startdate=.
gen enddate=.

local ts day week month year date 
foreach t in `ts'{
	gen ref`t'=.
}

gen refdatex=.										/* indicates whether the refdate is the actual date of interview or an externally given date */
label def refdatex 0 "external" 1 "actual"
label values refdatex refdatex
label variable refdatex "type of ref date"

* Weight
gen wgt=.

* Gender
gen male=.
label def male 0 female 1 male
label values male male

*---------------------------------*
***Income variables***
*---------------------------------*
local jobform wj se
	local wj wage job
	local se Self-employment job
local jobs mj aj
	local mj main 
	local aj all 
local tax g n o
	local g gross
	local n net
	local o other tax,
local payment c ik tot
	local c cash
	local ik inkind
	local tot inkind+cash/unspecified 

local income_vars inc_hh emp_wj emp_se ahrswk_wj_mj ahrswk_wj_aj  flag_set1 flag_set2 flag_set3	rep_hr_wage	ind_tot_wj ind_tot_se ind_tot_wjse commuting //se_hrs_flag
foreach jf in `jobform' {
	foreach j in `jobs' {
		foreach p in `payment' {
			foreach t in `tax' {
				gen inc_`jf'_`j'_`p'_`t' = .
				label variable inc_`jf'_`j'_`p'_`t' "``t'' ``j'' ``jf'' , ``p''"
				
				local income_vars `income_vars' inc_`jf'_`j'_`p'_`t'
			}
		}
	}
}
gen inc_hh = .
	label variable inc_hh "HH income: Total of individual employed & self-employed income"

	gen ind_tot_wj = .
	gen ind_tot_se = .
	gen ind_tot_wjse = .
	
gen commuting = .	
	
