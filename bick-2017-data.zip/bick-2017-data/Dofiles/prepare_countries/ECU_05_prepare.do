******************************************************************************************
* Program: ECU_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Ecuador
******************************************************************************************
 
use "Data/Ecuador\ECV LSMS 2005-2006\Data/indiv_merged.dta", clear 

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
drop hid
gen hhid = ciudad + zona + sector + vivienda + hogar
gen hid = hhid
*destring hhid, gen(hid)
replace pid=persona
order hid pid
sort hid pid

*-----------------------------------------

* Age 
gen age=edad

* Gender
replace male=1 if sexo==1
replace male=0 if sexo==2

gen hh_link = .
replace hh_link = 1 if  pd04 == 1 //Reference Person
replace hh_link = 2 if  pd04 == 2 //Spouse/Husband
replace hh_link = 3 if  pd04 == 3  |  pd04 == 4 |  pd04 == 5 //child, grand child
replace hh_link = 4 if   pd04 == 6 | pd04 == 7 //Ascendant (parent, grand parent, parent in law)
replace hh_link = 98 if  pd04 == 11 | pd04 == 12 //Not related
replace hh_link = 99 if   pd04 == 8 | pd04 ==9 | pd04 == 10  //Others 

*-----------------------------------------

* Weight
replace wgt=weight 			//This is household weight
gen hh_wgt = weight

* Interview date
decode fase_mes, generate(fase_mes_num)
gen year = substr(fase_mes_num, -4,.)
	destring year, replace
gen month = substr(fase_mes_num,1,3)
replace month = "Apr" if month == "Abr"
replace month = "Aug" if month == "Ago"
replace month = "Dec" if month == "Dic"
replace month = "Jan" if month == "Ene"

//Did not find another way of doing this
	replace refmonth = 1 if month == "Jan"
	replace refmonth = 2 if month == "Feb"
	replace refmonth = 3 if month == "Mar"
	replace refmonth = 4 if month == "Apr"
	replace refmonth = 5 if month == "May"
	replace refmonth = 6 if month == "Jun"
	replace refmonth = 7 if month == "Jul"
	replace refmonth = 8 if month == "Aug"
	replace refmonth = 9 if month == "Sep"
	replace refmonth = 10 if month == "Oct"
	replace refmonth = 11 if month == "Nov"
	replace refmonth = 12 if month == "Dec"

replace refdatex=0
replace refday=dow(refdate)
replace refweek=week(refdate)
replace refyear=year(year)

*-----------------------------------------

gen educ=. 
gen educlvl=.

gen edu = .
replace edu =1 if inrange(pe45,1,4)
replace edu =2 if inrange(pe45,5,6)
replace edu =3 if inrange(pe45,7,9)

******************************************
* Market work
******************************************

* Employment status (market work)									/* Universe: Age 10 and above */
replace emp=1 if pa01 == 1											//Worked last week?
replace emp=0 if pa01==2									
replace emp=1 if pa01==2 & pa02 == 1
replace emp = 2 if emp == 0 & pa03 == 1								//Did not work last week, but has job to return to

* Reason for being economically inactive
replace reason=0 if emp==0 | emp==1

*Work status
gen indic_mjwj = 1 if pa21 ==1 | pa21 ==2 | pa21 ==3 | pa21 ==8 | pa21 ==9 | pa21 ==14
replace indic_mjwj = 0 if inrange(pa21,4,7)
replace indic_mjwj = 0 if inrange(pa21,10,13)
gen indic_sjwj = .
replace indic_sjwj = 0 if inrange(pa55,4,7)
replace indic_sjwj = 0 if inrange(pa55,10,13)
replace indic_sjwj = 1 if pa55 == 1 | pa55 ==2 | pa55 == 3 | pa55 ==8 | pa55 ==9 | pa55 == 14

replace emp_wj = 1 if indic_mjwj == 1
replace emp_se = 1 if indic_mjwj == 0
replace emp_se = 1 if inrange(pa21,10,13)
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* Actual hours worked last week (all job)							/* Hours worked last week or the last week you worked before you became unemployed */
*1)	Main job
	*Actual days & hours per day worked last week
	replace  adayswk_mj = pa18
	replace ahrsday_mj = pa19
	replace ahrswk_mj = pa18*pa19

*2) Second Job
	*Actual days & hours per day worked last week
	replace  adayswk_sj = pa52
	replace ahrsday_sj = pa53
	replace ahrswk_sj = pa52*pa53
	
*3) All jobs
replace ahrswk_aj = pa66
	*egen hrs = rowtotal(ahrswk_mj ahrswk_sj), m
	*	replace ahrswk_aj = hrs
		*drop hrs
		
*-----------------------------------------

* Hours worked by job nature							
local time mj sj //ahrswk_sj
local mj pa21
local sj pa55

foreach t in `time' {
	gen `t'_wj=ahrswk_`t' if inrange(``t'',1,3) 
		replace `t'_wj= ahrswk_`t' if inrange(``t'',8,9)
		replace `t'_wj= ahrswk_`t' if  ``t'' == 14

	
	gen `t'_sa= ahrswk_`t' if inrange(``t'',10,13)
	gen `t'_sn= ahrswk_`t' if inrange(``t'',4,7) 
}

egen wj_aj = rowtotal(mj_wj sj_wj),m
	replace ahrswk_wj = wj_aj
egen sa_aj = rowtotal(mj_sa sj_sa),m
	replace ahrswk_sa = sa_aj
egen sn_aj = rowtotal(mj_sn sj_sn),m
	replace ahrswk_sn = sn_aj

egen hrs = rowtotal(ahrswk_mj ahrswk_sj),m	
	

replace ahrswk_wj_mj = ahrswk_mj if indic_mjwj == 1											//Main wage job hours
replace ahrswk_wj_aj = ahrswk_wj_mj if pa47a == 2											//No other job
replace ahrswk_wj_aj = ahrswk_wj_mj if (pa47a == 1 & (indic_sjwj == 0 | indic_sjwj == .)) 	//Has another job, but not wj or missing work status
replace ahrswk_wj_aj = hrs if (pa47a == 1 & indic_sjwj == 1) & indic_mjwj == 1				//Replace allwj hrs to total hrs if sj is wage & mj is wage
	*--> Has other job, but that's employee activity
	
replace flag_set1 = 1 if pa47a == 2	& indic_mjwj == 1										 //Only one (main) wage job	
replace flag_set2 = 1 if flag_set1 == 1 | (pa47a == 1 & indic_mjwj == 1 & indic_sjwj == 1)	 //Additional wage jobs on top of main wage job
replace flag_set3 = 1 if flag_set2 == 1 | (pa47a == 1 & indic_mjwj == 1 & indic_sjwj == 0)	 //Addtional se on top of mj wj

gen diff1 = ahrswk_wj_mj - hrs
gen diff2 = ahrswk_wj_aj - hrs
sum diff1 if flag_set1 == 1
sum diff2 if flag_set2 == 1
sum diff2 if flag_set3 == 1
	
*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2
replace chrsx=2

*-----------------------------------------
gen ind = .		//To be checked by David					//Supposedly CIIU Rev 3.1 Classification
replace ind = 1 if inrange(pa15,110,502)
replace ind = 2 if inrange(pa15,1110,4390)
replace ind = 3 if inrange(pa15,4510,9600)

*-----------------------------------------
*Income
*-----------------------------------------
*1) Wage income, main job
*New try!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
egen wj_mjc = rowtotal(pa35  pa38b pa39b pa41b),m						//Monthly in cash plus extra hours, commission, value of housing
egen wj_mjc_add = rowtotal(pa28b pa30b pa30d pa36b ),m					//Bonus payments, christmas, 13th salary etc: Yearly!
	replace wj_mjc_add = wj_mjc_add/12

gen ik_ail = .
replace ik_ail = pa40b*pa18*52/12 if pa40c == 1
replace ik_ail = pa40b*52/12 if pa40c == 2
replace ik_ail = pa40b*26/12 if pa40c == 3
replace ik_ail = pa40b if pa40c == 4	
replace ik_ail = ik_ail*12 												//To get yearly for the next aggr. step

gen ik_clo = .
replace ik_clo = pa42b*pa42c											//Yearly

gen ik_tra = pa43b*12													//Monthly

egen wj_mjik = rowtotal(pa30f ik_ail ik_clo ik_tra),m
	replace inc_wj_mj_ik_g = wj_mjik/12

egen wj_mjcash = rowtotal(wj_mjc wj_mjc_add),m
	replace inc_wj_mj_tot_g = wj_mjcash

gen wj_jope = .
replace wj_jope = pa23a*pa18*52/12 if pa23b == 1
replace wj_jope = pa23a*52/12 if pa23b == 2
replace wj_jope = pa23a*26/12 if pa23b == 3
replace wj_jope = pa23a if pa23b == 4
replace wj_jope = pa23a/3 if pa23b == 5
replace wj_jope = pa23a/6 if pa23b == 6
replace wj_jope = pa23a/12 if pa23b == 7
replace inc_wj_mj_tot_g = wj_jope if pa21 == 3	
	
egen wj_mjtot = rowtotal(wj_mjcash wj_mjik wj_jope),m  
	replace inc_wj_mj_tot_g = wj_mjtot if indic_mjwj == 1			//Replace if main wage job 
	
	
*Wage job second job
egen wj_sjc = rowtotal(pa58  pa61b),m
gen wj_sjbon = pa59b/12
gen wj_sjik = pa62b

gen wj_sjope = .
replace wj_sjope = pa57a*pa52*52/12 if pa57b == 1 & pa55 == 3	
replace wj_sjope = pa57a*52/12 if pa57b == 2 & pa55 == 3	
replace wj_sjope = pa57a*26/12 if pa57b == 3 & pa55 == 3	
replace wj_sjope = pa57a if pa57b == 4 & pa55 == 3	
replace wj_sjope = pa57a/3 if pa57b == 5 & pa55 == 3	
replace wj_sjope = pa57a/6 if pa57b == 6 & pa55 == 3	
replace wj_sjope = pa57a/12 if pa57b == 7 & pa55 == 3

egen wj_sjtot = rowtotal(wj_sjc wj_sjbon wj_sjik wj_sjope),m
egen wj_allj = rowtotal(wj_mjtot wj_sjtot),m	
	replace inc_wj_aj_tot_g = wj_allj if indic_mjwj == 1			//Replace if main wage job

	
*2) *Self employment income, main & second job: Standardization to average monthly does not work, too many 00 in months worked
gen se_mj = .
gen se_sj = .
local se_mj pa22
local se_sj pa56 

foreach inc in se_mj se_sj {
	replace `inc' = ``inc''a * ``inc''b * ``inc''c/12			//Amount * periodicity*#of time received per year --> down to monthly  
}


replace inc_se_mj_tot_n = se_mj if inrange(pa21,4,7)						//Replace only if self employment job
replace inc_se_mj_tot_n = se_mj if inrange(pa21,10,13)
gen inc_se_sj_tot_n = se_sj if inrange( pa55,4,7)						//Replace only if self employment job
replace inc_se_sj_tot_n = se_sj if inrange( pa55,10,13)

egen se_aj = rowtotal(inc_se_mj_tot_n inc_se_sj_tot_n),m	
	replace inc_se_aj_tot_n = se_aj
	

*Total individual income
egen tot_wjse = rowtotal(wj_allj se_aj),m	
	replace ind_tot_wjse = tot_wjse
	
*Household income
bysort hid: egen hh_wj = total(wj_allj),m	
bysort hid: egen hh_se = total(se_aj),m

egen hhinc = rowtotal(hh_wj hh_se),m
	replace inc_hh = hhinc
	
sum inc_wj_mj_tot_g inc_wj_aj_tot_g inc_se_mj_tot_n inc_se_aj_tot_n ind_tot_wjse inc_hh
	
* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_wgt `incvars'
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx

/*
*Old income codes
gen wj_mj = .
replace wj_mj = pa23a*adayswk_mj*52/12*pa16b/12 if pa23b == 1		//Daily-->Weekly-->Monthly-->avg. monthly
replace wj_mj = pa23a*52/12*pa16b/12 if pa23b == 2					//Weekly --> monthly-->avg. monthly
replace wj_mj = pa23a*26/12*pa16b/12 if pa23b == 3					//Biweekly-->avg. monthly
replace wj_mj = pa23a*pa16b/12 if pa23b == 4						//Monthly-->avg. monthly
replace wj_mj = pa23a/3*pa16b/12 if pa23b == 5						//Quarterly-->avg. monthly
replace wj_mj = pa23a/6*pa16b/12 if pa23b == 6						//Half year-->avg. monthly
replace wj_mj = pa23a/12*pa16b/12 if pa23b == 7						//Yearly-->avg. monthly

replace inc_wj_mj_tot_o = wj_mj if inlist(pa21,1,3)					//Replace if wage job
replace inc_wj_mj_tot_o = wj_mj if inlist(pa21,8,9)
replace inc_wj_mj_tot_o = wj_mj if pa21 == 14

*Self employment income, main job
gen se_mj = .
replace se_mj = pa22a *adayswk_mj*52/12*pa16b/12 if pa22b == 1			//Daily-->Weekly-->Monthly-->avg. monthly
replace se_mj = pa22a * 52/12 *pa16b/12 if pa22b == 2					//Weekly --> monthly-->avg. monthly
replace se_mj = pa22a *26/12*pa16b/12 if pa22b == 3						//Biweekly-->avg. monthly
replace se_mj = pa22a*pa16b/12  if pa22b == 4							//Monthly-->avg. monthly
replace se_mj = pa22a /3 *pa16b/12 if pa22b == 5						//Quarterly-->avg. monthly
replace se_mj = pa22a /6 *pa16b/12 if pa22b == 6						//Half year-->avg. monthly
replace se_mj = pa22a /12 *pa16b/12 if pa22b == 7						//Yearly-->avg. monthly

replace inc_se_mj_tot_n = se_mj if inlist(pa21,4,7)						//Replace only if self employment job
replace inc_se_mj_tot_n = se_mj if inlist(pa21,10,13)	
*/
