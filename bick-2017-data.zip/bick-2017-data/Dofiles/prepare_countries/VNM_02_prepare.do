******************************************************************************************
* Program: VNM_02_prepare.do
* Project: "Distribution of Hours Worked Around the World"
* By: Alex Bick, Nicola Fuchs-Schuendeln, David Lagakos, Ang Xing Yi
* Purpose: Constructs harmonized individual employment and hours worked data for Vietnam
******************************************************************************************

use "Data\Vietnam\VHLSS_Other Years\VHLSS_2002\Data\hhold\VNM_02_Merged", clear

* Initialize some variables 
qui do Dofiles/initialize_variables

* Generate household and personal id
local vs tinh xa hoso
foreach v in `vs'{
	gen `v's=string(`v')
}

replace hid=tinhs+"-"+xas+"-"+hosos

foreach v in `vs'{
	drop `v's
}

replace pid=matv 
order hid pid
sort hid pid

gen hh_link = .
replace hh_link = 1 if  m1c3 == 1 //Reference Person
replace hh_link = 2 if  m1c3 == 2 //Spouse/Husband
replace hh_link = 3 if  m1c3 == 3  |  m1c3 == 4 | m1c3 ==8 //child, grand child
replace hh_link = 4 if   m1c3 == 5 | m1c3 ==7 //Ascendant (parent, grand parent, parent in law)
*replace hh_link = 98 if  h2q4 == 9 | h2q4 == 10 | h2q4 == 96  //Not related
replace hh_link = 99 if   m1c3 == 6 | m1c3 ==9  //Others 

*-----------------------------------------

* Age 
gen age=m1c5

* Gender
replace male=1 if m1c2==1
replace male=0 if m1c2==2

*-----------------------------------------

* Weight
replace wgt=wt30
gen hh_wgt = totw	//wt30?!

* Interview date
replace refdatex=1
replace refdate=ngaydt
replace refday=dow(refdate)
replace refweek=week(refdate)
replace refmonth=month(refdate)
replace refyear=year(refdate)

*-----------------------------------------

*Schooling
gen educ=.
replace educ=1 if m2c4==1
replace educ=0 if m2c4==2
gen educlvl=.
*No info on current level of schooling

gen edu = .
replace edu = 1 if inrange(m2c3,0,2)
replace edu = 2 if inrange(m2c3,3,5)
replace edu = 3 if inrange(m2c3,6,9)

******************************************
* Market work
******************************************

* Employment status (market work)											/* Universe for market section: Age 10 and above */
replace emp=0 if m3c2==2						
replace emp=1 if m3c2==1													/* Worked for wage or salary, self-emp in agri/forestry/aquaculture or self-emp in non-agri production */
replace emp=2 if m3c2==1 & m3c3==0											/* Added by Paul: To account for employed but did not work previous week*/			

* Reason for being economically inactive
replace reason=0 if emp==1 | emp==0

*Work status
replace emp_wj = 1 if inrange(m3c8,1,9)
replace emp_se = 1 if m3c8 == 0
	replace emp_wj = 0 if emp_se == 1 & emp_wj == .
	replace emp_se = 0 if emp_wj == 1 & emp_se == .
	
*-----------------------------------------

* All jobs

* Actual hours worked in last 7 days
replace ahrswk_aj=m3c3
replace ahrswk_aj=0 if m3c3==. & emp==0										/* Replace missing hour with 0 if person is not employed */

*-----------------------------------------

* Main Job

* Months worked in last 12 months
replace mthsyr_mj=m3c9
replace mthsyr_mj=0 if m3c9==. & emp==0

* Usual days worked per week 
replace udaysmth_mj=m3c10
replace udaysmth_mj=0 if m3c10==. & emp==0

* Usual hours worked per day 
replace uhrsday_mj=m3c11
replace uhrsday_mj=0 if m3c11==. & emp==0

*-----------------------------------------

* Sec Job

* Months worked in last 12 months
replace mthsyr_sj=m3c13
replace mthsyr_sj=0 if m3c13==. & emp==0

* Usual days worked per month
replace udaysmth_sj=m3c14
replace udaysmth_sj=0 if m3c14==. & emp==0

* Usual hours worked per day 
replace uhrsday_sj=m3c15  
replace uhrsday_sj=0 if m3c15==. & emp==0

*-----------------------------------------

* Hours worked by job nature

* Generate indicator for each job nature: ONLY FOR MONTHS; DAYS; HRS/Day
local jobs mj
local nature wj sa sn sx uc
local time mthsyr udaysmth uhrsday

foreach j in `jobs'{ 
	foreach n in `nature'{ 
	gen `j'_`n'=0
	}
}

replace mj_wj=1 if m3c8>=1 & m3c8<=9
replace mj_sa=1 if m3c8==0 & m3c7<=5
replace mj_sn=1 if m3c8==0 & m3c7>5 & m3c7<=99								/* 99 is not unknown. It is a valid job category. */	
replace mj_sx=1 if m3c8==0 & m3c7==.
replace mj_uc=1 if m3c8==.

* Generate hours worked by job nature 
foreach t in `time'{
	foreach j in `jobs'{
		foreach n in `nature'{
		replace `t'_`n'= `t'_`n' + `t'_`j' if `t'_`n'~=. &`j'_`n'==1 & `t'_`j'~=. 
		replace `t'_`n'= `t'_`j' if `t'_`n'==. &`j'_`n'==1 & `t'_`j'~=. 
		}
	}
}

*Person who has only one job and is employee: That's his only one wage job! For multiple jobs, 
*we do not know for sure if aj_hrs are really only employee - so don't code yet!
replace ahrswk_wj_mj = ahrswk_aj if emp_wj == 1 & (m3c12 == 2)					//These guys had only one job which was wage. Note: m5c8 could also be used, but is contradictory to m3c12 - do not use!
replace ahrswk_wj_aj = ahrswk_aj if emp_wj == 1 & m3c12 == 2					//Same as above

replace flag_set1 = 1 if emp_wj == 1 & m3c12 == 2					
replace flag_set2 = 1 if flag_set1 == 1
replace flag_set3 = 1 if flag_set2 == 1
*-----------------------------------------

* Commuting and meal hours
replace mealhrsx=2															/* Not stated */													
replace chrsx=2

*-----------------------------------------

gen ind = .
replace ind = 1 if inrange(m3c7,1,5)
replace ind = 2 if inrange(m3c7,10,41)
replace ind = 3 if inrange(m3c7,45,99)

*replace ind = 1 if m3c7 == 1 | m2c7 == 2
*replace ind if inrange(m3c7,100,500)  

*-----------------------------------------
*Income: Wage job
*-----------------------------------------
*1) Income from salary/wagejob
	egen inc_wjmj = rowtotal( m5ac6 m5ac7a m5ac7d ),m			//last 12 months: salary, new year & holidays, others, 
		replace inc_wj_mj_tot_o = inc_wjmj/12 if emp_wj == 1	//Main job is paid employee
		replace inc_wj_mj_tot_o = . if m3c8 == 0				//Eventhough question supposedly asked only to salary and wage earners, we still have self employed incomes in there. 
																//Then, replace income to missing:

	egen inc_wjaj = rowtotal(inc_wjmj m5ac9),m		//All wage jobs, see Section 5A, Q8 & 9: salary from other wage jobs
		replace inc_wj_aj_tot_o = inc_wjaj/12 if emp_wj == 1
		replace inc_wj_aj_tot_o = . if m3c8 == 0				//Eventhough question supposedly asked only to salary and wage earners, we still have self employed incomes in there. 
		
*-----------------------------------------
*2) Household income from farming and other income sources (last 12 months)
*-----------------------------------------
	*2.1) HH income from farming
		egen farmrevenue = rowtotal(m5b24c17 m5b31cong  m5b41cong m5b61cong m5b51cong m5b1c8_8a),m
		egen farmcosts = rowtotal(m5b25c17e m5b32cong m5b42cong m5b62cong m5b52cong m5b1c10),m
		gen  inc_se_a =  (farmrevenue - farmcosts)/12 	//Farm income measure	
		
	*2.2) HH income from non-farm, non-forestry and non-aquaculture (last 12 months)
		gen inc_se_na =  (m5c1cong - m5c2cong)/12
		
	*2.3) HH other income sources: We do not use capital income &/or transfer, remittances!
		*gen hh_inc_other =  m5d1cong
		
*3) Our standard variables
	bysort hid: egen hh_wj = total(inc_wjaj)				//Bring wage income to hh_level
	replace hh_wj = hh_wj/12
	
	egen hh_tot = rowtotal(hh_wj inc_se_na inc_se_a ),m		//Generate household income
		replace inc_hh = hh_tot	

*Incomes are given in thousands dong, so need to multiply by this value
foreach v in inc_wj_mj_tot_o inc_wj_aj_tot_o inc_se_a inc_se_na inc_hh {
	replace `v' = `v' * 1000
}
		
*Checking what things look like:
*order hid pid hh_link m5ac6 inc_wj_mj_tot_o inc_wj_aj_tot_o hh_wj inc_se_a inc_se_na inc_hh
*sum inc_wj_mj_tot_o inc_wj_aj_tot_o hh_wj inc_se_a inc_se_na inc_hh

*Back to sets 1-3: If aj_wj income = mj_wj income, then other jobs are se!
replace flag_set3 = 1 if flag_set2 == 1 | (emp_wj == 1 & m3c12 == 1 & inc_wj_aj_tot_o == inc_wj_mj_tot_o)
replace ahrswk_wj_aj = ahrswk_wj_mj if (emp_wj == 1 & m3c12 == 1 & inc_wj_aj_tot_o == inc_wj_mj_tot_o)					//Same as above

**************************************
*Consumption and farm production
**************************************
egen expd = rowtotal(m6a1c3b m6a1c2b m6b1c4 m6b1c5 m6a2c6 m6a2c10 m6b2cong) ,m //Calculation of expenditure measure

**************************************

* Keep standardized variables
keep hid pid ahrsday_aj-age educ educlvl edu ind hh_link hh_wgt expd `income_vars' 
order hid pid male age wgt startdate-refdatex emp reason emp_nm mealhrsx chrsx
