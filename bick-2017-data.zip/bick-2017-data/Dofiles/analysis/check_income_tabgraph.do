*--------------------------------------------------------------------------*
*Figure A.3 in Online Appendix 
*--------------------------------------------------------------------------*
clear all
use "Data/Cleaned_data/GDPPC_vs_MInc.dta", clear
gen gdppc_e9pppry = gdppc_e9ry
gen gdppe_e9pppry = gdppe_e9ry

foreach p in pppr usd {
rename m_wj_mth_`p' m_wj_yr_`p'

gen frac_wj_yr_`p' = m_wj_yr_`p'/gdppe_e9`p'y	
	*replace frac_wj_aj_`p' = m_wj_mj_`p'/gdppe_e9`p'y if frac_wj_aj_`p' == .

gen frac_hh_pe_`p' = m_hh_pe_`p'/gdppe_e9`p'y

	foreach var in wj_yr hh_pe {
		sum frac_`var'_`p'
		if r(N) != 0 {
		correlate frac_`var'_`p' gdppe_e9`p'y
			local c_`var'_gdppe_`p' = r(rho)
		
		correlate frac_`var'_`p' gdppc_e9`p'y
			local c_`var'_gdppc_`p' = r(rho)
		}
		if r(N) == 0 {
			local c_`var'_gdppe_`p' = .
			local c_`var'_gdppc_`p' = .
		}
	}	//corr loop
}	//usd/pppr loop


*--------------------------------------------------------------------------*
**Graphical depiction of fractions
*--------------------------------------------------------------------------*
gen ln_gdppc_e9ry = ln(gdppc_e9ry)
replace frac_wj_yr_pppr = frac_wj_yr_pppr
replace frac_hh_pe_pppr = frac_hh_pe_pppr

local options1 =`" scheme(s2mono) legend(off) graphregion(color(white) fcolor(white)) legend(region(lcolor(white))) ytitle("Fraction Wage Job Income/GDPPE") xtitle("ln(GDP per Capita)")"'
local legend legend( on order(1 "Wage Earnings" 2 "Wages plus Self-Employment Earnings") symy(*5) symx(*5))
local options1hh =`" scheme(s2mono)  graphregion(color(white) fcolor(white)) `legend' legend(region(lcolor(white))) ytitle("Income per Worker/GDP per Worker") xtitle("ln(GDP per Capita)")"'
local options2 msize(medlarge) mlab(country) mlabcolor(gs0) mcolor(gs0) mlabpos(3) msymbol(x) ylabel(0(0.1)1.3, angle(0)) xlabel(7(0.5)11) //aspectratio(1)
local options2hh msize(medlarge) mlab(country) mlabcolor(gs8) mcolor(gs8) mlabpos(3) msymbol(x) ylabel(0(0.1)1.3, gmin gmax angle(0)) xlabel(7(0.5)11) //aspectratio(1)

forvalues t=1/2{
	sum t`t'_e9ry
	local t`t'=r(mean)
}
local line_options xline(`t1', lpattern(dot) lcolor(gs8)) xline(`t2', lpattern(dot) lcolor(gs8))


graph twoway (scatter frac_wj_yr_pppr ln_gdppc_e9ry , `options2'), `options1' `line_options' 
graph export "texinput/sh_wj_GDPPE.pdf", as(pdf) replace

graph twoway (scatter frac_wj_yr_pppr ln_gdppc_e9ry ,  `options2')	///
			 (scatter frac_hh_pe_pppr ln_gdppc_e9ry ,  `options2hh'),	///													///
			`options1hh' `line_options'  
graph export "texinput/sh_wjhh_GDPPE.pdf", as(pdf) replace
			

	
	
	
	
	
	
	
	


