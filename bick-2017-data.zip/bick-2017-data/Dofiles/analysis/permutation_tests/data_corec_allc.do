quiet{

local category 12 23 13
local vs hwp // er hwe
local gs a // m f
local as all // young prime old

********** Permutation tests between adjacent quartiles **********

foreach c in `category' {
foreach v in `vs' {
foreach g in `gs' {
foreach a in `as' {
forvalues x=1/3{

use Data/Cleaned_data/repl_master_stats, clear
drop p
if `x'==1 keep if coreDummy==1
if `x'==2 keep if robustDummy==2 

if `c'==12 {
keep if q_${z}==1 | q_${z}==2
local ql=1
local qh=2
}

if `c'==23 {
keep if q_${z}==2 | q_${z}==3
local ql=2
local qh=3
}

if `c'==13 {
keep if q_${z}==1 | q_${z}==3
local ql=1
local qh=3
}

gen v="`v'"
gen g="`g'"
gen a="`a'"
gen x=`x'
gen ql=`ql'
gen qh=`qh'

permute `v'_`g'_`a' avg_hrs=r(mean), nodrop nodots reps(${reps}): summarize `v'_`g'_`a' if q_${z}==`ql'

matrix rp=r(p)
gen p=rp[1,1] 

sum `v'_`g'_`a' if q_${z}==`ql'
gen d=round(r(mean),.1)

sum `v'_`g'_`a' if q_${z}==`qh'
replace d=d-round(r(mean),.1) 
if "`v'"=="er" replace d=d*100 

keep if _n==1
keep v g a x ql qh p d
save Data/ptest_`v'`g'`a'`x'`c', replace

}
}
}
}
}

clear
foreach c in `category' {
foreach v in `vs' {
foreach g in `gs' {
foreach a in `as' {
forvalues x=1/3{
	append using Data/ptest_`v'`g'`a'`x'`c'
}
}
}
}
}

save Data/ptest_corec_allc, replace
}
