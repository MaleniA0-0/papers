clear all

use data/simplified_wj_world_data, clear

keep if flag_set5==1
keep country hwe_a_all q sh_wj_emp sh_mwj_ws_hr_all sh_na_emp sh_wj_ws hm_n unit_wgt

sort country
tab country, gen(zid)
by country:	gen n=_n
count if n==1
local N=r(N)

gen hwe_wj=.
forvalues n=1/`N'{
	sum hm_n [aweight=unit_wgt] if zid`n'==1
	replace hwe_wj=r(mean) if zid`n' & n==1
}

keep if n==1

replace sh_mwj_ws_hr_all=0 if sh_mwj_ws_hr_all==.

local ss wj_emp mwj_ws_hr_all na_emp wj_ws
foreach s in `ss'{
	replace sh_`s'=sh_`s'*100
}

rename sh_mwj_ws_hr_all  sh_na_wj

sort q

local vs hwe_a_all hwe_wj sh_wj_emp sh_na_emp sh_na_wj
foreach v in `vs'{
	forvalues q=1/3{
		sum `v' if q==`q'
		local `v'`q'=r(mean)
	}
}

local thwe_a_all Hours per Worker: All Workers
local thwe_wj    Hours per Worker: Wage Workers (\textit{Non-Missing Wages})
local tsh_wj_emp  Share of Wage Workers (in \%)
local tsh_na_emp  Share of Workers w/ Missing Status (in \%)
local tsh_na_wj   Share of Wage Workers w/ Missing Wage (in \%)


*#################################################################
* Tex Table Generation
*#################################################################

********************************
* Settings
********************************

global name="overview_table_wj"
global write="file write ${name}"
global nextl=`"${write} ("\\") _n"'
global lastl=`"${write} ("\end{tabular}")"'
global close="file close ${name}"

local do1="do Dofiles/analysis/dcol"	
global fonttype /* ="\textit" */
global digit 1

file open ${name} using texinput/${name}.tex, write replace

***************************************************************
* Start table
***************************************************************

$write ("\begin{tabular}{lccc}") _n
$write ("\tabularnewline\hline\hline") _n
$write ("   & \multicolumn{3}{c}{Country Income Group}\tabularnewline") _n
$write ("&   Low  &  Middle    &  High  \\\hline") _n

foreach v in `vs'{
	$write ("`t`v''")
	forvalues q=1/3{
		$write ("&")
		global var ``v'`q''
		`do1'
	}
	$write ("\\") _n
	if "`v'"=="hwe_wj" $write ("\hline") _n
}
$write ("\hline") _n
*#################################################################
${lastl}
${close}
*#################################################################	


list country hwe_a_all hwe_wj sh_na_emp sh_na_wj if q==1












